# Guided Workflow artwork

The three `*-pro.png` files are bundled local artwork used by the Guided Workflow chooser. Keep this folder in release packages; no network connection is used.

Generated with OpenAI image generation on 2026-09-29 from the approved window concept. Illustrative astrophotography, not scientific observation data. Titles, descriptions, routing and buttons are native PJSR controls. The official InNova header logo remains the existing guided-compass asset.
