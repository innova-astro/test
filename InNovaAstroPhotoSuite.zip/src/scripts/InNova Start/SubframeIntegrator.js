#feature-id InNovaSubframeIntegrator : InNova Astro Photo Suite > InNova Subframe Review and Integration
#feature-icon InNovaStartIcon.svg
#feature-info Independent subframe review and integration. Closes when finished.
#engine v8
#define INNOVA_START_PUBLIC_WRAPPER
#define INNOVA_START_NATIVE_TEST
#include "InNovaStart.js"

function InNovaSubframeStandaloneMain()
{
   if (!MiraRequireCompatiblePixInsight("InNova Subframe Review & Integration")) return;
   _0x76b548f683();
   console.hide();


   let review = StartRunSubframeReview(false);
   if (review && review.cleanupDirectory && review.cleanupDirectory.length > 0) {
      try { StartSubframeRemoveTemporaryDirectory(review.cleanupDirectory); }
      catch (error) { console.warningln("Subframe temporary cleanup failed: " + error); }
   }
}
#iflt __PI_VERSION__ 01.09.04

#else
InNovaDiagnosticRun("Subframe standalone", InNovaSubframeStandaloneMain);
#endif
