#feature-id InNovaReviewCrop : InNova Astro Photo Suite > InNova Review and Crop
#feature-icon InNovaStartIcon.svg
#feature-info Independent image review, crop and astrometry.
#engine v8
#define INNOVA_START_PUBLIC_WRAPPER
#define INNOVA_START_NATIVE_TEST
#include "InNovaStart.js"

function InNovaReviewCropStandaloneMain()
{
   if (!MiraRequireCompatiblePixInsight("InNova Review & Crop")) return;
   _0x76b548f683();
   console.hide();
   let dialog = new InNovaStartDialog(false, true);
   dialog.windowTitle = InNovaTr("InNova Review & Crop — ") + InNovaStartVersion;
   for (;;) {
      dialog.runPreparationRequested = false;
      dialog.execute();
      if (!dialog.runPreparationRequested) break;
      dialog.runPreparationRequested = false;
      dialog.performRunPreparation();
      if (dialog.preparationFinished || dialog.processorDirectLaunchRequested) break;
   }


   if (dialog.processorDirectLaunchRequested)
      StartLaunchInNovaIntegrator(dialog.processorReturnSourceId || "", true, false);
   console.hide();
}
#iflt __PI_VERSION__ 01.09.04
#else
InNovaDiagnosticRun("Review & Crop standalone", InNovaReviewCropStandaloneMain);
#endif
