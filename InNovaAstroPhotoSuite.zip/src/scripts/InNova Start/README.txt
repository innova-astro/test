InNova Start — startup window (build 0079)

The menu command is InNova START. The logo and five entry choices appear
before image preparation. Guided Workflow begins at Step 1: Prepare Images;
InNova START opens the preparation tools directly and ends with Finish,
leaving results open without sending images or opening another module.
Guided Workflow retains image selection and handoff to Astro Processor. Astro
Processor (current Integrator), Adaptive Stretch and Photo Editor (current
Editor) each open independently from their own button. Their internal renaming
will follow separately. Exit closes Start.

INNOVA GET STARTED
============

Current version: v.0.1.build.0079

InNova Start is the preparation module for multi-night and multi-exposure
deep-sky HDR projects. This first development build implements the safe front
half of the proposed workflow:

1. Load FITS, XISF, TIFF and camera RAW images or discover images already open
in PixInsight. The RAW selector covers the major Canon, Nikon, Sony,
   Fujifilm, Olympus/OM System, Panasonic, Pentax, Leica, Hasselblad, Phase One,
   Sigma, Kodak and other manufacturer extensions supported by PixInsight.
   Loading reports a live stopwatch and preserves the final elapsed time.
2. Read exposure, filter, camera, dimensions and channel metadata.
3. Diagnose whether the selection is a single image, a single-night set, a
   multi-night integration set, a multi-channel project or an HDR exposure
   series.
4. Estimate image quality and automatically select a reference.
   The reference is chosen from the dominant image geometry, preventing an
   isolated mask or unrelated frame from becoming the reference merely because
   it has high contrast.
5. Preflight the reference star field. References with fewer than three
   detected stars switch directly to Sun/Moon preparation as a normal workflow
   adjustment, avoiding an alarming StarAlignment error for bright targets.
6. Register non-reference images with StarAlignment when a stellar field is
   available.
7. Create a registered copy of the reference so every source follows the same
   non-destructive workflow.
8. Detect the largest rectangular region with common data in every registered
   image, with a configurable safety margin.
9. Draw the retained crop rectangle directly over the image when a custom crop
   is preferred.
10. Apply exactly the same crop to newly generated copies.
11. Inspect registered and cropped copies in the built-in quick-stretch image
    viewer without modifying their linear pixel data.

Analyze and registration are executed by one Run button. Its English tooltip
describes every operation performed by the button.

Multi-night and HDR groups are configured visually in the registered/cropped
image viewer. The orange star toggles the currently visible image in or out of
the Multi-exposure group. On the first selection, a centred dialog chooses the
acquisition type and shows the target treatment. The first Next generates and
displays the combined result; a second Next continues to an InNova module.
Generated combinations use a bold blue `NEW INTEGRATED` or `NEW HDR` viewer
label. The compact destination step lists every individual and generated image
with a checkbox, so only explicitly selected images are sent to InNova
Integrator. It automatically fills the Sii, Ha, Oiii, R, G, B, L and OSC image
selectors with the best selected prepared result, prioritising a new HDR or
multi-night integration, then a crop, then a registered copy.

With one source image, Run skips StarAlignment, creates one non-destructive
review copy and opens the same quick-stretch viewer directly. Visual Crop,
Restore, zoom, Fit and Pan remain available, including for Vespera images.

Object treatment is automatic. Every new project first uses the normal Nebula
or Galaxy stellar workflow. If StarAlignment cannot register any target because
there is no usable star field, InNova Start automatically switches to Sun or
Moon treatment, cleans the failed review output and retries without requiring a
second Run. Bright-target treatment creates a safe review copy for every
exposure and opens the same viewer for inspection, removal, synchronized crop
and HDR selection.

The main header has no manual Project or Object boxes. It presents the guided
Single night, Multi-night and HDR workflow, while project/object metadata remain
internal for automatic processing and handoff. The compact resizable table is
initially sized through Camera; remaining columns stay available with the Input
images horizontal scroll bar.

HDR and Multi-night generation report a live stopwatch in both the main status
and the review information box, and retain the final elapsed time.

The review window ends with Back and Next navigation buttons. Back returns to
the initial InNova Start window for project changes. Next opens the Processing
Destination step with InNova Astro Processor, InNova Adaptive Stretch and InNova
Editor choices, followed by Exit.

Before the image table, three selectors define the processing context:

- Project: the same LRGB, RGB, SHO, HOO, OSC, SEESTAR and VAONIS VESPERA
  choices used by InNova Astro Processor.
- Acquisition: One single night, Multi-night or HDR (High Dynamic Range).
- Object type: Nebula or Galaxy, or Sun or Moon.

The selections are stored in shared PixInsight Settings keys named
InNovaHandoffProjectType, InNovaHandoffAcquisitionMode and
InNovaHandoffObjectType. They are ready for the future direct Integrator
launch/handoff. Sun or Moon skips stellar StarAlignment.

Image viewer
------------

Only after Run has finished successfully, a separate medium Image Viewer
window opens over InNova Start and loads every successful registered copy with
a temporary, non-destructive quick stretch. Previous/next arrows navigate the
sequence; magnifier buttons zoom in and out; Fit between them restores the
complete image to the viewer; the hand enables drag-to-pan.
There is no separate Crop box. The classic Crop icon activates direct visual
crop selection and asks whether to apply it to the complete sequence.

While crop selection or editing is active, every viewer toolbar control except
Crop is disabled. Clicking Crop again asks whether the selection is correct and
should be synchronized with the complete image sequence. Yes applies the crop;
No leaves the images unchanged and restores all viewer controls.

The Restore icon beside Crop asks for confirmation before discarding every
crop adjustment. It removes generated crop copies and reloads the original
registered sequence; source images and registered copies remain unchanged.

After the rectangle is drawn, it remains editable. Drag inside it to move the
complete frame, or drag any of its four corner and four edge handles to enlarge
or contract it. Click Crop a second time to confirm and apply the crop.

The viewer trash icon asks for confirmation before excluding the current exposure
from the project, table and registered/cropped sequences. It never closes,
deletes or modifies the corresponding PixInsight image. After Crop is applied,
the viewer automatically reloads the newly cropped copies for inspection.

Cropping is visual. Click Crop and drag a rectangle directly over the preview:
the area inside the blue rectangle is retained and the shaded area outside is
removed. The same rectangle is applied to the complete current sequence. The
manual X/Y/Width/Height fields are intentionally omitted. A further visual crop
can be drawn on the already cropped sequence if another adjustment is needed.

In the main window, Trash closes every image in the current project, including
the originals, and clears Input images. The adjacent recycle icon closes only
generated registration/crop results; original inputs remain open and loaded so
Run can be repeated from a clean state.

Project protection
------------------

Generated masks, previews, registered images, crops, rejection maps, weight
maps, starless/stars layers and background-model images are detected when the
image list is refreshed. They remain visible for diagnosis but are unchecked
automatically and a project warning identifies them.

Before registration, InNova Start also warns about conflicting OBJECT or WCS
coordinates, substantially different geometry and frame scales. If
StarAlignment succeeds only partially, successful copies remain usable while
failed images are explicitly identified and excluded from common-crop
calculation.

No source image is modified. Generated views use the suffixes
_InNovaStartRegistered and _InNovaStartCrop.

License and trial
-----------------

InNova Start is always free. It displays the locally available Suite trial or
license status and remaining days, but expiry, missing licenses, validation
failures and status-read errors never block Start. Paid modules retain their
own license checks. The shared trial clock is never reset by Start.

Planned next stages
-------------------

- Interactive crop overlay and coverage map.
- Registration quality report and limiting-image warnings.
- Per-exposure/per-filter integration for multi-night projects.
- HDR fusion of the resulting exposure masters.
- Final astrometric verification and hand-off to Adaptive Stretch/Editor.

Installation
------------

Add the InNova Start folder to PixInsight's script directories and use
Script > Feature Scripts to rescan. The command will appear under:

InNova Astro Photo Suite > InNova START
