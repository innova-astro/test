#include "lib/SubframeDirectPreview.js"
#include "lib/SubframePreviewCache.js"
#include "../InNova/lib/InNovaEditorTheme.js"
#include "../InNova/lib/InNovaNotice.js"


var StartSubframeCalibrationDirectorySetting =
   "InNovaStart/SubframeReview/CalibrationDirectory";

var StartSubframeOutputDirectorySetting =
   "InNovaStart/SubframeReview/OutputDirectory";
var StartSubframePreferredTemporaryVolume =
   "/Volumes/Astrofotografía 1";
var StartSubframeAlternateTemporaryVolume =
   "/Volumes/Astrofotografía";

function StartSubframeSupportedFilters()
{
   return [ [ InNovaTr( "Astronomical image files" ),
      "*.xisf *.fits *.fit *.fts *.tif *.tiff *.TIF *.TIFF" ],
      [ InNovaTr( "All files" ), "*" ] ];
}

function StartSubframeCollectSessionFiles( directory )
{
   let paths = [];
   function visit( path )
   {
      let base = String( path ).replace( /[\\\/]$/, "" );
      let find = new FileFind;
      if ( !find.begin( base + "/*" ) ) return;
      do {
         if ( find.name == "." || find.name == ".." ||
              String( find.name ).charAt( 0 ) == "." )
            continue;
         let itemPath = base + "/" + find.name;
         if ( find.isDirectory ) {
            visit( itemPath );
            continue;
         }
         if ( /\.(xisf|fits|fit|fts|tif|tiff)$/i.test( String( find.name ) ) )
            paths.push( itemPath );
      } while ( find.next() );
      find.end();
   }
   visit( directory );
   paths.sort();
   return paths;
}

function StartSubframeFileName( path )
{
   return File.extractNameAndExtension( path );
}

function StartSubframeFormatElapsed( milliseconds )
{
   let seconds = Math.max( 0, Math.floor( milliseconds/1000 ) );
   let hours = Math.floor( seconds/3600 );
   seconds -= hours*3600;
   let minutes = Math.floor( seconds/60 );
   seconds -= minutes*60;
   function two( value ) { return value < 10 ? "0" + value : String( value ); }
   return two( hours ) + ":" + two( minutes ) + ":" + two( seconds );
}

function StartPositionSubframeReview( dialog )
{
   if ( !dialog ) return;
   let screen = dialog.availableScreenRect;
   if ( !screen ) return;
   let margin = 8;
   let width = screen.x1 - screen.x0;
   let height = screen.y1 - screen.y0;
   let x = Math.round( screen.x0 + (width - dialog.width)/2 );
   let centeredY = Math.round( screen.y0 + (height - dialog.height)/2 );
   let upwardOffset = Math.round( dialog.logicalPixelsToPhysical( 72 ) );
   let y = centeredY - upwardOffset;
   x = Math.max( screen.x0 + margin,
      Math.min( x, screen.x1 - dialog.width - margin ) );
   y = Math.max( screen.y0 + margin,
      Math.min( y, screen.y1 - dialog.height - margin ) );
   dialog.move( x, y );
}

class StartSubframePreviewControl extends Control
{
constructor( parent, minimumWidth, minimumHeight )
{
   super( parent );
   let preview = this;
   this.bitmap = null;
   this.scaledBitmap = null;
   this.scale = 1;
   this.fitMode = true;
   this.panEnabled = true;
   this.scrolling = null;
   this.cropMode = false;
   this.cropEditMode = false;
   this.cropStart = null;
   this.cropSelection = null;
   this.cropDrag = null;
   this.sourceWidth = 0;
   this.sourceHeight = 0;
   this.onCropSelected = null;

   this.viewport = new StartImageReviewViewport( this,
      minimumWidth || 690, minimumHeight || 430 );
   this.viewport.viewport.cursor = new Cursor( StdCursor_OpenHand );

   this.setBitmap = function( bitmap, sourceWidth, sourceHeight, preparedDisplay )
   {
      this.bitmap = bitmap;
      this.sourceWidth = sourceWidth || (bitmap != null ? bitmap.width : 0);
      this.sourceHeight = sourceHeight || (bitmap != null ? bitmap.height : 0);
      this.cropMode = false;
      this.cropEditMode = false;
      this.cropStart = null;
      this.cropSelection = null;
      this.cropDrag = null;
      this.fitMode = true;
      this.viewport.horizontalScrollPosition = 0;
      this.viewport.verticalScrollPosition = 0;
      if (preparedDisplay && bitmap) {
         this.scaledBitmap=preparedDisplay;
         this.scale=preparedDisplay.width/bitmap.width;
         this.viewport.maxHorizontalScrollPosition=Math.max(0,preparedDisplay.width-this.viewport.viewport.width);
         this.viewport.maxVerticalScrollPosition=Math.max(0,preparedDisplay.height-this.viewport.viewport.height);
         this.viewport.viewport.update();
      } else this.viewport.rebuildFor( this );
   };
   this.setZoom = function( factor )
   {
      if ( this.bitmap == null ) return;
      this.fitMode = false;
      this.scale = Math.range( factor, 0.03, 8 );
      this.viewport.rebuildFor( this );
   };
   this.fit = function() { this.viewport.fitFor( this ); };
   this.setCropMode = function( active )
   {
      this.cropMode = active === true && this.bitmap != null;
      this.cropEditMode = false;
      this.cropStart = null;
      this.cropDrag = null;
      this.scrolling = null;
      this.panEnabled = !this.cropMode;
      this.viewport.viewport.cursor = new Cursor( this.cropMode ?
         StdCursor_Cross : StdCursor_OpenHand );
      this.viewport.viewport.update();
   };
   this.clearCrop = function()
   {
      this.cropMode = false;
      this.cropEditMode = false;
      this.cropStart = null;
      this.cropSelection = null;
      this.cropDrag = null;
      this.panEnabled = true;
      this.viewport.viewport.cursor = new Cursor( StdCursor_OpenHand );
      this.viewport.viewport.update();
   };
   this.viewportToSource = function( x, y, clampToImage )
   {
      if ( this.bitmap == null || this.scaledBitmap == null ||
           this.sourceWidth < 1 || this.sourceHeight < 1 ) return null;
      let offset = this.viewport.bitmapOffsetFor( this );
      let bx = (x - offset.x)/this.scale;
      let by = (y - offset.y)/this.scale;
      if ( clampToImage ) {
         bx = Math.range( bx, 0, this.bitmap.width - 1 );
         by = Math.range( by, 0, this.bitmap.height - 1 );
      } else if ( bx < 0 || by < 0 || bx >= this.bitmap.width ||
                  by >= this.bitmap.height ) return null;
      return {
         x: Math.range( Math.round( bx*this.sourceWidth/this.bitmap.width ),
            0, this.sourceWidth - 1 ),
         y: Math.range( Math.round( by*this.sourceHeight/this.bitmap.height ),
            0, this.sourceHeight - 1 )
      };
   };

   this.cropHitAction = function( point )
   {
      if ( this.cropSelection == null || this.scaledBitmap == null )
         return "new";
      let r = this.cropSelection;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      let tx = Math.max( 4, 10*this.sourceWidth/this.scaledBitmap.width );
      let ty = Math.max( 4, 10*this.sourceHeight/this.scaledBitmap.height );
      let nearLeft = Math.abs( point.x - r.x ) <= tx;
      let nearRight = Math.abs( point.x - right ) <= tx;
      let nearTop = Math.abs( point.y - r.y ) <= ty;
      let nearBottom = Math.abs( point.y - bottom ) <= ty;
      let verticalRange = point.y >= r.y - ty && point.y <= bottom + ty;
      let horizontalRange = point.x >= r.x - tx && point.x <= right + tx;
      if ( nearLeft && nearTop ) return "lt";
      if ( nearRight && nearTop ) return "rt";
      if ( nearLeft && nearBottom ) return "lb";
      if ( nearRight && nearBottom ) return "rb";
      if ( nearLeft && verticalRange ) return "l";
      if ( nearRight && verticalRange ) return "r";
      if ( nearTop && horizontalRange ) return "t";
      if ( nearBottom && horizontalRange ) return "b";
      if ( point.x >= r.x && point.x <= right &&
           point.y >= r.y && point.y <= bottom ) return "move";
      return "new";
   };

   this.updateCropDrag = function( point )
   {
      if ( this.cropDrag == null ) return;
      let d = this.cropDrag;
      let r = d.original;
      if ( d.action == "move" ) {
         this.cropSelection = {
            x: Math.range( r.x + point.x - d.start.x,
               0, this.sourceWidth - r.width ),
            y: Math.range( r.y + point.y - d.start.y,
               0, this.sourceHeight - r.height ),
            width: r.width, height: r.height
         };
         return;
      }
      let left = r.x;
      let top = r.y;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      if ( d.action.indexOf( "l" ) >= 0 )
         left = Math.range( point.x, 0, right - 63 );
      if ( d.action.indexOf( "r" ) >= 0 )
         right = Math.range( point.x, left + 63, this.sourceWidth - 1 );
      if ( d.action.indexOf( "t" ) >= 0 )
         top = Math.range( point.y, 0, bottom - 63 );
      if ( d.action.indexOf( "b" ) >= 0 )
         bottom = Math.range( point.y, top + 63, this.sourceHeight - 1 );
      this.cropSelection = { x: left, y: top,
         width: right - left + 1, height: bottom - top + 1 };
   };

   this.viewport.viewport.onResize = function()
   {
      if ( preview.fitMode ) preview.viewport.rebuildFor( preview );
   };
   this.viewport.onHorizontalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
   this.viewport.onVerticalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
   this.viewport.viewport.onMousePress = function(
      x, y, button, buttonState, modifiers )
   {
      if ( button != MouseButton_Left || preview.bitmap == null ) return;
      if ( preview.cropMode ) {
         let point = preview.viewportToSource( x, y );
         if ( point == null ) return;
         preview.cropStart = point;
         preview.cropSelection = { x: point.x, y: point.y,
            width: 1, height: 1 };
         this.update();
         return;
      }
      if ( preview.cropEditMode && preview.cropSelection != null ) {
         let point = preview.viewportToSource( x, y );
         if ( point == null ) return;
         let action = preview.cropHitAction( point );
         if ( action == "new" ) {
            preview.cropEditMode = false;
            preview.cropMode = true;
            preview.cropStart = point;
            preview.cropSelection = { x: point.x, y: point.y,
               width: 1, height: 1 };
         }
         else {
            let r = preview.cropSelection;
            preview.cropDrag = { action: action, start: point,
               original: { x: r.x, y: r.y,
                  width: r.width, height: r.height } };
         }
         this.update();
         return;
      }
      if ( !preview.panEnabled ) return;
      preview.viewport.beginPanFor( preview, x, y );
   };
   this.viewport.viewport.onMouseMove = function(
      x, y, buttonState, modifiers )
   {
      if ( preview.cropMode && preview.cropStart != null ) {
         let point = preview.viewportToSource( x, y, true );
         if ( point == null ) return;
         let left = Math.min( preview.cropStart.x, point.x );
         let top = Math.min( preview.cropStart.y, point.y );
         preview.cropSelection = { x: left, y: top,
            width: Math.abs( point.x - preview.cropStart.x ) + 1,
            height: Math.abs( point.y - preview.cropStart.y ) + 1 };
         this.update();
         return;
      }
      if ( preview.cropDrag != null ) {
         let point = preview.viewportToSource( x, y, true );
         if ( point == null ) return;
         preview.updateCropDrag( point );
         this.update();
         return;
      }
      preview.viewport.movePanFor( preview, x, y );
   };
   this.viewport.viewport.onMouseRelease = function(
      x, y, button, buttonState, modifiers )
   {
      if ( button != MouseButton_Left ) return;
      if ( preview.cropMode && preview.cropStart != null ) {
         let point = preview.viewportToSource( x, y, true );
         if ( point != null ) {
            let left = Math.min( preview.cropStart.x, point.x );
            let top = Math.min( preview.cropStart.y, point.y );
            preview.cropSelection = { x: left, y: top,
               width: Math.abs( point.x - preview.cropStart.x ) + 1,
               height: Math.abs( point.y - preview.cropStart.y ) + 1 };
         }
         preview.cropStart = null;
         preview.cropMode = false;
         preview.cropEditMode = true;
         preview.panEnabled = false;
         this.cursor = new Cursor( StdCursor_Cross );
         this.update();
         if ( preview.cropSelection != null &&
              typeof preview.onCropSelected == "function" )
            preview.onCropSelected( preview.cropSelection );
         return;
      }
      if ( preview.cropDrag != null ) {
         let point = preview.viewportToSource( x, y, true );
         if ( point != null ) preview.updateCropDrag( point );
         preview.cropDrag = null;
         this.update();
         if ( preview.cropSelection != null &&
              typeof preview.onCropSelected == "function" )
            preview.onCropSelected( preview.cropSelection );
         return;
      }
      preview.viewport.endPanFor( preview );
   };
   this.viewport.viewport.onPaint = function( x0, y0, x1, y1 )
   {
      let graphics = new Graphics( this );
      graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff25282c ) );
      let offset = preview.viewport.drawBitmapFor( graphics, preview );
      if ( offset != null && preview.cropSelection != null &&
           preview.sourceWidth > 0 && preview.sourceHeight > 0 ) {
         let r = preview.cropSelection;
         let left = offset.x + r.x*preview.scaledBitmap.width/
            preview.sourceWidth;
         let top = offset.y + r.y*preview.scaledBitmap.height/
            preview.sourceHeight;
         let right = offset.x + (r.x + r.width)*preview.scaledBitmap.width/
            preview.sourceWidth;
         let bottom = offset.y + (r.y + r.height)*preview.scaledBitmap.height/
            preview.sourceHeight;
         let imageRight = offset.x + preview.scaledBitmap.width;
         let imageBottom = offset.y + preview.scaledBitmap.height;
         let shade = new Brush( 0x98000000 );
         graphics.fillRect( offset.x, offset.y, imageRight, top, shade );
         graphics.fillRect( offset.x, bottom, imageRight, imageBottom, shade );
         graphics.fillRect( offset.x, top, left, bottom, shade );
         graphics.fillRect( right, top, imageRight, bottom, shade );
         graphics.pen = new Pen( 0xff33aaff, 2 );
         graphics.drawRect( left, top, right, bottom );
         let middleX = (left + right)/2;
         let middleY = (top + bottom)/2;
         let handles = [ [left, top], [middleX, top], [right, top],
            [left, middleY], [right, middleY], [left, bottom],
            [middleX, bottom], [right, bottom] ];
         for ( let h = 0; h < handles.length; ++h ) {
            let hx = Math.range( Math.round( handles[h][0] ),
               10, this.width - 11 );
            let hy = Math.range( Math.round( handles[h][1] ),
               10, this.height - 11 );
            graphics.fillRect( hx - 9, hy - 9, hx + 10, hy + 10,
               new Brush( 0xffffffff ) );
            graphics.fillRect( hx - 6, hy - 6, hx + 7, hy + 7,
               new Brush( 0xff087bd5 ) );
            graphics.pen = new Pen( 0xff002f62, 2 );
            graphics.drawRect( hx - 9, hy - 9, hx + 9, hy + 9 );
         }
      }
      graphics.end();
   };

   this.sizer = new VerticalSizer;
   this.sizer.add( this.viewport, 100 );
}
}

function StartSubframeReadPreview(item, fullResolution, sharedStretch, linearCache)
{
   let probe=new Image;
   let supported=typeof probe.computeAutoStretch==="function" && typeof probe.applyDisplayFunction==="function";
   probe.free();
   if(supported)return StartSubframeDirectPreview(item,fullResolution,sharedStretch,linearCache);
   return StartSubframeLegacyPreview(item,fullResolution);
}

function StartSubframeLegacyPreview( item, fullResolution )
{
   let windows = [];
   try {
      windows = ImageWindow.open( item.path );
      if ( windows == null || windows.length == 0 )
         throw new Error( InNovaTr( "PixInsight could not open this file." ) );
      let window = windows[0];
      let image = window.mainView.image;
      item.width = image.width;
      item.height = image.height;
      item.channels = image.numberOfChannels;
      item.exposure = StartExposureSeconds( window );
      item.filter = StartKeywordValue( window, [ "FILTER", "FILTERID" ] ) || "—";
      item.camera = StartKeywordValue( window,
         [ "INSTRUME", "CAMERA", "DETECTOR" ] ) || "—";
      let state = {};
      let bitmap = StartQuickStretchBitmap( window, false,
         item.quickStretchLinked !== false, state, fullResolution ? 0 : 1800 );
      item.quickStretchLinked = state.linked;
      item.quickStretchToggleAvailable = state.adjustable === true;
      return bitmap;
   } finally {
      for ( let i = 0; i < windows.length; ++i )
         try {
            if ( windows[i] != null && !windows[i].isNull )
               windows[i].forceClose();
         } catch ( error ) {}
   }
}

function StartSubframeCollectRecentMasters( directory, startedAt )
{
   let candidates = [];
   function visit( path )
   {
      let base = path;
      if ( base.length > 1 && /[\\\/]$/.test( base ) )
         base = base.substring( 0, base.length - 1 );
      let find = new FileFind;
      if ( !find.begin( base + "/*" ) )
         return;
      do {
         if ( find.name == "." || find.name == ".." )
            continue;
         let itemPath = base + "/" + find.name;
         if ( find.isDirectory ) {
            visit( itemPath );
            continue;
         }
         let name = String( find.name );
         if ( !/\.(xisf|fits|fit|fts)$/i.test( name ) )
            continue;
         if ( find.lastModified.getTime() < startedAt - 3000 )
            continue;
         if ( !/master[_-]?light|masterlight|integration/i.test( name ) )
            continue;
         if ( /rejection|low_rejection|high_rejection|drizzle/i.test( name ) )
            continue;
         candidates.push( { path: itemPath, modified: find.lastModified.getTime(),
            autocrop: /autocrop/i.test( name ) } );
      } while ( find.next() );
      find.end();
   }
   visit( directory );
   candidates.sort( function( a, b ) {
      if ( a.autocrop != b.autocrop ) return a.autocrop ? -1 : 1;
      return b.modified - a.modified;
   } );


   let paths = [];
   let seen = {};
   for ( let i = 0; i < candidates.length; ++i ) {
      let key = File.extractName( candidates[i].path ).replace( /_autocrop$/i, "" );
      if ( seen[key] ) continue;
      seen[key] = true;
      paths.push( candidates[i].path );
   }
   return paths;
}

function StartSubframeStorageRoot()
{
   let innovaDirectory = typeof _0xb47cd2e9fc == "function" ?
      _0xb47cd2e9fc() : File.homeDirectory + "/Documents/InNova";
   if ( !File.directoryExists( innovaDirectory ) )
      File.createDirectory( innovaDirectory );
   return innovaDirectory;
}

function StartSubframePreferredTemporaryRoot()
{
   if ( File.directoryExists( StartSubframePreferredTemporaryVolume ) )
      return StartSubframePreferredTemporaryVolume;
   if ( File.directoryExists( StartSubframeAlternateTemporaryVolume ) )
      return StartSubframeAlternateTemporaryVolume;
   return "";
}

function StartSubframeAutomaticOutputDirectory( processorName )
{
   let innovaDirectory;
   let preferredRoot = StartSubframePreferredTemporaryRoot();
   if ( preferredRoot.length > 0 ) {
      innovaDirectory = preferredRoot + "/InNova";
      if ( !File.directoryExists( innovaDirectory ) )
         File.createDirectory( innovaDirectory );
   }
   else {
      innovaDirectory = StartSubframeStorageRoot();
      console.warningln( "** Warning: The preferred Subframe temporary " +
         "volume is not connected. Using: " + innovaDirectory );
   }
   let temporaryDirectory = innovaDirectory + "/Subframe temporary";
   if ( !File.directoryExists( temporaryDirectory ) )
      File.createDirectory( temporaryDirectory );
   let outputDirectory = temporaryDirectory + "/" + processorName + "_" +
      String( Date.now() );
   if ( !File.directoryExists( outputDirectory ) )
      File.createDirectory( outputDirectory );
   return outputDirectory;
}

function StartSubframeMasterDirectory()
{
   let innovaDirectory = StartSubframeStorageRoot();
   let masterDirectory = innovaDirectory + "/Sub master files";
   if ( !File.directoryExists( masterDirectory ) )
      File.createDirectory( masterDirectory );
   return masterDirectory;
}

function StartSubframeDefaultMasterFolderName()
{
   let date = new Date;
   function twoDigits( value )
   {
      return value < 10 ? "0" + value : String( value );
   }
   return String( date.getFullYear() ) + "-" +
      twoDigits( date.getMonth() + 1 ) + "-" + twoDigits( date.getDate() );
}

function StartSubframeSafeMasterFolderName( value )
{
   let name = String( value || "" ).trim()
      .replace( /[\x00-\x1f<>:"\/\\|?*]/g, "-" )
      .replace( /[\. ]+$/g, "" );
   if ( name == "." || name == ".." ) name = "";
   if ( /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test( name ) )
      name = "_" + name;
   return name;
}

function StartSubframeUniqueMasterPath( directory, sourcePath )
{
   let target = directory + "/" + File.extractNameAndExtension( sourcePath );
   if ( !File.exists( target ) ) return target;
   return directory + "/" + File.extractName( sourcePath ) + "_" +
      String( Date.now() ) + File.extractExtension( sourcePath );
}

function StartSubframeRemoveTemporaryDirectory( directory )
{
   let normalized = String( directory ).replace( /\\/g, "/" );
   if ( normalized.indexOf( "/InNova/Subframe temporary/" ) < 0 )
      throw new Error( InNovaTr( "Refusing to remove a directory outside InNova's " +
         "Subframe temporary folder." ) );
   if ( !File.directoryExists( directory ) ) return;
   function removeContents( path )
   {
      let base = /[\\\/]$/.test( path ) ? path : path + "/";
      let find = new FileFind;
      if ( !find.begin( base + "*" ) ) return;
      do {
         if ( find.name == "." || find.name == ".." ) continue;
         let itemPath = base + find.name;
         if ( find.isDirectory ) {
            removeContents( itemPath );
            File.removeDirectory( itemPath );
         }
         else
            File.remove( itemPath );
      } while ( find.next() );
      find.end();
   }
   removeContents( directory );
   File.removeDirectory( directory );
}

function StartSubframeGaiaDatabaseStatus()
{
   let status = typeof MiraGaiaAstrometryStatus == "function" ?
      MiraGaiaAstrometryStatus() : { ready: false, databaseFilePaths: [],
         error: InNovaTr( "The Gaia process is not available." ) };
   let configured = status.databaseFilePaths || [];
   let paths = [];
   for ( let i = 0; i < configured.length; ++i ) {
      let value = configured[i];
      if ( value instanceof Array ) value = value.length > 0 ? value[0] : "";
      else if ( value != null && typeof value == "object" )
         value = value.databaseFilePath || value.filePath || value.path || "";
      value = String( value || "" );
      if ( value.length > 0 ) paths.push( value );
   }
   let accessible = [];
   for ( let i = 0; i < paths.length; ++i )
      if ( File.exists( paths[i] ) ) accessible.push( paths[i] );
   status.databaseFilePaths = paths;
   status.accessibleFilePaths = accessible;
   status.directory = accessible.length > 0 ?
      File.extractDrive( accessible[0] ) +
         File.extractDirectory( accessible[0] ).replace( /[\\\/]$/, "" ) : "";
   status.ready = status.ready === true &&
      (paths.length == 0 || accessible.length == paths.length);
   return status;
}

function StartSubframeAskToSaveMasters( masterDirectory, options )
{
   options = options || {};
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   let answer = StdButton_No;
   let selectedDirectory = masterDirectory;
   let dialogTitle = options.dialogTitle ||
      InNovaTr( "✦ InNova Subframe Review & Integration — Save master files" );
   dialog.windowTitle = dialogTitle;

   let background = StartLauncherPanel( dialog, false, true );
   background.setScaledFixedWidth( 640 );
   background.setScaledMinHeight( 325 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   background.sizer.add(InNovaBlackHeader(background, options.heading || InNovaTr( "Save master files?" ),
      options.completedText || InNovaTr( "The subframe integration has finished successfully." ), options.iconName || "subframe-review"));

   let location = StartLauncherPanel( background, false );
   location.setScaledMinHeight( options.locationIntro ? 112 : 78 );
   location.sizer = new VerticalSizer;
   location.sizer.margin = 10;
   location.sizer.add( StartLauncherLabel( location,
      (options.locationIntro ?
         "<span style=\"color:#72b8f4\"><b>" +
         StartHTMLText( options.locationIntro ) + "</b></span><br/><br/>" :
         "") +
      InNovaTr( "Do you want to save the resulting master file(s) in:<br/><b>" ) +
      StartHTMLText( masterDirectory ) + "</b>", 12, "#102b50", true ) );
   location.sizer.addSpacing( 12 );
   background.sizer.add( location );

   let folder = StartLauncherPanel( background, false );
   folder.setScaledFixedHeight( 52 );
   folder.sizer = new HorizontalSizer;
   folder.sizer.margin = 10;
   folder.sizer.spacing = 8;
   let folderNameLabel = new Label( folder );
   folderNameLabel.text = InNovaTr( "Folder name:" );
   folderNameLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   folderNameLabel.setFixedWidth( Math.max(dialog.logicalPixelsToPhysical(92),
      folderNameLabel.font.width(folderNameLabel.text) + dialog.logicalPixelsToPhysical(8)) );
   folder.sizer.add( folderNameLabel );
   let folderNameEdit = new Edit( folder );
   if (InNovaWindowsButtonStyle())
      folderNameEdit.styleSheet = InNovaStyleWithToolTips(
         'QLineEdit, QLineEdit:focus { ' +
         'background-color: #25282c; color: #e4e8ed; ' +
         'border: 1px solid #596573; border-image: none; background-image: none; ' +
         'selection-background-color: #0b78dc; selection-color: #ffffff; padding: 3px; }');
   folderNameEdit.text = StartSubframeDefaultMasterFolderName();
   folderNameEdit.toolTip =
      InNovaTr( "Name of the folder that will contain the master files from this run." );
   folder.sizer.add( folderNameEdit, 100 );
   background.sizer.add( folder );

   let buttons = new HorizontalSizer;
   buttons.spacing = 12;
   buttons.addStretch();
   let yesButton = new PushButton( background );
   yesButton.text = InNovaTr( "Yes" );
   yesButton.icon = dialog.scaledResource( ":/icons/save.png" );
   yesButton.setScaledFixedSize( 120, 30 );
   yesButton.onClick = function()
   {
      let folderName = StartSubframeSafeMasterFolderName(
         folderNameEdit.text );
      if ( folderName.length == 0 ) {
         new InNovaNotice( InNovaTr( "Enter a valid folder name." ), dialogTitle,
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      folderNameEdit.text = folderName;
      selectedDirectory = masterDirectory + "/" + folderName;
      try {
         if ( !File.directoryExists( selectedDirectory ) )
            File.createDirectory( selectedDirectory );
      } catch ( error ) {
         new InNovaNotice( InNovaTr( "The folder could not be created:\n\n" ) +
            selectedDirectory + "\n\n" + error,
            dialogTitle,
            StdIcon_Error, StdButton_Ok ).execute();
         return;
      }
      answer = StdButton_Yes;
      dialog.ok();
   };
   buttons.add( InNovaStyleBlackButton(yesButton) );
   let noButton = new PushButton( background );
   noButton.text = InNovaTr( "No" );
   noButton.icon = dialog.scaledResource( ":/icons/cancel.png" );
   noButton.setScaledFixedSize( 120, 30 );
   noButton.onClick = function()
   {
      answer = StdButton_No;
      dialog.ok();
   };
   buttons.add( InNovaStyleBlackButton(noButton) );
   buttons.addStretch();
   InNovaAddDialogActionSpace(background, background.sizer); background.sizer.add( buttons );

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
   return { answer: answer, directory: selectedDirectory };
}

function StartSubframeCalibrationIsEmpty( directories )
{
   return directories == null ||
      (String( directories.bias || "" ).length == 0 &&
       String( directories.darks || "" ).length == 0 &&
       String( directories.flats || "" ).length == 0);
}

function StartSubframeRequestCalibration(self, editExisting)
{
   if (self.calibrationChoiceMade && !editExisting) return true;
   let loadCalibration = self.calibrationChoiceMade ? StdButton_Yes :
      StartAskCenteredQuestion(
         InNovaTr("InNova Subframe Review & Integration — Calibration frames"),
         InNovaTr("Do you want to load calibration frames?\n\nDarks, Flats and Bias"),
         true, InNovaTr("Darks, Flats and Bias"));
   if (loadCalibration == StdButton_Yes) {
      let directories = StartSubframeChooseCalibrationFolders(self.calibrationDirectories);
      if (directories == null) return false;
      self.calibrationDirectories = directories;
   } else if (loadCalibration == StdButton_No) {
      self.calibrationDirectories = { bias: "", darks: "", flats: "" };
   } else return false;
   self.calibrationChoiceMade = true;
   self.updateCalibrationButton();
   return true;
}

function StartSubframeChooseCalibrationFolders( currentDirectories )
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr( "✦ InNova Subframe Review & Integration — Calibration frames" );
   dialog.directories = {
      bias: String( currentDirectories && currentDirectories.bias || "" ),
      darks: String( currentDirectories && currentDirectories.darks || "" ),
      flats: String( currentDirectories && currentDirectories.flats || "" )
   };

   let savedDirectory = Settings.read( StartSubframeCalibrationDirectorySetting, DataType_String );
   dialog.lastCalibrationDirectory = Settings.lastReadOK && savedDirectory ?
      String( savedDirectory ) :
      (dialog.directories.bias || dialog.directories.darks || dialog.directories.flats || File.homeDirectory);

   let background = StartLauncherPanel( dialog, false, true );
   background.setScaledMinWidth(700);
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   background.sizer.add(InNovaBlackHeader(background,InNovaTr( "Calibration frames" ),
      InNovaTr( "Select any Bias, Darks or Flats folders available for this project." ),"subframe-review"));

   let folders = StartLauncherPanel( background, false );
   folders.sizer = new VerticalSizer;
   folders.sizer.margin = 12;
   folders.sizer.spacing = 8;
   let useButton = new PushButton( background );
   function refreshUseButton()
   {
      useButton.enabled = !StartSubframeCalibrationIsEmpty(
         dialog.directories );
   }
   function addFolderRow( title, key )
   {
      let row = new HorizontalSizer;
      row.spacing = 7;
      let label = new Label( folders );
      label.text = title + ":";
      label.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      label.setScaledFixedWidth( 62 );
      row.add( label );
      let edit = new Edit( folders );
      edit.readOnly = true;
      if (InNovaWindowsButtonStyle())
         edit.styleSheet = InNovaStyleWithToolTips(
            'QLineEdit, QLineEdit:focus, QLineEdit:read-only { ' +
            'background-color: #25282c; color: #e4e8ed; ' +
            'border: 1px solid #596573; border-image: none; background-image: none; ' +
            'selection-background-color: #0b78dc; selection-color: #ffffff; padding: 3px; }');
      edit.text = dialog.directories[key];
      edit.toolTip = InNovaTr( "Optional " ) + title + InNovaTr( " folder" );
      row.add( edit, 100 );
      let browse = new ToolButton( folders );
      browse.icon = dialog.scaledResource( ":/icons/folder-open.png" );
      browse.setScaledFixedSize( 28, 28 );
      browse.toolTip = InNovaTr( "Select the " ) + title + InNovaTr( " folder" );
      browse.onClick = function()
      {
         let chooser = new GetDirectoryDialog;
         chooser.caption = InNovaTr( "Select the " ) + title + InNovaTr( " folder" );
         chooser.initialPath = dialog.lastCalibrationDirectory;
         if ( chooser.execute() ) {
            dialog.directories[key] = chooser.directory.replace( /[\\\/]$/, "" );
            dialog.lastCalibrationDirectory = chooser.directory;
            Settings.write( StartSubframeCalibrationDirectorySetting,
               DataType_String, dialog.lastCalibrationDirectory );
            edit.text = dialog.directories[key];
            refreshUseButton();
         }
      };
      row.add( browse );
      let clear = new ToolButton( folders );
      clear.icon = dialog.scaledResource( ":/icons/delete.png" );
      clear.setScaledFixedSize( 28, 28 );
      clear.toolTip = InNovaTr( "Clear the " ) + title + InNovaTr( " folder" );
      clear.onClick = function()
      {
         dialog.directories[key] = "";
         edit.text = "";
         refreshUseButton();
      };
      row.add( clear );
      folders.sizer.add( row );
   }
   addFolderRow( "Bias", "bias" );
   addFolderRow( "Darks", "darks" );
   addFolderRow( "Flats", "flats" );
   background.sizer.add( folders );

   background.sizer.add( StartLauncherLabel( background,
      InNovaTr( "FBPP/WBPP will scan the selected folders recursively and identify " +
      "their calibration type from image metadata and smart naming." ),
      11, "#243f5b", true ) );

   let buttons = new HorizontalSizer;
   buttons.spacing = 10;
   buttons.addStretch();
   useButton.text = InNovaTr( "Use selected folders" );
   useButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   useButton.setScaledFixedSize( 170, 30 );
   useButton.onClick = function() { dialog.ok(); };
   buttons.add( InNovaStyleBlackButton(useButton) );
   let closeButton = new PushButton( background );
   closeButton.text = InNovaTr( "Close" );
   closeButton.icon = dialog.scaledResource( ":/icons/close.png" );
   closeButton.setScaledFixedSize( 120, 30 );
   closeButton.onClick = function() { dialog.cancel(); };
   buttons.add( InNovaStyleBlackButton(closeButton) );
   InNovaAddDialogActionSpace(background, background.sizer); background.sizer.add( buttons );
   refreshUseButton();

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   if ( dialog.execute() != StdDialogCode_Ok ) return null;
   return dialog.directories;
}

function StartBatchPreprocessingPhase( output, processorName, isStarting,
   isRunning )
{
   if ( isStarting ) return InNovaTr( "Starting " ) + processorName;
   if ( !isRunning ) return InNovaTr( "Finalizing master files" );


   let text = String( output || "" ).toLowerCase();
   if ( text.length > 180000 ) text = text.substring( text.length - 180000 );
   let phases = [
      { name: processorName + InNovaTr( " is working" ), tokens: [
         "batchpreprocessing", "building frame groups", "loading files" ] },
      { name: InNovaTr( "Calibration" ), tokens: [
         "imagecalibration", "begin calibration", "calibrating light" ] },
      { name: InNovaTr( "Debayer" ), tokens: [
         "begin demosaicing", "debayer will", "cfa pattern (detected)",
         "debayer:" ] },
      { name: InNovaTr( "Measurements" ), tokens: [
         "perform image measurements", "subframeselector" ] },
      { name: InNovaTr( "Selecting the reference frame" ), tokens: [
         "selection of the best reference frame", "best reference frame" ] },
      { name: InNovaTr( "Registration" ), tokens: [
         "begin registration of light frames", "staralignment" ] },
      { name: InNovaTr( "Local Normalization" ), tokens: [
         "begin local normalization", "localnormalization" ] },
      { name: InNovaTr( "Fast Integration" ), tokens: [
         "begin fast integration", "fastintegration", "fast integration" ] },
      { name: InNovaTr( "Image Integration" ), tokens: [
         "begin image integration", "imageintegration", "image integration" ] },
      { name: InNovaTr( "Drizzle Integration" ), tokens: [
         "drizzleintegration", "drizzle integration" ] },
      { name: InNovaTr( "RGB Combination" ), tokens: [
         "rgb combination", "channelcombination" ] },
      { name: InNovaTr( "Cropping the master light" ), tokens: [
         "begin autocrop", "autocrop of master light", "auto crop" ] },
      { name: InNovaTr( "Writing master files" ), tokens: [
         "writing master", "master light frame" ] }
   ];
   let bestIndex = -1;
   let bestName = processorName + InNovaTr( " is working" );
   for ( let i = 0; i < phases.length; ++i )
      for ( let j = 0; j < phases[i].tokens.length; ++j ) {
         let index = text.lastIndexOf( phases[i].tokens[j] );
         if ( index > bestIndex ) {
            bestIndex = index;
            bestName = phases[i].name;
         }
      }
   return bestName;
}

class StartFBPPProgressDialog extends Dialog
{
constructor( process, fileCount, processorName )
{
   super();
      InNovaApplyBlackTheme(this);
   let self = this;
   this.process = process;
   this.completed = false;
   this.succeeded = false;
   this.output = "";
   this.startedAt = Date.now();
   this.processorName = processorName;


   this.foregroundRestoreStage = 0;
   this.foregroundRestoreDelays = [ 1.0, 3.0, 7.0 ];
   this.windowTitle = InNovaTr( "✦ InNova Subframe Review & Integration — " ) + processorName;

   let header = StartLauncherPanel( this, true );
   header.setScaledFixedSize( 620, 108 );
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   header.sizer.add( StartLauncherIcon( header, "subframe-review", 78 ) );
   let headerText = new VerticalSizer;
   headerText.addStretch();
   headerText.add( StartLauncherLabel( header,
      InNovaTr( "<b>InNova Subframe Integration</b>" ), 20, "#102b50", false ) );
   headerText.add( StartLauncherLabel( header,
      (processorName == "WBPP" ? "WeightedBatchPreprocessing" :
       "FastBatchPreprocessing") + InNovaTr( " processing monitor" ),
      12, "#243f5b", false ) );
   headerText.addStretch();
   header.sizer.add( headerText, 100 );

   let information = StartLauncherPanel( this, false );
   information.setScaledFixedSize( 590, 146 );
   information.sizer = new VerticalSizer;
   information.sizer.margin = 12;
   information.sizer.spacing = 6;

   let title = StartLauncherLabel( information,
      InNovaTr( "Integrating " ) + fileCount + InNovaTr( " selected subframe(s)…" ),
      12, "#243f5b", true );

   this.phase = StartLauncherLabel( information,
      InNovaTr( "<span style=\"color:#087fbd\">Current step</span><br/>" +
      "<b>" ) + processorName + InNovaTr( String.fromCharCode(32,105,115,32,119,111,114,107,105,110,103,60,47,98,62,60,98,114,47,62,80,108,101,97,115,101,32,119,97,105,116,46,46,46) ),
      15, "#102b50", true );
   this.phase.setScaledMinHeight( 70 );

   this.status = new Label( this );
   this.status.useRichText = true;
   this.status.textAlignment = TextAlign_Center | TextAlign_VertCenter;
   this.status.setScaledMinSize( 550, 30 );

   information.sizer.add( title );
   information.sizer.add( this.phase );
   information.sizer.add( this.status );

   this.stopButton = new PushButton( this );
   this.stopButton.text = InNovaTr( "STOP" );
   this.stopButton.icon = InNovaBlackPlaybackIcon(this, "stop");
   this.stopButton.onClick = function()
   {
      if ( self.process != null &&
           (self.process.isStarting || self.process.isRunning) )
         self.process.terminate();
      self.completed = true;
      self.succeeded = false;
      self.cancel();
   };

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(this.stopButton) );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 0;
   this.sizer.spacing = 12;
   this.sizer.add( header );
   let body = new VerticalSizer;
   body.margin = 16;
   body.spacing = 12;
   body.add( information );
   body.add( buttons );
   this.sizer.add( body );
   this.adjustToContents();
   this.setFixedSize();

   this.timer = new Timer;
   this.timer.interval = 0.25;
   this.timer.periodic = true;
   this.timer.onTimeout = function()
   {
      try { self.output += self.process.stdout.toString(); } catch ( error ) {}
      try { self.output += self.process.stderr.toString(); } catch ( error ) {}
      let elapsedSeconds = (Date.now() - self.startedAt)/1000;
      let phase = StartBatchPreprocessingPhase( self.output,
         self.processorName, self.process.isStarting,
         self.process.isRunning );
      self.phase.text = "<p align=\"center\"><span style=\"color:#087fbd\">" +
         InNovaTr( "Current step</span><br/><b>" ) + StartHTMLText( phase ) +
         InNovaTr( String.fromCharCode(60,47,98,62,60,98,114,47,62,80,108,101,97,115,101,32,119,97,105,116,46,46,46,60,47,112,62) );
      self.status.text = "<p align=\"center\"><b style=\"color:#72b8f4\">" +
         InNovaTr( "⏱ Elapsed: " ) + StartSubframeFormatElapsed(
            Date.now() - self.startedAt ) + "</b></p>";
      if ( (self.process.isStarting || self.process.isRunning) &&
           self.foregroundRestoreStage < self.foregroundRestoreDelays.length &&
           elapsedSeconds >= self.foregroundRestoreDelays[
              self.foregroundRestoreStage] ) {
         self.bringToFront();
         ++self.foregroundRestoreStage;
      }
      if ( !self.process.isStarting && !self.process.isRunning ) {
         self.timer.stop();
         try { self.output += self.process.stdout.toString(); } catch ( error ) {}
         try { self.output += self.process.stderr.toString(); } catch ( error ) {}
         self.completed = true;
         self.succeeded = self.process.exitCode === 0;
         self.ok();
      }
   };
   this.onShow = function()
   {
      MiraCenterDialog( this );
      this.bringToFront();
      self.timer.start();
   };
   this.onClose = function()
   {
      if ( self.completed ) return true;
      if ( self.process != null &&
           (self.process.isStarting || self.process.isRunning) )
         self.process.terminate();
      self.completed = true;
      self.succeeded = false;
      return true;
   };
}
}

function StartWaitForVisibleBatchPreprocessing( process )
{
   let output = "";
   function collectOutput()
   {
      let chunk = "";
      try { chunk += process.stdout.toString(); } catch ( error ) {}
      try { chunk += process.stderr.toString(); } catch ( error ) {}
      output += chunk;
      if (chunk.length) InNovaDiagnosticWrite("OUTPUT", "FBPP / WBPP", chunk.slice(-16384));
   }
   if ( process.isStarting && !process.waitForStarted( 10000 ) ) {
      collectOutput();
      return { succeeded: false, output: output };
   }


   while ( process.isStarting || process.isRunning ) {
      process.waitForFinished( 250 );
      collectOutput();
      CoreApplication.processEvents();
   }
   collectOutput();
   return { succeeded: process.exitCode === 0, output: output };
}

function StartRunBatchPreprocessingAutomation( paths, outputDirectory,
   processorName, gaiaDatabasePaths, calibrationDirectories )
{
   processorName = processorName == "WBPP" ? "WBPP" : "FBPP";
   let scriptPath = CoreApplication.srcDirPath +
      "/scripts/BatchPreprocessing/" + processorName + ".js";
   if ( !File.exists( scriptPath ) )
      throw new Error( processorName + InNovaTr( " was not found at:\n" ) + scriptPath );
   for ( let i = 0; i < paths.length; ++i )
      if ( /[,=]/.test( paths[i] ) )
         throw new Error( processorName +
            InNovaTr( " automation cannot receive a file path " +
            "containing a comma or equals sign:\n" ) + paths[i] );
   if ( /[,=]/.test( outputDirectory ) )
      throw new Error( processorName +
         InNovaTr( " automation cannot use an output path containing " +
         "a comma or equals sign." ) );


   let runItems = [ scriptPath, "automationMode=true",
      "platesolve=false", "platesolveFallbackManual=false",
      "outputDirectory=" + outputDirectory ];
   for ( let i = 0; i < paths.length; ++i )
      runItems.push( "file=" + paths[i] );
   let calibrationPaths = [];
   if ( calibrationDirectories != null ) {
      calibrationPaths.push( String( calibrationDirectories.bias || "" ) );
      calibrationPaths.push( String( calibrationDirectories.darks || "" ) );
      calibrationPaths.push( String( calibrationDirectories.flats || "" ) );
   }
   let knownCalibrationPaths = {};
   for ( let i = 0; i < calibrationPaths.length; ++i ) {
      let calibrationPath = calibrationPaths[i].replace( /[\\\/]$/, "" );
      if ( calibrationPath.length == 0 || knownCalibrationPaths[calibrationPath] )
         continue;
      if ( /[,=]/.test( calibrationPath ) )
         throw new Error( processorName +
            InNovaTr( " automation cannot use a calibration folder path containing " +
            "a comma or equals sign:\n" ) + calibrationPath );
      if ( !File.directoryExists( calibrationPath ) )
         throw new Error( InNovaTr( "The calibration folder is not accessible:\n" ) +
            calibrationPath );
      knownCalibrationPaths[calibrationPath] = true;
      runItems.push( "dir=" + calibrationPath );
   }

   let executable = CoreApplication.filePath;
   let platform = String( CoreApplication.platform ).toLowerCase();
   let arguments = [ "-n", "--force-exit", "--automation-mode" ];
   arguments.push( "-r=\"" + runItems.join( "," ) + "\"" );
   let process = new ExternalProcess;
   process.start( executable, arguments );
   return StartWaitForVisibleBatchPreprocessing( process );
}

class InNovaSubframeReviewDialog extends Dialog
{
constructor( guidedWorkflow )
{
   super();
      InNovaApplyBlackTheme(this);
   let self = this;
   this.guidedWorkflow = guidedWorkflow === true;
   this.items = [];
   this.currentIndex = -1;
   this.masterPaths = [];
   this.cleanupDirectory = "";
   this.frameCache = new StartSubframePreviewCache;
   this.previewLoading = false;
   this.sessionPreparing = false;
   this.stretchOnDemand = false;
   this.previewClosed = false;
   this.closeRequested = false;
   this.pendingReviewIndex = -1;
   this.detailMode = false;
   this.detailBitmap = null;
   this.lastSummaryAt = 0;
   this.calibrationDirectories = { bias: "", darks: "", flats: "" };
   this.calibrationChoiceMade = false;
   this.windowTitle = InNovaTr( "🎞 InNova Subframe Review & Integration — " ) + InNovaStartVersion;

   let header = StartLauncherPanel( this, true );
   header.setScaledFixedHeight( 108 );
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   header.sizer.add( StartLauncherIcon( header, "subframe-review", 78 ) );
   let headerText = new VerticalSizer;
   headerText.addStretch();
   headerText.add( StartLauncherLabel( header,
      "<b>InNova Subframe Review & Integration</b>", 20, "#102b50", false ) );
   headerText.add( StartLauncherLabel( header,
      InNovaTr( "Review light subframes · Blink · Accept or reject · Create masters with FBPP/WBPP" ),
      12, "#243f5b", false ) );
   headerText.addStretch();
   header.sizer.add( headerText, 100 );

   let listPaneWidth = 570;
   this.tree = new TreeBox( this );
   this.tree.numberOfColumns = 5;
   this.tree.headerVisible = true;
   this.tree.rootDecoration = false;
   this.tree.alternateRowColor = true;
   this.tree.multipleSelection = true;
   this.tree.setHeaderText( 0, InNovaTr( "Use" ) );
   this.tree.setHeaderText( 1, InNovaTr( "Light subframe" ) );
   this.tree.setHeaderText( 2, InNovaTr( "Exposure" ) );
   this.tree.setHeaderText( 3, InNovaTr( "Filter" ) );
   this.tree.setHeaderText( 4, InNovaTr( "Geometry" ) );
   this.tree.setColumnWidth( 0, 42 );
   this.tree.setColumnWidth( 1, 260 );
   this.tree.setColumnWidth( 2, 76 );
   this.tree.setColumnWidth( 3, 72 );
   this.tree.setColumnWidth( 4, 105 );
   this.tree.setScaledMinSize( listPaneWidth, 430 );

   this.preview = new StartSubframePreviewControl( this );
   this.previewFrame = new GroupBox( this );
   this.previewFrame.title = InNovaTr( "Preview" );
   this.previewFrame.sizer = new VerticalSizer;
   this.previewFrame.sizer.margin = 6;
   this.previewFrame.sizer.add( this.preview, 100 );

   let center = new HorizontalSizer;
   center.spacing = 10;
   center.add( this.tree );
   center.add( this.previewFrame, 100 );

   this.loadButton = new ToolButton( this );
   this.loadButton.icon = this.scaledResource( ":/icons/folder-open.png" );
   this.loadButton.setScaledFixedSize( 32, 32 );
   this.loadButton.toolTip = InNovaTr( "Load light subframes" );
   this.sessionFolderButton = new ToolButton( this );
   this.sessionFolderButton.icon =
      StartLauncherBitmap( "icons/session-folder-add.svg" );
   this.sessionFolderButton.setScaledFixedSize( 32, 32 );
   this.sessionFolderButton.toolTip =
      InNovaTr( "Add session folder — Load all supported light subframes recursively. " +
      "Files with the same name in different folders remain separate." );
   this.rejectButton = new ToolButton( this );
   this.rejectButton.icon = this.scaledResource( ":/icons/trash.png" );
   this.rejectButton.setScaledFixedSize( 32, 32 );
   this.rejectButton.toolTip =
      InNovaTr( "Remove the selected subframes from this list; keep them on disk" );
   this.resetButton = new ToolButton( this );
   this.resetButton.icon = InNovaEditorLightActionIcon("reset");
   this.resetButton.setScaledFixedSize( 30, 30 );
   this.resetButton.toolTip =
      InNovaTr( "Reset Subframe Review and clear all loaded subframes" );
   this.allButton = new ToolButton( this );
   this.allButton.icon = StartLauncherBitmap( "icons/select-all.svg" );
   this.allButton.setScaledFixedSize( 32, 32 );
   this.allButton.toolTip = InNovaTr( "Mark all images as USE" );
   this.allButton.enabled = false;
   this.zoomInButton = new ToolButton( this );
   this.zoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomInButton.setScaledFixedSize( 30, 30 );
   this.zoomInButton.toolTip = InNovaTr( "Zoom in" );
   this.fitButton = new ToolButton( this );
   this.fitButton.icon = InNovaBlackPlaybackIcon( this, "fit" );
   this.fitButton.setScaledFixedSize( 30, 30 );
   this.fitButton.toolTip = InNovaTr( "Fit image to preview" );
   this.fitButton.onClick = function() {
      if(self.previewLoading)return;
      if(self.detailMode) { self.detailMode=false;self.detailBitmap=null;self.preview.fitMode=true;self.showIndex(self.currentIndex); }
      else self.preview.fit();
      self.prefetchTimer.start();
   };
   this.detailButton = new PushButton(this);
   this.detailButton.text="1:1";
   this.detailButton.toolTip=InNovaTr("Pause and inspect the original image at full resolution");
   this.detailButton.onClick=function() {
      if(self.previewLoading || self.currentIndex<0)return;
      self.stopBlinkTimer();self.prefetchTimer.stop();self.updateBlinkButton(false);
      self.previewLoading=true;self.updateLoadingControls();
      try {
         let item=self.items[self.currentIndex];
         self.detailBitmap=StartSubframeReadPreview(item,true,self.frameCache.sharedStretch ? self.frameCache.stretches : null);
         self.detailMode=true;
         self.preview.setBitmap(self.detailBitmap,item.width,item.height,self.detailBitmap);
         self.preview.fitMode=false;self.preview.scale=1;
      } catch(error) {
         console.warningln("Blink 1:1: "+error);
      } finally {self.previewLoading=false;}
      if(self.closeRequested){self.stopPreviewSession();self.cancel();return;}
      self.updateSummary();
   };
   this.panButton = new ToolButton( this );
   this.panButton.icon = StartHandIcon().scaledTo(
      this.logicalPixelsToPhysical(24), this.logicalPixelsToPhysical(24));
   this.panButton.setScaledFixedSize( 32, 32 );
   this.panButton.checkable = true;
   this.panButton.checked = true;
   this.panButton.toolTip = InNovaTr( "Pan the zoomed preview by dragging" );
   this.zoomOutButton = new ToolButton( this );
   this.zoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOutButton.setScaledFixedSize( 30, 30 );
   this.zoomOutButton.toolTip = InNovaTr( "Zoom out" );
   this.quickStretchLinkButton = new ToolButton( this );
   this.quickStretchLinkButton.icon = StartQuickStretchLinkIcon( true ).scaledTo(
      this.logicalPixelsToPhysical(26), this.logicalPixelsToPhysical(26));
   this.quickStretchLinkButton.setScaledFixedSize( 32, 32 );
   this.quickStretchLinkButton.iconWidth = this.logicalPixelsToPhysical(26);
   this.quickStretchLinkButton.iconHeight = this.logicalPixelsToPhysical(26);
   this.quickStretchLinkButton.enabled = false;
   this.quickStretchLinkButton.toolTip =
      InNovaTr( "Unlink RGB channels and recalculate Quick Stretch" );
   this.quickStretchLinkButton.onClick = function()
   {
      let item = self.currentIndex >= 0 ? self.items[self.currentIndex] : null;
      if (self.previewLoading || !item || !item.quickStretchToggleAvailable) return;
      self.stopBlinkTimer();
      self.updateBlinkButton(false);
      item.quickStretchLinked = item.quickStretchLinked !== true;
      self.frameCache.invalidate(item);
      self.showIndex(self.currentIndex);
      self.prefetchTimer.start();
   };
   this.previousButton = new ToolButton( this );
   this.previousButton.icon = InNovaBlackPlaybackIcon(this, "previous");
   this.previousButton.setScaledFixedSize( 30, 30 );
   this.previousButton.toolTip = InNovaTr( "Previous subframe" );
   this.playButton = new ToolButton( this );
   this.playButton.icon = InNovaBlackPlaybackIcon(this, "play");
   this.playButton.setScaledFixedSize( 30, 30 );
   this.playButton.checkable = true;
   this.playButton.styleSheet=InNovaStyleWithToolTips(
      "QToolButton:enabled { background-color: #0b78dc; border: 1px solid #72b8f4; } "+
      "QToolButton:enabled:hover { background-color: #1269b5; } "+
      "QToolButton:enabled:checked { background-color: #0b78dc; } "+
      "QToolButton:disabled { background-color: transparent; border: 1px solid transparent; }");
   this.playButton.toolTip = InNovaTr( "Blink through the loaded subframes" );
   this.updateBlinkButton = function( playing )
   {
      self.playButton.checked = playing === true;
      self.playButton.icon = InNovaBlackPlaybackIcon(self, playing ? "pause" : "play");
      self.playButton.toolTip = playing ?
         InNovaTr( "Pause Blink playback" ) : InNovaTr( "Blink through the loaded subframes" );
   };
   this.blinkDelaySpin = new SpinBox( this );
   this.blinkDelaySpin.minValue = 50;
   this.blinkDelaySpin.maxValue = 5000;
   this.blinkDelaySpin.stepSize = 50;
   this.blinkDelaySpin.value = 50;
   this.blinkDelaySpin.suffix = " ms";
   this.blinkDelaySpin.setScaledFixedWidth( 88 );
   this.blinkDelaySpin.toolTip =
      InNovaTr( "Time between subframes during Blink (50 to 5000 milliseconds)" );
   this.nextButton = new ToolButton( this );
   this.nextButton.icon = InNovaBlackPlaybackIcon(this, "next");
   this.nextButton.setScaledFixedSize( 30, 30 );
   this.nextButton.toolTip = InNovaTr( "Next subframe" );
   this.processorLabel = new Label( this );
   this.processorLabel.text = InNovaTr( "Integrate subs with:" );
   this.processorLabel.textAlignment =
      TextAlign_Right | TextAlign_VertCenter;
   this.calibrationLabel = new Label( this );
   this.calibrationLabel.text = InNovaTr( "Open Darks, Bias, Flats:" );
   this.calibrationLabel.textAlignment =
      TextAlign_Right | TextAlign_VertCenter;
   this.calibrationButton = new ToolButton( this );
   this.calibrationButton.icon = this.scaledResource( ":/icons/folder-open.png" );
   this.calibrationButton.setScaledFixedSize( 30, 30 );
   this.calibrationButton.checkable = true;
   this.processorCombo = new ComboBox( this );
   this.processorCombo.addItem( "FBPP" );
   this.processorCombo.addItem( "WBPP" );
   this.processorCombo.currentItem = 0;
   this.processorCombo.setScaledMinWidth( 92 );
   this.integrateButton = new PushButton( this );
   this.integrateButton.text = InNovaTr( "Run" );
   this.integrateButton.icon = InNovaBlackPlaybackIcon(this, "play");
   this.integrateButton.toolTip = InNovaTr( "Send only accepted subframes to the selected " +
      "preprocessing script, run it automatically and open the generated " +
      "master in Bridge." );
   this.closeButton = new PushButton( this );
   this.closeButton.text = InNovaTr( "Close" );
   this.closeButton.icon = this.scaledResource( ":/icons/close.png" );

   let listToolbar = new Control( this );

   listToolbar.setScaledMinWidth( listPaneWidth );
   listToolbar.sizer = new HorizontalSizer;
   listToolbar.sizer.spacing = 8;
   listToolbar.sizer.add( this.loadButton );
   listToolbar.sizer.add( this.sessionFolderButton );
   listToolbar.sizer.add( this.rejectButton );
   listToolbar.sizer.add( this.resetButton );
   listToolbar.sizer.add( this.zoomInButton );
   listToolbar.sizer.add( this.fitButton );
   listToolbar.sizer.add( this.detailButton );
   listToolbar.sizer.add( this.panButton );
   listToolbar.sizer.add( this.zoomOutButton );
   listToolbar.sizer.add( this.allButton );
   listToolbar.sizer.add( this.quickStretchLinkButton );
   listToolbar.sizer.addSpacing( 16 );
   listToolbar.sizer.add( this.previousButton );
   listToolbar.sizer.add( this.blinkDelaySpin );
   listToolbar.sizer.addSpacing( 8 );
   listToolbar.sizer.add( this.playButton );
   listToolbar.sizer.add( this.nextButton );

   let previewToolbar = new Control( this );
   previewToolbar.sizer = new HorizontalSizer;
   previewToolbar.sizer.spacing = 8;
   previewToolbar.sizer.add( this.processorLabel );
   previewToolbar.sizer.add( this.processorCombo );
   previewToolbar.sizer.addSpacing( 12 );
   previewToolbar.sizer.addStretch();
   previewToolbar.sizer.add( this.calibrationLabel );
   previewToolbar.sizer.add( this.calibrationButton );
   previewToolbar.sizer.addSpacing( 12 );
   previewToolbar.sizer.addStretch();
   previewToolbar.sizer.add( InNovaStyleBlackButton(this.integrateButton) );
   previewToolbar.sizer.addSpacing( 4 );
   previewToolbar.sizer.add( InNovaStyleBlackButton(this.closeButton) );
   this.integrateButton.setScaledFixedWidth(112);
   this.closeButton.setScaledFixedWidth(112);

   let buttons = new HorizontalSizer;
   buttons.spacing = 20;
   buttons.add( listToolbar );
   buttons.add( previewToolbar, 100 );

   this.gaiaGroup = new GroupBox( this );

   this.gaiaGroup.title = "";
   this.gaiaGroup.sizer = new VerticalSizer;
   this.gaiaGroup.sizer.margin = 7;
   this.gaiaInformation = new Label( this.gaiaGroup );
   this.gaiaInformation.useRichText = true;
   this.gaiaInformation.wordWrapping = true;
   this.gaiaInformation.textAlignment =
      TextAlign_Left | TextAlign_VertCenter;
   let gaiaStatus = StartSubframeGaiaDatabaseStatus();
   this.gaiaStatus = gaiaStatus;
   if ( gaiaStatus.ready ) {
      let location = gaiaStatus.directory.length > 0 ?
         StartHTMLText( gaiaStatus.directory ) :
         InNovaTr( "Gaia DR3 XPSD global database" );
      let fileCount = gaiaStatus.accessibleFilePaths.length > 0 ?
         " · " + gaiaStatus.accessibleFilePaths.length +
            InNovaTr( " Gaia database file(s) accessible" ) : "";
      this.gaiaInformation.text =
         InNovaTr( "<b style=\"color:#72b8f4\">✅ Gaia DR3 database available</b> · " ) +
         location + fileCount;
   }
   else {
      this.gaiaInformation.text =
         InNovaTr( "<b style=\"color:#ff5252\">⚠️ Gaia DR3 database is not correctly " +
         "configured.</b> Open <b>Process → Star Catalogs → Gaia</b>, click " +
         "<b>Preferences (wrench)</b>, select <b>Gaia DR3</b>, add the " +
         "<b>gdr3*.xpsd</b> files and click <b>OK</b>." );
   }
   this.gaiaDatabaseText = this.gaiaInformation.text;
   this.gaiaDatabaseToolTip = gaiaStatus.ready ?
      InNovaTr( "The Gaia DR3 database files are configured and accessible." ) :
      String( gaiaStatus.error || InNovaTr( "Gaia DR3 is unavailable." ) );
   this.gaiaStartupVisible = true;
   this.gaiaInformation.toolTip = this.gaiaDatabaseToolTip;
   this.gaiaGroup.sizer.add( this.gaiaInformation );
   this.sharedStretchCheck=new CheckBox(this.gaiaGroup);
   this.sharedStretchCheck.text=InNovaTr("Shared stretch per filter (faster loading)");
   this.sharedStretchCheck.checked=true;
   this.sharedStretchCheck.onCheck=function(checked){
      if(self.previewLoading || self.sessionPreparing){this.checked=!checked;return;}
      self.stopBlinkTimer();self.updateBlinkButton(false);self.prefetchTimer.stop();
      let index=self.currentIndex;

      self.preview.setBitmap(null);self.detailBitmap=null;self.detailMode=false;
      self.frameCache.setStretchMode(checked);
      for(let item of self.items){item.previewError="";item.displayKey="";}

      self.sessionPreparing=false;self.stretchOnDemand=true;
      if(self.items.length)self.showIndex(Math.max(0,Math.min(index,self.items.length-1)));
      self.updateSummary();self.prefetchTimer.start();
   };
   this.gaiaGroup.sizer.add(this.sharedStretchCheck);

   this.sizer = new VerticalSizer;
   this.sizer.margin = 12;
   this.sizer.spacing = 9;
   this.sizer.add( header );
   this.sizer.add( center, 100 );
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add( buttons );
   this.sizer.add( this.gaiaGroup );

   this.sizer.addSpacing( 16 );

   this.updateLoadingControls = function()
   {

      let loading=self.sessionPreparing;
      for(let control of [self.loadButton,self.sessionFolderButton,self.tree,
         self.previewFrame,self.processorCombo,self.calibrationButton,
         self.blinkDelaySpin,self.sharedStretchCheck]) control.enabled=!loading;
      if(loading) for(let control of [self.rejectButton,self.resetButton,
         self.zoomInButton,self.fitButton,self.detailButton,self.panButton,
         self.zoomOutButton,self.allButton,self.quickStretchLinkButton,
         self.previousButton,self.playButton,self.nextButton,self.integrateButton])
         control.enabled=false;
      self.closeButton.enabled=true;
   };

   this.updateSummary = function()
   {
      let accepted = 0;
      for ( let i = 0; i < self.items.length; ++i )
         if ( self.items[i].accepted ) ++accepted;
      self.sharedStretchCheck.enabled = !self.sessionPreparing;
      self.integrateButton.enabled = !self.sessionPreparing && accepted >= 2;
      let allUsed = self.items.length > 0 && accepted == self.items.length;
      self.allButton.enabled = self.items.length > 0;
      self.allButton.icon = StartLauncherBitmap(allUsed ?
         "icons/deselect-all.svg" : "icons/select-all.svg");
      self.allButton.toolTip = InNovaTr(allUsed ?
         "Remove USE from all images" : "Mark all images as USE");
      let current = self.currentIndex >= 0 ? self.items[self.currentIndex] : null;
      self.quickStretchLinkButton.enabled = !!current &&
         current.bitmap != null && current.quickStretchToggleAvailable === true;
      self.quickStretchLinkButton.icon = StartQuickStretchLinkIcon(
         !current || current.quickStretchLinked !== true ).scaledTo(
            self.logicalPixelsToPhysical(26), self.logicalPixelsToPhysical(26));
      self.quickStretchLinkButton.toolTip = current && current.quickStretchLinked === true ?
         InNovaTr( "RGB channels: Linked · Click to unlink and recalculate Quick Stretch" ) :
         InNovaTr( "RGB channels: Unlinked · Click to link and recalculate Quick Stretch" );
      let summary = self.items.length == 0 ?
         InNovaTr( "Load the light subframes you want to review." ) :
         "<b>" + accepted + InNovaTr( " accepted</b> · " ) +
            (self.items.length - accepted) + InNovaTr( " rejected · " ) +
            self.items.length + InNovaTr( " total" ) +
            (current == null ? "" : " · <b>" +
             StartHTMLText( StartSubframeFileName( current.path ) ) + "</b>" +
            (current.camera && current.camera != "—" ?
                " · " + StartHTMLText( current.camera ) : ""));
      let summaryToolTip = self.items.length == 0 ?
         InNovaTr( "Load the light subframes you want to review." ) :
         accepted + InNovaTr( " accepted, " ) + (self.items.length - accepted) +
         InNovaTr( " rejected, " ) + self.items.length + InNovaTr( " total" ) +
         (current == null ? "" : "\n" +
          StartSubframeFileName( current.path ));
      if ( self.items.length > 0 )
         self.gaiaStartupVisible = false;
      if ( self.gaiaStartupVisible ) {
         self.gaiaInformation.text = self.gaiaDatabaseText + " - " + summary;
         self.gaiaInformation.toolTip = self.gaiaDatabaseToolTip +
            "\n\n" + summaryToolTip;
      }
      else {
         self.gaiaInformation.text = summary;
         self.gaiaInformation.toolTip = summaryToolTip;
      }
      self.rejectButton.enabled = self.tree.selectedNodes.length > 0;
      self.resetButton.enabled = self.items.length > 0;
      self.zoomInButton.enabled = current != null;
      self.fitButton.enabled = current != null;
      self.detailButton.enabled = current != null;
      self.panButton.enabled = current != null;
      self.zoomOutButton.enabled = current != null;
      self.previousButton.enabled = !self.sessionPreparing && self.items.length > 1;
      self.nextButton.enabled = !self.sessionPreparing && self.items.length > 1;
      self.playButton.enabled = !self.sessionPreparing && accepted > 1 && !self.items.some(function(item){return item.accepted && !!item.previewError;});
      if(accepted<2 && self.playButton.checked){self.stopBlinkTimer();self.updateBlinkButton(false);}
      self.updateLoadingControls();
      if(self.sessionPreparing)self.gaiaInformation.text="<b style=\"color:#72b8f4\">"+InNovaTr("Preparing… ")+self.items.filter(function(item){return item.previewReady || item.previewError;}).length+" / "+self.items.length+"</b>";
   };

   this.updateCalibrationButton = function()
   {
      let directories = self.calibrationDirectories;
      let selected = [];
      if ( directories.bias.length > 0 )
         selected.push( "Bias: " + directories.bias );
      if ( directories.darks.length > 0 )
         selected.push( "Darks: " + directories.darks );
      if ( directories.flats.length > 0 )
         selected.push( "Flats: " + directories.flats );
      self.calibrationButton.checked = selected.length > 0;
      self.calibrationButton.toolTip = selected.length > 0 ?
         InNovaTr( "Calibration folders selected:\n" ) + selected.join( "\n" ) +
            InNovaTr( "\n\nClick to change them." ) :
         InNovaTr( "Select optional Bias, Darks and Flats folders for FBPP/WBPP" );
   };

   this.updateRow = function( index )
   {
      if ( index < 0 || index >= self.items.length ||
           index >= self.tree.numberOfChildren ) return;
      let item = self.items[index];
      let node = self.tree.child( index );
      node.checked = item.accepted;
      node.setText( 2, StartExposureText( item.exposure ) );
      node.setText( 3, item.filter || "—" );
      node.setText( 4, item.width > 0 ?
         item.width + " × " + item.height : "—" );
      for ( let column = 0; column < 5; ++column )
         node.setTextColor( column, item.accepted ? 0xffe4e8ed : 0xffef8178 );
   };

   this.rebuildTree = function()
   {
      self.tree.clear();
      for ( let i = 0; i < self.items.length; ++i ) {
         let node = new TreeBoxNode( self.tree );
         node.__index__ = i;
         node.checkable = true;
         node.checked = self.items[i].accepted;
         node.setText( 1, StartSubframeFileName( self.items[i].path ) );
         self.updateRow( i );
      }
      self.updateSummary();
   };

   this.trimPreviewCache = function( protectedIndex )
   {
      self.frameCache.trim([self.items[protectedIndex]]);
   };

   this.showIndex = function( index )
   {
      if ( self.sessionPreparing || index < 0 || index >= self.items.length ) return;
      if(self.previewLoading) {
         self.pendingReviewIndex=index;
         self.stopBlinkTimer();self.updateBlinkButton(false);self.prefetchTimer.stop();
         return;
      }
      self.pendingReviewIndex=-1;
      self.stopBlinkTimer();self.updateBlinkButton(false);


      let preserveManualZoom = !self.preview.fitMode && !self.detailMode;
      self.detailMode=false;self.detailBitmap=null;
      let previousScale = self.preview.scale;
      let previousCenter = null;
      if ( preserveManualZoom && self.preview.scaledBitmap != null ) {
         let viewport = self.preview.viewport.viewport;
         let offset = self.preview.viewport.bitmapOffsetFor( self.preview );
         previousCenter = {
            x: (viewport.width/2 - offset.x)/self.preview.scaledBitmap.width,
            y: (viewport.height/2 - offset.y)/self.preview.scaledBitmap.height
         };
      }
      self.currentIndex = index;
      self.previewLoading = true;self.updateLoadingControls();
      let item = self.items[index];
      try {
         if ( item.bitmap == null ) {
            self.gaiaInformation.text = InNovaTr( "Loading preview <b>" ) +
               StartHTMLText( StartSubframeFileName( item.path ) ) + "</b>…";
            self.gaiaInformation.toolTip =
               InNovaTr( "Loading the selected subframe preview." );
            CoreApplication.processEvents();
            self.frameCache.prepare( item );
         }
         item.previewError="";
         self.frameCache.touch(item);
         let viewport=self.preview.viewport.viewport;
         let display=self.frameCache.display(item,viewport.width,viewport.height,
            preserveManualZoom ? previousScale : 0);
         self.preview.setBitmap(item.bitmap,item.width,item.height,display);
         self.trimPreviewCache(index);
         if ( preserveManualZoom && self.preview.bitmap != null ) {
            self.preview.fitMode=false;
            self.preview.scale=previousScale;
            if ( previousCenter != null &&
                 self.preview.scaledBitmap != null ) {
               let viewport = self.preview.viewport.viewport;
               self.preview.viewport.horizontalScrollPosition = Math.range(
                  Math.round( previousCenter.x*self.preview.scaledBitmap.width -
                     viewport.width/2 ),
                  0, self.preview.viewport.maxHorizontalScrollPosition );
               self.preview.viewport.verticalScrollPosition = Math.range(
                  Math.round( previousCenter.y*self.preview.scaledBitmap.height -
                     viewport.height/2 ),
                  0, self.preview.viewport.maxVerticalScrollPosition );
               viewport.update();
            }
         }
         self.updateRow( index );
      } catch ( error ) {
         item.accepted = false;
         item.error = String( error );
         self.preview.setBitmap( null );
         self.updateRow( index );
         new InNovaNotice( InNovaTr( "The subframe could not be previewed and has been " +
            "rejected.\n\n" ) + item.path + "\n\n" + error,
            InNovaTr( "InNova Subframe Review & Integration" ), StdIcon_Warning, StdButton_Ok ).execute();
      }
      self.previewLoading = false;
      if(self.closeRequested){self.stopPreviewSession();self.cancel();return;}
      if(self.pendingReviewIndex>=0 && self.pendingReviewIndex!==index) {
         let requested=self.pendingReviewIndex;self.pendingReviewIndex=-1;
         self.showIndex(requested);return;
      }
      self.pendingReviewIndex=-1;
      let node = self.tree.child( index );
      if ( node != null ) {
         self.tree.currentNode = node;
         node.selected = true;
      }
      self.updateSummary();
      if(self.stretchOnDemand)self.prefetchTimer.start();
   };

   this.setSelectedState = function( accepted )
   {
      let nodes = self.tree.selectedNodes;
      for ( let i = 0; i < nodes.length; ++i ) {
         let index = nodes[i].__index__;
         if ( index >= 0 && index < self.items.length ) {
            self.items[index].accepted = accepted;
            self.updateRow( index );
            if ( !accepted ) nodes[i].selected = false;
         }
      }
      self.updateSummary();
   };

   this.tree.onCurrentNodeUpdated = function( node )
   {
      if ( node != null && node.__index__ != self.currentIndex )
         self.showIndex( node.__index__ );
   };
   this.tree.onNodeUpdated = function( node, column )
   {
      if ( column != 0 || node == null ) return;
      let index = node.__index__;
      if ( index >= 0 && index < self.items.length ) {
         self.items[index].accepted = node.checked;
         self.updateRow( index );
         self.updateSummary();
      }
   };
   this.tree.onNodeDoubleClicked = function( node )
   {
      if ( node == null ) return;
      let index = node.__index__;
      self.items[index].accepted = !self.items[index].accepted;
      self.updateRow( index );
      self.updateSummary();
   };

   this.addLightPaths = function( paths )
   {
      if(self.previewLoading)return 0;
      self.stopBlinkTimer();self.updateBlinkButton(false);
      let known = {};
      for ( let i = 0; i < self.items.length; ++i )
         known[self.items[i].path] = true;
      let added = 0;
      for ( let i = 0; i < paths.length; ++i ) {
         let path = String( paths[i] );
         if ( known[path] ) continue;
         known[path] = true;
         self.items.push( { path: path, accepted: true, bitmap: null,
            previewUsed: 0, width: 0, height: 0, channels: 0,
            exposure: NaN, filter: "—", camera: "—", error: "" } );
         ++added;
      }
      if(added) {
         self.sessionPreparing=true;self.currentIndex=-1;
         self.preview.setBitmap(null);self.detailBitmap=null;self.detailMode=false;
      }
      self.rebuildTree();
      if (added) self.prefetchTimer.start();
      return added;
   };

   this.loadButton.onClick = function()
   {
      if(self.previewLoading)return;
      let open = new OpenFileDialog;
      open.multipleSelections = true;
      open.caption = InNovaTr( "InNova Subframe Review & Integration — Load light subframes" );
      open.filters = StartSubframeSupportedFilters();
      if ( !open.execute() ) return;
      self.addLightPaths( open.filePaths );
   };
   this.sessionFolderButton.onClick = function()
   {
      if(self.previewLoading)return;
      let chooser = new GetDirectoryDialog;
      chooser.caption =
         InNovaTr( "InNova Subframe Review & Integration — Add session folder" );
      chooser.initialPath = File.homeDirectory;
      if ( !chooser.execute() ) return;
      let paths = StartSubframeCollectSessionFiles( chooser.directory );
      if ( paths.length == 0 ) {
         new InNovaNotice( InNovaTr( "No supported light subframes were found in this " +
            "folder or its subfolders." ),
            InNovaTr( "InNova Subframe Review & Integration" ), StdIcon_Information,
            StdButton_Ok ).execute();
         return;
      }
      self.addLightPaths( paths );


      self.updateSummary();
   };
   this.rejectButton.onClick = function()
   {
      if(self.previewLoading)return;
      let nodes = self.tree.selectedNodes;
      if ( nodes.length == 0 && self.tree.currentNode != null )
         nodes = [ self.tree.currentNode ];
      if ( nodes.length == 0 ) return;
      let answer = StartAskCenteredQuestion(
         InNovaTr( "✦ InNova Subframe Review & Integration — Remove selected images" ),
         InNovaTr( "Do you want to remove the selected images from the list?" ), true );
      if ( answer != StdButton_Yes ) return;
      self.stopBlinkTimer();
      self.updateBlinkButton( false );
      let indices = [];
      for ( let i = 0; i < nodes.length; ++i )
         indices.push( nodes[i].__index__ );
      indices.sort( function( a, b ) { return b - a; } );
      let nextIndex = indices[indices.length - 1];
      for ( let i = 0; i < indices.length; ++i ) {
         let index = indices[i];
         if ( index < 0 || index >= self.items.length ) continue;
         self.frameCache.invalidate(self.items[index]);
         let cacheIndex=self.frameCache.entries.indexOf(self.items[index]);
         if(cacheIndex>=0)self.frameCache.entries.splice(cacheIndex,1);
         self.items.splice( index, 1 );
      }
      self.prefetchTimer.stop();
      self.detailBitmap=null;self.detailMode=false;
      self.currentIndex = -1;
      self.rebuildTree();
      if ( self.items.length > 0 ) {
         self.showIndex( Math.min( nextIndex, self.items.length - 1 ) );
         self.prefetchTimer.start();
      }
      else {
         self.preview.setBitmap( null );
         self.updateSummary();
      }
   };
   this.resetButton.onClick = function()
   {
      if(self.previewLoading)return;
      self.stopBlinkTimer();
      self.updateBlinkButton( false );
      self.items = [];
      self.sessionPreparing=false;
      self.currentIndex = -1;
      self.masterPaths = [];
      self.cleanupDirectory = "";
      self.calibrationDirectories = { bias: "", darks: "", flats: "" };
      self.calibrationChoiceMade = false;
      self.prefetchTimer.stop();
      self.frameCache.dispose();
      self.frameCache=new StartSubframePreviewCache;
      self.frameCache.sharedStretch=self.sharedStretchCheck.checked;
      self.detailBitmap=null;self.detailMode=false;
      self.preview.setBitmap( null );
      self.preview.scale = 1;
      self.tree.clear();
      self.updateCalibrationButton();
      self.updateSummary();
   };
   this.allButton.onClick = function()
   {
      if (self.items.length == 0) return;
      let useAll = !self.items.every(function(item) { return item.accepted; });
      for (let i = 0; i < self.items.length; ++i) {
         self.items[i].accepted = useAll;
         self.updateRow(i);
      }
      self.updateSummary();
   };
   this.zoomInButton.onClick = function()
   {
      self.stopBlinkTimer();self.updateBlinkButton(false);
      self.preview.setZoom( self.preview.scale*1.35 );
   };
   this.panButton.onClick = function( checked )
   {
      self.preview.panEnabled = checked;
      self.preview.scrolling = null;
      self.preview.viewport.viewport.cursor = new Cursor( checked ?
         StdCursor_OpenHand : StdCursor_Arrow );
   };
   this.zoomOutButton.onClick = function()
   {
      self.stopBlinkTimer();self.updateBlinkButton(false);
      self.preview.setZoom( self.preview.scale/1.35 );
   };
   this.previousButton.onClick = function()
   {
      if ( self.items.length > 0 ) self.showIndex(
         ((self.pendingReviewIndex>=0?self.pendingReviewIndex:self.currentIndex) - 1 + self.items.length)%self.items.length );
   };
   this.nextButton.onClick = function()
   {
      if ( self.items.length > 0 ) self.showIndex(
         ((self.pendingReviewIndex>=0?self.pendingReviewIndex:self.currentIndex) + 1)%self.items.length );
   };


   this.prefetchTimer = new Timer;
   this.prefetchTimer.interval = 0.01;
   this.prefetchTimer.periodic = false;
   this.prepareAhead = function()
   {
      if(self.previewClosed || self.previewLoading || !self.items.length)return;
      if(self.sessionPreparing) {
         let pending=-1,completed=0;
         for(let i=0;i<self.items.length;++i) {
            if(self.items[i].previewReady || self.items[i].previewError)++completed;
            else if(pending<0)pending=i;
         }
         if(pending<0) {
            self.sessionPreparing=false;
            let first=self.items.findIndex(function(item){return item.previewReady && !item.previewError;});
            if(first>=0)self.showIndex(first);
            self.updateSummary();
            if(self.items.some(function(item){return !!item.previewError;}))
               self.gaiaInformation.text=InNovaTr("Some previews could not be prepared. Select the affected images to retry.");
            self.prefetchTimer.start();
            return;
         }
         self.previewLoading=true;self.updateLoadingControls();
         try {

            self.frameCache.prepare(self.items[pending]);
            self.frameCache.trim([self.items[pending]]);
         } catch(error) {
            self.items[pending].previewError=String(error);self.items[pending].accepted=false;
            console.warningln("Blink preview: "+self.items[pending].path+": "+error);
         } finally {self.previewLoading=false;}
      if(self.closeRequested){self.stopPreviewSession();self.cancel();return;}
         self.updateRow(pending);
         self.gaiaInformation.text="<b style=\"color:#72b8f4\">"+InNovaTr("Preparing… ")+(completed+1)+" / "+self.items.length+"</b>";
         self.prefetchTimer.start();
         return;
      }
      let pending=-1,ready=0;
      for(let item of self.items)if(item.previewReady)++ready;
      let playing=self.playButton.checked;
      let viewport=self.preview.viewport.viewport,scale=0;
      let aheadIndices=[],buffered=0;
      for(let n=1;n<=self.items.length && aheadIndices.length<8;++n) {
         let i=(Math.max(0,self.currentIndex)+n)%self.items.length;
         if(!playing || self.items[i].accepted!==false)aheadIndices.push(i);
      }
      if(playing && aheadIndices.length<2){self.stopBlinkTimer();self.updateBlinkButton(false);return;}

      for(let i of aheadIndices) {
         let item=self.items[i];
         if(item.previewError) {
            if(playing){self.stopBlinkTimer();self.updateBlinkButton(false);self.gaiaInformation.text=InNovaTr("Some previews could not be prepared. Select the affected images to retry.");return;}
            continue;
         }
         let key=item.bitmap ? viewport.width+":"+viewport.height+":"+Math.range(Math.min(Math.max(10,viewport.width-8)/item.bitmap.width,Math.max(10,viewport.height-8)/item.bitmap.height),0.03,8) : "";
         if(item.bitmap && item.displayBitmap && item.displayKey===key)++buffered;
         else {pending=i;break;}
      }
      if(playing && buffered>=Math.min(4,aheadIndices.length))self.startBlinkTimer();
      if(pending<0 && !playing && !self.stretchOnDemand) {

         for(let n=1;n<=self.items.length;++n) {
            let i=(Math.max(0,self.currentIndex)+n)%self.items.length;
            if(!self.items[i].previewReady && !self.items[i].previewError){pending=i;break;}
         }
      }
      if(pending<0)return;
      let wasReady=self.items[pending].previewReady===true;
      self.previewLoading=true;self.updateLoadingControls();
      try {
         let item=self.items[pending];
         self.frameCache.prepare(item);
         self.frameCache.display(item,viewport.width,viewport.height,scale);

         let protectedItems=[self.items[self.currentIndex],item];
         for(let i of aheadIndices)protectedItems.push(self.items[i]);
         self.frameCache.trim(protectedItems);
         self.updateRow(pending);
      } catch(error) {
         let item=self.items[pending];item.bitmap=null;item.displayBitmap=null;
         item.previewError=String(error);
         console.warningln("Blink preview: "+item.path+": "+error);
      } finally { self.previewLoading=false; }
      if(self.closeRequested){self.stopPreviewSession();self.cancel();return;}
      if(self.pendingReviewIndex>=0) {
         let requested=self.pendingReviewIndex;self.pendingReviewIndex=-1;
         self.showIndex(requested);return;
      }
      self.updateSummary();

      if(playing && !self.playButton.checked)return;
      if(!playing && !self.stretchOnDemand && ready<self.items.length) {
         self.gaiaInformation.text=InNovaTr("Preparing Blink previews: ")+
            (ready+(!wasReady && self.items[pending].previewReady?1:0))+" / "+self.items.length;
      }
      if(!self.previewClosed)self.prefetchTimer.start();
   };
   this.prefetchTimer.onTimeout = function(){self.prepareAhead();};
   this.showPreparedIndex = function(index)
   {
      let item=self.items[index];
      if(!item || !item.bitmap || !item.displayBitmap)return false;
      let started=Date.now(), manual=!self.preview.fitMode;
      let sx=self.preview.viewport.horizontalScrollPosition,sy=self.preview.viewport.verticalScrollPosition;
      self.currentIndex=index;
      for(let selected of self.tree.selectedNodes)selected.selected=false;
      self.preview.setBitmap(item.bitmap,item.width,item.height,item.displayBitmap);
      if(manual) {
         self.preview.fitMode=false;
         self.preview.viewport.horizontalScrollPosition=Math.min(sx,self.preview.viewport.maxHorizontalScrollPosition);
         self.preview.viewport.verticalScrollPosition=Math.min(sy,self.preview.viewport.maxVerticalScrollPosition);
      }
      self.frameCache.touch(item);
      let node=self.tree.child(index);if(node){self.tree.currentNode=node;node.selected=true;}

      self.gaiaInformation.text=(index+1)+" / "+self.items.length+" · "+
         StartHTMLText(StartSubframeFileName(item.path));
      ++self.frameCache.stats.displayed;
      self.frameCache.stats.displayMilliseconds+=Date.now()-started;
      return true;
   };

   this.blinkTimer = new Timer;
   this.blinkTimer.interval = this.blinkDelaySpin.value/1000;
   this.blinkTimer.periodic = true;
   this.blinkActive=false;
   this.startBlinkTimer=function(){
      if(!self.blinkActive){self.blinkActive=true;self.blinkTimer.start();}
   };
   this.stopBlinkTimer=function(){self.blinkActive=false;self.blinkTimer.stop();};
   this.blinkTimer.onTimeout = function()
   {
      if ( !self.playButton.checked || self.items.length < 2 ) {
         self.stopBlinkTimer();
         self.updateBlinkButton( false );
         return;
      }
      if(self.previewLoading)return;
      let next=-1;
      for(let n=1;n<=self.items.length;++n) {
         let i=(self.currentIndex+n)%self.items.length;
         if(self.items[i].accepted!==false){next=i;break;}
      }
      if(next<0 || next===self.currentIndex){self.stopBlinkTimer();self.updateBlinkButton(false);return;}
      if(!self.showPreparedIndex(next)) {
         ++self.frameCache.stats.bufferWaits;
         self.stopBlinkTimer();
      }
      self.prefetchTimer.start();
   };
   this.blinkDelaySpin.onValueUpdated = function( value )
   {
      self.blinkTimer.interval = value/1000;
      if ( self.playButton.checked ) {
         self.stopBlinkTimer();
         self.startBlinkTimer();
      }
   };
   this.playButton.onClick = function( checked )
   {
      if(self.sessionPreparing || (checked && self.items.filter(function(item){return item.accepted!==false;}).length<2)){self.updateBlinkButton(false);return;}
      self.updateBlinkButton( checked );
      if ( checked ) {
         self.detailMode=false;self.detailBitmap=null;

         self.preview.fitMode=true;
         self.stopBlinkTimer();

         self.prefetchTimer.start();
      } else {
         self.stopBlinkTimer();self.prefetchTimer.stop();
         self.updateSummary();
         console.writeln("InNova Blink metrics: "+JSON.stringify(self.frameCache.stats));
      }
   };

   this.calibrationButton.onClick = function()
   {
      StartSubframeRequestCalibration(self, true);
      self.updateCalibrationButton();
   };

   this.integrateButton.onClick = function()
   {
      if(self.previewLoading)return;
      let selected = [];
      for ( let i = 0; i < self.items.length; ++i )
         if ( self.items[i].accepted ) selected.push( self.items[i].path );
      if ( selected.length < 2 ) {
         new InNovaNotice( InNovaTr( "Select at least two subframes to integrate." ),
            InNovaTr( "InNova Subframe Review & Integration" ), StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      let processorName = self.processorCombo.currentItem == 1 ?
         "WBPP" : "FBPP";
      if (StartAskCenteredQuestion(
         InNovaTr("InNova Subframe Review & Integration"),
         InNovaTr("Do you want to run the process?"), true) != StdButton_Yes) return;
      if (!StartSubframeRequestCalibration(self, false)) return;
      let output = StartSubframeAutomaticOutputDirectory( processorName );
      Settings.write( StartSubframeOutputDirectorySetting,
         DataType_String, output );
      self.stopBlinkTimer();
      self.updateBlinkButton( false );
      self.integrateButton.enabled = false;
      self.processorCombo.enabled = false;
      self.gaiaInformation.text = InNovaTr( "Starting " ) + processorName + "…";
      self.gaiaInformation.toolTip =
         processorName + InNovaTr( " is preparing the selected subframes." );
      CoreApplication.processEvents();
      self.prefetchTimer.stop();
      self.hide();
      let startedAt = Date.now();
      try {
         let result = StartRunBatchPreprocessingAutomation( selected, output,
            processorName, self.gaiaStatus.accessibleFilePaths,
            self.calibrationDirectories );
         if ( !result.succeeded )
            throw new Error( processorName +
               InNovaTr( " did not finish successfully.\n\n" ) +
               result.output.substring( Math.max( 0, result.output.length - 3000 ) ) );
         let masters = StartSubframeCollectRecentMasters( output, startedAt );
         if ( masters.length == 0 )
            throw new Error( processorName +
               InNovaTr( " finished, but no new master light could be identified in " +
               "the selected output directory." ) );
         let masterDirectory = StartSubframeMasterDirectory();
         let saveChoice = StartSubframeAskToSaveMasters( masterDirectory );
         if ( saveChoice.answer == StdButton_Yes ) {
            let saved = [];
            for ( let i = 0; i < masters.length; ++i ) {
               let target = StartSubframeUniqueMasterPath(
                  saveChoice.directory, masters[i] );
               File.copyFile( target, masters[i] );
               saved.push( target );
            }
            self.masterPaths = saved;
            try {
               StartSubframeRemoveTemporaryDirectory( output );
            } catch ( cleanupError ) {
               console.warningln( "** Warning: The temporary processing " +
                  "folder could not be removed: " + cleanupError );
            }
            console.noteln( "✅ Saved " + saved.length +
               " master file(s) in: " + saveChoice.directory );
         }
         else {
            self.masterPaths = masters;
            self.cleanupDirectory = output;
         }
         self.ok();
      } catch ( error ) {


         self.closeRequested = true;
         self.masterPaths = [];
         self.cancel();
         self.hide();
         new InNovaNotice( InNovaTr( "The selected subframes could not be integrated.\n\n" ) +
            error, InNovaTr( "InNova Subframe Review & Integration — " ) + processorName,
            StdIcon_Error, StdButton_Ok ).execute();
      }
   };
   this.closeButton.onClick = function()
   {
      self.closeRequested=true;self.prefetchTimer.stop();self.stopBlinkTimer();
      if(self.previewLoading)return;
      self.stopPreviewSession();self.cancel();
   };
   this.onClose = function()
   {
      if(self.previewLoading){self.closeRequested=true;self.prefetchTimer.stop();self.stopBlinkTimer();return false;}
      self.stopPreviewSession();
      self.stopBlinkTimer();
      self.updateBlinkButton( false );
      return true;
   };

   this.stopPreviewSession = function() {
      self.previewClosed=true;self.prefetchTimer.stop();self.stopBlinkTimer();
      self.preview.setBitmap(null);self.detailBitmap=null;self.frameCache.dispose();
   };
   this.rebuildTree();
   this.updateCalibrationButton();
   this.adjustToContents();
   let screen = this.availableScreenRect;
   if ( screen ) {
      let width = Math.min( this.width, screen.x1 - screen.x0 - 40 );
      let height = Math.min( this.height, screen.y1 - screen.y0 - 60 );
      this.resize( width, height );
   }
   this.onShow = function() { StartPositionSubframeReview( this ); };
   StartPositionSubframeReview( this );
}
}

function StartRunSubframeReview( guidedWorkflow )
{
   if (!_0x8fd8025167("InNova Subframe Review & Integration"))
      return {masterPaths: [], cleanupDirectory: "", continueToBridge: false};
   let dialog = new InNovaSubframeReviewDialog( guidedWorkflow );
   let accepted=false;
   try { accepted = dialog.execute() == StdDialogCode_Ok; }
   finally {

      try { dialog.hide(); }
      finally { dialog.stopPreviewSession(); }
   }
   return { masterPaths: accepted ? dialog.masterPaths : [],
      cleanupDirectory: accepted ? dialog.cleanupDirectory : "",
      continueToBridge: accepted && dialog.masterPaths.length > 0 };
}
