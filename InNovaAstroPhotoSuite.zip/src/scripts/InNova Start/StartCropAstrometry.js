
function StartCropAstrometryScale(window)
{
   if (!window || window.isNull) return null;
   try {


      let metadata = new AstrometricMetadata("ImageSolver");
      metadata.focal = null;
      metadata.xpixsz = null;
      metadata.resolution = null;
      metadata.ExtractMetadata(window);
      let scale = metadata.resolution;
      if (MiraIsFiniteNumber(scale) && scale > 0) return scale;

      function number(name) {
         let entry = MiraWindowKeywordEntry(window, [name]);
         if (!entry) return null;
         let value = Number(entry.value.replace(/[dD]/g, "e"));
         return isFinite(value) ? value : null;
      }
      let unit1 = MiraWindowKeywordEntry(window, ["CUNIT1"]);
      let unit2 = MiraWindowKeywordEntry(window, ["CUNIT2"]);
      if ((!unit1 || /^deg(rees)?$/i.test(unit1.value)) &&
          (!unit2 || /^deg(rees)?$/i.test(unit2.value))) {
         let a = number("CD1_1"), b = number("CD1_2");
         let c = number("CD2_1"), d = number("CD2_2");
         if (a !== null && d !== null) {
            scale = (Math.sqrt(a*a + (b || 0)*(b || 0)) +
               Math.sqrt((c || 0)*(c || 0) + d*d))/2;
            if (scale > 0) return scale;
         }
         let x = number("CDELT1"), y = number("CDELT2");
         if (x && y) return (Math.abs(x) + Math.abs(y))/2;
      }
   } catch (e) {
      console.warningln("⚠️ Cannot read original image scale for " + window.mainView.id + ": " + e);
   }
   return null;
}

function StartCropAstrometryRetry(text)
{
   let escaped = String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/\n/g, "<br/>");
   return new MessageBox("<p align=\"center\">" + escaped + "</p>" +
      "<p align=\"center\">The cropped images have been kept.<br/>" +
      "Would you like to try again?</p>",
      "InNova Bridge — Astrometry", StdIcon_Warning,
      StdButton_Retry, StdButton_Cancel).execute() == StdButton_Retry;
}

function StartRestoreCropAstrometry(series, consoleVisibilityChanged)
{
   function setProcessConsoleVisible(visible)
   {
      if (visible) console.show();
      else console.hide();
      if (typeof consoleVisibilityChanged == "function")
         consoleVisibilityChanged(visible);
      CoreApplication.processEvents();
   }

   let previousTarget = "";
   while (true) {
   let pending = series.filter(function(item) {
      return !MiraHasAstrometricSolution(item.window);
   });
   if (pending.length == 0) {
      setProcessConsoleVisible(false);
      return "Astrometric solutions are available.";
   }
   try {
      let prompt = new Dialog;
      prompt.windowTitle = "🔭 InNova Bridge — Restore astrometry";
      prompt.sizer = new VerticalSizer;
      prompt.sizer.margin = 16;
      prompt.sizer.spacing = 12;
      let message = new Label(prompt);
      message.useRichText = true;
      message.textAlignment = TextAlign_Center;
      let singleImage = pending.length == 1;
      message.text = (singleImage ? "The cropped image has no valid astrometric solution.<br/>" :
         "The cropped images have no valid astrometric solution.<br/>") +
         "Cropping can remove the previous solution.<br/><br/>" +
         (singleImage ? "<b>Which object is shown in this image?</b><br/><br/>" :
            "<b>Which object is shown in these images?</b><br/><br/>") +
         "Enter a catalog name, such as M 31 or NGC 7000.<br/>" +
         "ImageSolver will resolve this target and solve the cropped " +
         (singleImage ? "image" : "images") + " automatically.";
      prompt.sizer.add(message);
      let target = new Edit(prompt);
      target.text = previousTarget;
      target.toolTip = "Object shared by the cropped image series";
      prompt.sizer.add(target);
      let buttons = new HorizontalSizer;
      buttons.spacing = 8;
      buttons.addStretch();
      let solve = new PushButton(prompt);
      solve.text = "Solve";
      solve.enabled = false;
      let cancel = new PushButton(prompt);
      cancel.text = "Cancel";
      buttons.add(solve);
      buttons.add(cancel);
      buttons.addStretch();
      prompt.sizer.add(buttons);
      function validate() {
         solve.enabled = target.text.trim().length > 0;
      }
      target.onTextUpdated = validate;
      validate();
      solve.onClick = function() { prompt.ok(); };
      cancel.onClick = function() { prompt.cancel(); };
      prompt.adjustToContents();
      if (prompt.execute() != StdDialogCode_Ok)
         return "Cropped images kept without astrometric solutions.";

      previousTarget = target.text.trim();


      setProcessConsoleVisible(true);
      let seed = MiraResolveSesameObject(previousTarget);
      if (!seed) throw new Error("The object name could not be resolved. Check the catalog name and Internet connection.");
      let failed = [];
      let solved = 0;
      for (let i = 0; i < pending.length; ++i) {
         let item = pending[i];
         try {
            console.noteln("🔭 Solving cropped image " + (i + 1) + "/" + pending.length + ": " + item.window.mainView.id);
            let solver = MiraPrepareAutomaticSolver(item.window, false, seed, 0);
            let resolution = item.astrometryScale;
            if (!MiraIsFiniteNumber(resolution) || resolution <= 0) {


               resolution = solver.metadata.resolution;
               if (solver.metadata.useFocal && solver.metadata.focal > 0 && solver.metadata.xpixsz > 0)
                  resolution = solver.metadata.ResolutionFromFocal(solver.metadata.focal);
               console.noteln("🔭 Original image scale unavailable; using ImageSolver configuration: " +
                  (resolution * 3600) + " arcsec/pixel.");
            }
            if (!MiraIsFiniteNumber(resolution) || resolution <= 0)
               throw new Error("Neither the image nor the ImageSolver configuration provides a usable scale.");
            solver.metadata.resolution = resolution;
            solver.metadata.useFocal = false;

            solver.solverCfg.generateDistortModel = false;
            solver.solverCfg.showStars = false;
            solver.solverCfg.showStarMatches = false;
            solver.solverCfg.showDistortion = false;
            solver.solverCfg.showSimplifiedSurfaces = false;
            solver.solveImage(item.window);
            if (!MiraHasAstrometricSolution(item.window))
               throw new Error("ImageSolver did not produce a valid solution.");
            ++solved;
         } catch (e) {
            failed.push(item.window.mainView.id);
            console.warningln("⚠️ Astrometry failed for " + item.window.mainView.id + ": " + e);
         }
      }

      setProcessConsoleVisible(false);
      if (failed.length) {
         if (StartCropAstrometryRetry("Automatic astrometry failed for " + failed.length +
            (failed.length == 1 ? " image." : " images.") +
            "\nSee the Process Console for details."))
            continue;
      }
      else if (solved > 0)
         new MessageBox("<p align=\"center\">Astrometric solution completed successfully.</p>" +
            "<p align=\"center\">" + solved + (solved == 1 ? " cropped image has" : " cropped images have") +
            " a valid astrometric solution.</p>",
            "InNova Bridge — Astrometry", StdIcon_Information, StdButton_Ok).execute();
      return "Astrometry restored for " + solved + " of " + pending.length + " cropped images.";
   } catch (e) {
      setProcessConsoleVisible(false);
      console.warningln("⚠️ Crop astrometry: " + e);
      if (StartCropAstrometryRetry(String(e))) continue;
      return "Cropped images kept; automatic astrometry could not be completed.";
   }
}
}
