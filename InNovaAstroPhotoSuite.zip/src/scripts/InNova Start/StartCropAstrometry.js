#include "../InNova/lib/InNovaEditorTheme.js"
#include "../InNova/lib/InNovaNotice.js"
#include "lib/OriginalCaptureScale.js"

function StartCropAstrometryScale(window)
{
   if (!window || window.isNull) return null;
   try {


      let metadata = new AstrometricMetadata("ImageSolver");
      metadata.focal = null;
      metadata.xpixsz = null;
      metadata.resolution = null;
      metadata.ExtractMetadata(window);
      let scale = metadata.resolution;
      if (MiraIsFiniteNumber(scale) && scale > 0) return scale;

      function number(name) {
         let entry = MiraWindowKeywordEntry(window, [name]);
         if (!entry) return null;
         let value = Number(entry.value.replace(/[dD]/g, "e"));
         return isFinite(value) ? value : null;
      }
      let unit1 = MiraWindowKeywordEntry(window, ["CUNIT1"]);
      let unit2 = MiraWindowKeywordEntry(window, ["CUNIT2"]);
      if ((!unit1 || /^deg(rees)?$/i.test(unit1.value)) &&
          (!unit2 || /^deg(rees)?$/i.test(unit2.value))) {
         let a = number("CD1_1"), b = number("CD1_2");
         let c = number("CD2_1"), d = number("CD2_2");
         if (a !== null && d !== null) {
            scale = (Math.sqrt(a*a + (b || 0)*(b || 0)) +
               Math.sqrt((c || 0)*(c || 0) + d*d))/2;
            if (scale > 0) return scale;
         }
         let x = number("CDELT1"), y = number("CDELT2");
         if (x && y) return (Math.abs(x) + Math.abs(y))/2;
      }

      if (MiraIsFiniteNumber(metadata.xpixsz) && metadata.xpixsz > 0 &&
          MiraIsFiniteNumber(metadata.focal) && metadata.focal > 0)
         return metadata.xpixsz / metadata.focal * 0.18 / Math.PI;

      let profile = MiraSmartTelescopeOpticalProfile(window);
      if (profile && profile.pixel > 0 && profile.focal > 0) {
         scale = profile.pixel / profile.focal * 0.18 / Math.PI;
         console.noteln("🔭 Image scale from " + profile.name + ": " + (scale * 3600) + " arcsec/pixel.");
         return scale;
      }
   } catch (e) {
      console.warningln("⚠️ Cannot read original image scale for " + window.mainView.id + ": " + e);
   }
   return typeof StartOriginalCaptureScale == "function" ? StartOriginalCaptureScale(window) : null;
}

var StartCropAstrometryRunProcessor = "__RUN_INNOVA_ASTRO_PROCESSOR__";

function StartCropAstrometryFailureAction(text, allowProcessorLaunch)
{
   let prompt = new Dialog; InNovaApplyBlackTheme(prompt);
   prompt.windowTitle = InNovaTr("🔭 InNova Bridge — Astrometric Solution");
   prompt.sizer = new VerticalSizer;
   prompt.sizer.margin = 16;
   prompt.sizer.spacing = 12;

   let header = StartLauncherPanel(prompt, true);
   header.setScaledFixedHeight(92);
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   header.sizer.add(StartLauncherIcon(header, "bridge", 68));
   let headerText = new VerticalSizer;
   headerText.spacing = 5;
   headerText.addStretch();
   headerText.add(StartLauncherLabel(header,
      InNovaTr("<b>Astrometric Solution</b>"), 20, "#102b50", false));
   headerText.add(StartLauncherLabel(header,
      InNovaTr("Restore the astrometric solution after cropping."),
      12, "#243f5b", false));
   headerText.addStretch();
   header.sizer.add(headerText, 100);
   prompt.sizer.add(header);

   let message = new Label(prompt);
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_Center;
   message.text =
      InNovaTr("<p align=\"center\"><b>Automatic astrometry could not be completed.</b></p>");
   message.setScaledMinWidth(620);
   prompt.sizer.add(message);
   let action = "cancel";
   let buttons = new HorizontalSizer;
   buttons.spacing = 8;
   buttons.addStretch();
   let retry = new PushButton(prompt);
   retry.text = InNovaTr("Retry");
   retry.icon = InNovaEditorLightActionIcon("reset");
   retry.setScaledFixedHeight(28);
   retry.onClick = function() { action = "retry"; prompt.ok(); };
   buttons.add(InNovaStyleBlackButton(retry));
   if ( allowProcessorLaunch === true ) {
      let run = new PushButton(prompt);
      run.text = InNovaTr("🚀  Run InNova Astro Processor");
      run.setScaledFixedHeight(28);
      run.onClick = function() { action = "processor"; prompt.ok(); };
      buttons.add(InNovaStyleBlackButton(run));
   }
   let cancel = new PushButton(prompt);
   cancel.text = InNovaTr("Cancel");
   cancel.icon = prompt.scaledResource( ":/icons/cancel.png" );
   cancel.setScaledFixedHeight(28);
   cancel.onClick = function() { action = "cancel"; prompt.cancel(); };
   buttons.add(InNovaStyleBlackButton(cancel));
   buttons.addStretch();
   InNovaAddDialogActionSpace(prompt, prompt.sizer); prompt.sizer.add(buttons);
   prompt.adjustToContents();
   prompt.execute();
   return action;
}


function StartCropAutomaticMetadata(item)
{
   try {
      let window = item.astrometrySolveWindow && !item.astrometrySolveWindow.isNull ?
         item.astrometrySolveWindow : item.window;
      if (!MiraWindowProvidesCoordinateMetadata(window)) return null;
      let metadata = new AstrometricMetadata("ImageSolver");
      metadata.ra = null; metadata.dec = null;
      metadata.ExtractMetadata(window);
      let scale = MiraIsFiniteNumber(item.astrometryScale) && item.astrometryScale > 0 ?
         item.astrometryScale : StartCropAstrometryScale(window);
      if (!MiraIsFiniteNumber(metadata.ra) || metadata.ra < 0 || metadata.ra >= 360 ||
          !MiraIsFiniteNumber(metadata.dec) || Math.abs(metadata.dec) > 90 ||
          !MiraIsFiniteNumber(scale) || scale <= 0) return null;
      return {seed:{ra:metadata.ra,dec:metadata.dec},scale:scale};
   } catch (error) { return null; }
}

function StartRestoreCropAstrometry(series, consoleVisibilityChanged,
   showApplyMultiNightPrompt, allowProcessorLaunch, progressChanged)
{
   function setProcessConsoleVisible(visible)
   {
      if (visible) console.show();
      else console.hide();
      if (typeof consoleVisibilityChanged == "function")
         consoleVisibilityChanged(visible);
      CoreApplication.processEvents();
   }

   let previousTarget = "";
   let automaticMetadataAttempted = false;
   while (true) {
   let pending = series.filter(function(item) {
      return !MiraHasAstrometricSolution(item.window);
   });
   if (pending.length == 0) {
      setProcessConsoleVisible(false);
      return InNovaTr("Astrometric solutions are available.");
   }
   try {


      pending.forEach(function(item) {
         if (MiraIsFiniteNumber(item.astrometryScale) && item.astrometryScale > 0) return;
         let candidates=[item.astrometrySolveWindow,item.window],source=item.source,visited=[];
         while(source && visited.indexOf(source)<0) {
            visited.push(source);candidates.push(source.window || source);source=source.source;
         }
         for(let candidate of candidates) {
            if(!candidate || candidate.isNull || !candidate.mainView)continue;
            let scale=StartCropAstrometryScale(candidate);
            if(MiraIsFiniteNumber(scale) && scale>0) {
               item.astrometryScale=scale;item.astrometryScaleManual=false;break;
            }
         }
      });
      let automaticByImage = !automaticMetadataAttempted ? pending.map(function(item) {
         return StartCropAutomaticMetadata(item);
      }) : [];
      let automatic = automaticByImage.length == pending.length &&
         automaticByImage.every(function(metadata) { return metadata != null; });
      automaticMetadataAttempted = true;
      let seed = automatic ? automaticByImage[0].seed : null;
      if (!seed) {
      let prompt = new Dialog; InNovaApplyBlackTheme(prompt);
      prompt.windowTitle = InNovaTr("🔭 InNova Bridge — Astrometric Solution");
      prompt.sizer = new VerticalSizer;
      prompt.sizer.margin = 16;
      prompt.sizer.spacing = 12;

      let header = StartLauncherPanel(prompt, true);
      header.setScaledFixedHeight(92);
      header.sizer = new HorizontalSizer;
      header.sizer.margin = 12;
      header.sizer.spacing = 16;
      header.sizer.add(StartLauncherIcon(header, "bridge", 68));
      let headerText = new VerticalSizer;
      headerText.spacing = 5;
      headerText.addStretch();
      headerText.add(StartLauncherLabel(header,
         InNovaTr("<b>Astrometric Solution</b>"), 20, "#102b50", false));
      headerText.add(StartLauncherLabel(header,
         InNovaTr("Restore the astrometric solution after cropping."),
         12, "#243f5b", false));
      headerText.addStretch();
      header.sizer.add(headerText, 100);
      prompt.sizer.add(header);

      let message = new Label(prompt);
      message.useRichText = true;
      message.textAlignment = TextAlign_Center;
      message.text = InNovaTr("<b>Enter the object name and click Solve.</b>");
      message.margin = 6;
      prompt.sizer.add(message);
      function styleAstrometryInput(edit) {
         if (InNovaWindowsButtonStyle())
            edit.styleSheet = InNovaStyleWithToolTips(
               'QLineEdit, QLineEdit:focus { ' +
               'background-color: #25282c; color: #e4e8ed; ' +
               'border: 1px solid #596573; border-image: none; background-image: none; ' +
               'selection-background-color: #0b78dc; selection-color: #ffffff; padding: 3px; }');
      }
      let target = new Edit(prompt);
      styleAstrometryInput(target);
      target.text = previousTarget;
      target.toolTip =
         InNovaTr("Enter a catalog name, such as M 31 or NGC 7000.");
      target.setScaledMinWidth(620);
      prompt.sizer.add(target);


      let scaleInput = null;
      if (pending.some(function(item) {
         return item.astrometryScaleManual || !MiraIsFiniteNumber(item.astrometryScale) || item.astrometryScale <= 0;
      })) {
         let label = new Label(prompt);
         label.text = InNovaTr("Project scale (arcsec/pixel):");
         prompt.sizer.add(label);
         scaleInput = new Edit(prompt);
         styleAstrometryInput(scaleInput);
         let knownScale = series.filter(function(item) {
            return MiraIsFiniteNumber(item.astrometryScale) && item.astrometryScale > 0;
         });
         scaleInput.text = knownScale.length ? String(knownScale[0].astrometryScale * 3600) : "";
         scaleInput.toolTip = InNovaTr("One scale for all registered images in this project, regardless of filter.");
         prompt.sizer.add(scaleInput);
      }
      function inputScale() {
         return scaleInput ? Number(scaleInput.text.trim().replace(",", ".")) : null;
      }
      let buttons = new HorizontalSizer;
      buttons.spacing = 8;
      buttons.addStretch();
      let solve = new PushButton(prompt);
      solve.text = InNovaTr("Solve");
      solve.icon = StartImageSolverIcon();
      solve.setScaledFixedHeight(28);
      solve.enabled = false;
      let cancel = new PushButton(prompt);
      cancel.text = InNovaTr("Cancel");
      cancel.icon = prompt.scaledResource( ":/icons/cancel.png" );
      cancel.setScaledFixedHeight(28);
      let examples = new Label(prompt);
      examples.useRichText = true;
      examples.textAlignment = TextAlign_Center;
      examples.text =
         InNovaTr("<span style=\"color:#c5deef\">Examples: M 42, NGC 6888, ") +
         "IC 1848, Barnard 150</span>";
      prompt.sizer.add(examples);
      buttons.add(InNovaStyleBlackButton(solve));
      buttons.add(InNovaStyleBlackButton(cancel));
      buttons.addStretch();
      InNovaAddDialogActionSpace(prompt, prompt.sizer); prompt.sizer.add(buttons);
      function validate() {
         solve.enabled = target.text.trim().length > 0 &&
            (!scaleInput || (MiraIsFiniteNumber(inputScale()) && inputScale() > 0));
      }
      target.onTextUpdated = validate;
      if (scaleInput) scaleInput.onTextUpdated = validate;
      validate();
      solve.onClick = function() { prompt.ok(); };
      cancel.onClick = function() { prompt.cancel(); };
      prompt.adjustToContents();
      if (prompt.execute() != StdDialogCode_Ok)
         return InNovaTr("Cropped images kept without astrometric solutions.");

      if (scaleInput) pending.forEach(function(item) {
         item.astrometryScale = inputScale() / 3600;
         item.astrometryScaleManual = true;
      });
      previousTarget = target.text.trim();


      setProcessConsoleVisible(true);
      if (typeof progressChanged == "function") progressChanged("Downloading...");
      seed = MiraResolveSesameObject(previousTarget, function() {
         if (typeof progressChanged == "function") progressChanged("Downloading...");
      });
      if (!seed) throw new Error(InNovaTr("The object name could not be resolved. Check the catalog name and Internet connection."));
      }
      setProcessConsoleVisible(true);
      if (typeof progressChanged == "function") progressChanged("Downloading...");
      let failed = [];
      let solved = 0;
      for (let i = 0; i < pending.length; ++i) {
         let item = pending[i];
         try {
            console.noteln("🔭 Solving cropped image " + (i + 1) + "/" + pending.length + ": " + item.window.mainView.id);
            let solveWindow = item.astrometrySolveWindow != null &&
               !item.astrometrySolveWindow.isNull ?
               item.astrometrySolveWindow : item.window;
            if (solveWindow !== item.window)
               console.noteln("🔭 Using an identically cropped linear proxy for ImageSolver.");
            let solver = MiraPrepareAutomaticSolver(solveWindow, false, automatic ? automaticByImage[i].seed : seed, 0);
            let resolution = automatic ? automaticByImage[i].scale : item.astrometryScale;
            if (!MiraIsFiniteNumber(resolution) || resolution <= 0)
               throw new Error(InNovaTr("Enter a valid image scale before solving."));
            solver.metadata.resolution = resolution;
            solver.metadata.useFocal = false;

            solver.solverCfg.generateDistortModel = false;
            solver.solverCfg.showStars = false;
            solver.solverCfg.showStarMatches = false;
            solver.solverCfg.showDistortion = false;
            solver.solverCfg.showSimplifiedSurfaces = false;


            solver.solverCfg.distortionCorrection = false;
            if (!MiraHasAstrometricSolution(solveWindow))
               solver.solveImage(solveWindow);
            if (solveWindow !== item.window &&
                !StartCopyAstrometricSolution(solveWindow, item.window))
               throw new Error(InNovaTr("The linear proxy solution could not be transferred to the cropped image."));
            if (!MiraHasAstrometricSolution(item.window))
               throw new Error(InNovaTr("ImageSolver did not produce a valid solution."));
            ++solved;
         } catch (e) {
            failed.push(item.window.mainView.id);
            console.warningln("⚠️ Astrometry failed for " + item.window.mainView.id + ": " + e);
         }
      }

      setProcessConsoleVisible(false);
      if (failed.length && automatic) continue;
      if (failed.length) {
         let failureAction = StartCropAstrometryFailureAction(
            InNovaTr("ImageSolver failed for ") + failed.length +
            (failed.length == 1 ? InNovaTr(" image.") : InNovaTr(" images.")) +
            InNovaTr("\nSee the Process Console for details."), allowProcessorLaunch);
         if (failureAction == "retry")
            continue;
         if (failureAction == "processor")
            return StartCropAstrometryRunProcessor;
      }
      else if (solved > 0) {
         let completedText = showApplyMultiNightPrompt === true ?
            InNovaTr("<p align=\"center\"><b>Process completed successfully.</b></p>") +
            InNovaTr("<p align=\"center\">Now click the <b>Apply Multi-night</b> button.</p>") :
            InNovaTr("<p align=\"center\">Astrometric solution completed successfully.</p>") +
            "<p align=\"center\">" + solved +
            (solved == 1 ? InNovaTr(" cropped image has") : InNovaTr(" cropped images have")) +
            InNovaTr(" a valid astrometric solution.</p>");
         new InNovaNotice(completedText,
            InNovaTr("InNova Bridge — Astrometry"), StdIcon_Information, StdButton_Ok).execute();
      }
      return InNovaTr("Astrometry restored for ") + solved + InNovaTr(" of ") + pending.length + InNovaTr(" cropped images.");
   } catch (e) {
      setProcessConsoleVisible(false);
      console.warningln("⚠️ Crop astrometry: " + e);
      let failureAction = StartCropAstrometryFailureAction(
         String(e), allowProcessorLaunch);
      if (failureAction == "retry") continue;
      if (failureAction == "processor")
         return StartCropAstrometryRunProcessor;
      return InNovaTr("Cropped images kept; automatic astrometry could not be completed.");
   }
}
}
