#include "../InNova/lib/InNovaEditorTheme.js"
#include "../InNova/lib/InNovaNotice.js"
#iflt __PI_VERSION__ 01.09.04

#ifndef INNOVA_START_PUBLIC_WRAPPER
#feature-id    InNovaStart : InNova Astro Photo Suite > InNova START
#feature-icon  InNovaStartIcon.svg
#feature-info  Guided workflow, image preparation and direct access to InNova modules.
#endif

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

new InNovaNotice( "InNova START requires PixInsight 1.9.4 or later.",
   "InNova START", StdIcon_Error, StdButton_Ok ).execute();

#else

#engine v8

console.clear();
console.writeln();
if (typeof InNovaInformationStandaloneSession !== "undefined" && InNovaInformationStandaloneSession)
   console.writeln("👽 Launching InNova Image Information");
else
   console.writeln("🚀 Launching InNova Astro Photo Suite.");
console.writeln();


#define TITLE "InNova Start"

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>
#include <pjsr/ImageOp.jsh>

var InNovaStartVersion = "v1.19.build 0356";

var OptionSeestar = "OFF";
var OptionSmartTelescopeModel = "SEESTAR_AUTO";
var InNovaStartRegisteredSuffix = "_InNovaStartRegistered";
var InNovaStartBrightTargetSuffix = "_InNovaStartBrightTarget";
var InNovaStartCropSuffix = "_InNovaStartCrop";
var InNovaStartHDRSuffix = "_InNovaStartHDR";
var InNovaStartIntegrationSuffix = "_InNovaStartIntegration";
var InNovaStartCombinedSuffix = "_combined";
var InNovaHandoffProjectSetting = "InNovaHandoffProjectType";
var InNovaHandoffAcquisitionSetting = "InNovaHandoffAcquisitionMode";
var InNovaHandoffObjectSetting = "InNovaHandoffObjectType";
var InNovaIntegratorHandoffPendingSetting =
   "InNovaGetStartedIntegratorHandoffPending";
var InNovaIntegratorHandoffProjectSetting =
   "InNovaGetStartedIntegratorProject";
var InNovaIntegratorHandoffImagePrefix =
   "InNovaGetStartedIntegratorImage_";
var InNovaIntegratorHandoffRgbStarsSetting =
   "InNovaGetStartedIntegratorRgbStars";
var InNovaIntegratorHandoffHaBlendSetting =
   "InNovaGetStartedIntegratorHaBlend";
var InNovaIntegratorHandoffNoticeShownSetting =
   "InNovaGetStartedIntegratorNoticeShown";
var InNovaIntegratorProcessSettingPrefix =
   "InNovaGetStartedIntegratorProcess_";
var ProjecTname = "✦ InNova Start";
var ProjecTver = InNovaStartVersion;


var _0x2d876a3211 = String.fromCharCode(50,53,97,100,49,49,120,106,114);
var _0xdb74725897 =
   String.fromCharCode(49,97,102,51,50,99,57,97,101,51,101,56,55,53,48,98,99,54,97,100,56,102,56,102,98,50,53,48,56,54,99,99,50,98,52,99,53,53,97,99,49,102,51,52,50,98,53,97,97,56,52,98,49,50,99,50,101,102,99,50,100,56,54,51);
var _0xbe2d41ec95 = "";
var _0xde359df820 = "EMPTY";
var _0x3d979369e7 = false;
var InNovaStartPreviewSerial = 0;
var InNovaStartBugLogActive = false;
var InNovaStartExistingConsoleText = "";

function StartBeginBugReportCapture()
{


   try {
      InNovaStartExistingConsoleText = String( console.logText() );
   } catch ( error ) {
      InNovaStartExistingConsoleText = "";
   }
   try {
      console.beginLog();
      InNovaStartBugLogActive = true;
   } catch ( error ) {
      InNovaStartBugLogActive = false;
   }
}

function StartBugReportBuildInformation()
{
   return [
      "InNova Start: " + InNovaStartVersion,
      "InNova Astro Processor: v1.19.build 0481",
         "InNova Photo Editor: v1.19.build 0248",
      "InNova Photo Editor engine: v1.19.build 0201",
      "InNova Smart Stretch: v1.19.build 0104",
      "PixInsight: " + CoreApplication.versionMajor + "." +
         CoreApplication.versionMinor + "." +
         CoreApplication.versionRelease + " build " +
         CoreApplication.versionBuild,
      "Platform: " + CoreApplication.platform
   ].join( "\n" );
}

function StartBugReportText()
{
   let currentConsoleText = "";
   try {
      currentConsoleText = String( console.logText() );
   } catch ( error ) {
      currentConsoleText = "";
   }
   let consoleText = currentConsoleText;
   if ( InNovaStartExistingConsoleText.length > 0 ) {
      if ( currentConsoleText.indexOf( InNovaStartExistingConsoleText ) < 0 )
         consoleText = InNovaStartExistingConsoleText +
            (currentConsoleText.length > 0 ? "\n" + currentConsoleText : "");
   }
   if ( consoleText.length == 0 )
      consoleText = "No console output was available for this session.";
   return "InNova Astro Photo Suite - Bug report\n" +
      "Generated: " + new Date().toISOString() + "\n\n" +
      "BUILDS\n------\n" + StartBugReportBuildInformation() +
      "\n\nPIXINSIGHT PROCESS CONSOLE\n--------------------------\n" +
      consoleText + "\n" + InNovaDiagnosticReport();
}

function StartOpenBugReportEmail(reportPath)
{
   let body = String.fromCharCode(80,108,101,97,115,101,32,97,116,116,97,99,104,32,116,104,101,32,115,97,118,101,100,32,114,101,112,111,114,116,32,109,97,110,117,97,108,108,121,58,10) + reportPath + "\n\n" + StartBugReportBuildInformation();
   return MiraOpenSupportMail("InNova Astro Photo Suite - Bug report", body);
}

var MiraDependencyEntry = #__FILE__;
#include "../InNova/lib/lite01.js"

#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaBridgeImageSolver"
#include "../InNova/lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Start"
#include "../InNova/lib/process12.js"
#include "StartCropAstrometry.js"
#include "lib/ImageReviewViewport.js"


var InNovaStartSuiteStatus = "Suite status unavailable";

function _0x690bbf5e93( paidModule )
{
   return InNovaLocalizedSuiteStatus((paidModule ? "" : "FREE · ") + InNovaStartSuiteStatus.replace( / · \d+ day\(s\)/g, "" ));
}

function _0x76b548f683()
{
   _0xbe2d41ec95 = "";
   _0xde359df820 = _0xcb30d9961f() ? String.fromCharCode(70,82,69,69,95,67,65,77,80,65,73,71,78) : String.fromCharCode(69,88,80,73,82,69,68);
   InNovaStartSuiteStatus = _0x9012890e39();
   return true;
}


#include "lib/SharedImageMetadata.js"
#include "../InNova Image Information/lib/InNovaInformation.js"


function StartExposureText( seconds )
{
   if ( !isFinite( seconds ) || seconds <= 0 )
      return "—";
   if ( seconds < 1 ) {
      let denominator = Math.round( 1/seconds );
      if ( denominator > 1 )
         return "1/" + denominator + " s";
   }
   return format( "%.6g s", seconds );
}

function StartElapsedRichText( elapsed )
{
   return InNovaTr( "<b style=\"color:#72b8f4\">⏱ Elapsed: " ) + elapsed + "</b>";
}

function StartSafeId( text )
{
   let id = String( text ).replace( /[^A-Za-z0-9_]/g, "_" );
   if ( id.length == 0 || !/[A-Za-z]/.test( id.charAt( 0 ) ) )
      id = "InNovaStart_" + id;
   return id;
}

function StartAuxiliaryReason( id )
{
   let value = String( id ).toLowerCase();


   if ( StartIsReusableBridgeOutput( id ) )
      return "";
   if ( value.indexOf( "registered" ) >= 0 ||
        value.indexOf( "innovastartcrop" ) >= 0 )
      return InNovaTr( "InNova Multi-Night or registration output" );
   let generatedTokens =
      /(^|_)(mask|preview|registered|crop|rejection|weight|background|starless|stars|abe|dbe)(_|[0-9]|$)/;
   if ( generatedTokens.test( value ) )
      return InNovaTr( "Auxiliary/generated image" );
   return "";
}

function StartIsReusableBridgeOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "innovastartregistered" ) >= 0 ||
      value.indexOf( "innovastartbrighttarget" ) >= 0 ||
      value.indexOf( "innovastartcrop" ) >= 0 ||
      value.indexOf( "innovastarthdr" ) >= 0 ||
      value.indexOf( "innovastartintegration" ) >= 0;
}

function StartIsTransientBridgeOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "innovastartpreview" ) >= 0 ||
      value.indexOf( "innovastartstarpreflight" ) >= 0 ||
      value.indexOf( "innovastarthdrfileinput" ) >= 0;
}

function StartIsGeneratedOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "registered" ) >= 0 ||
      value.indexOf( "innovastartbrighttarget" ) >= 0 ||
      value.indexOf( "innovastartcrop" ) >= 0 ||
      value.indexOf( "innovastarthdr" ) >= 0 ||
      value.indexOf( "innovastartintegration" ) >= 0 ||
      value.indexOf( "innovastartpreview" ) >= 0;
}

#include "lib/SharedWorkspaceIcons.js"


function StartSubframeMastersFolderIcon()
{
   return new Bitmap(":/icons/documents-import.png");
}


class StartCropInstructionDialog extends Dialog
{
constructor()
{
   super();
      InNovaApplyBlackTheme(this);
   let dialog = this;
   this.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Crop selection" );

   this.textLabel = new Label( this );
   this.textLabel.useRichText = true;
   this.textLabel.wordWrapping = true;
   this.textLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.textLabel.text =
      InNovaTr( "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">Draw a rectangle around the part of the image " +
      "you want to keep.</p>" +
      "<p align=\"center\">Everything outside the rectangle will be " +
      "cropped.</p>" +
      "<p align=\"center\"><b>Click the Crop icon again to confirm the " +
      "crop.</b></p>" );
   this.textLabel.minWidth = 520;
   this.textLabel.margin = 8;

   this.okButton = new PushButton( this );
   this.okButton.text = InNovaTr( "OK" );
   this.okButton.defaultButton = true;
   this.okButton.onClick = function() { dialog.ok(); };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = InNovaTr( "Cancel" );
   this.cancelButton.onClick = function() { dialog.cancel(); };

   let buttonRow = new HorizontalSizer;
   buttonRow.spacing = 8;
   buttonRow.addStretch();
   buttonRow.add( InNovaStyleBlackButton(this.okButton) );
   buttonRow.add( InNovaStyleBlackButton(this.cancelButton) );
   buttonRow.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 14;
   this.sizer.spacing = 10;
   this.sizer.add(InNovaBlackHeader(this, this.windowTitle));
   this.sizer.add( this.textLabel );
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add( buttonRow );
   this.adjustToContents();
}
}

function StartHTMLText( value )
{
   return String( value ).replace( /&/g, "&amp;" ).replace( /</g, "&lt;" )
      .replace( />/g, "&gt;" ).replace( /\"/g, "&quot;" );
}

class StartUnrelatedImagesDialog extends Dialog
{
constructor( referenceId, issues )
{
   super();
      InNovaApplyBlackTheme(this);
   let dialog = this;
   this.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Possible unrelated images" );

   this.message = new Label( this );
   this.message.useRichText = true;
   this.message.wordWrapping = true;
   this.message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let issueText = "";
   for ( let i = 0; i < issues.length && i < 8; ++i )
      issueText += "<p align=\"center\">• <b>" +
         StartHTMLText( issues[i].entry.id ) + "</b> — " +
         StartHTMLText( issues[i].reason ) + "</p>";
   if ( issues.length > 8 ) issueText += "<p align=\"center\">• …</p>";
   this.message.text =
      InNovaTr( "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">Some selected images may not belong to the " +
      "same project as the reference <b>" ) + StartHTMLText( referenceId ) +
      "</b>:</p>" + issueText +
      InNovaTr( "<p align=\"center\">Review the selection before continuing.</p>" +
      "<p align=\"center\"><b>Register them anyway?</b></p>" );
   this.message.minWidth = 650;
   this.message.margin = 10;

   this.yesButton = new PushButton( this );
   this.yesButton.text = InNovaTr( "Yes" );
   this.yesButton.defaultButton = true;
   this.yesButton.onClick = function() { dialog.ok(); };
   this.noButton = new PushButton( this );
   this.noButton.text = "No";
   this.noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(this.yesButton) );
   buttons.add( InNovaStyleBlackButton(this.noButton) );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 16;
   this.sizer.spacing = 10;
   this.sizer.add(InNovaBlackHeader(this, this.windowTitle));
   this.sizer.add( this.message );
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add( buttons );
   this.adjustToContents();
}
}

class StartAuxiliaryImagesDialog extends Dialog
{
constructor( entries )
{
   super();
      InNovaApplyBlackTheme(this);
   let dialog = this;
   this.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Project warning" );

   this.message = new Label( this );
   this.message.useRichText = true;
   this.message.wordWrapping = true;
   this.message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let names = "";
   for ( let i = 0; i < entries.length; ++i )
      names += "<p align=\"center\">• <b>" +
         StartHTMLText( entries[i].id ) + "</b></p>";
   this.message.text =
      InNovaTr( "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">These loaded images look auxiliary and were " +
      "left unchecked:</p>" ) + names +
      InNovaTr( "<p align=\"center\"><b>Do you want to delete them?</b></p>" +
      "<p align=\"center\">If you select Yes, they will not be added to " +
      "Input images and will be closed in PixInsight.</p>" +
      "<p align=\"center\"><b>The original files on disk will not be " +
      "deleted.</b></p>" );
   this.message.minWidth = 650;
   this.message.margin = 10;

   this.yesButton = new PushButton( this );
   this.yesButton.text = InNovaTr( "Yes" );
   this.yesButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.yesButton.defaultButton = false;
   this.yesButton.onClick = function() { dialog.ok(); };
   this.noButton = new PushButton( this );
   this.noButton.text = "No";
   this.noButton.defaultButton = true;
   this.noButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(this.yesButton) );
   buttons.add( InNovaStyleBlackButton(this.noButton) );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 16;
   this.sizer.spacing = 10;
   this.sizer.add(InNovaBlackHeader(this, this.windowTitle));
   this.sizer.add( this.message );
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add( buttons );
   this.adjustToContents();
}
}

function StartAskCenteredQuestion(
   title, text, showInformationIcon, boldText, brandIconName )
{
   title = InNovaTr(title); text = InNovaTr(text);
   if (boldText) boldText = InNovaTr(boldText);
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = title;

   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let paragraphs = String( text ).split( "\n\n" );
   let html = showInformationIcon && !brandIconName ?
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" : "";
   for ( let i = 0; i < paragraphs.length; ++i )
      html += "<p align=\"center\">" +
         StartHTMLText( paragraphs[i] ).replace( /\n/g, "<br/>" ) +
         "</p>";
   if ( boldText ) {
      let escapedBoldText = StartHTMLText( boldText );
      html = html.split( escapedBoldText ).join( "<b>" + escapedBoldText + "</b>" );
   }
   message.text = html;
   message.minWidth = 590;
   message.margin = 10;

   let yesButton = new PushButton( dialog );
   yesButton.text = InNovaTr("Yes");
   yesButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   yesButton.defaultButton = true;
   yesButton.onClick = function() { dialog.ok(); };
   let noButton = new PushButton( dialog );
   noButton.text = InNovaTr("No");
   noButton.icon = dialog.scaledResource( ":/icons/cancel.png" );
   noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(yesButton) );
   buttons.add( InNovaStyleBlackButton(noButton) );
   buttons.addStretch();
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 10;
   dialog.sizer.add(InNovaBlackHeader(dialog, title, "", brandIconName));
   dialog.sizer.add( message );
   InNovaAddDialogActionSpace(dialog, dialog.sizer); dialog.sizer.add( buttons );
   dialog.adjustToContents();
   let accepted = dialog.execute() == StdDialogCode_Ok;


   dialog.hide();
   CoreApplication.processEvents();
   return accepted ? StdButton_Yes : StdButton_No;
}

function StartShowMultiNightRegistrationWarning( referenceId, failed )
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Registration warning" );

   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.minWidth = 520;
   message.margin = 10;
   let failedHTML = [];
   for ( let i = 0; i < failed.length; ++i )
      failedHTML.push( "<span style=\"color:#c62828\"><b>" +
         StartHTMLText( failed[i] ) + "</b></span>" );
   message.text =
      InNovaTr( "<p align=\"center\"><span style=\"font-size:38pt;color:#e6a23c\">⚠</span></p>" +
      "<p align=\"center\">These images could not be registered to <b>" ) +
      StartHTMLText( referenceId ) + InNovaTr( "</b><br/>and may not belong to the project:</p>" +
      "<p align=\"center\">" ) + failedHTML.join( "<br/>" ) + InNovaTr( "</p>" +
      "<p align=\"center\">They have been excluded from common-crop " +
      "calculation.<br/>Successful registered copies are preserved.</p>" );

   let okButton = new PushButton( dialog );
   okButton.text = InNovaTr( "OK" );
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 110, 28 );
   okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(okButton) );
   buttons.addStretch();

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 8;
   dialog.sizer.add(InNovaBlackHeader(dialog, dialog.windowTitle));
   dialog.sizer.add( message );
   InNovaAddDialogActionSpace(dialog, dialog.sizer); dialog.sizer.add( buttons );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

function StartShowMultiNightCropRequired( heading, detailsHTML, instruction )
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Common crop required" );

   let background = StartLauncherPanel( dialog, false, true );
   background.setScaledFixedSize( 720, 330 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   let banner = StartLauncherPanel(background,true);banner.setScaledFixedHeight(112);
   let titleRow = new HorizontalSizer;
   titleRow.spacing = 16;
   titleRow.add( StartLauncherIcon( banner, "bridge", 76 ) );
   let titleText = new VerticalSizer;
   titleText.addStretch();
   titleText.add( StartLauncherLabel( banner,
      InNovaTr( "<b>Common crop required</b>" ), 20, "#102b50", false ) );
   titleText.add( StartLauncherLabel( banner,
      InNovaTr( "Create one common frame for the complete multi-night sequence." ),
      12, "#174675", false ) );
   titleText.addStretch();
   titleRow.add( titleText, 100 );
   banner.sizer = titleRow;banner.sizer.margin=8;
   background.sizer.add(banner);

   let information = StartLauncherPanel( background, false );
   information.sizer = new VerticalSizer;
   information.sizer.margin = 12;
   let message = new Label( information );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.text = "<p align=\"center\"><b>" + heading +
      "</b></p>" + detailsHTML +
      "<p align=\"center\"><span style=\"font-size:24pt\">✂️</span>" +
      "</p><p align=\"center\">" + instruction + "</p>";
   information.sizer.add( message, 100 );
   background.sizer.add( information, 100 );

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   let okButton = new PushButton( background );
   okButton.text = InNovaTr( "OK" );
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 120, 30 );
   okButton.onClick = function() { dialog.ok(); };
   buttons.add( InNovaStyleBlackButton(okButton) );
   buttons.addStretch();
   InNovaAddDialogActionSpace(background, background.sizer); background.sizer.add( buttons );

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

class StartMultiExposureDialog extends Dialog
{
constructor( acquisitionIndex, imageIds, finalSelection )
{
   super();
      InNovaApplyBlackTheme(this);
   let dialog = this;
   this.finalSelection = finalSelection === true;
   imageIds = imageIds instanceof Array ? imageIds : [ String( imageIds ) ];
   this.windowTitle = InNovaTr( "🔭 InNova Multi-Night — Multi-Night Combination" );

   this.header = StartLauncherPanel( this, true );
   this.header.setScaledFixedHeight( 92 );
   this.header.sizer = new HorizontalSizer;
   this.header.sizer.margin = 12;
   this.header.sizer.spacing = 16;
   this.header.sizer.add( StartLauncherIcon( this.header, "bridge", 68 ) );
   let headerText = new VerticalSizer;
   headerText.spacing = 4;
   headerText.addStretch();
   headerText.add( StartLauncherLabel( this.header,
      InNovaTr( "<b>Multi-Night Combination</b>" ), 20, "#102b50", false ) );
   headerText.add( StartLauncherLabel( this.header,
      InNovaTr( "Combine registered images from different nights or exposure levels." ),
      12, "#243f5b", false ) );
   headerText.addStretch();
   this.header.sizer.add( headerText, 100 );

   this.imagesGroup = new GroupBox( this );
   this.imagesGroup.title = InNovaTr( "Images" );
   this.imagesLabel = new Label( this.imagesGroup );
   this.imagesLabel.useRichText = true;
   this.imagesLabel.wordWrapping = true;
   this.imagesLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   let imageList = "";
   for ( let i = 0; i < imageIds.length; ++i )
      imageList += (i > 0 ? "<br/>" : "") + "<b>" +
         StartHTMLText( imageIds[i] ) + "</b>";
   for ( let i = imageIds.length; i < 4; ++i ) imageList += "<br/>&nbsp;";
   this.imagesLabel.text =
      (this.finalSelection ?
         InNovaTr( "The following images have been selected:" ) :
         InNovaTr( "The current image will be added to the combination:" )) +
      "<br/><br/>" + imageList;
   this.imagesLabel.minWidth = 700;
   this.imagesGroup.sizer = new VerticalSizer;
   this.imagesGroup.sizer.margin = 10;
   this.imagesGroup.sizer.add( this.imagesLabel );

   this.combinationLabel = new Label( this );
   this.combinationLabel.text = InNovaTr( "Combination type:" );
   this.acquisitionCombo = new ComboBox( this );
   this.acquisitionCombo.addItem( InNovaTr( "Multi-night integration" ) );
   this.acquisitionCombo.addItem( InNovaTr( "HDR (High Dynamic Range)" ) );
   this.acquisitionCombo.currentItem = acquisitionIndex == 2 ? 1 : 0;


   this.combinationLabel.visible = this.finalSelection;
   this.acquisitionCombo.visible = this.finalSelection;
   let combinationRow = new HorizontalSizer;
   combinationRow.spacing = 8;
   combinationRow.addStretch();
   combinationRow.add( this.combinationLabel );
   combinationRow.add( this.acquisitionCombo );
   combinationRow.addStretch();

   this.informationGroup = new GroupBox( this );
   this.informationGroup.title = InNovaTr( "Information" );
   this.informationLabel = new Label( this.informationGroup );
   this.informationLabel.useRichText = true;
   this.informationLabel.wordWrapping = true;
   this.informationLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.informationLabel.text =
      InNovaTr( "<p align=\"center\"><b>Select the images you want to combine.</b></p>" +
      "<p align=\"center\">Multi-night requires <b>at least 2 images</b>.<br/>" +
      "HDR requires <b>at least 3 images</b> with distinct exposure levels.</p>" +
      "<p align=\"center\">Images must have compatible geometry after " +
      "registration.<br/>Bracketed HDR images must provide consecutive " +
      "exposure values." ) +
      (this.finalSelection ?
         InNovaTr( "<br/><br/><span style=\"color:#d7191c\"><b>" +
         "Make sure the dimensions of the images to be combined are identical. " +
         "If they are not, crop the corners slightly before continuing." +
         "</b></span>" ) : "") + "</p>";
   this.informationGroup.sizer = new VerticalSizer;
   this.informationGroup.sizer.margin = 10;
   this.informationGroup.sizer.add( this.informationLabel );

   this.okButton = new PushButton( this );
   this.okButton.text = InNovaTr( "OK" );
   this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.okButton.defaultButton = true;
   this.cancelButton = new PushButton( this );
   this.cancelButton.text = InNovaTr( "Cancel" );
   this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancelButton.onClick = function() { dialog.cancel(); };
   this.okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.spacing = 12;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(this.okButton) );
   buttons.add( InNovaStyleBlackButton(this.cancelButton) );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 14;
   this.sizer.spacing = 10;
   this.sizer.add( this.header );
   this.sizer.add( this.imagesGroup );
   if ( this.finalSelection ) this.sizer.add( combinationRow );
   this.sizer.add( this.informationGroup );
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add( buttons );
   this.adjustToContents();
}
}

function StartNumericKeyword( window, names )
{
   let text = StartKeywordValue( window, names );
   let value = parseFloat( text );
   return isFinite( value ) ? value : NaN;
}

function StartWindowIdSet()
{
   let result = {};
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
      if ( windows[i] != null && !windows[i].isNull &&
           !windows[i].mainView.isNull )
         result[windows[i].mainView.id] = true;
   return result;
}

#include "lib/SharedCropGeometry.js"


function StartClassifyProject( entries, declaredMode )
{
   if ( entries.length == 0 )
      return { title: InNovaTr( "Empty project" ), insufficientHDRFilters: [],
         detail: InNovaTr( "No source image is selected." ) };
   if ( entries.length == 1 )
      return { title: InNovaTr( "Single image" ), insufficientHDRFilters: [], detail:
         InNovaTr( "One source image is selected; registration and HDR composition are not required." ) };

   let nights = {};
   let nightCount = 0;
   let datedCount = 0;
   let filters = {};
   let filterCount = 0;
   let exposureLevels = {};
   let measuredExposureCount = 0;
   let masterCount = 0;
   for ( let i = 0; i < entries.length; ++i ) {
      let entry = entries[i];
      let night = StartAstronomicalNight( entry.dateObs );
      if ( night.length > 0 ) {
         ++datedCount;
         if ( !nights[night] ) { nights[night] = true; ++nightCount; }
      }
      let filter = entry.filter == "—" ? "UNKNOWN" :
         String( entry.filter ).toUpperCase();
      if ( !filters[filter] ) { filters[filter] = true; ++filterCount; }
      if ( exposureLevels[filter] == null ) exposureLevels[filter] = {};
      if ( isFinite( entry.exposure ) && entry.exposure > 0 ) {
         ++measuredExposureCount;


         exposureLevels[filter][Math.round( 1000*entry.exposure )] = true;
      }
      if ( entry.isMaster ) ++masterCount;
   }

   let hdrFilters = [];
   let incompleteHDRFilters = [];
   for ( let filter in exposureLevels ) {
      let levelCount = 0;
      for ( let level in exposureLevels[filter] ) ++levelCount;
      if ( levelCount >= 3 ) hdrFilters.push( filter );
      else if ( levelCount == 2 ) incompleteHDRFilters.push( filter );
   }

   let title;
   if ( hdrFilters.length > 0 && filterCount > 1 )
      title = InNovaTr( "Multi-channel HDR project" );
   else if ( hdrFilters.length > 0 )
      title = InNovaTr( "HDR exposure series" );
   else if ( filterCount > 1 && nightCount > 1 )
      title = InNovaTr( "Multi-night, multi-channel project" );
   else if ( filterCount > 1 )
      title = InNovaTr( "Multi-channel image set — not HDR by exposure" );
   else if ( nightCount > 1 )
      title = InNovaTr( "Multi-night integration project" );
   else if ( nightCount == 1 && datedCount == entries.length )
      title = InNovaTr( "Single-night image set" );
   else
      title = InNovaTr( "Image set — acquisition night is uncertain" );

   let details = [];
   if ( nightCount > 0 ) details.push( nightCount + InNovaTr( " observing night(s)" ) );
   else details.push( InNovaTr( "DATE-OBS unavailable" ) );
   details.push( filterCount + InNovaTr( " filter/channel group(s)" ) );
   if ( hdrFilters.length > 0 )
      details.push( InNovaTr( "at least three exposure levels in " ) + hdrFilters.join( ", " ) );
   else if ( incompleteHDRFilters.length > 0 )
      details.push( InNovaTr( "only two exposure levels in " ) +
         incompleteHDRFilters.join( ", " ) +
         InNovaTr( "; InNova Multi-Night requires at least three for HDR" ) );
   else if ( measuredExposureCount == entries.length )
      details.push( InNovaTr( "no filter has multiple exposure levels" ) );
   else
      details.push( InNovaTr( "some exposure metadata is unavailable" ) );
   if ( masterCount > 0 )
      details.push( masterCount + InNovaTr( " probable integrated master(s)" ) );
   let declaredTitles = {
      SINGLE_NIGHT: InNovaTr( "One single night" ),
      MULTI_NIGHT: InNovaTr( "Multi-night" ),
      HDR: InNovaTr( "HDR (High Dynamic Range)" )
   };
   let declaredTitle = declaredTitles[declaredMode] || title;
   let mismatch = "";
   if ( declaredMode == "HDR" && hdrFilters.length == 0 )
      mismatch = incompleteHDRFilters.length > 0 ?
         InNovaTr( " Warning: HDR requires at least three compatible exposure levels; only two were detected." ) :
         InNovaTr( " Warning: metadata does not show at least three exposure levels within the same filter." );
   else if ( declaredMode == "SINGLE_NIGHT" && nightCount > 1 )
      mismatch = InNovaTr( " Warning: DATE-OBS indicates more than one observing night." );
   else if ( declaredMode == "MULTI_NIGHT" && nightCount == 1 &&
             datedCount == entries.length )
      mismatch = InNovaTr( " Warning: DATE-OBS currently indicates only one observing night." );
   return { title: declaredTitle, detectedTitle: title,
      insufficientHDRFilters: incompleteHDRFilters,
      detail: InNovaTr( "Selected treatment: " ) + declaredTitle + InNovaTr( ". Detected data: " ) +
         title + "; " + details.join( "; ") + "." + mismatch };
}


function StartSeriesSourceEntry( item )
{
   let source = item;
   while ( source != null && source.source != null )
      source = source.source;
   return source;
}


function StartSpccMessage( text, icon, title )
{
   let html = String( text )
      .replace( /&/g, "&amp;" )
      .replace( /</g, "&lt;" )
      .replace( />/g, "&gt;" )
      .replace( /\n/g, "<br/>" );
   new InNovaNotice( "<p align=\"center\">" + html + "</p>",
      title || InNovaTr( "InNova Multi-Night — SPCC" ),
      icon === undefined ? StdIcon_Warning : icon,
      StdButton_Ok ).execute();
}

function StartRunImageSolver( window, item, progress )
{
   if ( window == null || window.isNull || window.mainView.isNull ) {
      StartSpccMessage( InNovaTr( "ImageSolver cannot run because no valid image is selected." ),
         StdIcon_Warning, InNovaTr( "InNova Image Information - Imagesolver" ) );
      return false;
   }
   if ( window.mainView.image.isComplex ) {
      StartSpccMessage( InNovaTr( "ImageSolver cannot run on an image with complex samples." ),
         StdIcon_Warning, InNovaTr( "InNova Image Information - Imagesolver" ) );
      return false;
   }
   if ( MiraHasAstrometricSolution( window ) ) {
      StartSpccMessage( InNovaTr( "The selected image already has a valid astrometric solution." ),
         StdIcon_Information, InNovaTr( "InNova Image Information - Imagesolver" ) );
      return true;
   }

   let solver = new ImageSolver;
   let solverDialog = null;
   let accepted = false;
   try {
      window.show();
      window.bringToFront();
      for ( ;; ) {
         solver.initialize( window, false );
         let preparedProject = StartPreparedOscProject( item );
         let seestarProject = preparedProject.indexOf( "SEESTAR" ) == 0;
         let vaonisProject = preparedProject.indexOf( "VAONIS" ) == 0;
         OptionSeestar = seestarProject ? "ON" : "OFF";
         OptionSmartTelescopeModel = seestarProject || vaonisProject ?
            (preparedProject == "SEESTAR" ? "SEESTAR_AUTO" :
             (preparedProject == "VAONIS_VESPERA" ? "VAONIS_AUTO" :
              preparedProject)) : "NONE";
         if ( seestarProject || vaonisProject )
            MiraApplySmartTelescopeOpticalProfile( solver, window );
         solver.solverCfg.useActive = true;
         solverDialog = new ImageSolverDialog(
            solver.solverCfg, solver.metadata, true );
         if ( solverDialog.execute() ) {
            accepted = true;
            break;
         }
         if ( !solverDialog.resetRequest ) return false;
         solver = new ImageSolver;
      }

      if ( !accepted ) return false;
      solver.solverCfg = solverDialog.solverCfg;
      solver.solverCfg.useActive = true;
      solver.metadata = solverDialog.metadata;
      let preparedProject = StartPreparedOscProject( item );
      let seestarProject = preparedProject.indexOf( "SEESTAR" ) == 0;
      let vaonisProject = preparedProject.indexOf( "VAONIS" ) == 0;
      OptionSeestar = seestarProject ? "ON" : "OFF";
      OptionSmartTelescopeModel = seestarProject || vaonisProject ?
         (preparedProject == "SEESTAR" ? "SEESTAR_AUTO" :
          (preparedProject == "VAONIS_VESPERA" ? "VAONIS_AUTO" :
           preparedProject)) : "NONE";
      if ( seestarProject || vaonisProject )
         MiraApplySmartTelescopeOpticalProfile( solver, window );
      solver.solverCfg.SaveSettings();
      solver.metadata.SaveSettings();
      if ( typeof progress == "function" )
         progress( InNovaTr( "Running ImageSolver…" ) );
      console.show();
      console.noteln( "🔭 InNova Multi-Night: solving " + window.mainView.id );
      solver.solveImage( window );
      if ( !MiraHasAstrometricSolution( window ) )
         throw new Error( InNovaTr( "ImageSolver finished without a valid astrometric solution." ) );
      console.noteln( "✅ Astrometric solution detected: " + window.mainView.id );
      return true;
   } catch ( error ) {
      StartSpccMessage( InNovaTr( "ImageSolver could not solve the selected image.\n\n" ) +
         (error.message || error), StdIcon_Error,
         InNovaTr( "InNova Image Information - Imagesolver" ) );
      return false;
   }
}

function StartSpccSourceText( item )
{
   let window = item != null && item.window != null ? item.window : item;
   let source = StartSeriesSourceEntry( item );
   let sourceWindow = source != null && source.window != null ?
      source.window : source;
   let names = [ "CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION",
      "FILTER", "FILTERID", "INNVDEV" ];
   function collect( candidate ) {
      if ( candidate == null || candidate.isNull ) return "";
      let values = [];
      let keywords = candidate.keywords;
      for ( let i = 0; i < keywords.length; ++i ) {
         let keywordName = String( keywords[i].name ).toUpperCase();
         for ( let j = 0; j < names.length; ++j )
            if ( keywordName == names[j] ) {
               values.push( String( keywords[i].strippedValue ) );
               break;
            }
      }
      return values.join( " " );
   }
   return collect( window ) + " " + collect( sourceWindow ) + " " +
      (window != null && window.filePath ? String( window.filePath ) : "") + " " +
      (sourceWindow != null && sourceWindow.filePath ?
         String( sourceWindow.filePath ) : "");
}

function StartSpccProfileNames( item )
{
   let identity = StartSpccSourceText( item );
   let project = /VAONIS|VESPERA/i.test( identity ) ? "VAONIS_VESPERA" :
      (/SEESTAR|S30\s*PRO(?![A-Z0-9])|S50(?:\s*PRO)?(?![A-Z0-9])/i.test( identity ) ? "SEESTAR" : "OSC");
   let dualBand = /DUAL[ _-]*BAND|DUALBAND|DUO[ _-]*BAND|(^|[^A-Z])DB([^A-Z]|$)/i.test( identity );
   let lightPollution = /(^|[^A-Z])LP([^A-Z]|$)|LIGHT[ _-]*POLLUTION/i.test( identity );

   if ( project == "SEESTAR" ) {
      let root = lightPollution || dualBand ?
         "Seestar-LP-" : "Sony IMX 462-662-585-UVIRCut ";
      return { red: root + "R", green: root + "G", blue: root + "B",
         label: lightPollution || dualBand ? "Seestar LP" :
            "Seestar S50 (Sony IMX462 with UV/IR cut)",
         narrowband: dualBand };
   }

   if ( project == "VAONIS_VESPERA" ) {
      let model;
      if ( /VESPERA[^A-Z0-9]*PRO/i.test( identity ) )
         model = "Vaonis VESPERA Pro 2-";
      else if ( /VESPERA[^A-Z0-9]*(II|III|2|3)([^A-Z0-9]|$)/i.test( identity ) )
         model = "Vaonis VESPERA II, 3-";
      else
         return null;
      let filter = dualBand ? "Dual Band " : "CLS ";
      return { red: model + filter + "R", green: model + filter + "G",
         blue: model + filter + "B",
         label: model.replace( /-$/, "" ) + " " + filter.trim(),
         narrowband: dualBand };
   }
   return null;
}

function StartSpccDatabasePath( fileName )
{
   let root = CoreApplication.binDirPath.replace( /[\\\/]+bin[\\\/]?$/, "" );
   let candidates = [
      root + "/library/" + fileName,
      CoreApplication.binDirPath + "/../library/" + fileName
   ];
   for ( let i = 0; i < candidates.length; ++i )
      if ( File.exists( candidates[i] ) ) return candidates[i];
   return "";
}

function StartSpccXmlAttributeData( xml, tag, name )
{
   let escaped = String( name ).replace( /[.*+?^${}()|[\]\\]/g, "\\$&" );
   let expression = new RegExp( "<" + tag +
      "\\s+name=\"" + escaped + "\"[^>]*\\sdata=\"([^\"]+)\"" );
   let match = expression.exec( xml );
   return match != null ? match[1] : "";
}

function StartSpccLoadCurves( profile )
{
   let filterPath = StartSpccDatabasePath( "filters.xspd" );
   let whitePath = StartSpccDatabasePath( "white-references.xspd" );
   if ( filterPath.length == 0 || whitePath.length == 0 )
      return { error: InNovaTr( "SPCC cannot run because the PixInsight spectral databases could not be found." ) };
   try {
      let filters = File.readTextFile( filterPath );
      let whites = File.readTextFile( whitePath );
      let red = StartSpccXmlAttributeData( filters, "Filter", profile.red );
      let green = StartSpccXmlAttributeData( filters, "Filter", profile.green );
      let blue = StartSpccXmlAttributeData( filters, "Filter", profile.blue );
      let white = StartSpccXmlAttributeData( whites, "WhiteRef", "Average Spiral Galaxy" );
      if ( red.length == 0 || green.length == 0 || blue.length == 0 )
         return { error: InNovaTr( "SPCC cannot run because the required RGB response curves are missing from the PixInsight filter database.\n\nProfile: " ) + profile.label };
      if ( white.length == 0 )
         return { error: InNovaTr( "SPCC cannot run because the Average Spiral Galaxy white reference is missing from the PixInsight spectral database." ) };
      return { red: red, green: green, blue: blue, white: white };
   } catch ( error ) {
      return { error: InNovaTr( "SPCC cannot read the PixInsight spectral databases.\n\n" ) +
         (error.message || error) };
   }
}

function StartSpccLooksLinear( window, item )
{
   if ( item != null && item.alreadyStretched === true ) return false;
   let keywords = window.keywords;
   for ( let i = 0; i < keywords.length; ++i )
      if ( String( keywords[i].name ).toUpperCase() == "HISTORY" &&
           /HISTOGRAMTRANSFORMATION|MASKEDSTRETCH|GENERALIZEDHYPERBOLICSTRETCH|INNOVA[ _]?ADAPTIVE|INNOVA[ _]?PHOTO[ _]?EDITOR/i.test(
              String( keywords[i].strippedValue ) ) ) return false;
   try {
      let median = window.mainView.computeOrFetchProperty( "Median" );
      let channels = Math.min( 3, window.mainView.image.numberOfChannels );
      for ( let c = 0; c < channels; ++c )
         if ( median.at( c ) >= 0.25 ) return false;
   } catch ( ignored ) {}
   return true;
}

function StartCopyAstrometricSolution( source, target )
{
   if ( !MiraHasAstrometricSolution( source ) ) return false;
   let processing = false;
   try {
      let metadata = new AstrometricMetadata( "InNovaBridgeImageSolver" );
      metadata.ExtractMetadata( source );
      target.mainView.beginProcess(
         UndoFlag_Keywords | UndoFlag_AstrometricSolution );
      processing = true;
      metadata.SaveKeywords( target, false );
      metadata.SaveProperties( target, "InNova Multi-Night SPCC", "Gaia DR3/SP" );
      target.regenerateAstrometricSolution();
      target.mainView.endProcess();
      processing = false;
      return MiraHasAstrometricSolution( target );
   } catch ( error ) {
      if ( processing )
         try { target.mainView.endProcess(); } catch ( ignored ) {}
      console.warningln( "⚠️ Could not transfer the astrometric solution: " +
         (error.message || error) );
      return false;
   }
}

function StartConfigureSpccProcess( profile, curves, applyCalibration,
   generateGraphs )
{
   let process = new SpectrophotometricColorCalibration;
   process.applyCalibration = applyCalibration;
   process.generateGraphs = generateGraphs;


   process.narrowbandMode = false;
   process.whiteReferenceSpectrum = curves.white;
   process.whiteReferenceName = "Average Spiral Galaxy";
   process.redFilterTrCurve = curves.red;
   process.redFilterName = profile.red;
   process.greenFilterTrCurve = curves.green;
   process.greenFilterName = profile.green;
   process.blueFilterTrCurve = curves.blue;
   process.blueFilterName = profile.blue;
   process.deviceQECurve = "300,1,400,1,500,1,600,1,700,1,800,1,900,1,1000,1,1100,1";
   process.deviceQECurveName = "Ideal detector QE";
   process.catalogId = "GaiaDR3SP";
   return process;
}

function StartShowDeferredSpccReport( request )
{
   if ( request == null || request.window == null || request.window.isNull ||
        request.window.mainView.isNull )
      return false;
   let process = StartConfigureSpccProcess( request.profile, request.curves,
      false, true );
   if ( !process.canExecuteOn( request.window.mainView ) ) {
      StartSpccMessage(
         InNovaTr( "The SPCC White Balance Functions report could not be generated because its source image is no longer available." ) );
      return false;
   }
   try {
      console.show();
      console.noteln(
         "🌈 InNova Multi-Night: generating the SPCC White Balance Functions report…" );
      CoreApplication.processEvents();
      if ( !process.executeOn( request.window.mainView ) )
         throw new Error( InNovaTr( "SpectrophotometricColorCalibration did not complete." ) );
      console.hide();
      return true;
   } catch ( error ) {
      console.hide();
      StartSpccMessage( InNovaTr( "The SPCC White Balance Functions report could not be generated.\n\n" ) +
         (error.message || error), StdIcon_Error );
      return false;
   }
}

function StartRunSpccCopy( window, item, progress, deferredReport )
{
   if ( window == null || window.isNull || window.mainView.isNull ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because no valid image is selected." ) );
      return null;
   }
   let image = window.mainView.image;
   if ( !image.isColor || image.numberOfChannels < 3 ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because the selected image is not an RGB color image." ) );
      return null;
   }
   if ( image.isComplex ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run on an image with complex samples." ) );
      return null;
   }
   if ( !StartSpccLooksLinear( window, item ) ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because the selected image appears to be nonlinear or has already been stretched.\n\nSelect a linear image before applying any stretch." ) );
      return null;
   }
   if ( !MiraHasAstrometricSolution( window ) ) {
      let answer = StartAskCenteredQuestion(
         InNovaTr( "InNova Multi-Night — SPCC" ),
         InNovaTr( "SPCC requires a valid astrometric solution.\n\nWould you like to run ImageSolver now?" ),
         true,
         "ImageSolver" );
      if ( answer != StdButton_Yes )
         return null;
      if ( !StartRunImageSolver( window, item, progress ) ||
           !MiraHasAstrometricSolution( window ) )
         return null;
   }
   if ( typeof SpectrophotometricColorCalibration == "undefined" ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because SpectrophotometricColorCalibration is not installed in this PixInsight installation." ) );
      return null;
   }
   let gaia = MiraGaiaDr3SpStatus();
   if ( !gaia.processInstalled || !gaia.supported || !gaia.ready ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because the Gaia DR3/SP local database is not available or is not configured.\n\n" ) +
         (gaia.error || InNovaTr( "Configure valid Gaia DR3/SP XPSD files in the Gaia process." ) ) );
      return null;
   }
   let profile = StartSpccProfileNames( item );
   if ( profile == null ) {
      StartSpccMessage( InNovaTr( "SPCC cannot run because InNova could not identify a supported RGB sensor and filter profile for this image.\n\nAutomatic profiles are available for Seestar S30 Pro, S50 and Vaonis Vespera II, III and Pro images." ) );
      return null;
   }
   let curves = StartSpccLoadCurves( profile );
   if ( curves.error != null ) {
      StartSpccMessage( curves.error );
      return null;
   }


   let process = StartConfigureSpccProcess( profile, curves, true, false );
   if ( !process.canExecuteOn( window.mainView ) ) {
      StartSpccMessage( InNovaTr( "SPCC cannot execute on the selected image. Check that it is a linear RGB main view with a valid astrometric solution." ) );
      return null;
   }

   let copy = StartCloneWindow( window,
      window.mainView.id + "_InNovaSPCC" );
   if ( !StartCopyAstrometricSolution( window, copy ) ) {
      copy.forceClose();
      StartSpccMessage(
         InNovaTr( "SPCC cannot run because the astrometric solution could not be transferred to the image copy." ) );
      return null;
   }
   if ( !process.canExecuteOn( copy.mainView ) ) {
      copy.forceClose();
      StartSpccMessage(
         InNovaTr( "SPCC cannot execute on the image copy after transferring its astrometric solution." ) );
      return null;
   }
   try {
      if ( typeof progress == "function" )
         progress( InNovaTr( "Running SPCC color calibration…" ) );
      console.show();
      console.noteln( "🌈 InNova Multi-Night: applying SPCC to copy " +
         copy.mainView.id );
      console.writeln( "⚙️ RGB response profile: " + profile.label );
      CoreApplication.processEvents();
      if ( !process.executeOn( copy.mainView ) )
         throw new Error( InNovaTr( "SpectrophotometricColorCalibration did not complete." ) );
      if ( deferredReport != null ) {
         deferredReport.window = window;
         deferredReport.profile = profile;
         deferredReport.curves = curves;
      }
      copy.bringToFront();
      return copy;
   } catch ( error ) {
      if ( copy != null && !copy.isNull ) copy.forceClose();
      StartSpccMessage( InNovaTr( "SPCC could not calibrate the image.\n\n" ) +
         (error.message || error), StdIcon_Error );
      return null;
   }
}


function StartPreparedImagePriority( item )
{
   if ( item.kind == "HDR" ) return 50;
   if ( item.kind == "INTEGRATION" ) return 45;
   let window = item.window || item;
   let id = window != null && !window.isNull && !window.mainView.isNull ?
      String( window.mainView.id ).toLowerCase() : "";
   if ( id.indexOf( "innovastartcrop" ) >= 0 ) return 35;
   if ( id.indexOf( "registered" ) >= 0 ) return 25;
   return 10;
}


function StartShowMonochromeProcessorInformation()
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr("🔭 InNova Multi-Night — Monochrome images");
   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.minWidth = 620;
   message.margin = 10;
   message.text = InNovaTr(
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\"><b>InNova Astro Processor cannot process a " +
      "single monochrome image by itself.</b></p>" +
      "<p align=\"center\">To process monochrome data, select a complete " +
      "set of separate channel images, such as <b>Red, Green and Blue</b>." +
      "</p><p align=\"center\">Complete SHO or HOO narrowband channel " +
      "sets are also supported.</p>" +
      "<p align=\"center\">If you only have one file, select an integrated " +
      "RGB/OSC image.</p>" );
   let okButton = new PushButton( dialog );
   okButton.text = InNovaTr("OK");
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 92, 24 );
   okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(okButton) );
   buttons.addStretch();
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 10;
   dialog.sizer.add(InNovaBlackHeader(dialog, dialog.windowTitle));
   dialog.sizer.add( message );
   InNovaAddDialogActionSpace(dialog, dialog.sizer); dialog.sizer.add( buttons );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

function StartPrepareSubframeMastersForProcessor( windows )
{
   let items = [];
   for ( let i = 0; i < windows.length; ++i )
      items.push( StartImageEntry( windows[i] ) );
   if ( !StartProcessorSelectionSupportsMonochrome( items ) ) {
      StartShowMonochromeProcessorInformation();
      return false;
   }

   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   let assignments = {};
   for ( let i = 0; i < items.length; ++i ) {
      let key = StartPreparedChannelKey( items[i] );
      if ( key.length > 0 && assignments[key] == null )
         assignments[key] = windows[i].mainView.id;
   }
   let assigned = 0;
   for ( let i = 0; i < keys.length; ++i ) {
      let value = assignments[keys[i]] || "";
      Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
         DataType_String, value );
      if ( value.length > 0 ) ++assigned;
   }
   if ( assigned == 0 ) return false;

   let project = "OSC";
   if ( assignments.PimageSii && assignments.PimageHa &&
        assignments.PimageOiii )
      project = "SHO";
   else if ( assignments.PimageHa && assignments.PimageOiii )
      project = "HOO";
   else if ( assignments.PimageRed && assignments.PimageGreen &&
             assignments.PimageBlue && assignments.PimageLuminance )
      project = "LRGB";
   else if ( assignments.PimageRed && assignments.PimageGreen &&
             assignments.PimageBlue )
      project = "RGB";
   else if ( assignments.PimageOsc ) {
      for ( let i = 0; i < items.length; ++i )
         if ( windows[i].mainView.id == assignments.PimageOsc ) {
            project = StartPreparedOscProject( items[i] );
            break;
         }
   }

   Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffHaBlendSetting,
      DataType_String, "0" );
   Settings.write( InNovaHandoffProjectSetting, DataType_String, project );
   Settings.write( InNovaHandoffAcquisitionSetting,
      DataType_String, "SINGLE_NIGHT" );
   Settings.write( InNovaHandoffObjectSetting, DataType_String, "STARS" );
   Settings.write( InNovaIntegratorHandoffProjectSetting,
      DataType_String, project );
   Settings.write( InNovaIntegratorHandoffPendingSetting,
      DataType_String, "1" );
   console.noteln( "🚀 Guided Subframe handoff: " + assigned +
      " master image(s) assigned to InNova Astro Processor." );
   return true;
}

function StartPrepareProcessorLaunchWithoutImages()
{
   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   for ( let i = 0; i < keys.length; ++i )
      Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
         DataType_String, "" );
   let project = Settings.read( InNovaHandoffProjectSetting,
      DataType_String );
   if ( !Settings.lastReadOK || typeof project != "string" ||
        project.length == 0 )
      project = "OSC";
   Settings.write( InNovaIntegratorHandoffProjectSetting,
      DataType_String, project );
   Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffHaBlendSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffPendingSetting,
      DataType_String, "1" );
}

function StartShowProcessorHandoffInformation( mastersAssigned )
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr( "🔭 InNova Guided Workflow — Astro Processor" );
   let background = new Control( dialog );
   background.setScaledFixedWidth( 650 );
   background.setScaledMinHeight( 510 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   let headerPanel = StartLauncherPanel( background, true );
   headerPanel.setScaledFixedHeight( 92 );
   headerPanel.sizer = new VerticalSizer;
   headerPanel.sizer.margin = 12;
   let heading = new HorizontalSizer;
   heading.spacing = 16;
   heading.add( StartLauncherIcon( headerPanel, "astro-processor", 68 ) );
   let headingText = new VerticalSizer;
   headingText.spacing = 5;
   headingText.addStretch();
   headingText.add( StartLauncherLabel( headerPanel,
      "<b>InNova Astro Processor</b>", 20, "#102b50", false ) );
   headingText.add( StartLauncherLabel( headerPanel,
      InNovaTr( "Choose the modules you want to run." ), 12, "#174675", false ) );
   headingText.addStretch();
   heading.add( headingText, 100 );
   headerPanel.sizer.add( heading );
   background.sizer.add( headerPanel );

   let information = new Label( background );
   information.useRichText = true;
   information.wordWrapping = true;
   information.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   information.text =
      "<p align=\"center\"><span style=\"font-size:30pt;color:#2784b9\">" +
      "ⓘ</span></p>" +
      (mastersAssigned === true ?
         InNovaTr( "<p align=\"center\"><b>The master images have been assigned to " +
         "InNova Astro Processor.</b></p>" +
         "<p align=\"center\"><b>Check that the assigned images and channels " +
         "are correct, then choose the modules to execute.</b></p><br/><br/>" ) :
         InNovaTr( "<p align=\"center\"><b>Choose Basic or Advanced mode before " +
         "opening InNova Astro Processor.</b></p>" +
         "<p align=\"center\">Select your stacked image in Astro Processor, " +
         "then <b>check that the project and image assignment are correct.</b>" +
         "</p><br/><br/>" ));
   background.sizer.add( information );

   background.sizer.add( StartLauncherLabel( background,
      InNovaTr( "<b>Select the Astro Processor processing mode</b>" ),
      13, "#0869d6", true ) );

   let basicGroup = new GroupBox( background );
   basicGroup.title = InNovaTr( "Basic" );
   basicGroup.sizer = new VerticalSizer;
   basicGroup.sizer.margin = 10;
   let basic = new RadioButton( basicGroup );
   basic.text = InNovaTr( "Basic Mode:  Photo Editor" );
   basic.checked = true;
   let basicRow = new HorizontalSizer;
   basicRow.addStretch();
   basicRow.add( basic );
   basicRow.addStretch();
   basicGroup.sizer.add( basicRow );

   let advancedGroup = new GroupBox( background );
   advancedGroup.title = InNovaTr( "Advanced" );
   advancedGroup.sizer = new VerticalSizer;
   advancedGroup.sizer.margin = 10;
   advancedGroup.sizer.spacing = 5;
   let advanced = new RadioButton( advancedGroup );
   advanced.text = InNovaTr( "Advanced Mode:" );
   let advancedRow = new HorizontalSizer;
   advancedRow.addStretch();
   advancedRow.add( advanced );
   advancedRow.addStretch();
   advancedGroup.sizer.add( advancedRow );
   advancedGroup.sizer.addSpacing( 8 );
   let definitions = [
      { key: "BackgroundCorrection", label: InNovaTr( "Background Correction" ) },
      { key: "Denoise", label: InNovaTr( "Denoise" ) },
      { key: "Sharpen", label: InNovaTr( "Sharpen" ) },
      { key: "DarkStructureEnhance", label: InNovaTr( "Dark Structure Enhance" ) },
      { key: "StarRefinement", label: InNovaTr( "Star Refinement" ) },
      { key: "PhotoEditor", label: InNovaTr( "Photo Editor" ) }
   ];
   let checks = {};
   let remembered = {};
   let columns = new HorizontalSizer;
   columns.spacing = 36;
   columns.addStretch();
   let left = new VerticalSizer;
   left.spacing = 10;
   let right = new VerticalSizer;
   right.spacing = 10;
   for ( let i = 0; i < definitions.length; ++i ) {
      let definition = definitions[i];
      let check = new CheckBox( advancedGroup );
      check.text = definition.label;
      check.setScaledMinHeight( 24 );
      check.checked = false;
      check.enabled = false;
      check.toolTip = InNovaTr( "Run " ) + definition.label +
         InNovaTr( " in InNova Astro Processor" );
      checks[definition.key] = check;
      remembered[definition.key] = true;
      let row = new HorizontalSizer;
      row.add( check );
      row.addStretch();
      (i < 3 ? left : right).add( row );
   }
   columns.add( left, 50 );
   columns.add( right, 50 );
   columns.addStretch();
   advancedGroup.sizer.add( columns );
   function setAdvancedMode( enabled )
   {
      for ( let i = 0; i < definitions.length; ++i ) {
         let definition = definitions[i];
         let check = checks[definition.key];
         if ( enabled ) {
            check.checked = remembered[definition.key] !== false;
            check.enabled = true;
         } else {
            remembered[definition.key] = check.checked;
            check.checked = false;
            check.enabled = false;
         }
      }
   }
   basic.onCheck = function( checked )
   {
      if ( checked ) {
         advanced.checked = false;
         setAdvancedMode( false );
      }
   };
   advanced.onCheck = function( checked )
   {
      if ( checked ) {
         basic.checked = false;
         setAdvancedMode( true );
      }
   };
   background.sizer.add( basicGroup );
   background.sizer.add( advancedGroup );

   let run = new PushButton( background );
   run.text = InNovaTr( "Run" );
   run.icon = InNovaBlackPlaybackIcon(dialog, "play");
   run.defaultButton = true;
   run.setScaledFixedSize( 100, 30 );
   run.onClick = function()
   {
      for ( let i = 0; i < definitions.length; ++i ) {
         let definition = definitions[i];
         let enabled = basic.checked ? definition.key == "PhotoEditor" :
            checks[definition.key].checked;
         Settings.write( InNovaIntegratorProcessSettingPrefix +
            definition.key, DataType_String, enabled ? "1" : "0" );
      }
      Settings.remove( InNovaIntegratorProcessSettingPrefix +
         "HAlphaBlend" );
      Settings.write( InNovaIntegratorHandoffNoticeShownSetting,
         DataType_String, "1" );
      dialog.ok();
   };
   let cancel = new PushButton( background );
   cancel.text = InNovaTr( "Cancel" );
   cancel.icon = dialog.scaledResource( ":/icons/close.png" );
   cancel.setScaledFixedSize( 100, 30 );
   cancel.onClick = function() { dialog.cancel(); };
   let buttons = new HorizontalSizer;
   buttons.spacing = 10;
   buttons.addStretch();
   buttons.add( InNovaStyleBlackButton(run) );
   buttons.add( InNovaStyleBlackButton(cancel) );
   InNovaAddDialogActionSpace(background, background.sizer); background.sizer.add( buttons );
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   let accepted = dialog.execute() == StdDialogCode_Ok;
   if ( !accepted ) {
      Settings.remove( InNovaIntegratorHandoffPendingSetting );
      Settings.remove( InNovaIntegratorHandoffNoticeShownSetting );
   }
   return accepted;
}

function StartLaunchInNovaIntegrator( bridgeReturnSourceId, preparationHandoff, returnToStart )
{
   let scriptPath = File.extractDrive(#__FILE__) +
      File.extractDirectory(#__FILE__) + "/../InNova/InNova01.js";
   let key = "InNova/ProcessorReturnToStart";
   let baselineIds = [];
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
      if ( windows[i] != null && !windows[i].isNull &&
           !windows[i].mainView.isNull )
         baselineIds.push( windows[i].mainView.id );
   if (returnToStart === false) Settings.remove(key);
   else Settings.write(key, DataType_String, JSON.stringify({
      path: File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/InNovaStart.js",
      created: Date.now(),
      returnMode: bridgeReturnSourceId ? "bridge" : "start",
      sourceId: bridgeReturnSourceId || "",
      baselineIds: baselineIds
   }));
   try {


      return StartLaunchModule( scriptPath,
         bridgeReturnSourceId || preparationHandoff ? 1.25 : 0.20 );
   }
   catch (error) {
      Settings.write(key, DataType_String, "");
      Settings.remove( InNovaIntegratorHandoffNoticeShownSetting );
      throw error;
   }
}

function StartLaunchModule( scriptPath, launchDelaySeconds )
{
   console.noteln( "🚀 Opening InNova module: " + scriptPath );


   return MiraLaunchSuiteScript( scriptPath,
      launchDelaySeconds == null ? 0.20 : launchDelaySeconds );
}

function StartCloseSeriesWindows( series )
{
   for ( let i = 0; i < series.length; ++i ) {
      let window = series[i].window || series[i];
      if ( window != null && !window.isNull ) window.forceClose();
   }
}

function StartCloseMultiNightTemporaryWindows()
{
   let windows = ImageWindow.windows.slice();
   let closed = 0;
   for ( let i = 0; i < windows.length; ++i ) {
      let window = windows[i];
      if ( window == null || window.isNull || window.mainView.isNull )
         continue;
      let id = String( window.mainView.id ).toLowerCase();
      if ( id.indexOf( "innovastartregistered" ) < 0 &&
           id.indexOf( "innovastartcrop" ) < 0 )
         continue;
      try {
         window.forceClose();
         ++closed;
      } catch ( error ) {
         console.warningln( "⚠️ Could not close temporary Multi-Night " +
            "window " + window.mainView.id + ": " + error );
      }
   }
   if ( closed > 0 )
      console.noteln( "🧹 Closed " + closed +
         " temporary registered/cropped Multi-Night window(s)." );
   return closed;
}


function StartIntegrationChannelWeightMetrics( window, channel )
{
   let image = window.mainView.image;
   let selectedChannel = Math.range( channel, 0,
      Math.max( 0, image.numberOfChannels - 1 ) );
   let maximumSamples = 80000;
   let step = Math.max( 1, Math.ceil( Math.sqrt(
      image.width*image.height/maximumSamples ) ) );
   let values = [];
   let differences = [];
   for ( let y = Math.floor( step/2 ); y + 1 < image.height; y += step )
      for ( let x = Math.floor( step/2 ); x + 1 < image.width; x += step ) {
         let value = image.sample( x, y, selectedChannel );
         let right = image.sample( x + 1, y, selectedChannel );
         let below = image.sample( x, y + 1, selectedChannel );
         if ( !isFinite( value ) || !isFinite( right ) || !isFinite( below ) )
            continue;
         if ( Math.abs( value ) < 1.0e-12 &&
              Math.abs( right ) < 1.0e-12 && Math.abs( below ) < 1.0e-12 )
            continue;
         if ( value >= 0.985 || right >= 0.985 || below >= 0.985 )
            continue;
         values.push( value );
         differences.push( Math.abs( value - right ) );
         differences.push( Math.abs( value - below ) );
      }
   if ( values.length < 32 || differences.length < 64 )
      return { signal: 0, noise: 0, snr: 0, rawWeight: 1,
         fallback: true };
   values.sort( function( a, b ) { return a - b; } );
   differences.sort( function( a, b ) { return a - b; } );
   let background = values[Math.floor( 0.50*(values.length - 1) )];
   let upper = values[Math.floor( 0.995*(values.length - 1) )];
   let signal = Math.max( 1.0e-8, upper - background );
   let noise = differences[Math.floor( 0.50*(differences.length - 1) )]/
      0.953872;
   if ( !isFinite( noise ) || noise <= 1.0e-10 )
      return { signal: signal, noise: 0, snr: 0, rawWeight: 1,
         fallback: true };
   let snr = signal/noise;
   return { signal: signal, noise: noise, snr: snr,
      rawWeight: Math.max( 1.0e-8, snr*snr ), fallback: false };
}

function StartApplyChannelWeightedIntegration( output, items, metrics )
{
   if ( output == null || output.isNull || items.length == 0 ) return false;
   let channels = output.mainView.image.numberOfChannels;
   function channelExpression( channel ) {
      let terms = [];
      for ( let i = 0; i < items.length; ++i ) {
         let window = items[i].window || items[i];
         let weight = metrics[i].channelWeights[
            Math.min( channel, metrics[i].channelWeights.length - 1 ) ];
         terms.push( "(" + weight.toPrecision( 15 ) + "*" +
            window.mainView.id + "[" + channel + "])" );
      }
      return terms.join( "+" );
   }
   let process = new PixelMath;
   process.expression = channelExpression( 0 );
   process.expression1 = channels >= 3 ? channelExpression( 1 ) : "";
   process.expression2 = channels >= 3 ? channelExpression( 2 ) : "";
   process.expression3 = "";
   process.useSingleExpression = channels < 3;
   process.symbols = "";
   process.generateOutput = true;
   process.singleThreaded = false;
   process.optimization = true;
   process.use64BitWorkingImage = false;
   process.rescale = false;


   process.truncate = false;
   process.createNewImage = false;
   process.showNewImage = false;
   return process.executeOn( output.mainView, false );
}


function StartPreparePhotometricIntegrationItems( items )
{
   if ( items == null || items.length < 2 )
      return { items: items || [], temporaryWindows: [], normalized: false };
   let reference = items[0].window || items[0];
   if ( reference == null || reference.isNull || reference.mainView.isNull )
      return { items: items, temporaryWindows: [], normalized: false };
   let prepared = [ items[0] ];
   let temporaryWindows = [];
   try {
      console.noteln( "⚖️ Photometric normalization reference: " +
         reference.mainView.id );
      for ( let i = 1; i < items.length; ++i ) {
         let source = items[i].window || items[i];
         if ( source == null || source.isNull || source.mainView.isNull )
            throw new Error( InNovaTr( "A selected integration image is no longer available." ) );
         let normalized = StartCloneWindow( source,
            source.mainView.id + "_InNovaPhotometricFit", false );
         temporaryWindows.push( normalized );
         let fit = new LinearFit;
         fit.referenceViewId = reference.mainView.id;
         fit.rejectLow = 0.0;
         fit.rejectHigh = 0.92;
         if ( !fit.executeOn( normalized.mainView ) )
            throw new Error( InNovaTr( "LinearFit could not normalize " ) +
               source.mainView.id + "." );
         prepared.push( { window: normalized,
            source: StartSeriesSourceEntry( items[i] ) } );
         console.writeln( "  ✓ " + source.mainView.id +
            " normalized to " + reference.mainView.id );
      }
      return { items: prepared, temporaryWindows: temporaryWindows,
         normalized: true };
   } catch ( error ) {
      StartCloseSeriesWindows( temporaryWindows );
      console.warningln( "⚠️ Photometric normalization was not applied: " +
         error + " Using the registered images without normalization." );
      return { items: items, temporaryWindows: [], normalized: false };
   }
}


function StartCreateIntegrationSeries( series, combineDifferentFilters )
{
   let groups = {};
   for ( let i = 0; i < series.length; ++i ) {
      let source = StartSeriesSourceEntry( series[i] );
      let window = series[i].window || series[i];
      if ( source == null || window == null || window.isNull ||
           source.projectCompatible === false ||
           source.multiExposureSelected !== true ) continue;
      let image = window.mainView.image;
      let filter = source.filter == "—" ?
         (source.channels >= 3 ? "OSC_COLOR" : "UNFILTERED") :
         String( source.filter ).toUpperCase();
      let exposureKey = isFinite( source.exposure ) && source.exposure > 0 ?
         Math.round( 1000*source.exposure ) + "ms" : "UNKNOWN_EXPOSURE";
      let groupingFilter = combineDifferentFilters === true ?
         "MIXED_FILTERS" : filter;
      let key = groupingFilter + " | " + image.width + "x" + image.height + "x" +
         image.numberOfChannels;
      if ( groups[key] == null )
         groups[key] = { label: filter, filters: {}, filterNames: [],
            exposure: source.exposure, exposureKey: exposureKey, items: [] };
      else if ( groups[key].exposureKey != exposureKey )
         groups[key].exposureKey = "MIXED_EXPOSURE";
      if ( groups[key].filters[filter] == null ) {
         groups[key].filters[filter] = true;
         groups[key].filterNames.push( filter );
         if ( combineDifferentFilters === true )
            groups[key].label = groups[key].filterNames.join( " + " );
      }
      groups[key].items.push( series[i] );
   }

   let results = [];
   for ( let key in groups ) {
      let group = groups[key];
      if ( group.items.length < 2 ) continue;
      console.noteln( "⚙️ Integrating " + group.items.length + " images: " + group.label );
      let photometric = { items: group.items, temporaryWindows: [],
         normalized: false };
      try {
         photometric = StartPreparePhotometricIntegrationItems( group.items );
         let integrationItems = photometric.items;
         let metrics = [];
         let channels = (integrationItems[0].window ||
            integrationItems[0]).mainView.image.numberOfChannels;
         let weightedChannels = channels >= 3 ? 3 : 1;
         let channelWeightSums = [];
         for ( let c = 0; c < weightedChannels; ++c )
            channelWeightSums.push( 0 );
         for ( let i = 0; i < integrationItems.length; ++i ) {
            let metricWindow = integrationItems[i].window || integrationItems[i];
            let metric = StartIntegrationWeightMetrics( metricWindow );
            metric.channelMetrics = [];
            metric.channelWeights = [];
            for ( let c = 0; c < weightedChannels; ++c ) {
               let channelMetric = StartIntegrationChannelWeightMetrics(
                  metricWindow, c );
               metric.channelMetrics.push( channelMetric );
               channelWeightSums[c] += channelMetric.rawWeight;
            }
            metrics.push( metric );
         }
         for ( let i = 0; i < metrics.length; ++i ) {
            for ( let c = 0; c < weightedChannels; ++c )
               metrics[i].channelWeights.push(
                  isFinite( channelWeightSums[c] ) &&
                  channelWeightSums[c] > 0 ?
                     metrics[i].channelMetrics[c].rawWeight/
                        channelWeightSums[c] : 1/metrics.length );
            metrics[i].weight = weightedChannels >= 3 ?
               0.2126*metrics[i].channelWeights[0] +
               0.7152*metrics[i].channelWeights[1] +
               0.0722*metrics[i].channelWeights[2] :
               metrics[i].channelWeights[0];
            let metricWindow = integrationItems[i].window || integrationItems[i];
            console.writeln( "📊 " + metricWindow.mainView.id +
               ": SNR " + format( "%.2f", metrics[i].snr ) +
               " · noise " + format( "%.6g", metrics[i].noise ) +
               (weightedChannels >= 3 ?
                  " · weights R/G/B " +
                  format( "%.1f%%", 100*metrics[i].channelWeights[0] ) +
                  "/" + format( "%.1f%%", 100*metrics[i].channelWeights[1] ) +
                  "/" + format( "%.1f%%", 100*metrics[i].channelWeights[2] ) :
                  " · weight " + format( "%.1f%%", 100*metrics[i].weight )) +
               (metrics[i].fallback ? " · fallback estimate" : "") );
         }
         let first = integrationItems[0].window || integrationItems[0];
         let output = StartCloneWindow( first,
            "InNovaStart_" + group.label + "_" +
            group.exposureKey +
            InNovaStartIntegrationSuffix + InNovaStartCombinedSuffix );
         if ( !StartApplyChannelWeightedIntegration(
                  output, integrationItems, metrics ) ) {
            output.forceClose();
            throw new Error( InNovaTr( "PixelMath could not apply the RGB noise weights." ) );
         }
         StartWriteCombinationSource( output, group.items );
         StartCloseSeriesWindows( photometric.temporaryWindows );
         photometric.temporaryWindows = [];
         results.push( { window: output, kind: "INTEGRATION",
            integrationLabel: InNovaTr( "INTEGRATED — " ) + group.label,
            sourceItems: group.items, weightMetrics: metrics,
            photometricallyNormalized: photometric.normalized } );
      } catch ( error ) {
         StartCloseSeriesWindows( photometric.temporaryWindows );
         console.warningln( "⚠️ InNova Multi-Night multi-night integration failed for " +
            group.label + ": " + error );
      }
   }
   return results;
}


function StartCreateHDRSeries( series )
{
   let groups = {};
   for ( let i = 0; i < series.length; ++i ) {
      let source = StartSeriesSourceEntry( series[i] );
      if ( source == null || !source.hdrCompatible ||
           source.multiExposureSelected !== true ) continue;
      let window = series[i].window || series[i];
      let image = window.mainView.image;
      let key = source.hdrGroup + " | " + image.width + "x" +
         image.height + "x" + image.numberOfChannels;
      if ( groups[key] == null )
         groups[key] = { label: source.hdrGroup, items: [], levels: {} };
      let level = Math.round( 1000*source.exposure );
      let candidate = { item: series[i], exposure: source.exposure };
      groups[key].items.push( candidate );
      if ( groups[key].levels[level] == null ) groups[key].levels[level] = [];
      groups[key].levels[level].push( candidate );
   }

   let results = [];
   for ( let key in groups ) {
      let group = groups[key];
      let levelCount = 0;
      for ( let level in group.levels ) ++levelCount;
      if ( levelCount < 3 ) continue;
      let hdrInputs = [];
      let temporaryIntegrations = [];
      let temporaryFiles = [];
      try {


         for ( let level in group.levels ) {
            let candidates = group.levels[level];
            if ( candidates.length == 1 ) {
               hdrInputs.push( candidates[0] );
               continue;
            }
            let first = candidates[0].item.window || candidates[0].item;
            let average = StartCloneWindow( first,
               "InNovaStart_" + group.label + "_" + level + "ms_Master" );
            average.mainView.beginProcess( UndoFlag_NoSwapFile );
            for ( let i = 1; i < candidates.length; ++i ) {
               let other = candidates[i].item.window || candidates[i].item;
               average.mainView.image.apply( other.mainView.image, ImageOp.Add );
            }
            average.mainView.image.apply( candidates.length, ImageOp.Div );
            average.mainView.endProcess();
            temporaryIntegrations.push( { window: average } );
            hdrInputs.push( { item: { window: average },
               exposure: candidates[0].exposure } );
         }
         hdrInputs.sort( function( a, b ) { return b.exposure - a.exposure; } );
         let idsBefore = StartWindowIdSet();
         let process = new HDRComposition;
         let processImages = [];
         for ( let i = 0; i < hdrInputs.length; ++i ) {
            let window = hdrInputs[i].item.window || hdrInputs[i].item;
            let temporaryPath = File.systemTempDirectory + "/" +
               StartSafeId( "InNovaStartHDR_" + group.label + "_" +
                  (new Date()).getTime() + "_" + i ) + ".xisf";
            let fileCopy = StartCloneWindow( window,
               "InNovaStartHDRFileInput_" + i );
            let saved = fileCopy.saveAs(
               temporaryPath, false, false, false, false );
            fileCopy.forceClose();
            if ( !saved )
               throw new Error( InNovaTr( "Could not create a temporary HDR input." ) );
            temporaryFiles.push( temporaryPath );
            processImages.push( [ true, temporaryPath ] );
         }
         process.images = processImages;
         process.outputMasks = false;
         console.noteln( "🌗 Running HDRComposition…" );
         if ( !process.executeGlobal() )
            throw new Error( InNovaTr( "HDRComposition did not generate an image." ) );
         let generated = null;
         let windows = ImageWindow.windows;
         for ( let i = 0; i < windows.length; ++i )
            if ( windows[i] != null && !windows[i].isNull &&
                 !windows[i].mainView.isNull &&
                 !idsBefore[windows[i].mainView.id] ) {
               generated = windows[i];
               break;
            }
         if ( generated == null )
            throw new Error( InNovaTr( "The HDRComposition result could not be located." ) );
         let output = StartCloneWindow( generated,
            "InNovaStart_" + group.label + InNovaStartHDRSuffix +
            InNovaStartCombinedSuffix );
         generated.forceClose();
         StartWriteCombinationSource( output, group.items );
         StartCloseSeriesWindows( temporaryIntegrations );
         for ( let i = 0; i < temporaryFiles.length; ++i )
            if ( File.exists( temporaryFiles[i] ) ) File.remove( temporaryFiles[i] );
         results.push( { window: output, kind: "HDR",
            hdrLabel: "HDR — " + group.label,
            sourceItems: group.items } );
      } catch ( error ) {
         StartCloseSeriesWindows( temporaryIntegrations );
         for ( let i = 0; i < temporaryFiles.length; ++i )
            if ( File.exists( temporaryFiles[i] ) ) File.remove( temporaryFiles[i] );
         console.warningln( "⚠️ InNova Multi-Night HDR composition failed for " +
            group.label + ": " + error );
      }
   }
   return results;
}

function StartLuminance( image, x, y )
{
   let value = image.sample( x, y, 0 );
   if ( image.numberOfChannels >= 3 )
      value = 0.2126*value + 0.7152*image.sample( x, y, 1 ) +
         0.0722*image.sample( x, y, 2 );
   return value;
}


function StartPreflightStarCount( window )
{
   if ( window == null || window.isNull || window.mainView.isNull ) return -1;
   let auxiliary = null;
   try {
      let source = window.mainView.image;
      let workingImage = source;
      if ( source.isColor ) {
         auxiliary = new ImageWindow( source.width, source.height,
            source.numberOfChannels, 32, true, true,
            StartSafeId( "InNovaStartStarPreflight" ) );
         auxiliary.mainView.beginProcess( UndoFlag_NoSwapFile );
         auxiliary.mainView.image.assign( source );
         auxiliary.mainView.endProcess();
         let grayscale = new ConvertToGrayscale;
         grayscale.executeOn( auxiliary.mainView );
         workingImage = auxiliary.mainView.image;
      }
      let detector = new StarDetector;
      detector.structureLayers = 5;
      detector.noiseReductionFilterRadius = 1;
      detector.sensitivity = 0.5;
      detector.peakResponse = 0.5;
      detector.allowClusteredSources = false;
      detector.maxDistortion = 0.6;
      detector.minStructureSize = 3;
      detector.fitPSF = false;
      let stars = detector.stars( workingImage );
      if ( auxiliary != null && !auxiliary.isNull ) auxiliary.forceClose();
      return stars.length;
   } catch ( error ) {
      if ( auxiliary != null && !auxiliary.isNull ) auxiliary.forceClose();
      console.writeln( "🔎 Star-field preflight was inconclusive: " + error );
      return -1;
   }
}


function StartCloneWindow( source, id, showOutput )
{
   let image = source.mainView.image;
   let output = new ImageWindow( image.width, image.height,
      image.numberOfChannels, 32, true, image.colorSpace != ColorSpace_Gray,
      StartSafeId( id ) );
   output.mainView.beginProcess( UndoFlag_NoSwapFile );
   output.mainView.image.assign( image );
   output.mainView.endProcess();
   try { output.keywords = source.keywords; } catch ( error ) {}
   if ( showOutput !== false ) output.show();
   return output;
}

function StartQuickStretchRow( median, mad, channelIndexes )
{
   let inverted = 0;
   for ( let i = 0; i < channelIndexes.length; ++i )
      if ( median.at( channelIndexes[i] ) > 0.5 ) ++inverted;

   if ( inverted < channelIndexes.length ) {
      let shadows = 0;
      let center = 0;
      for ( let i = 0; i < channelIndexes.length; ++i ) {
         let c = channelIndexes[i];
         shadows += median.at( c ) - 2.8*mad.at( c );
         center += median.at( c );
      }
      shadows = Math.range( shadows/channelIndexes.length, 0, 1 );
      center = Math.mtf(
         0.25, center/channelIndexes.length - shadows );
      return [ shadows, center, 1, 0, 1 ];
   }

   let highlights = 0;
   let center = 0;
   for ( let i = 0; i < channelIndexes.length; ++i ) {
      let c = channelIndexes[i];
      highlights += median.at( c ) + 2.8*mad.at( c );
      center += median.at( c );
   }
   highlights = Math.range(
      highlights/channelIndexes.length, 0, 1 );
   center = Math.mtf(
      highlights - center/channelIndexes.length, 0.25 );
   return [ 0, center, highlights, 0, 1 ];
}

function StartQuickStretchRowsLinked( rows )
{
   if ( rows == null || rows.length < 3 ) return true;
   for ( let c = 1; c < 3; ++c )
      for ( let i = 0; i < rows[0].length; ++i )
         if ( Math.abs( rows[c][i] - rows[0][i] ) > 1.0e-12 )
            return false;
   return true;
}

function StartQuickStretchAutomaticLinkedMode( median, mad )
{


   let minimum = 1;
   let maximum = 0;
   let noise = 0;
   for ( let c = 0; c < 3; ++c ) {
      let value = median.at( c );
      minimum = Math.min( minimum, value );
      maximum = Math.max( maximum, value );
      noise += mad.at( c );
   }
   noise /= 3;


   if ( maximum >= 0.25 ) return true;
   let spread = maximum - minimum;
   let relativeSpread = spread/Math.max( maximum, 1.0e-6 );
   let significantSpread = spread > 2.5*Math.max( noise, 1.0e-6 );
   return !(relativeSpread > 0.15 && significantSpread);
}

function StartQuickStretchBitmap( source, alreadyStretched,
   linkedChannels, stretchState, maximumPreviewDimension )
{
   if ( stretchState != null ) {
      stretchState.linked = null;
      stretchState.adjustable = false;
      stretchState.automatic = false;
   }
   if ( source == null || source.isNull || source.mainView.isNull )
      return null;
   let previewWindow = null;
   try {
      let image = new Image( source.mainView.image );
      let maximumDimension = maximumPreviewDimension === 0 ?
         Math.max(image.width, image.height) : (maximumPreviewDimension || 1800);
      let scale = Math.min( 1,
         maximumDimension/Math.max( image.width, image.height ) );
      if ( scale < 1 )
         image.resample( scale, scale, 0, 0 );
      if ( alreadyStretched ) {
         let bitmap = image.render();
         image.free();
         if ( stretchState != null ) {
            stretchState.linked = null;
            stretchState.adjustable = false;
         }
         return bitmap;
      }

      previewWindow = new ImageWindow( image.width, image.height,
         image.numberOfChannels, 32, true, image.isColor,
         StartSafeId( "InNovaStartPreview_" + (++InNovaStartPreviewSerial) ) );
      previewWindow.mainView.beginProcess( UndoFlag_NoSwapFile );
      previewWindow.mainView.image.assign( image );
      previewWindow.mainView.endProcess();
      image.free();

      let view = previewWindow.mainView;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );
      let histogram = new HistogramTransformation;
      let identity = [ 0, 0.5, 1, 0, 1 ];
      let rows;
      let automaticMode = false;
      let useLinkedChannels = linkedChannels !== false;
      if ( view.image.isColor ) {
         automaticMode = typeof linkedChannels != "boolean";
         useLinkedChannels = automaticMode ?
            StartQuickStretchAutomaticLinkedMode( median, mad ) :
            linkedChannels;
         if ( useLinkedChannels ) {
            let linkedRow = StartQuickStretchRow(
               median, mad, [ 0, 1, 2 ] );
            rows = [ linkedRow, linkedRow, linkedRow, identity ];
         } else {
            rows = [
               StartQuickStretchRow( median, mad, [ 0 ] ),
               StartQuickStretchRow( median, mad, [ 1 ] ),
               StartQuickStretchRow( median, mad, [ 2 ] ),
               identity
            ];
         }
      } else {
         let grayRow = StartQuickStretchRow( median, mad, [ 0 ] );
         rows = [ identity, identity, identity, grayRow ];
      }
      histogram.H = rows;
      if ( stretchState != null ) {


         stretchState.linked = view.image.isColor ?
            (useLinkedChannels &&
             StartQuickStretchRowsLinked( rows )) : null;
         stretchState.adjustable = view.image.isColor;
         stretchState.automatic = view.image.isColor && automaticMode;
      }
      histogram.executeOn( view, false );
      let bitmap = view.image.render();
      previewWindow.forceClose();
      return bitmap;
   } catch ( error ) {
      if ( previewWindow != null && !previewWindow.isNull )
         previewWindow.forceClose();
      console.warningln( "⚠️ Quick-stretch preview failed: " + error );
      try { return source.mainView.image.render(); } catch ( ignored ) {}
      return null;
   }
}

class InNovaStartImageViewer extends Control
{
constructor( parent, informationParent, navigationParent )
{
   super( parent );
   let viewer = this;
   this.series = [];
   this.index = -1;
   this.bitmap = null;
   this.scaledBitmap = null;
   this.scale = 1;
   this.fitMode = true;
   this.panEnabled = true;
   this.scrolling = null;
   this.seriesLabel = "";
   this.onRemoveRequested = null;
   this.onMultiExposureRequested = null;
   this.onCropRequested = null;
   this.onRestoreCropRequested = null;
   this.onCropSelected = null;
   this.cropMode = false;
   this.cropEditMode = false;
   this.cropStart = null;
   this.cropDrag = null;
   this.cropSelection = null;
   this.cropInteractionActive = false;
   this.quickStretchLinked = null;
   this.quickStretchToggleAvailable = false;
   this.onImageSolverRequested = null;
   this.onColorCalibrationRequested = null;
   this.onConsoleRequested = null;

   this.scrollBox = new StartImageReviewViewport( this, 820, 440 );
   this.scrollBox.viewport.cursor = new Cursor( StdCursor_OpenHand );

   this.previousButton = new ToolButton( this );
   this.previousButton.icon = InNovaBlackPlaybackIcon(this, "previous");
   this.previousButton.setScaledFixedSize( 40, 34 );
   this.previousButton.toolTip = InNovaTr( "Previous image" );

   this.consoleButton = new ToolButton( this );
   this.consoleButton.icon =
      this.scaledResource( ":/toolbar/view-process-console.png" );
   this.consoleButton.setScaledFixedSize( 28, 28 );
   this.consoleButton.toolTip = InNovaTr( "Show the PixInsight Process Console" );
   this.consoleButton.onClick = function()
   {
      if ( typeof viewer.onConsoleRequested == "function" )
         viewer.onConsoleRequested();
   };

   this.zoomInButton = new ToolButton( this );
   this.zoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomInButton.setScaledFixedSize( 28, 28 );
   this.zoomInButton.toolTip = InNovaTr( "Zoom in" );

   this.fitButton = new ToolButton( this );
   this.fitButton.icon =
      this.scaledResource( ":/toolbar/view-zoom-fit.png" );
   this.fitButton.setScaledFixedSize( 28, 28 );
   this.fitButton.toolTip = InNovaTr( "Fit image to viewer" );

   this.zoomOutButton = new ToolButton( this );
   this.zoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOutButton.setScaledFixedSize( 28, 28 );
   this.zoomOutButton.toolTip = InNovaTr( "Zoom out" );

   this.panButton = new ToolButton( this );
   this.panButton.icon = StartHandIcon().scaledTo(
      this.logicalPixelsToPhysical(24), this.logicalPixelsToPhysical(24));
   this.panButton.setScaledFixedSize( 32, 32 );
   this.panButton.checkable = true;
   this.panButton.checked = true;
   this.panButton.toolTip = InNovaTr( "Pan the zoomed image by dragging" );

   this.cropToolButton = new ToolButton( this );
   this.cropToolButton.icon = StartCropIcon();
   this.cropToolButton.setScaledFixedSize( 32, 32 );
   this.cropToolButton.toolTip =
      InNovaTr( "Crop: draw or edit the retained rectangle; click again to apply it" );

   this.adaptiveAccessEnabled = false;
   this.adaptiveButton = new ToolButton( this );
   this.adaptiveButton.icon = StartAdaptiveIcon();
   this.adaptiveButton.setScaledFixedSize( 32, 32 );
   this.adaptiveButton.toolTip = InNovaTr( "Open the current image in InNova Smart Stretch" );
   this.adaptiveButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onAdaptiveRequested == "function" )
         viewer.onAdaptiveRequested( window );
   };

   this.informationButton = new ToolButton(this);
   this.informationButton.icon = new Bitmap(InNovaInformationIconPath.replace("InNova_Information.png","information-toolbar.svg")).scaledTo(this.logicalPixelsToPhysical(30),this.logicalPixelsToPhysical(30));
   this.informationButton.setScaledFixedSize(32,32);
   this.informationButton.toolTip = "InNova Image Information";
   this.informationButton.onClick = function() { InNovaShowInformation(viewer.currentWindow()); };
   this.quickStretchLinkButton = new ToolButton( this );
   this.quickStretchLinkButton.icon = StartQuickStretchLinkIcon( true ).scaledTo(
         this.logicalPixelsToPhysical(26), this.logicalPixelsToPhysical(26));
   this.quickStretchLinkButton.setScaledFixedSize( 32, 32 );
   this.quickStretchLinkButton.toolTip =
      InNovaTr( "Unlink RGB channels and recalculate Quick Stretch" );
   this.updateQuickStretchLinkButton = function()
   {
      this.quickStretchLinkButton.icon =
         StartQuickStretchLinkIcon( this.quickStretchLinked !== true ).scaledTo(
         this.logicalPixelsToPhysical(26), this.logicalPixelsToPhysical(26));
      this.quickStretchLinkButton.toolTip =
         this.quickStretchLinked === true ?
         InNovaTr( "RGB channels: Linked · Click to unlink and recalculate Quick Stretch" ) :
         InNovaTr( "RGB channels: Unlinked · Click to link and recalculate Quick Stretch" );
   };
   this.quickStretchLinkButton.onClick = function()
   {
      if ( !viewer.quickStretchToggleAvailable ||
           viewer.cropInteractionActive || viewer.index < 0 ) return;
      let item = viewer.series[viewer.index];
      let window = item.window || item;
      if ( window == null || window.isNull ) return;
      let targetLinked = viewer.quickStretchLinked !== true;
      let state = {};
      viewer.footer.text = targetLinked ?
         InNovaTr( "Recalculating linked RGB Quick Stretch…" ) :
         InNovaTr( "Recalculating unlinked RGB Quick Stretch…" );
      CoreApplication.processEvents();
      let bitmap = StartQuickStretchBitmap(
         window, false, targetLinked, state );
      if ( bitmap == null ) return;
      viewer.bitmap = bitmap;
      viewer.quickStretchLinked = state.linked;
      viewer.quickStretchToggleAvailable = state.adjustable === true;
      item.quickStretchLinked = state.linked;
      item.quickStretchAutomatic = false;
      viewer.rebuildScaledBitmap();
      viewer.updateQuickStretchLinkButton();
      viewer.updateInformation();
      viewer.updateButtons();
   };

   this.imageSolverButton = new ToolButton( this );
   this.imageSolverButton.icon = StartImageSolverIcon();
   this.imageSolverButton.setScaledFixedSize( 32, 32 );
   this.imageSolverButton.toolTip =
      InNovaTr( "Solve the current image with ImageSolver" );
   this.imageSolverButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onImageSolverRequested == "function" )
         viewer.onImageSolverRequested( window,
            viewer.index >= 0 ? viewer.series[viewer.index] : window );
   };

   this.colorCalibrationButton = new ToolButton( this );
   this.colorCalibrationButton.icon = StartColorCalibrationIcon();
   this.colorCalibrationButton.setScaledFixedSize( 32, 32 );
   this.colorCalibrationButton.toolTip =
      InNovaTr( "Create a copy and apply SPCC color calibration" );
   this.colorCalibrationButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onColorCalibrationRequested == "function" )
         viewer.onColorCalibrationRequested( window,
            viewer.index >= 0 ? viewer.series[viewer.index] : window );
   };

   this.processorButton = new ToolButton( this );
   this.processorButton.icon = StartProcessorRocketIcon();
   this.processorButton.setScaledFixedSize( 32, 32 );
   this.processorButton.toolTip = InNovaTr( "Open InNova Astro Processor" );
   this.processorButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onProcessorRequested == "function" )
         viewer.onProcessorRequested( window );
   };

   this.editorButton = new ToolButton( this );
   this.editorButton.icon = StartEditorAdjustmentsIcon();
   this.editorButton.setScaledFixedSize( 32, 32 );
   this.editorButton.toolTip = InNovaTr( "Open the current image in InNova Photo Editor" );
   this.editorButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onEditorRequested == "function" )
         viewer.onEditorRequested( window );
   };

   this.restoreCropButton = new ToolButton( this );
   this.restoreCropButton.icon = InNovaEditorLightActionIcon("reset");
   this.restoreCropButton.setScaledFixedSize( 28, 28 );
   this.restoreCropButton.toolTip =
      InNovaTr( "Restore the image sequence and discard all crop adjustments" );

   this.removeButton = new ToolButton( this );
   this.removeButton.icon = this.scaledResource( ":/icons/trash.png" );
   this.removeButton.setScaledFixedSize( 28, 28 );
   this.removeButton.toolTip =
      InNovaTr( "Remove this image from the project without closing or deleting it in PixInsight" );

   this.multiExposureButton = new ToolButton( this );
   this.multiExposureButton.icon = StartMultiExposureIcon();
   this.multiExposureButton.setScaledFixedSize( 32, 32 );
   this.multiExposureButton.checkable = true;
   this.multiExposureButton.toolTip =
      InNovaTr( "Add or remove the current image from the Multi-exposure selection" );

   this.nextButton = new ToolButton( this );
   this.nextButton.icon = InNovaBlackPlaybackIcon(this, "next");
   this.nextButton.setScaledFixedSize( 40, 34 );
   this.nextButton.toolTip = InNovaTr( "Next image" );

   let labelParent = informationParent || this;
   this.fileLabel = new Label( labelParent );
   this.fileLabel.useRichText = true;
   this.fileLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   this.fileLabel.setScaledFixedHeight( 22 );
   this.fileLabel.text = InNovaTr( "No image selected" );


   if ( labelParent != null && labelParent.title !== undefined )
      labelParent.title = InNovaTr("Image: 0 / 0");

   this.footer = new Label( navigationParent || labelParent );
   this.footer.useRichText = true;
   this.footer.wordWrapping = true;
   this.footer.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;


   this.footer.setScaledFixedHeight( 44 );
   this.footer.text =
      InNovaTr( "<b>Use the ← and → arrows to move through the images.</b><br>" +
      "In this process, you can zoom in on the images, crop them, or create " +
      "a multi-night integration." );

   this.exifLabel = new Label( labelParent );
   this.exifLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.exifLabel.setScaledFixedHeight( 22 );
   this.exifLabel.text =
      InNovaTr( "Exposure: — · Filter: — · Camera: — · Geometry: —" );

   this.updateInformation = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) {
         this.fileLabel.text =
            InNovaTr( "<span style=\"color:#168de2\">No image selected</span>" );
         this.multiExposureButton.checked = false;
         if ( labelParent != null && labelParent.title !== undefined )
            labelParent.title = InNovaTr("Image: 0 / 0");
         this.footer.text =
            InNovaTr( "Run the project to preview registered images." );
         this.exifLabel.text =
            InNovaTr( "Exposure: — · Filter: — · Camera: — · Geometry: —" );
         return;
      }
      let item = this.series[this.index];
      let window = item.window || item;
      let typeText = item.kind == "HDR" ? InNovaTr( " - ✅ NEW HDR" ) :
         (item.kind == "INTEGRATION" ?
            InNovaTr( " - ✅ NEW MULTI-EXPOSURE IMAGE" ) : "");
      let source = item;
      while ( source != null && source.source != null ) source = source.source;
      let selected = source != null &&
         source.multiExposureSelected === true && typeText.length == 0;
      this.fileLabel.text = item.kind == "HDR" ||
         item.kind == "INTEGRATION" ?
         "<b style=\"color:#168de2\">" +
         StartHTMLText( window.mainView.id + typeText ) + "</b>" : selected ?
         "<b style=\"color:#d97800\">★ " +
         StartHTMLText( window.mainView.id ) +
         InNovaTr( " — ADDED TO MULTI-EXPOSURE</b>" ) :
         "<span style=\"color:#168de2\">" +
         StartHTMLText( window.mainView.id + typeText ) + "</span>";
      this.multiExposureButton.checked = selected;
      if ( labelParent != null && labelParent.title !== undefined )
         labelParent.title = InNovaTr( "Image: " ) + (this.index + 1) + " / " +
            this.series.length;
      this.footer.text =
         InNovaTr( "<b>Use the ← and → arrows to move through the images.</b> · " ) +
         (item.alreadyStretched ? InNovaTr( "Processed image" ) :
            ((item.quickStretchAutomatic === true ? InNovaTr( "Automatic " ) : "") +
             (this.quickStretchLinked === false ? InNovaTr( "unlinked" ) : InNovaTr( "linked" )) +
             InNovaTr( " RGB Quick Stretch" ))) +
         InNovaTr( "<br>In this process, you can zoom in on the images, crop them, " +
         "or create a multi-night integration." );
      let metadataSource = item;
      if ( item.sourceItems != null && item.sourceItems.length > 0 ) {
         metadataSource = item.sourceItems[0];
         if ( metadataSource.item != null )
            metadataSource = metadataSource.item;
      }
      metadataSource = StartSeriesSourceEntry( metadataSource );
      let exposureText = item.kind == "HDR" ? InNovaTr( "Multiple exposures" ) :
         (metadataSource != null ?
            StartExposureText( metadataSource.exposure ) : "—");
      let filterText = metadataSource != null &&
         metadataSource.filter != null ? metadataSource.filter : "—";
      let cameraText = metadataSource != null &&
         metadataSource.camera != null ? metadataSource.camera : "—";
      let image = window.mainView.image;
      this.exifLabel.text = InNovaTr( "Exposure: " ) + exposureText +
         InNovaTr( " · Filter: " ) + filterText +
         InNovaTr( " · Camera: " ) + cameraText +
         InNovaTr( " · Geometry: " ) + image.width + " × " + image.height;
   };

   this.updateButtons = function()
   {
      let available = this.series.length > 0;
      this.informationButton.enabled = available && !this.cropInteractionActive;
      let currentIsDerived = available && this.index >= 0 &&
         (this.series[this.index].kind == "HDR" ||
          this.series[this.index].kind == "INTEGRATION");
      if ( this.cropInteractionActive ) {
         this.previousButton.enabled = false;
         this.nextButton.enabled = false;
         this.zoomInButton.enabled = false;
         this.fitButton.enabled = false;
         this.zoomOutButton.enabled = false;
         this.panButton.enabled = false;
         this.cropToolButton.enabled = available;
         this.quickStretchLinkButton.enabled = false;
         this.adaptiveButton.enabled = false;
         this.imageSolverButton.enabled = false;
         this.colorCalibrationButton.enabled = false;
         this.editorButton.enabled = false;
         this.processorButton.enabled = false;
         this.restoreCropButton.enabled = false;
         this.removeButton.enabled = false;
         this.multiExposureButton.enabled = false;
         return;
      }
      this.previousButton.enabled = available && this.index > 0;
      this.nextButton.enabled = available && this.index + 1 < this.series.length;
      this.zoomInButton.enabled = available;
      this.fitButton.enabled = available;
      this.zoomOutButton.enabled = available;
      this.panButton.enabled = available;
      this.cropToolButton.enabled = available;
      this.quickStretchLinkButton.enabled = available &&
         this.quickStretchToggleAvailable;
      this.adaptiveButton.enabled = available && this.adaptiveAccessEnabled;
      this.imageSolverButton.enabled = available && this.adaptiveAccessEnabled;
      this.colorCalibrationButton.enabled = available && this.adaptiveAccessEnabled;
      this.editorButton.enabled = available && this.adaptiveAccessEnabled;
      this.processorButton.enabled = available && this.adaptiveAccessEnabled;
      this.restoreCropButton.enabled = available;
      this.removeButton.enabled = available && !currentIsDerived;
      this.multiExposureButton.enabled = available && !currentIsDerived;
   };

   this.setCropInteractionActive = function( active )
   {
      this.cropInteractionActive = active === true;
      this.updateButtons();
   };

   this.currentWindow = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) return null;
      let item = this.series[this.index];
      let window = item.window || item;
      if ( window == null || window.isNull || window.mainView == null ||
           window.mainView.isNull ) return null;
      return window;
   };

   this.bitmapOffset = function()
   {
      return this.scrollBox.bitmapOffsetFor( this );
   };

   this.viewportToSource = function( x, y, clampToImage )
   {
      let window = this.currentWindow();
      if ( window == null || this.bitmap == null ||
           this.scaledBitmap == null ) return null;
      let offset = this.bitmapOffset();
      let bx = (x - offset.x)/this.scale;
      let by = (y - offset.y)/this.scale;
      if ( clampToImage ) {
         bx = Math.range( bx, 0, this.bitmap.width - 1 );
         by = Math.range( by, 0, this.bitmap.height - 1 );
      } else if ( bx < 0 || by < 0 || bx >= this.bitmap.width ||
                  by >= this.bitmap.height ) return null;
      let image = window.mainView.image;
      return {
         x: Math.range( Math.round( bx*image.width/this.bitmap.width ),
            0, image.width - 1 ),
         y: Math.range( Math.round( by*image.height/this.bitmap.height ),
            0, image.height - 1 )
      };
   };

   this.setCropMode = function( active )
   {
      this.cropMode = active === true && this.bitmap != null;
      this.cropEditMode = false;
      this.cropStart = null;
      this.cropDrag = null;
      this.scrolling = null;
      if ( this.cropMode ) {
         this.panEnabled = false;
         this.panButton.checked = false;
      }
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropMode ? StdCursor_Cross :
         (this.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow) );
      this.scrollBox.viewport.update();
   };

   this.setCropEditMode = function( active )
   {
      this.cropMode = false;
      this.cropStart = null;
      this.cropDrag = null;
      this.scrolling = null;
      this.cropEditMode = active === true && this.cropSelection != null;
      if ( this.cropEditMode ) {
         this.panEnabled = false;
         this.panButton.checked = false;
      }
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropEditMode ? StdCursor_Cross :
         (this.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow) );
      this.scrollBox.viewport.update();
   };

   this.setCropSelection = function( rectangle )
   {
      this.cropSelection = rectangle;
      this.scrollBox.viewport.update();
   };

   this.cropHitAction = function( point )
   {
      if ( this.cropSelection == null || this.scaledBitmap == null ) return "new";
      let window = this.currentWindow();
      if ( window == null ) return "new";
      let image = window.mainView.image;
      let r = this.cropSelection;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      let tx = Math.max( 4, 10*image.width/this.scaledBitmap.width );
      let ty = Math.max( 4, 10*image.height/this.scaledBitmap.height );
      let nearLeft = Math.abs( point.x - r.x ) <= tx;
      let nearRight = Math.abs( point.x - right ) <= tx;
      let nearTop = Math.abs( point.y - r.y ) <= ty;
      let nearBottom = Math.abs( point.y - bottom ) <= ty;
      let verticalRange = point.y >= r.y - ty && point.y <= bottom + ty;
      let horizontalRange = point.x >= r.x - tx && point.x <= right + tx;
      if ( nearLeft && nearTop ) return "lt";
      if ( nearRight && nearTop ) return "rt";
      if ( nearLeft && nearBottom ) return "lb";
      if ( nearRight && nearBottom ) return "rb";
      if ( nearLeft && verticalRange ) return "l";
      if ( nearRight && verticalRange ) return "r";
      if ( nearTop && horizontalRange ) return "t";
      if ( nearBottom && horizontalRange ) return "b";
      if ( point.x >= r.x && point.x <= right &&
           point.y >= r.y && point.y <= bottom ) return "move";
      return "new";
   };

   this.updateCropDrag = function( point )
   {
      if ( this.cropDrag == null ) return;
      let d = this.cropDrag;
      let r = d.original;
      let window = this.currentWindow();
      if ( window == null ) {
         this.cropDrag = null;
         return;
      }
      let image = window.mainView.image;
      if ( d.action == "move" ) {
         let x = Math.range( r.x + point.x - d.start.x,
            0, image.width - r.width );
         let y = Math.range( r.y + point.y - d.start.y,
            0, image.height - r.height );
         this.cropSelection = { x: x, y: y,
            width: r.width, height: r.height };
         return;
      }
      let left = r.x;
      let top = r.y;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      if ( d.action.indexOf( "l" ) >= 0 )
         left = Math.range( point.x, 0, right - 63 );
      if ( d.action.indexOf( "r" ) >= 0 )
         right = Math.range( point.x, left + 63, image.width - 1 );
      if ( d.action.indexOf( "t" ) >= 0 )
         top = Math.range( point.y, 0, bottom - 63 );
      if ( d.action.indexOf( "b" ) >= 0 )
         bottom = Math.range( point.y, top + 63, image.height - 1 );
      this.cropSelection = { x: left, y: top,
         width: right - left + 1, height: bottom - top + 1 };
   };

   this.rebuildScaledBitmap = function()
   {
      this.scrollBox.rebuildFor( this );
   };

   this.showCurrent = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) return;
      let item = this.series[this.index];
      let window = item.window || item;
      this.footer.text = InNovaTr( "<b>Preparing quick-stretch preview…</b>" );
      CoreApplication.processEvents();
      let stretchState = {};
      this.bitmap = StartQuickStretchBitmap( window,
         item.alreadyStretched === true,
         typeof item.quickStretchLinked == "boolean" &&
         item.quickStretchAutomatic !== true ?
            item.quickStretchLinked : false,
         stretchState );
      this.quickStretchLinked = stretchState.linked;
      this.quickStretchToggleAvailable =
         stretchState.adjustable === true;
      if ( this.quickStretchToggleAvailable )
         item.quickStretchLinked = this.quickStretchLinked;
      item.quickStretchAutomatic = stretchState.automatic === true;
      this.updateQuickStretchLinkButton();
      this.cropMode = false;
      this.cropEditMode = this.cropSelection != null;
      this.panEnabled = !this.cropEditMode;
      this.panButton.checked = this.panEnabled;
      this.fitMode = true;
      this.scrollBox.horizontalScrollPosition = 0;
      this.scrollBox.verticalScrollPosition = 0;
      this.rebuildScaledBitmap();
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropEditMode ? StdCursor_Cross : StdCursor_OpenHand );
      this.updateInformation();
      this.updateButtons();
   };

   this.showModuleResult = function( result, sourceId, alreadyStretched )
   {
      if ( !result || result.isNull ) return;
      let index = -1;
      for ( let i = 0; i < this.series.length; ++i ) {
         let window = this.series[i].window || this.series[i];
         if ( !window.isNull && window.mainView.id == sourceId ) { index = i; break; }
      }
      let previous = index >= 0 ? this.series[index] : StartImageEntry(result);
      let replacement = { window: result, source: previous,
         alreadyStretched: alreadyStretched !== false, kind: previous.kind,
         sourceItems: previous.sourceItems };

      let updated = this.series.slice();
      if ( index < 0 ) { index = updated.length; updated.push(replacement); }
      else updated[index] = replacement;
      if ( typeof this.onModuleResultShown == "function" )
         this.onModuleResultShown( previous, replacement );
      this.setSeries(updated, this.seriesLabel, index);
   };

   this.setSeries = function( series, label, preferredIndex )
   {
      this.series = series || [];
      this.seriesLabel = label || InNovaTr( "Images" );
      this.index = this.series.length > 0 ? Math.range(
         preferredIndex === undefined ? 0 : preferredIndex,
         0, this.series.length - 1 ) : -1;
      this.bitmap = null;
      this.scaledBitmap = null;
      this.quickStretchLinked = null;
      this.quickStretchToggleAvailable = false;
      this.cropSelection = null;
      this.cropMode = false;
      this.cropEditMode = false;
      this.cropDrag = null;
      if ( this.index >= 0 )
         this.showCurrent();
      else {
         this.updateInformation();
         this.updateButtons();
         this.scrollBox.viewport.update();
      }
   };

   this.zoom = function( factor )
   {
      this.scrollBox.zoomFor( this, factor );
      this.updateInformation();
   };

   this.previousButton.onClick = function()
   {
      if ( viewer.index > 0 ) {
         --viewer.index;
         viewer.showCurrent();
         if ( typeof viewer.onIndexChanged == "function" )
            viewer.onIndexChanged( viewer.index );
      }
   };
   this.nextButton.onClick = function()
   {
      if ( viewer.index + 1 < viewer.series.length ) {
         ++viewer.index; viewer.showCurrent();
         if ( typeof viewer.onIndexChanged == "function" )
            viewer.onIndexChanged( viewer.index );
      }
   };
   this.zoomInButton.onClick = function() { viewer.zoom( 1.35 ); };
   this.fitButton.onClick = function()
   {
      viewer.scrollBox.fitFor( viewer );
      viewer.updateInformation();
   };
   this.zoomOutButton.onClick = function() { viewer.zoom( 1/1.35 ); };
   this.panButton.onClick = function()
   {
      viewer.cropMode = false;
      viewer.cropEditMode = false;
      viewer.cropStart = null;
      viewer.cropDrag = null;
      viewer.panEnabled = this.checked;
      viewer.scrollBox.viewport.cursor = new Cursor(
         viewer.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow );
   };
   this.cropToolButton.onClick = function()
   {
      if ( viewer.onCropRequested != null ) viewer.onCropRequested();
   };
   this.restoreCropButton.onClick = function()
   {
      if ( viewer.onRestoreCropRequested != null )
         viewer.onRestoreCropRequested();
   };
   this.removeButton.onClick = function()
   {
      if ( viewer.index >= 0 && viewer.onRemoveRequested != null )
         viewer.onRemoveRequested( viewer.series[viewer.index], viewer.index );
   };
   this.multiExposureButton.onClick = function()
   {
      if ( viewer.index >= 0 && viewer.onMultiExposureRequested != null )
         viewer.onMultiExposureRequested( viewer.series[viewer.index],
            this.checked );
   };

   this.scrollBox.viewport.onResize = function()
   {
      if ( viewer.fitMode ) viewer.rebuildScaledBitmap();
   };
   this.scrollBox.onHorizontalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
   this.scrollBox.onVerticalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
      this.scrollBox.viewport.onMousePress = function(
      x, y, button, buttonState, modifiers )
   {
      if ( button != MouseButton_Left ) return;
      if ( viewer.cropMode ) {
         let point = viewer.viewportToSource( x, y );
         if ( point == null ) return;
         viewer.cropStart = point;
         viewer.cropSelection = { x: point.x, y: point.y,
            width: 1, height: 1 };
         this.update();
         return;
      }
      if ( viewer.cropEditMode && viewer.cropSelection != null ) {
         let point = viewer.viewportToSource( x, y );
         if ( point == null ) return;
         let action = viewer.cropHitAction( point );
         if ( action == "new" ) {
            viewer.cropEditMode = false;
            viewer.cropMode = true;
            viewer.cropStart = point;
            viewer.cropSelection = { x: point.x, y: point.y,
               width: 1, height: 1 };
         } else {
            let r = viewer.cropSelection;
            viewer.cropDrag = { action: action, start: point,
               original: { x: r.x, y: r.y,
                  width: r.width, height: r.height } };
         }
         this.update();
         return;
      }
      if ( !viewer.panEnabled ) return;
      viewer.scrollBox.beginPanFor( viewer, x, y );
   };
   this.scrollBox.viewport.onMouseMove = function(
      x, y, buttonState, modifiers )
   {
      if ( viewer.cropMode && viewer.cropStart != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point == null ) return;
         let left = Math.min( viewer.cropStart.x, point.x );
         let top = Math.min( viewer.cropStart.y, point.y );
         viewer.cropSelection = { x: left, y: top,
            width: Math.abs( point.x - viewer.cropStart.x ) + 1,
            height: Math.abs( point.y - viewer.cropStart.y ) + 1 };
         this.update();
         return;
      }
      if ( viewer.cropDrag != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point == null ) return;
         viewer.updateCropDrag( point );
         this.update();
         return;
      }
      viewer.scrollBox.movePanFor( viewer, x, y );
   };
   this.scrollBox.viewport.onMouseRelease = function(
      x, y, button, buttonState, modifiers )
   {
      if ( viewer.cropMode && viewer.cropStart != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point != null ) {
            let left = Math.min( viewer.cropStart.x, point.x );
            let top = Math.min( viewer.cropStart.y, point.y );
            viewer.cropSelection = { x: left, y: top,
               width: Math.abs( point.x - viewer.cropStart.x ) + 1,
               height: Math.abs( point.y - viewer.cropStart.y ) + 1 };
         }
         let rectangle = viewer.cropSelection;
         viewer.cropStart = null;
         viewer.cropMode = false;
         viewer.cropEditMode = true;
         viewer.panEnabled = false;
         viewer.panButton.checked = false;
         this.cursor = new Cursor( StdCursor_Cross );
         this.update();
         if ( rectangle != null && viewer.onCropSelected != null )
            viewer.onCropSelected( rectangle );
         return;
      }
      if ( viewer.cropDrag != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point != null ) viewer.updateCropDrag( point );
         viewer.cropDrag = null;
         this.update();
         if ( viewer.cropSelection != null && viewer.onCropSelected != null )
            viewer.onCropSelected( viewer.cropSelection );
         return;
      }
      viewer.scrollBox.endPanFor( viewer );
   };
   this.scrollBox.viewport.onPaint = function( x0, y0, x1, y1 )
   {
      let graphics = new Graphics( this );
      graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff25282c ) );
      if ( viewer.scaledBitmap != null ) {
         let offset = viewer.scrollBox.drawBitmapFor( graphics, viewer );
         let ox = offset.x;
         let oy = offset.y;
         if ( viewer.cropSelection != null ) {
            let window = viewer.currentWindow();
            if ( window != null ) {
               let image = window.mainView.image;
               let rectangle = viewer.cropSelection;
               let left = ox + rectangle.x*viewer.scaledBitmap.width/image.width;
               let top = oy + rectangle.y*viewer.scaledBitmap.height/image.height;
               let right = ox + (rectangle.x + rectangle.width)*
                  viewer.scaledBitmap.width/image.width;
               let bottom = oy + (rectangle.y + rectangle.height)*
                  viewer.scaledBitmap.height/image.height;
               let imageRight = ox + viewer.scaledBitmap.width;
               let imageBottom = oy + viewer.scaledBitmap.height;
               let shade = new Brush( 0x98000000 );
               graphics.fillRect( ox, oy, imageRight, top, shade );
               graphics.fillRect( ox, bottom, imageRight, imageBottom, shade );
               graphics.fillRect( ox, top, left, bottom, shade );
               graphics.fillRect( right, top, imageRight, bottom, shade );
               graphics.pen = new Pen( 0xff33aaff, 2 );
               graphics.drawLine( left, top, right, top );
               graphics.drawLine( right, top, right, bottom );
               graphics.drawLine( right, bottom, left, bottom );
               graphics.drawLine( left, bottom, left, top );


               let middleX = (left + right)/2;
               let middleY = (top + bottom)/2;
               let handles = [ [left, top], [middleX, top], [right, top],
                  [left, middleY], [right, middleY], [left, bottom],
                  [middleX, bottom], [right, bottom] ];
               for ( let h = 0; h < handles.length; ++h ) {


                  let hx = Math.range( Math.round( handles[h][0] ),
                     10, this.width - 11 );
                  let hy = Math.range( Math.round( handles[h][1] ),
                     10, this.height - 11 );
                  graphics.fillRect( hx - 9, hy - 9, hx + 10, hy + 10,
                     new Brush( 0xffffffff ) );
                  graphics.fillRect( hx - 6, hy - 6, hx + 7, hy + 7,
                     new Brush( 0xff087bd5 ) );
                  graphics.pen = new Pen( 0xff002f62, 2 );
                  graphics.drawRect( hx - 9, hy - 9, hx + 9, hy + 9 );
               }
            }
         }
      }
      graphics.end();
   };

   let controls = new HorizontalSizer;
   controls.spacing = 7;
   controls.addStretch();
   controls.add( this.previousButton );
   controls.add( this.zoomInButton );
   controls.add( this.fitButton );
   controls.add( this.panButton );
   controls.add( this.zoomOutButton );
   controls.add( this.cropToolButton );
   controls.add( this.consoleButton );
   controls.add( this.imageSolverButton );
   controls.add( this.colorCalibrationButton );
   controls.add( this.quickStretchLinkButton );
   controls.add( this.informationButton );
   controls.add( this.adaptiveButton );
   controls.add( this.processorButton );
   controls.add( this.editorButton );
   controls.add( this.restoreCropButton );
   controls.add( this.removeButton );
   controls.add( this.multiExposureButton );
   controls.add( this.nextButton );
   controls.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.spacing = 5;
   this.sizer.add( this.scrollBox, 100 );
   this.sizer.add( controls );
   this.updateButtons();
}
}

function StartPixelHasData( image, x, y )
{
   x = Math.range( Math.round( x ), 0, image.width - 1 );
   y = Math.range( Math.round( y ), 0, image.height - 1 );
   for ( let c = 0; c < image.numberOfChannels; ++c )
      if ( Math.abs( image.sample( x, y, c ) ) > 1.0e-12 )
         return true;
   return false;
}


class InNovaStartDialog extends Dialog
{
constructor( guidedWorkflow, reviewCropMode )
{
   super();
      InNovaApplyBlackTheme(this);
   let self = this;
   this.reviewCropMode = reviewCropMode === true;
   this.guidedWorkflow = !this.reviewCropMode && guidedWorkflow !== false;
   this.unifiedBridgeWindow = true;
   this.preparationFinished = false;
   this.entries = [];
   this.registeredSeries = [];
   this.croppedSeries = [];
   this.integrationSeries = [];
   this.hdrSeries = [];
   this.multiExposureConfigured = false;
   this.combinationPreviewGenerated = false;
   this.combinationChoiceConfirmed = false;


   this.multiExposureCropRequired = false;
   this.multiExposureManualCropStarted = false;
   this.multiExposureSynchronizedCropAccepted = false;
   this.multiNightSaveOffered = false;
   this.combineDifferentFilters = false;
   this.autoBrightTarget = false;
   this.lastRegistrationFailure = "";
   this.cropRectangle = null;
   this.referenceId = "";
   this.windowTitle = InNovaTr( "🔭 InNova Multi-Night — " ) + InNovaStartVersion +
      " — " + _0x690bbf5e93(true);
   this.minWidth = 650;
   this.userResizable = true;

   this.clearDerivedSeries = function()
   {
      let sourceEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true )
            sourceEntries.push( self.entries[i] );
      self.entries = sourceEntries;
      StartCloseSeriesWindows( self.integrationSeries );
      StartCloseSeriesWindows( self.hdrSeries );
      self.integrationSeries = [];
      self.hdrSeries = [];
   };

   this.buildViewerSeries = function( baseSeries, baseLabel )
   {


      if ( self.imageViewer != null ) {
         self.imageViewer.series = [];
         self.imageViewer.index = -1;
         self.imageViewer.bitmap = null;
         self.imageViewer.scaledBitmap = null;
         self.imageViewer.cropSelection = null;
         self.imageViewer.cropMode = false;
         self.imageViewer.cropEditMode = false;
         self.imageViewer.cropStart = null;
         self.imageViewer.cropDrag = null;
         self.imageViewer.scrolling = null;
      }
      self.clearDerivedSeries();


      if ( self.multiExposureConfigured &&
           self.combinationPreviewGenerated &&
           self.acquisitionCombo.currentItem == 1 )
         self.integrationSeries = StartCreateIntegrationSeries( baseSeries,
            self.combineDifferentFilters );
      if ( self.multiExposureConfigured &&
           self.combinationPreviewGenerated &&
           self.acquisitionCombo.currentItem == 2 )
         self.hdrSeries = StartCreateHDRSeries( baseSeries );
      let result = baseSeries.concat( self.integrationSeries ).concat(
         self.hdrSeries );
      let label = baseLabel;
      if ( self.integrationSeries.length > 0 ) label += InNovaTr( " + integration" );
      if ( self.hdrSeries.length > 0 ) label += " + HDR";
      return { series: result, label: label };
   };

   this.bridgeHeader = StartBridgeHeader(this, true, this.guidedWorkflow, this.reviewCropMode);

   function savedSetting( key, fallback )
   {
      let value = Settings.read( key, DataType_String );
      return Settings.lastReadOK && typeof value == "string" ? value : fallback;
   }

   this.projectGroup = new GroupBox( this );
   this.projectGroup.title = InNovaTr( "Project" );
   this.projectCombo = new ComboBox( this.projectGroup );
   let projectItems = [ "LRGB", "RGB", "SHO", "HOO",
      InNovaTr( "OSC (RGB Color camera .xisf or Raw)" ), "SEESTAR (.fit)",
      "VAONIS VESPERA (.tiff)" ];
   let projectValues = [ "LRGB", "RGB", "SHO", "HOO", "OSC",
      "SEESTAR", "VAONIS_VESPERA" ];
   for ( let i = 0; i < projectItems.length; ++i )
      this.projectCombo.addItem( projectItems[i] );
   let savedProject = savedSetting( InNovaHandoffProjectSetting, "OSC" );
   this.projectCombo.currentItem = Math.max( 0,
      projectValues.indexOf( savedProject ) );
   this.projectCombo.toolTip =
      InNovaTr( "Select the same project type used by InNova Astro Processor." );
   this.projectGroup.sizer = new VerticalSizer;
   this.projectGroup.sizer.margin = 7;
   this.projectGroup.sizer.add( this.projectCombo );
   this.projectGroup.visible = false;

   this.acquisitionGroup = new GroupBox( this );
   this.acquisitionGroup.title = InNovaTr( "Acquisition" );
   this.acquisitionCombo = new ComboBox( this.acquisitionGroup );
   let acquisitionItems = [ "One single night", InNovaTr( "Multi-night" ),
      InNovaTr( "HDR (High Dynamic Range)" ) ];
   let acquisitionValues = [ "SINGLE_NIGHT", "MULTI_NIGHT", "HDR" ];
   for ( let i = 0; i < acquisitionItems.length; ++i )
      this.acquisitionCombo.addItem( acquisitionItems[i] );


   this.acquisitionCombo.currentItem = 0;
   this.acquisitionCombo.toolTip =
      InNovaTr( "Choose whether the images come from one night, multiple nights, or " +
      "multiple exposure levels for a high dynamic range composition." );
   this.acquisitionGroup.sizer = new VerticalSizer;
   this.acquisitionGroup.sizer.margin = 7;
   this.acquisitionGroup.sizer.add( this.acquisitionCombo );
   this.acquisitionGroup.visible = false;

   this.objectGroup = new GroupBox( this );
   this.objectGroup.title = InNovaTr( "Object type" );
   this.objectCombo = new ComboBox( this.objectGroup );
   this.objectCombo.addItem( InNovaTr( "Nebula or Galaxy" ) );
   this.objectCombo.addItem( InNovaTr( "Sun or Moon" ) );


   this.objectCombo.currentItem = 0;
   this.objectCombo.toolTip =
      InNovaTr( "Nebula or Galaxy uses stellar registration and astrometry. Sun or " +
      "Moon uses the bright-target workflow." );
   this.objectGroup.sizer = new VerticalSizer;
   this.objectGroup.sizer.margin = 7;
   this.objectGroup.sizer.add( this.objectCombo );
   this.objectGroup.visible = false;

   this.selectionRow = new HorizontalSizer;
   this.selectionRow.spacing = 9;
   this.selectionRow.add( this.projectGroup, 100 );

   this.saveHandoffSelections = function()
   {
      Settings.write( InNovaHandoffProjectSetting, DataType_String,
         projectValues[self.projectCombo.currentItem] );
      Settings.write( InNovaHandoffAcquisitionSetting, DataType_String,
         acquisitionValues[self.acquisitionCombo.currentItem] );
      Settings.write( InNovaHandoffObjectSetting, DataType_String,
         self.objectCombo.currentItem == 1 ? "MOON_SUN" : "STARS" );
   };
   this.projectCombo.onItemSelected = function() { self.saveHandoffSelections(); };
   this.acquisitionCombo.onItemSelected = function() { self.saveHandoffSelections(); };
   this.objectCombo.onItemSelected = function() { self.saveHandoffSelections(); };

   this.imagesGroup = new GroupBox( this );
   this.imagesGroup.title = InNovaTr( "Images" );
   this.imagesTree = new TreeBox( this.imagesGroup );
   this.imagesTree.numberOfColumns = 10;
   this.imagesTree.headerVisible = true;
   this.imagesTree.rootDecoration = false;
   this.imagesTree.multipleSelection = true;
   this.imagesTree.alternateRowColor = true;
   this.imagesTree.setHeaderText( 0, InNovaTr( "Use" ) );
   this.imagesTree.setHeaderText( 1, InNovaTr( "Combine" ) );
   this.imagesTree.setHeaderText( 2, InNovaTr( "Image" ) );
   this.imagesTree.setHeaderText( 3, InNovaTr( "Exposure" ) );
   this.imagesTree.setHeaderText( 4, InNovaTr( "Filter" ) );
   this.imagesTree.setHeaderText( 5, InNovaTr( "Camera" ) );
   this.imagesTree.setHeaderText( 6, InNovaTr( "Geometry" ) );
   this.imagesTree.setHeaderText( 7, InNovaTr( "Quality" ) );
   this.imagesTree.setHeaderText( 8, InNovaTr( "Project check" ) );
   this.imagesTree.setHeaderText( 9, InNovaTr( "Reference" ) );
   this.imagesTree.setColumnWidth( 0, 38 );
   this.imagesTree.setColumnWidth( 1, 65 );
   this.imagesTree.setColumnWidth( 2, 190 );
   this.imagesTree.setColumnWidth( 3, 80 );
   this.imagesTree.setColumnWidth( 4, 70 );
   this.imagesTree.setColumnWidth( 5, 130 );
   this.imagesTree.setColumnWidth( 6, 110 );
   this.imagesTree.setColumnWidth( 7, 70 );
   this.imagesTree.setColumnWidth( 8, 180 );
   this.imagesTree.setColumnWidth( 9, 70 );
   this.imagesTree.setScaledMinSize( 620, 330 );

   this.inputViewerGroup = new GroupBox( this.imagesGroup );
   this.inputViewerGroup.title = InNovaTr( "Preview" );
   this.inputPreview = new StartSubframePreviewControl(
      this.inputViewerGroup, 430, 330 );
   this.inputViewerGroup.sizer = new VerticalSizer;
   this.inputViewerGroup.sizer.margin = 7;
   this.inputViewerGroup.sizer.add( this.inputPreview, 100 );

   let inputReviewRow = new HorizontalSizer;
   inputReviewRow.spacing = 10;


   inputReviewRow.add( this.imagesTree, 135 );
   inputReviewRow.add( this.inputViewerGroup, 100 );


   this.imageToolbar = new Control( this.imagesGroup );
   this.imageToolbar.setScaledFixedHeight( 44 );
   this.arrangeButton = new ToolButton( this.imageToolbar );
   this.arrangeButton.icon = this.scaledResource( ":/icons/windows.png" );
   this.arrangeButton.setScaledFixedSize( 28, 28 );
   this.arrangeButton.toolTip = InNovaTr( "Minimize open images (Window > Arrange Icons organizes their icons)" );
   this.arrangeButton.onClick = function()
   {
      MiraPrepareWorkspaceForRun( self );
      self.bringToFront();
   };
   this.loadButton = new ToolButton( this.imageToolbar );
   this.loadButton.icon = this.scaledResource( ":/icons/folder-open.png" );
   this.loadButton.setScaledFixedSize( 28, 28 );
   this.loadButton.toolTip = InNovaTr( "Load images from disk" );
   this.subframeMastersButton = new ToolButton( this.imageToolbar );
   this.subframeMastersButton.icon = this.scaledResource(":/icons/documents-import.png");
   this.subframeMastersButton.setScaledFixedSize( 28, 28 );
   this.subframeMastersButton.toolTip =
      InNovaTr( "Load master images saved by InNova Subframe Review & Integration\n" +
      "Documents/InNova/Sub master files" );
   this.refreshButton = new ToolButton( this.imageToolbar );
   this.refreshButton.icon = InNovaEditorRefreshIcon();
   this.refreshButton.setScaledFixedSize( 28, 28 );
   this.refreshButton.toolTip = InNovaTr( "Refresh the list of open PixInsight images" );
   this.clearButton = new ToolButton( this.imageToolbar );
   this.clearButton.icon = this.scaledResource( ":/icons/trash.png" );
   this.clearButton.setScaledFixedSize( 28, 28 );
   this.clearButton.toolTip =
      InNovaTr( "Remove the selected image from the list" );
   this.inputZoomInButton = new ToolButton( this.imageToolbar );
   this.inputZoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.inputZoomInButton.setScaledFixedSize( 28, 28 );
   this.inputZoomInButton.toolTip = InNovaTr( "Zoom+ · Zoom in on the preview" );
   this.inputZoomInButton.enabled = false;
   this.inputFitButton = new ToolButton( this.imageToolbar );
   this.inputFitButton.icon = InNovaBlackPlaybackIcon( this, "fit" );
   this.inputFitButton.setScaledFixedSize( 28, 28 );
   this.inputFitButton.toolTip = InNovaTr( "Fit image to preview" );
   this.inputFitButton.enabled = false;
   this.inputFitButton.onClick = function() { self.inputPreview.fit(); };
   this.inputPanButton = new ToolButton( this.imageToolbar );
   this.inputPanButton.icon = StartHandIcon().scaledTo(
      this.logicalPixelsToPhysical(24), this.logicalPixelsToPhysical(24));
   this.inputPanButton.setScaledFixedSize( 30, 30 );
   this.inputPanButton.checkable = true;
   this.inputPanButton.checked = true;
   this.inputPanButton.toolTip =
      InNovaTr( "Pan · Drag to move the zoomed image" );
   this.inputPanButton.enabled = false;
   this.inputZoomOutButton = new ToolButton( this.imageToolbar );
   this.inputZoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.inputZoomOutButton.setScaledFixedSize( 28, 28 );
   this.inputZoomOutButton.toolTip = InNovaTr( "Zoom− · Zoom out of the preview" );
   this.inputZoomOutButton.enabled = false;
   this.inputQuickStretchLinked = null;
   this.inputQuickStretchToggleAvailable = false;
   this.inputInformationButton = new ToolButton(this.imageToolbar);
   this.inputInformationButton.icon = new Bitmap(InNovaInformationIconPath.replace("InNova_Information.png","information-toolbar.svg")).scaledTo(this.logicalPixelsToPhysical(30),this.logicalPixelsToPhysical(30));
   this.inputInformationButton.setScaledFixedSize(32,32);
   this.inputInformationButton.toolTip = "InNova Image Information";
   this.inputInformationButton.enabled = false;
   this.inputInformationButton.onClick = function() {
      let index=self.inputPreviewIndex;
      if(index>=0 && index<self.entries.length)InNovaShowInformation(self.entries[index].window);
   };
   this.inputQuickStretchLinkButton = new ToolButton( this.imageToolbar );
   this.inputQuickStretchLinkButton.icon = StartQuickStretchLinkIcon( true ).scaledTo(
         this.logicalPixelsToPhysical(26), this.logicalPixelsToPhysical(26));
   this.inputQuickStretchLinkButton.setScaledFixedSize( 32, 32 );
   this.inputQuickStretchLinkButton.toolTip =
      InNovaTr( "Unlink RGB channels and recalculate Quick Stretch" );
   this.inputQuickStretchLinkButton.enabled = false;
   this.updateInputQuickStretchLinkButton = function()
   {
      self.inputQuickStretchLinkButton.icon =
         StartQuickStretchLinkIcon( self.inputQuickStretchLinked !== true ).scaledTo(
         self.logicalPixelsToPhysical(26), self.logicalPixelsToPhysical(26));
      self.inputQuickStretchLinkButton.toolTip =
         self.inputQuickStretchLinked === true ?
         InNovaTr( "RGB channels: Linked · Click to unlink and recalculate Quick Stretch" ) :
         InNovaTr( "RGB channels: Unlinked · Click to link and recalculate Quick Stretch" );
   };
   this.inputCombineButton = new ToolButton( this.imageToolbar );
   this.inputCombineButton.icon = StartMultiExposureIcon();
   this.inputCombineButton.setScaledFixedSize( 32, 32 );
   this.inputCombineButton.checkable = true;
   this.inputCombineButton.enabled = false;
   this.inputCombineButton.toolTip =
      InNovaTr( "Add the selected source image to the multi-night combination and advance to the next image" );
   this.inputCropButton = new ToolButton( this.imageToolbar );
   this.inputCropButton.icon = StartCropIcon();
   this.inputCropButton.setScaledFixedSize( 32, 32 );
   this.inputCropButton.checkable = true;
   this.inputCropButton.enabled = false;
   this.inputCropButton.hide();
   this.inputCropButton.toolTip =
      InNovaTr( "Apply the automatic common crop to the prepared image copies" );
   this.inputResetBridgeButton = new ToolButton( this.imageToolbar );
   this.inputResetBridgeButton.icon =
      InNovaEditorLightActionIcon("reset");
   this.inputResetBridgeButton.setScaledFixedSize( 28, 28 );
   this.inputResetBridgeButton.enabled = false;
   this.inputResetBridgeButton.hide();
   this.inputResetBridgeButton.toolTip =
      InNovaTr( "Reset Multi-Night and return to the original input images" );
   this.cleanOutputsButton = new ToolButton( this.imageToolbar );
   this.cleanOutputsButton.icon = this.scaledResource( ":/icons/delete.png" );
   this.cleanOutputsButton.setScaledFixedSize( 32, 32 );
   this.cleanOutputsButton.toolTip =
      InNovaTr( "Close generated registration, integration, crop and HDR results, but keep the original input images" );
   this.runButton = new PushButton( this.imageToolbar );
   this.runButton.text = InNovaTr( "Run" );
   this.runButton.icon = InNovaBlackPlaybackIcon(this, "play");
   this.runButton.defaultButton = true;
   this.runButton.toolTip =
      InNovaTr( "Register and combine the selected multi-night images:\n" +
      "• inspect exposure, filter, camera, geometry and acquisition date;\n" +
      "• validate the selected multi-night group;\n" +
      "• detect auxiliary or potentially unrelated images;\n" +
      "• estimate quality and select the best reference from the dominant geometry;\n" +
      "• register non-reference images with StarAlignment;\n" +
      "• combine the registered copies with normalized SNR weighting;\n" +
      "• preserve every original image unchanged." );

   this.consoleButton = new ToolButton( this.imageToolbar );
   this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
   this.consoleButton.setScaledFixedSize( 28, 28 );
   this.consoleButton.toolTip = InNovaTr( "Show the PixInsight Process Console" );

   this.closeButton = new PushButton( this.imageToolbar );
   this.closeButton.text = InNovaTr( "Close" );
   this.closeButton.icon = this.scaledResource( ":/icons/close.png" );

   let imageButtons = new HorizontalSizer;
   imageButtons.spacing = 8;
   imageButtons.add( this.consoleButton );
   imageButtons.add( this.arrangeButton );
   imageButtons.add( this.loadButton );
   imageButtons.add( this.subframeMastersButton );
   imageButtons.add( this.refreshButton );
   imageButtons.add( this.cleanOutputsButton );
   imageButtons.add( this.clearButton );
   imageButtons.add( this.inputZoomInButton );
   imageButtons.add( this.inputFitButton );
   imageButtons.add( this.inputPanButton );
   imageButtons.add( this.inputZoomOutButton );
   imageButtons.add( this.inputQuickStretchLinkButton );
   imageButtons.add( this.inputInformationButton );
   imageButtons.add( this.inputCombineButton );
   imageButtons.add( this.inputCropButton );
   imageButtons.add( this.inputResetBridgeButton );
   imageButtons.addStretch();
   imageButtons.add( InNovaStyleBlackButton(this.runButton) );
   imageButtons.add( InNovaStyleBlackButton(this.closeButton) );
   this.imageToolbar.sizer = imageButtons;
   this.imageToolbar.sizer.margin = 4;
   this.imagesGroup.setScaledMinHeight( 430 );
   this.imagesGroup.sizer = new VerticalSizer;
   this.imagesGroup.sizer.margin = 8;
   this.imagesGroup.sizer.spacing = 7;
   this.imagesGroup.sizer.add( inputReviewRow, 100 );
   this.imagesGroup.sizer.addSpacing( 10 );
   this.imagesGroup.sizer.add( this.imageToolbar );

   this.reviewDialog = new Dialog; InNovaApplyBlackTheme(this.reviewDialog);
   this.reviewDialog.windowTitle =
      InNovaTr( "🔭 InNova Multi-Night" );
   this.reviewDialog.userResizable = true;

   this.reviewHeader = StartBridgeHeader(this.reviewDialog, false, false, this.reviewCropMode);

   this.viewerGroup = new GroupBox( this.reviewDialog );
   this.viewerGroup.title = InNovaTr( "Image Viewer" );
   this.imageInformationGroup = new GroupBox( this.reviewDialog );
   this.imageInformationGroup.title = InNovaTr("Image: 0 / 0");
   this.reviewInformationPanel = new Frame( this.reviewDialog );
   this.reviewInformationPanel.frameStyle = FrameStyle_Box;
   this.imageViewer = new InNovaStartImageViewer( this.viewerGroup,
      this.imageInformationGroup, this.reviewInformationPanel );


   this.latestPreparedByInputId = {};
   this.rememberLatestPrepared = function( inputItem, outputItem )
   {
      let inputWindow = inputItem != null ? (inputItem.window || inputItem) : null;
      let outputWindow = outputItem != null ? (outputItem.window || outputItem) : null;
      if ( inputWindow == null || inputWindow.isNull ||
           inputWindow.mainView == null || inputWindow.mainView.isNull ||
           outputWindow == null || outputWindow.isNull ||
           outputWindow.mainView == null || outputWindow.mainView.isNull ) return;
      self.latestPreparedByInputId[inputWindow.mainView.id] = outputItem;
   };
   this.resolveLatestPrepared = function( item )
   {
      let resolved = item;
      let visited = {};
      for ( ;; ) {
         let window = resolved != null ? (resolved.window || resolved) : null;
         if ( window == null || window.isNull || window.mainView == null ||
              window.mainView.isNull ) return item;
         let id = window.mainView.id;
         if ( visited[id] || self.latestPreparedByInputId[id] == null )
            return resolved;
         visited[id] = true;
         let candidate = self.latestPreparedByInputId[id];
         let candidateWindow = candidate.window || candidate;
         if ( candidateWindow == null || candidateWindow.isNull ||
              candidateWindow.mainView == null || candidateWindow.mainView.isNull ) {
            delete self.latestPreparedByInputId[id];
            return resolved;
         }
         resolved = candidate;
      }
   };
   this.resolveLatestPreparedSeries = function( series )
   {
      let resolved = [];
      for ( let i = 0; i < series.length; ++i )
         resolved.push( self.resolveLatestPrepared( series[i] ) );
      return resolved;
   };
   this.resolveLatestProcessorPrepared = function( item )
   {
      let resolved = self.resolveLatestPrepared( item );


      while ( resolved != null && resolved.alreadyStretched === true &&
              resolved.source != null )
         resolved = resolved.source;
      return resolved;
   };
   this.resolveLatestProcessorSeries = function( series )
   {
      let resolved = [];
      for ( let i = 0; i < series.length; ++i )
         resolved.push( self.resolveLatestProcessorPrepared( series[i] ) );
      return resolved;
   };
   this.imageViewer.onModuleResultShown = function( inputItem, outputItem )
   {
      self.rememberLatestPrepared( inputItem, outputItem );
   };
   this.imageViewer.adaptiveAccessEnabled = !this.guidedWorkflow;
   this.imageViewer.onConsoleRequested = function()
   {
      if ( self.consoleIsVisible ) self.hideProcessConsole();
      else self.showProcessConsole();
   };
   this.stretchedEditorSources = {};
   let runAdaptiveNow = function( window, skipConfirmation )
   {
      if ( self.guidedWorkflow ) return null;
      if ( skipConfirmation !== true &&
           StartAskCenteredQuestion( InNovaTr( "InNova Smart Stretch" ),
           InNovaTr( "Would you like to open InNova Smart Stretch?" ), true,
           InNovaTr( "InNova Smart Stretch" ) ) != StdButton_Yes )
         return null;
      let mainPosition = MiraParkIntegratorForAdaptiveStretch(self);
      let reviewPosition = MiraParkIntegratorForAdaptiveStretch(self.reviewDialog);
      let resultWindow = null;
      try {
         window.bringToFront();
         let stretched = StartRunAdaptiveEmbedded();
         if ( stretched && stretched.window && !stretched.window.isNull ) {
            resultWindow = stretched.window;
            self.stretchedEditorSources[stretched.sourceId] = stretched.window;
            self.stretchedEditorSources[stretched.window.mainView.id] = stretched.window;
            self.imageViewer.showModuleResult(stretched.window, stretched.sourceId);
         }
      } catch ( error ) {
         new InNovaNotice( InNovaTr( "InNova Smart Stretch could not be opened.\n\n" ) + error,
            "🔭 InNova Multi-Night", StdIcon_Error, StdButton_Ok ).execute();
      } finally {
         self.hideProcessConsole();


         if (mainPosition) self.position = mainPosition;
         MiraRestoreIntegratorAfterAdaptiveStretch(self.reviewDialog, reviewPosition);
         self.imageViewer.updateButtons();
      }
      return resultWindow;
   };
   this.imageViewer.onAdaptiveRequested = runAdaptiveNow;
   this.pendingSpccReport = null;
   this.imageViewer.onColorCalibrationRequested = function( window, item )
   {
      if ( self.guidedWorkflow ) return;
      self.imageViewer.colorCalibrationButton.enabled = false;
      self.beginElapsed( InNovaTr( "Preparing SPCC color calibration…" ), true );
      let completed = false;
      try {
         let deferredReport = {};
         let calibrated = StartRunSpccCopy( window, item, function( message ) {
            self.updateElapsed( message );
         }, deferredReport );
         if ( calibrated != null && !calibrated.isNull ) {
            self.pendingSpccReport = deferredReport;
            self.imageViewer.showModuleResult( calibrated,
               window.mainView.id, false );
            completed = true;
         }
      } finally {
         let elapsed = self.finishElapsed();
         let result = completed ? InNovaTr( "<b>SPCC completed.</b>" ) :
            InNovaTr( "SPCC was not completed." );
         result += "  " + StartElapsedRichText( elapsed );
         self.status.text = result;
         self.reviewStatus.text = result;
         self.hideProcessConsole();
         self.imageViewer.updateButtons();
      }
   };
   this.imageViewer.onImageSolverRequested = function( window, item )
   {
      if ( self.guidedWorkflow ) return;
      self.imageViewer.imageSolverButton.enabled = false;
      self.beginElapsed( "Running ImageSolver…", true );
      let completed = false;
      try {
         if ( StartRunImageSolver( window, item, function( message ) {
            self.updateElapsed( message );
         } ) ) {
            self.imageViewer.showCurrent();
            completed = true;
         }
      } finally {
         let elapsed = self.finishElapsed();
         let result = completed ? InNovaTr( "<b>ImageSolver completed.</b>" ) :
            InNovaTr( "ImageSolver was not completed." );
         result += "  " + StartElapsedRichText( elapsed );
         self.status.text = result;
         self.reviewStatus.text = result;
         self.hideProcessConsole();
         self.imageViewer.updateButtons();
      }
   };
   this.imageViewer.onProcessorRequested = function( window )
   {
      if (self.guidedWorkflow) return;
      let selected = [];
      for ( let i = 0; i < self.imageViewer.series.length; ++i ) {
         let item = self.imageViewer.series[i];
         let itemWindow = item.window || item;
         if ( itemWindow != null && !itemWindow.isNull &&
              !itemWindow.mainView.isNull &&
              itemWindow.mainView.id == window.mainView.id ) {
            let latest = self.resolveLatestPrepared( item );
            let processorSource = self.resolveLatestProcessorPrepared( item );
            let latestWindow = latest.window || latest;
            let processorWindow = processorSource.window || processorSource;
            if ( latest.alreadyStretched === true &&
                 latestWindow.mainView.id != processorWindow.mainView.id ) {
               let answer = StartAskCenteredQuestion(
                  InNovaTr( "InNova Multi-Night — Linear image required" ),
                  InNovaTr( "The selected image is already stretched and cannot be " +
                  "sent to InNova Astro Processor.\n\nWould you like to use " +
                  "the latest linear prepared image instead?\n" ) +
                  processorWindow.mainView.id,
                  true, processorWindow.mainView.id );
               if ( answer != StdButton_Yes ) return;
            }
            selected.push( processorSource );
            break;
         }
      }
      if ( selected.length == 0 ) {
         let latest = self.resolveLatestPrepared( window );
         let processorSource = self.resolveLatestProcessorPrepared( window );
         let latestWindow = latest.window || latest;
         let processorWindow = processorSource.window || processorSource;
         if ( latest.alreadyStretched === true &&
              latestWindow.mainView.id != processorWindow.mainView.id ) {
            let answer = StartAskCenteredQuestion(
               InNovaTr( "InNova Multi-Night — Linear image required" ),
               InNovaTr( "The selected image is already stretched and cannot be sent " +
               "to InNova Astro Processor.\n\nWould you like to use the " +
               "latest linear prepared image instead?\n" ) +
               processorWindow.mainView.id,
               true, processorWindow.mainView.id );
            if ( answer != StdButton_Yes ) return;
         }
         selected.push( processorSource );
      }
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return;
      }
      if (StartAskCenteredQuestion(InNovaTr( "InNova Astro Processor" ),
         InNovaTr( "Would you like to open InNova Astro Processor now?" ), true,
         InNovaTr( "InNova Astro Processor" )) != StdButton_Yes) return;
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new InNovaNotice(
            InNovaTr( "The selected image channel could not be identified. Check " +
            "its Filter or Bayer metadata." ),
            InNovaTr( "🔭 InNova Multi-Night — Channel not identified" ),
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }

      let handoffWindow = selected[0].window || selected[0];
      self.processorReturnSourceId = handoffWindow.mainView.id;
      self.processorDirectLaunchRequested = true;
      self.reviewNavigation = "processor";
      self.reviewDialog.ok();
   };
   let runEditorNow = function( window, stretched, skipConfirmation )
   {
      if ( self.guidedWorkflow ) return null;
      if ( skipConfirmation !== true &&
           StartAskCenteredQuestion( InNovaTr( "InNova Photo Editor" ),
           InNovaTr( "Would you like to open InNova Photo Editor?" ), true,
           InNovaTr( "InNova Photo Editor" ) ) != StdButton_Yes )
         return null;
      let mainPosition = MiraParkIntegratorForAdaptiveStretch(self);
      let reviewPosition = MiraParkIntegratorForAdaptiveStretch(self.reviewDialog);
      let resultWindow = null;
      try {
         let edited = StartRunEditorEmbedded(stretched);
         if ( edited && !edited.isNull ) {
            resultWindow = edited;
            self.stretchedEditorSources[window.mainView.id] = edited;
            self.stretchedEditorSources[stretched.mainView.id] = edited;
            self.stretchedEditorSources[edited.mainView.id] = edited;
            self.imageViewer.showModuleResult(edited, window.mainView.id);
         }
      } catch ( error ) {
         new InNovaNotice( InNovaTr( "InNova Photo Editor could not be opened.\n\n" ) + error,
            "🔭 InNova Multi-Night", StdIcon_Error, StdButton_Ok ).execute();
      } finally {
         self.hideProcessConsole();
         if (mainPosition) self.position = mainPosition;
         MiraRestoreIntegratorAfterAdaptiveStretch(self.reviewDialog, reviewPosition);
         self.imageViewer.updateButtons();
      }
      return resultWindow;
   };
   this.imageViewer.onEditorRequested = function( window )
   {
      if ( self.guidedWorkflow ) return;
      let stretched = self.stretchedEditorSources[window.mainView.id];
      if ( !stretched || stretched.isNull ) {
         if ( StartAskCenteredQuestion(
              InNovaTr( "InNova Smart Stretch" ),
              InNovaTr( "This image has not been stretched yet.\n\n" +
              "Would you like to run InNova Smart Stretch now?" ),
              true, InNovaTr( "InNova Smart Stretch" ) ) != StdButton_Yes )
            return;


         stretched = runAdaptiveNow( window, true );
         if ( !stretched || stretched.isNull ) return;
         runEditorNow( window, stretched, true );
         return;
      }
      runEditorNow( window, stretched, false );
   };
   this.viewerGroup.sizer = new VerticalSizer;
   this.viewerGroup.sizer.margin = 8;
   this.viewerGroup.sizer.add( this.imageViewer, 100 );
   this.imageInformationGroup.sizer = new VerticalSizer;
   this.imageInformationGroup.sizer.margin = 8;
   this.imageInformationGroup.sizer.spacing = 4;
   this.imageInformationGroup.sizer.add( this.imageViewer.fileLabel );
   this.imageInformationGroup.sizer.add( this.imageViewer.exifLabel );
   this.imageViewer.onRemoveRequested = function( item, viewerIndex, confirmed )
   {
      let window = item.window || item;
      if ( confirmed !== true ) {
         let answer = StartAskCenteredQuestion(
            InNovaTr( "🔭 InNova Multi-Night — Remove selected images" ),
            InNovaTr( "Do you want to remove the selected images from the list?" ), true );
         if ( answer != StdButton_Yes ) return;
      }

      let sourceEntry = item;
      while ( sourceEntry != null && sourceEntry.source != null )
         sourceEntry = sourceEntry.source;

      let keptEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i] !== sourceEntry )
            keptEntries.push( self.entries[i] );
      self.entries = keptEntries;
      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;

      let keptRegistered = [];
      for ( let i = 0; i < self.registeredSeries.length; ++i )
         if ( self.registeredSeries[i].source !== sourceEntry )
            keptRegistered.push( self.registeredSeries[i] );
      self.registeredSeries = keptRegistered;

      let keptCropped = [];
      for ( let i = 0; i < self.croppedSeries.length; ++i ) {
         let croppedSource = self.croppedSeries[i];
         while ( croppedSource != null && croppedSource.source != null )
            croppedSource = croppedSource.source;
         if ( croppedSource !== sourceEntry )
            keptCropped.push( self.croppedSeries[i] );
      }
      self.croppedSeries = keptCropped;

      if ( sourceEntry != null && sourceEntry.id == self.referenceId )
         self.referenceId = "";
      self.updateTree();
      let showingCropped = self.imageViewer.seriesLabel.indexOf(
         InNovaTr( "Cropped images" ) ) == 0;
      let remaining = showingCropped ?
         self.croppedSeries : self.registeredSeries;
      let rebuilt = self.buildViewerSeries( remaining,
         showingCropped ? InNovaTr( "Cropped images" ) : InNovaTr( "Registered images" ) );
      self.imageViewer.setSeries( rebuilt.series, rebuilt.label, viewerIndex );
      let enoughRegistered = self.registeredSeries.length >= 2;
      self.autoCropButton.enabled = enoughRegistered;
      self.cropButton.enabled = enoughRegistered;
      self.runButton.enabled = self.entries.length > 0;
      let removalStatus = InNovaTr( "Removed <b>" ) + window.mainView.id +
         InNovaTr( "</b> from the InNova Multi-Night project and image sequence. " +
         "The PixInsight image remains open and unchanged." );
      self.status.text = removalStatus;
      self.reviewStatus.text = removalStatus;
   };

   this.imageViewer.onMultiExposureRequested = function( item, selected )
   {
      if ( item == null || item.kind == "HDR" ||
           item.kind == "INTEGRATION" ) return;
      let source = item;
      while ( source != null && source.source != null ) source = source.source;
      if ( source == null ) return;
      let window = item.window || item;

      if ( selected && !self.multiExposureConfigured ) {
         let dialog = new StartMultiExposureDialog(
            self.acquisitionCombo.currentItem,
            [ window.mainView.id ], false );
         if ( dialog.execute() != StdDialogCode_Ok ) {
            source.multiExposureSelected = false;
            self.imageViewer.updateInformation();
            return;
         }
         self.multiExposureConfigured = true;
         self.saveHandoffSelections();
      }

      source.multiExposureSelected = selected === true;


      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;
      let selectedCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].multiExposureSelected === true ) ++selectedCount;
      if ( selectedCount == 0 ) {
         self.multiExposureConfigured = false;
         self.acquisitionCombo.currentItem = 0;
      }

      self.combinationPreviewGenerated = false;
      self.updateReviewNextButton();
      self.clearDerivedSeries();
      let showingCropped = self.imageViewer.seriesLabel.indexOf(
         InNovaTr( "Cropped images" ) ) == 0;
      let baseSeries = showingCropped && self.croppedSeries.length > 0 ?
         self.croppedSeries : self.registeredSeries;
      let preferredIndex = self.imageViewer.index;
      self.imageViewer.setSeries( baseSeries,
         showingCropped ? InNovaTr( "Cropped images" ) : InNovaTr( "Registered images" ),
         preferredIndex );
      self.updateTree();

      let treatment = self.acquisitionCombo.currentItem == 2 ? "HDR" :
         InNovaTr( "Multi-night" );
      let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
      let selectionStatus = selectedCount == 0 ?
         InNovaTr( "Multi-exposure selection cleared." ) :
         "<b style=\"color:#d97800\">" + treatment +
         InNovaTr( " selection:</b> " ) + selectedCount + InNovaTr( " image(s) selected. " ) +
         (selectedCount < required ?
            InNovaTr( "Select at least " ) + required + InNovaTr( " images." ) :
            InNovaTr( "Click Run to register and combine the selected images." ));
      self.status.text = selectionStatus;
      self.reviewStatus.text = selectionStatus;
   };

   this.cropGroup = new GroupBox( this.reviewDialog );
   this.cropGroup.title = InNovaTr( "Crop" );
   this.marginLabel = new Label( this.cropGroup );
   this.marginLabel.text = InNovaTr( "Safety margin:" );
   this.marginSpin = new SpinBox( this.cropGroup );
   this.marginSpin.minValue = 0;
   this.marginSpin.maxValue = 256;
   this.marginSpin.value = 12;
   this.marginSpin.suffix = " px";
   this.autoCropButton = new PushButton( this.cropGroup );
   this.autoCropButton.text = InNovaTr( "Auto common crop" );
   this.autoCropButton.enabled = false;
   this.cropButton = new PushButton( this.cropGroup );
   this.cropButton.text = InNovaTr( "Crop" );
   this.cropButton.enabled = false;
   this.cropButton.toolTip =
      InNovaTr( "Draw a rectangle on the image. The area inside is kept; the shaded area outside is cropped." );
   this.applyCropButton = new PushButton( this.cropGroup );
   this.applyCropButton.text = InNovaTr( "Apply to registered copies" );
   this.applyCropButton.enabled = false;
   this.cropValueLabel = new Label( this.cropGroup );
   this.cropValueLabel.useRichText = true;
   this.cropValueLabel.wordWrapping = true;
   this.cropValueLabel.text =
      InNovaTr( "Click Crop, then drag over the image to select the area to keep." );
   let cropRow = new HorizontalSizer;
   cropRow.spacing = 7;
   cropRow.add( this.marginLabel );
   cropRow.add( this.marginSpin );
   cropRow.addSpacing( 10 );
   cropRow.add( InNovaStyleBlackButton(this.autoCropButton) );
   cropRow.addSpacing( 10 );
   cropRow.add( InNovaStyleBlackButton(this.cropButton) );
   cropRow.add( InNovaStyleBlackButton(this.applyCropButton) );
   cropRow.addStretch();
   this.cropGroup.sizer = new VerticalSizer;
   this.cropGroup.sizer.margin = 8;
   this.cropGroup.sizer.spacing = 7;
   this.cropGroup.sizer.add( cropRow );
   this.cropGroup.sizer.add( this.cropValueLabel );
   this.cropGroup.visible = false;


   this.reviewStatus = this.imageViewer.footer;
   this.reviewInformationPanel.sizer = new VerticalSizer;
   this.reviewInformationPanel.sizer.margin = 7;
   this.reviewInformationPanel.sizer.spacing = 0;
   this.reviewInformationPanel.sizer.add( this.reviewStatus );
   this.reviewBackButton = new PushButton( this.reviewDialog );
   this.reviewBackButton.text = InNovaTr( "←  Back" );
   this.reviewBackButton.toolTip =
      InNovaTr( "Close the image review and return to InNova Multi-Night" );
   this.reviewNextButton = new PushButton( this.reviewDialog );
   this.reviewNextButton.text = InNovaTr( "Next  →" );
   if ( this.guidedWorkflow )
      this.reviewNextButton.styleSheet =
         InNovaStyleWithToolTips("color:#087bd5;font-weight:bold;");
   this.reviewBackButton.setScaledFixedHeight( 28 );
   this.reviewNextButton.setScaledFixedHeight( 28 );
   this.updateReviewNextButton = function()
   {
      let needsCombination = self.multiExposureConfigured &&
         !self.combinationPreviewGenerated;
      let cropBusy = self.imageViewer.cropInteractionActive === true ||
         self.confirmedCropApplyPending === true;
      self.reviewNextButton.text = needsCombination ? InNovaTr( "Apply Multi-night" ) :
         (self.guidedWorkflow ? InNovaTr( "Next  →" ) : InNovaTr( "Close" ));
      self.reviewNextButton.styleSheet = InNovaStyleWithToolTips(needsCombination ||
         self.guidedWorkflow ? "color:#087bd5;font-weight:bold;" : "");
      self.reviewNextButton.icon = needsCombination ?
         InNovaBlackPlaybackIcon(self, "play") :
         (self.guidedWorkflow ? new Bitmap : self.scaledResource( ":/icons/close.png" ));
      self.reviewNextButton.toolTip = needsCombination ?
         InNovaTr( "Review the selected images and choose the combination type" ) :
         (self.guidedWorkflow ? InNovaTr( "Choose images to send to InNova Astro Processor" ) :
          InNovaTr( "Close preparation and keep the images open without sending them to another module" ));
      self.reviewNextButton.enabled = !cropBusy &&
         !(needsCombination && self.multiExposureCropRequired);
   };
   this.updateReviewNextButton();
   let reviewBottom = new HorizontalSizer;
   reviewBottom.addStretch();
   reviewBottom.add( InNovaStyleBlackButton(this.reviewBackButton) );
   reviewBottom.addSpacing( 12 );
   reviewBottom.add( InNovaStyleBlackButton(this.reviewNextButton) );
   reviewBottom.addStretch();
   this.reviewDialog.sizer = new VerticalSizer;
   this.reviewDialog.sizer.margin = 10;
   this.reviewDialog.sizer.spacing = 9;
   this.reviewDialog.sizer.add( this.reviewHeader );
   this.reviewDialog.sizer.add( this.viewerGroup, 100 );
   this.reviewDialog.sizer.add( this.imageInformationGroup );
   this.reviewDialog.sizer.add( this.reviewInformationPanel );
   this.reviewDialog.sizer.add( reviewBottom );
   this.reviewNavigation = "back";


   this.applyConfirmedCropInReview = function()
   {
      let launchProcessor = false;
      try {
         let cropWasRequired = self.multiExposureCropRequired;
         let cropApplied = self.applyCropButton.onClick() === true;
         launchProcessor = self.runProcessorAfterCropRequested === true;
         self.runProcessorAfterCropRequested = false;
         if ( cropApplied && cropWasRequired ) {
            self.multiExposureCropRequired = false;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = true;
            self.reviewStatus.text +=
               InNovaTr( "<br/><b>Crop completed. Multi-night integration can continue.</b>" );
            self.status.text = self.reviewStatus.text;
         }
      }
      finally {
         self.imageViewer.setCropInteractionActive( false );
         self.reviewDialog.enabled = true;
         self.updateReviewNextButton();
      }
      if ( launchProcessor ) {
         self.reviewNavigation = "next";
         self.reviewDialog.ok();
      }
   };
   this.confirmedCropApplyPending = false;
   this.confirmedCropApplyTimer = new Timer;
   this.confirmedCropApplyTimer.interval = 0.05;
   this.confirmedCropApplyTimer.periodic = false;
   this.confirmedCropApplyTimer.onTimeout = function()
   {
      if ( !self.confirmedCropApplyPending ) return;
      self.confirmedCropApplyPending = false;
      self.applyConfirmedCropInReview();
   };
   this.reviewBackButton.onClick = function()
   {
      if (self.reviewOperationDepth > 0) return;
      self.reviewNavigation = "back";
      self.reviewDialog.ok();
   };
   this.reviewNextButton.onClick = function()
   {
      if ( self.multiExposureConfigured &&
           !self.combinationPreviewGenerated ) {
         let selectedSources = [];
         for ( let i = 0; i < self.entries.length; ++i )
            if ( self.entries[i].multiExposureSelected === true )
               selectedSources.push( self.entries[i] );
         let selectedImageIds = [];
         for ( let i = 0; i < selectedSources.length; ++i ) {
            let displayId = selectedSources[i].id;
            for ( let j = 0; j < self.imageViewer.series.length; ++j )
               if ( StartSeriesSourceEntry( self.imageViewer.series[j] ) ===
                    selectedSources[i] ) {
                  let selectedWindow = self.imageViewer.series[j].window ||
                     self.imageViewer.series[j];
                  if ( selectedWindow != null && !selectedWindow.isNull &&
                       selectedWindow.mainView != null &&
                       !selectedWindow.mainView.isNull )
                     displayId = selectedWindow.mainView.id;
                  break;
               }
            selectedImageIds.push( displayId );
         }
         if ( !self.combinationChoiceConfirmed ) {
            let combinationDialog = new StartMultiExposureDialog(
               self.acquisitionCombo.currentItem, selectedImageIds, true );
            if ( combinationDialog.execute() != StdDialogCode_Ok ) return;
            self.acquisitionCombo.currentItem =
               combinationDialog.acquisitionCombo.currentItem == 0 ? 1 : 2;
            self.combinationChoiceConfirmed = true;
            self.saveHandoffSelections();
         }
         let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
         if ( selectedSources.length < required ) {
            new InNovaNotice(
               self.acquisitionCombo.currentItem == 2 ?
                  InNovaTr( "<p align=\"center\">HDR requires <b>at least 3 images</b> with distinct exposure levels.<br/><br/>" +
                  "Use the star icon to add more images, then click <b>Apply Multi-night</b>.</p>" ) :
                  InNovaTr( "<p align=\"center\">Multi-night integration requires <b>at least 2 images</b>.<br/><br/>" +
                  "Use the star icon to add more images, then click <b>Apply Multi-night</b>.</p>" ),
               InNovaTr( "🔭 InNova Multi-Night — More images required" ),
               StdIcon_Information, StdButton_Ok ).execute();
            return;
         }
         if ( self.acquisitionCombo.currentItem == 2 ) {
            let levels = {};
            for ( let i = 0; i < selectedSources.length; ++i ) {
               if ( !isFinite( selectedSources[i].exposure ) ||
                    selectedSources[i].exposure <= 0 ) {
                  new InNovaNotice(
                     InNovaTr( "Every selected HDR image must provide a valid exposure value." ),
                     InNovaTr( "🔭 InNova Multi-Night — HDR exposure unavailable" ),
                     StdIcon_Warning, StdButton_Ok ).execute();
                  return;
               }
               levels[Math.round( 1000*selectedSources[i].exposure )] = true;
            }
            let levelCount = 0;
            for ( let level in levels ) ++levelCount;
            if ( levelCount < 3 ) {
               new InNovaNotice(
                  InNovaTr( "HDR requires at least three distinct exposure levels." ),
                  InNovaTr( "🔭 InNova Multi-Night — HDR requires three exposures" ),
                  StdIcon_Warning, StdButton_Ok ).execute();
               return;
            }
         }

         let showingCropped = self.croppedSeries.length > 0 &&
            self.imageViewer.seriesLabel.indexOf( InNovaTr( "Cropped images" ) ) == 0;
         let baseSeries = showingCropped ?
            self.croppedSeries : self.registeredSeries;


         let incompleteCoverage = self.multiExposureSynchronizedCropAccepted ?
            [] : StartIncompleteCombinationCoverage( baseSeries );
         if ( incompleteCoverage.length > 0 ) {
            self.multiExposureCropRequired = true;
            self.inputCropButton.show();
            self.inputResetBridgeButton.show();
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = false;
            self.updateReviewNextButton();
            StartShowMultiNightCropRequired(
               InNovaTr( "The selected images still contain registration borders " +
                  "without valid image data." ),
               "<p align=\"center\"><span style=\"color:#c62828\"><b>" +
                  StartHTMLText( incompleteCoverage.join( ", " ) ) +
                  "</b></span></p>",
               InNovaTr( "Use Crop to keep only the common covered area.<br/><br/>" +
                  "<b>The multi-night integration will then continue " +
                  "automatically.</b>" ) );
            self.focusCropRequiredImage(
               baseSeries, incompleteCoverage[0], showingCropped );
            return;
         }
         let compatibility = StartCombinationCompatibility(
            selectedSources, baseSeries );
         let selectedDetails = StartCombinationImageDetails(
            selectedSources, baseSeries );
         if ( !compatibility.sameGeometry ) {
            self.multiExposureCropRequired = true;
            self.inputCropButton.show();
            self.inputResetBridgeButton.show();
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = false;
            self.updateReviewNextButton();
            StartShowMultiNightCropRequired(
               InNovaTr( "The selected images cannot be combined because their " +
                  "registered geometry is different." ),
               InNovaTr( "<p align=\"center\"><b>Selected image characteristics" +
                  "</b><br/><br/>" ) + selectedDetails + "</p>",
               InNovaTr( "Use Crop to define a common image area. The multi-night " +
                  "integration will then continue automatically." ) );
            return;
         }
         let differingValues = [];
         if ( compatibility.differentCamera )
            differingValues.push( InNovaTr( "Cameras: " ) +
               compatibility.cameras.join( " / " ) );
         if ( self.acquisitionCombo.currentItem == 1 &&
              compatibility.differentExposure )
            differingValues.push( InNovaTr( "Exposure times: " ) +
               compatibility.exposures.join( " / " ) );
         if ( differingValues.length > 0 ) {
            let answer = StartAskCenteredQuestion(
               InNovaTr( "🔭 InNova Multi-Night — Different image characteristics" ),
               InNovaTr( "The selected images have the same registered geometry, " +
               "but these characteristics are different:\n\n" ) +
               differingValues.join( "\n" ) +
               InNovaTr( "\n\nDo you want to combine them anyway?" ),
               false, InNovaTr( "Do you want to combine them anyway?" ) );
            if ( answer != StdButton_Yes ) return;
         }
         self.combinationPreviewGenerated = true;
         let resultName = self.acquisitionCombo.currentItem == 2 ?
            "HDR" : InNovaTr( "Multi-night integration" );
         self.beginElapsed( InNovaTr( "Generating " ) + resultName + "…", true );
         let generated = null;
         let generationError = null;
         try {
            generated = self.buildViewerSeries( baseSeries,
               showingCropped ? InNovaTr( "Cropped images" ) : InNovaTr( "Registered images" ) );
         } catch ( error ) {
            generationError = error;
         }
         let generationElapsed = self.finishElapsed();
         if ( generationError != null ) {
            self.combinationPreviewGenerated = false;
            self.updateReviewNextButton();
            self.reviewStatus.text = "<b style=\"color:#c33\">" +
               resultName + InNovaTr( " failed:</b> " ) + generationError +
               "  " + StartElapsedRichText( generationElapsed );
            self.status.text = self.reviewStatus.text;
            new InNovaNotice( String( generationError ),
               InNovaTr( "🔭 InNova Multi-Night — Combination failed" ),
               StdIcon_Error, StdButton_Ok ).execute();
            return;
         }
         let derivedCount = self.integrationSeries.length +
            self.hdrSeries.length;
         if ( derivedCount == 0 &&
              self.acquisitionCombo.currentItem == 1 ) {
            let filters = {};
            let filterNames = [];
            for ( let i = 0; i < selectedSources.length; ++i ) {
               let filter = selectedSources[i].filter == "—" ?
                  (selectedSources[i].channels >= 3 ?
                     "OSC/COLOR" : "UNFILTERED") :
                  String( selectedSources[i].filter ).toUpperCase();
               if ( filters[filter] == null ) {
                  filters[filter] = true;
                  filterNames.push( filter );
               }
            }
            if ( filterNames.length > 1 ) {
               let combineAnswer = new InNovaNotice(
                  InNovaTr( "<p align=\"center\">Images captured with different " +
                  "filter types have been found: <b>" ) +
                  StartHTMLText( filterNames.join( " / " ) ) +
                  InNovaTr( "</b>.</p><p align=\"center\"><b>Selected image " +
                  "characteristics</b><br/><br/>" ) + selectedDetails +
                  InNovaTr( "</p><p align=\"center\"><b>Do you want to combine " +
                  "them anyway?</b></p>" ),
                  InNovaTr( "🔭 InNova Multi-Night — Different filter types found" ),
                  StdIcon_Warning, StdButton_Yes,
                  StdButton_No ).execute();
               if ( combineAnswer == StdButton_Yes ) {
                  self.combineDifferentFilters = true;
                  self.combinationPreviewGenerated = true;
                  self.beginElapsed(
                     InNovaTr( "Generating a mixed-filter Multi-night integration…" ), true );
                  generationError = null;
                  try {
                     generated = self.buildViewerSeries( baseSeries,
                        showingCropped ?
                           InNovaTr( "Cropped images" ) : InNovaTr( "Registered images" ) );
                  } catch ( error ) {
                     generationError = error;
                  }
                  generationElapsed = self.finishElapsed();
                  if ( generationError != null ) {
                     self.combinationPreviewGenerated = false;
                     self.combineDifferentFilters = false;
                     self.updateReviewNextButton();
                     self.reviewStatus.text =
                        "<b style=\"color:#c33\">" + resultName +
                        " failed:</b> " + generationError + "  " +
                        StartElapsedRichText( generationElapsed );
                     self.status.text = self.reviewStatus.text;
                     new InNovaNotice( String( generationError ),
                        InNovaTr( "🔭 InNova Multi-Night — Combination failed" ),
                        StdIcon_Error, StdButton_Ok ).execute();
                     return;
                  }
                  derivedCount = self.integrationSeries.length +
                     self.hdrSeries.length;
               } else {
                  self.combinationPreviewGenerated = false;
                  self.updateReviewNextButton();
                  self.reviewStatus.text =
                     InNovaTr( "The images were not combined because their filters " +
                     "are different." );
                  self.status.text = self.reviewStatus.text;
                  return;
               }
            }
         }
         if ( derivedCount == 0 ) {
            self.combinationPreviewGenerated = false;
            self.updateReviewNextButton();
            self.reviewStatus.text =
               InNovaTr( "<b style=\"color:#c33\">The selected images could not " +
               "be combined.</b> " ) + StartElapsedRichText( generationElapsed );
            self.status.text = self.reviewStatus.text;
            new InNovaNotice(
               InNovaTr( "<p align=\"center\">The selected images could not be " +
               "combined. Check their filter, registered geometry and " +
               "exposure values.<br/><br/><b>Selected image " +
               "characteristics</b><br/><br/>" ) + selectedDetails + "</p>",
               InNovaTr( "🔭 InNova Multi-Night — Combination unavailable" ),
               StdIcon_Warning, StdButton_Ok ).execute();
            return;
         }
         self.imageViewer.setSeries( generated.series, generated.label,
            generated.series.length - 1 );
         self.multiExposureSynchronizedCropAccepted = false;
         self.reviewStatus.text = "<b>" + resultName +
            InNovaTr( " generated.</b> " ) + StartElapsedRichText( generationElapsed );
         self.updateReviewNextButton();
         self.status.text = self.reviewStatus.text;
         return;
      }
      self.reviewNavigation = "next";
      self.reviewDialog.ok();
   };
   this.reviewDialog.adjustToContents();


   this.reviewCenterTimer = new Timer;
   this.reviewCenterTimer.interval = 0.05;
   this.reviewCenterTimer.periodic = false;
   this.reviewCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self.reviewDialog );
   };
   this.reviewDialog.onShow = function()
   {
      MiraCenterDialog( this );
      self.reviewCenterTimer.start();
   };
   MiraCenterDialog( this.reviewDialog );

   this.nextStepDialog = new Dialog; InNovaApplyBlackTheme(this.nextStepDialog);
   this.nextStepDialog.windowTitle =
      InNovaTr( "🔭 InNova Multi-Night — Processing Destination" );

   this.destinationHeader = StartLauncherPanel(this.nextStepDialog, true);
   this.destinationHeader.setScaledFixedHeight(92);
   this.destinationHeader.sizer = new HorizontalSizer;
   this.destinationHeader.sizer.margin = 12;
   this.destinationHeader.sizer.spacing = 16;
   this.destinationHeader.sizer.add(StartLauncherIcon(this.destinationHeader, "astro-processor", 68));
   let destinationText = new VerticalSizer;
   destinationText.spacing = 5;
   destinationText.addStretch();
   destinationText.add(StartLauncherLabel(this.destinationHeader,
      "<b>InNova Astro Processor</b>", 20, "#102b50", false));
   this.nextStepIntro = StartLauncherLabel(this.destinationHeader,
      InNovaTr( "Select the images to open in <b>InNova Astro Processor</b>. " +
      "The processing mode is selected after clicking Run there." ),
      12, "#243f5b", false);
   destinationText.add(this.nextStepIntro);
   destinationText.addStretch();
   this.destinationHeader.sizer.add(destinationText, 100);

   this.nextStepTree = new TreeBox( this.nextStepDialog );
   this.nextStepTree.numberOfColumns = 3;
   this.nextStepTree.headerVisible = true;
   this.nextStepTree.rootDecoration = false;
   this.nextStepTree.alternateRowColor = true;
   this.nextStepTree.setHeaderText( 0, InNovaTr( "Send" ) );
   this.nextStepTree.setHeaderText( 1, InNovaTr( "Image" ) );
   this.nextStepTree.setHeaderText( 2, InNovaTr( "Prepared type" ) );
   this.nextStepTree.setColumnWidth( 0, 60 );
   this.nextStepTree.setColumnWidth( 1, 300 );
   this.nextStepTree.setColumnWidth( 2, 150 );
   this.nextStepTree.setScaledMinSize( 520, 190 );
   this.destinationSeries = [];
   this.destinationSelection = [];

   this.populateDestinationImages = function()
   {
      self.nextStepTree.clear();
      self.destinationSeries = self.resolveLatestPreparedSeries(
         self.imageViewer.series );
      let hasCombinedResult = self.destinationSeries.some( function( item ) {
         return item.kind == "INTEGRATION" || item.kind == "HDR";
      } );
      for ( let i = 0; i < self.destinationSeries.length; ++i ) {
         let item = self.destinationSeries[i];
         let window = item.window || item;
         let isCombinedResult = item.kind == "INTEGRATION" ||
            item.kind == "HDR";
         let type = item.kind == "INTEGRATION" ?
            InNovaTr( "✅ NEW MULTI-EXPOSURE IMAGE" ) :
            (item.kind == "HDR" ? InNovaTr( "✅ NEW HDR" ) :
             (self.imageViewer.seriesLabel.indexOf( InNovaTr( "Cropped images" ) ) == 0 ?
                InNovaTr( "Cropped image" ) : InNovaTr( "Registered image" )));
         let node = new TreeBoxNode( self.nextStepTree );
         node.checkable = true;


         node.checked = hasCombinedResult ? isCombinedResult : true;
         node.setText( 1, window.mainView.id );
         node.setText( 2, type );
         if ( item.kind == "INTEGRATION" || item.kind == "HDR" )
            for ( let column = 0; column < 3; ++column ) {
               node.setBackgroundColor( column, 0xff254968 );
               node.setTextColor( column, 0xffe4e8ed );
            }
      }
      self.nextStepIntro.text =
         InNovaTr( "Select the images to open in <b>InNova Astro Processor</b>. " +
         "The processing mode is selected after clicking <b>Run</b> there." );
   };

   this.hasDestinationCroppedImages = function()
   {
      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              /innovastartcrop/i.test( windows[i].mainView.id ) )
            return true;
      return false;
   };

   this.deleteDestinationRegisteredImages = function( protectedSeries )
   {
      let protectedIds = {};
      for ( let i = 0; i < protectedSeries.length; ++i ) {
         let protectedWindow = protectedSeries[i].window || protectedSeries[i];
         if ( protectedWindow != null && !protectedWindow.isNull &&
              protectedWindow.mainView != null &&
              !protectedWindow.mainView.isNull )
            protectedIds[protectedWindow.mainView.id] = true;
      }
      let windows = ImageWindow.windows;
      let deleted = 0;
      for ( let i = 0; i < windows.length; ++i ) {
         let window = windows[i];
         if ( window == null || window.isNull || window.mainView.isNull ||
              !/innovastartregistered/i.test( window.mainView.id ) ||
              protectedIds[window.mainView.id] )
            continue;
         let id = window.mainView.id;
         try {
            window.forceClose();
            ++deleted;
            console.noteln( "🗑️ Deleted superseded registered image: " + id );
         } catch ( error ) {
            console.warningln( "⚠️ Could not delete registered image " +
               id + ": " + error );
         }
      }
      let retained = [];
      for ( let i = 0; i < self.registeredSeries.length; ++i ) {
         let itemWindow = self.registeredSeries[i].window ||
            self.registeredSeries[i];
         if ( itemWindow != null && !itemWindow.isNull &&
              itemWindow.mainView != null && !itemWindow.mainView.isNull )
            retained.push( self.registeredSeries[i] );
      }
      self.registeredSeries = retained;
      return deleted;
   };

   this.selectedDestinationImages = function()
   {
      let selected = [];
      for ( let i = 0; i < self.destinationSeries.length; ++i )
         if ( self.nextStepTree.child( i ).checked )
            selected.push( self.destinationSeries[i] );
      return selected;
   };

   this.prepareIntegratorHandoff = function( selected )
   {
      if (self.reviewCropMode && !StartReviewCropCheckProject(selected.map(function(item) {
         return StartSeriesSourceEntry(item);
      }))) return false;
      let requested = self.resolveLatestPreparedSeries( selected );
      selected = self.resolveLatestProcessorSeries( selected );
      for ( let i = 0; i < requested.length && i < selected.length; ++i ) {
         let requestedWindow = requested[i].window || requested[i];
         let selectedWindow = selected[i].window || selected[i];
         if ( requestedWindow != null && selectedWindow != null &&
              !requestedWindow.isNull && !selectedWindow.isNull &&
              !requestedWindow.mainView.isNull &&
              !selectedWindow.mainView.isNull &&
              requestedWindow.mainView.id != selectedWindow.mainView.id )
            console.noteln(
               "ℹ️ InNova Multi-Night: Astro Processor requires a linear image; " +
               "using " + selectedWindow.mainView.id + " instead of the " +
               "stretched result " + requestedWindow.mainView.id + "." );
      }
      let keys = [ "PimageSii", "PimageHa", "PimageOiii",
         "PimageRed", "PimageGreen", "PimageBlue",
         "PimageLuminance", "PimageOsc" ];
      let assignments = {};
      let priorities = {};
      for ( let i = 0; i < selected.length; ++i ) {
         let key = StartPreparedChannelKey( selected[i] );
         if ( key.length == 0 ) continue;
         let priority = StartPreparedImagePriority( selected[i] );
         if ( assignments[key] == null || priority > priorities[key] ) {
            let window = selected[i].window || selected[i];
            assignments[key] = window.mainView.id;
            priorities[key] = priority;
         }
      }
      let assignedCount = 0;
      for ( let i = 0; i < keys.length; ++i ) {
         let value = assignments[keys[i]] || "";
         Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
            DataType_String, value );
         if ( value.length > 0 ) ++assignedCount;
      }
      if ( assignedCount == 0 ) return false;
      self.saveHandoffSelections();
      let project = projectValues[self.projectCombo.currentItem];
      if ( assignments.PimageSii && assignments.PimageHa &&
           assignments.PimageOiii )
         project = "SHO";
      else if ( assignments.PimageHa && assignments.PimageOiii )
         project = "HOO";
      else if ( assignments.PimageRed && assignments.PimageGreen &&
                assignments.PimageBlue && assignments.PimageLuminance )
         project = "LRGB";
      else if ( assignments.PimageRed && assignments.PimageGreen &&
                assignments.PimageBlue )
         project = "RGB";
      else if ( assignments.PimageOsc ) {
         project = "OSC";
         for ( let i = 0; i < selected.length; ++i ) {
            let colorItemWindow = selected[i].window || selected[i];
            if ( colorItemWindow != null && !colorItemWindow.isNull &&
                 !colorItemWindow.mainView.isNull &&
                 colorItemWindow.mainView.id == assignments.PimageOsc ) {
               project = StartPreparedOscProject( selected[i] );
               break;
            }
         }
      }
      let useRgbStars =
         (project == "SHO" || project == "HOO") &&
         assignments.PimageRed && assignments.PimageGreen &&
         assignments.PimageBlue;
      let useHaBlend =
         (project == "RGB" || project == "LRGB") &&
         assignments.PimageHa;
      Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
         DataType_String, useRgbStars ? "1" : "0" );
      Settings.write( InNovaIntegratorHandoffHaBlendSetting,
         DataType_String, useHaBlend ? "1" : "0" );
      Settings.write( InNovaIntegratorHandoffProjectSetting,
         DataType_String, project );
      Settings.write( InNovaIntegratorHandoffPendingSetting,
         DataType_String, "1" );
      return true;
   };

   this.integratorDestinationButton = new PushButton(
      this.nextStepDialog );
   this.integratorDestinationButton.text = InNovaTr( "Run" );
   this.integratorDestinationButton.icon =
      InNovaBlackPlaybackIcon(this, "play");
   this.integratorDestinationButton.toolTip =
      InNovaTr( "Open the selected images in InNova Astro Processor" );
   this.integratorDestinationButton.setScaledFixedSize( 92, 24 );
   this.integratorDestinationButton.onClick = function()
   {
      if ( !self.guidedWorkflow ) return;
      let selected = self.selectedDestinationImages();
      if ( selected.length == 0 ) {
         new InNovaNotice(
            InNovaTr( "Select at least one prepared image to continue." ),
            InNovaTr( "🔭 InNova Multi-Night — No images selected" ),
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return;
      }
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new InNovaNotice(
            InNovaTr( "The selected image channels could not be identified. Check " +
            "their Filter metadata or use channel names such as Sii, Ha, " +
            "Oiii, R, G, B or L." ),
            InNovaTr( "🔭 InNova Multi-Night — Channels not identified" ),
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }


      if ( self.hasDestinationCroppedImages() )
         self.deleteDestinationRegisteredImages( selected );
      self.destinationSelection = selected;
      self.integratorLaunchRequested = true;
      self.nextStepDialog.ok();
   };

   this.cancelDestinationButton = new PushButton( this.nextStepDialog );
   this.cancelDestinationButton.text = InNovaTr( "Cancel" );
   this.cancelDestinationButton.icon =
      this.scaledResource( ":/icons/cancel.png" );
   this.cancelDestinationButton.toolTip =
      InNovaTr( "Close this selection without opening InNova Astro Processor" );
   this.cancelDestinationButton.setScaledFixedSize( 92, 24 );
   this.cancelDestinationButton.onClick = function()
   {
      self.integratorLaunchRequested = false;
      self.nextStepDialog.cancel();
   };

   let destinations = new HorizontalSizer;
   destinations.spacing = 10;
   destinations.addStretch();
   destinations.add( InNovaStyleBlackButton(this.integratorDestinationButton) );
   destinations.add( InNovaStyleBlackButton(this.cancelDestinationButton) );

   this.nextStepDialog.sizer = new VerticalSizer;
   this.nextStepDialog.sizer.margin = 16;
   this.nextStepDialog.sizer.spacing = 12;
   this.nextStepDialog.sizer.add( this.destinationHeader );
   this.nextStepDialog.sizer.addSpacing( 4 );
   this.nextStepDialog.sizer.add( this.nextStepTree, 100 );
   this.nextStepDialog.sizer.addSpacing( 4 );
   this.nextStepDialog.sizer.add( destinations );
   this.nextStepDialog.adjustToContents();
   this.integratorLaunchRequested = false;

   this.continueGuidedMultiNightToProcessor = function()
   {
      if ( !self.guidedWorkflow ) return false;
      let selected = [];
      let combined = self.integrationSeries.concat( self.hdrSeries );
      for ( let i = 0; i < combined.length; ++i ) {
         let window = combined[i].window || combined[i];
         if ( window != null && !window.isNull &&
              window.mainView != null && !window.mainView.isNull )
            selected.push( combined[i] );
      }
      if ( selected.length == 0 ) return false;
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return false;
      }
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new InNovaNotice(
            InNovaTr( "The combined image channels could not be identified. Check " +
            "their Filter metadata or channel names before continuing." ),
            InNovaTr( "🔭 InNova Multi-Night — Channels not identified" ),
            StdIcon_Warning, StdButton_Ok ).execute();
         return false;
      }
      self.destinationSelection = selected;
      self.integratorLaunchRequested = true;
      self.ok();
      return true;
   };

   this.executeReviewStep = function()
   {
      if ( self.unifiedBridgeWindow ) {
         let completed = self.runUnifiedMultiNightCombination();
         self.presentPreparedInBridge();
         if ( completed ) {
            self.offerMultiNightSave();
            self.continueGuidedMultiNightToProcessor();
         }
         return;
      }

      self.hideProcessConsole();
      self.reviewNavigation = "back";
      self.reviewDialog.enabled = true;
      self.updateReviewNextButton();
      self.reviewDialog.execute();


      if ( self.processorDirectLaunchRequested ) {
         self.pendingSpccReport = null;
         self.ok();
         return;
      }
      if ( self.pendingSpccReport != null ) {
         let pendingReport = self.pendingSpccReport;
         self.pendingSpccReport = null;
         StartShowDeferredSpccReport( pendingReport );
      }
      if ( self.reviewNavigation == "next" ) {
         if ( !self.guidedWorkflow ) {
            self.preparationFinished = true;
            self.ok();
            return;
         }
         self.populateDestinationImages();
         self.nextStepDialog.execute();
         if ( self.integratorLaunchRequested ) self.ok();
      }
   };

   this.status = new Label( this );
   this.status.useRichText = true;
   this.status.wordWrapping = true;
   this.status.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.status.frameStyle = FrameStyle_Box;
   this.status.styleSheet = InNovaStyleWithToolTips("QLabel { border: 1px solid #535d68; background-color: #2d3136; color: #e4e8ed; }");
   this.status.margin = 8;
   this.status.setScaledMinHeight( 88 );
   this.elapsedStarted = 0;
   this.elapsedMessage = "";
   this.elapsedInReview = false;
   this.elapsedText = function()
   {
      let seconds = Math.max( 0,
         Math.floor( (Date.now() - self.elapsedStarted)/1000 ) );
      function two( value ) { return value < 10 ? "0" + value : String( value ); }
      return two( Math.floor( seconds/3600 ) ) + ":" +
         two( Math.floor( (seconds%3600)/60 ) ) + ":" +
         two( seconds%60 );
   };
   this.elapsedTimer = new Timer( 1, true, this );
   this.elapsedTimer.onTimeout = function()
   {
      if ( self.elapsedStarted <= 0 ) return;
      self.status.text = self.elapsedMessage +
         "  " + StartElapsedRichText( self.elapsedText() );
      self.status.update();
      if ( self.elapsedInReview ) {
         self.reviewStatus.text = self.elapsedMessage +
            "  " + StartElapsedRichText( self.elapsedText() );
         self.reviewStatus.update();
      }
   };
   this.beginElapsed = function( message, inReview )
   {
      InNovaDiagnosticWrite("STATUS", "Image preparation", String(message));
      console.noteln( "⚙️ " + message );
      self.elapsedMessage = message;
      self.elapsedInReview = inReview === true;
      self.elapsedStarted = Date.now();
      self.elapsedTimer.stop();
      self.elapsedTimer.start();
      self.status.text = message + "  " + StartElapsedRichText( "00:00:00" );
      self.status.update();
      if ( self.elapsedInReview ) {
         self.reviewStatus.text =
            message + "  " + StartElapsedRichText( "00:00:00" );
         self.reviewStatus.update();
      }
      CoreApplication.processEvents();
   };
   this.updateElapsed = function( message )
   {
      if ( self.elapsedStarted <= 0 ) return;
      self.elapsedMessage = message;
      self.elapsedTimer.onTimeout();
      CoreApplication.processEvents();
   };
   this.finishElapsed = function()
   {
      let text = self.elapsedStarted > 0 ? self.elapsedText() : "00:00:00";
      self.elapsedTimer.stop();
      self.elapsedStarted = 0;
      self.elapsedInReview = false;
      return text;
   };

   this.consoleIsVisible = false;
   this.showProcessConsole = function()
   {
      console.show();
      self.consoleIsVisible = true;
      self.consoleButton.toolTip = InNovaTr( "Hide the PixInsight Process Console" );
      if (self.imageViewer && self.imageViewer.consoleButton)
         self.imageViewer.consoleButton.toolTip =
            InNovaTr( "Hide the PixInsight Process Console" );
      CoreApplication.processEvents();
   };
   this.hideProcessConsole = function()
   {
      console.hide();
      self.consoleIsVisible = false;
      self.consoleButton.toolTip = InNovaTr( "Show the PixInsight Process Console" );
      if (self.imageViewer && self.imageViewer.consoleButton)
         self.imageViewer.consoleButton.toolTip =
            InNovaTr( "Show the PixInsight Process Console" );
      CoreApplication.processEvents();
   };

   this.sizer = new VerticalSizer;
   this.sizer.margin = 10;
   this.sizer.spacing = 9;
   this.sizer.add( this.bridgeHeader );
   this.sizer.add( this.imagesGroup, 100 );
   this.sizer.add( this.status );
   this.sizer.addSpacing( 16 );

   this.selectedEntries = function()
   {
      let selected = [];
      for ( let i = 0; i < self.entries.length; ++i ) {
         if ( self.entries[i].generatedMultiNight === true ) continue;
         self.entries[i].enabled = self.imagesTree.child( i ).checked;
         if ( self.entries[i].enabled &&
              (!self.multiExposureConfigured ||
               self.entries[i].multiExposureSelected === true) )
            selected.push( self.entries[i] );
      }
      return selected;
   };

   this.focusCropRequiredImage = function( series, imageId, showingCropped )
   {
      let seriesIndex = -1;
      let sourceEntry = null;
      for ( let i = 0; i < series.length; ++i ) {
         let window = series[i].window || series[i];
         if ( window != null && !window.isNull &&
              !window.mainView.isNull && window.mainView.id == imageId ) {
            seriesIndex = i;
            sourceEntry = StartSeriesSourceEntry( series[i] );
            break;
         }
      }
      if ( seriesIndex < 0 ) return false;

      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i] === sourceEntry ||
              (sourceEntry != null && self.entries[i].id == sourceEntry.id) ) {


            self.inputPreviewIndex = i;
            break;
         }


      self.imageViewer.setSeries( series,
         showingCropped ? InNovaTr( "Cropped images" ) : InNovaTr( "Registered images" ),
         seriesIndex );
      return true;
   };

   this.selectInputPreview = function( index )
   {
      if ( index < 0 || index >= self.entries.length ) return;
      let entry = self.entries[index];


      let preserveManualZoom = !self.inputPreview.fitMode;
      let previousScale = self.inputPreview.scale;
      let previousCenter = null;
      if ( preserveManualZoom && self.inputPreview.scaledBitmap != null ) {
         let viewport = self.inputPreview.viewport.viewport;
         let offset = self.inputPreview.viewport.bitmapOffsetFor(
            self.inputPreview );
         previousCenter = {
            x: (viewport.width/2 - offset.x)/
               self.inputPreview.scaledBitmap.width,
            y: (viewport.height/2 - offset.y)/
               self.inputPreview.scaledBitmap.height
         };
      }
      self.inputPreviewIndex = index;
      let state = {};
      let previewWindow = entry.loaderPreviewWindow != null &&
         !entry.loaderPreviewWindow.isNull ?
         entry.loaderPreviewWindow : entry.window;
      let linked = typeof entry.inputQuickStretchLinked == "boolean" &&
         entry.inputQuickStretchAutomatic !== true ?
         entry.inputQuickStretchLinked : false;
      self.inputPreview.setBitmap( StartQuickStretchBitmap(
         previewWindow, false, linked, state ),
         previewWindow.mainView.image.width,
         previewWindow.mainView.image.height );
      self.inputQuickStretchLinked = state.linked;
      self.inputQuickStretchToggleAvailable = state.adjustable === true;
      entry.inputQuickStretchLinked = state.linked;
      entry.inputQuickStretchAutomatic = state.automatic === true;
      self.updateInputQuickStretchLinkButton();
      if ( preserveManualZoom && self.inputPreview.bitmap != null ) {
         self.inputPreview.setZoom( previousScale );
         if ( previousCenter != null &&
              self.inputPreview.scaledBitmap != null ) {
            let viewport = self.inputPreview.viewport.viewport;
            self.inputPreview.viewport.horizontalScrollPosition = Math.range(
               Math.round( previousCenter.x*
                  self.inputPreview.scaledBitmap.width - viewport.width/2 ),
               0, self.inputPreview.viewport.maxHorizontalScrollPosition );
            self.inputPreview.viewport.verticalScrollPosition = Math.range(
               Math.round( previousCenter.y*
                  self.inputPreview.scaledBitmap.height - viewport.height/2 ),
               0, self.inputPreview.viewport.maxVerticalScrollPosition );
            viewport.update();
         }
      }
      self.inputZoomInButton.enabled = self.inputPreview.bitmap != null;
      self.inputFitButton.enabled = self.inputPreview.bitmap != null;
      self.inputPanButton.enabled = self.inputPreview.bitmap != null;
      self.inputZoomOutButton.enabled = self.inputPreview.bitmap != null;
      self.inputInformationButton.enabled = self.inputPreview.bitmap != null;
      self.inputQuickStretchLinkButton.enabled =
         self.inputPreview.bitmap != null &&
         self.inputQuickStretchToggleAvailable;
      self.inputCombineButton.enabled = true;
      if ( entry.generatedMultiNight === true )
         self.inputCombineButton.enabled = false;
      self.inputCombineButton.checked = entry.multiExposureSelected === true;
      self.inputCropButton.enabled = self.registeredSeries.length >= 2;
      self.inputResetBridgeButton.enabled = self.registeredSeries.length > 0 ||
         self.croppedSeries.length > 0 || self.integrationSeries.length > 0 ||
         self.hdrSeries.length > 0;
   };

   this.inputZoomInButton.onClick = function()
   {
      self.inputPreview.setZoom( self.inputPreview.scale*1.35 );
   };
   this.inputPanButton.onClick = function( checked )
   {
      self.inputPreview.panEnabled = checked;
      self.inputPreview.scrolling = null;
      self.inputPreview.viewport.viewport.cursor = new Cursor( checked ?
         StdCursor_OpenHand : StdCursor_Arrow );
   };
   this.inputZoomOutButton.onClick = function()
   {
      self.inputPreview.setZoom( self.inputPreview.scale/1.35 );
   };
   this.inputQuickStretchLinkButton.onClick = function()
   {
      if ( !self.inputQuickStretchToggleAvailable ||
           self.inputPreviewIndex < 0 ||
           self.inputPreviewIndex >= self.entries.length ) return;
      let entry = self.entries[self.inputPreviewIndex];
      entry.inputQuickStretchLinked =
         self.inputQuickStretchLinked !== true;
      entry.inputQuickStretchAutomatic = false;
      self.selectInputPreview( self.inputPreviewIndex );
   };

   this.setInputCombine = function( index, selected )
   {
      if ( index < 0 || index >= self.entries.length ) return;
      self.entries[index].multiExposureSelected = selected === true;
      let selectedCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].multiExposureSelected === true ) ++selectedCount;
      self.multiExposureConfigured = selectedCount > 0;
      self.acquisitionCombo.currentItem = selectedCount > 0 ? 1 : 0;
      self.combinationPreviewGenerated = false;
      self.combinationChoiceConfirmed = false;
      self.updateTree( index );
      self.status.text = selectedCount > 0 ?
         InNovaTr( "<b style=\"color:#d97800\">Combine:</b> " ) + selectedCount +
         InNovaTr( " image(s) selected. Select at least two compatible images before Run." ) :
         InNovaTr( "Combine selection cleared." );
   };

   this.advanceInputPreviewAfterCombine = function( index, selected )
   {


      if ( selected !== true ) return;
      let nextIndex = index + 1;
      while ( nextIndex < self.entries.length &&
              self.entries[nextIndex].generatedMultiNight === true )
         ++nextIndex;

      if ( nextIndex >= self.entries.length ) return;
      self.selectInputPreview( nextIndex );
      let current = self.imagesTree.child( nextIndex );
      if ( current != null ) self.imagesTree.currentNode = current;
   };

   this.inputCombineButton.onClick = function()
   {
      let index = self.inputPreviewIndex;
      let selected = this.checked;
      self.setInputCombine( index, selected );
      self.advanceInputPreviewAfterCombine( index, selected );
   };

   this.imagesTree.onCurrentNodeUpdated = function( node )
   {
      if ( node == null ) return;
      let index = node.__index__;
      if ( index >= 0 && index < self.entries.length &&
           index != self.inputPreviewIndex )
         self.selectInputPreview( index );
   };

   this.imagesTree.onNodeClicked = function( node, column )
   {
      if ( node == null || column != 1 ) return;
      let index = node.__index__;
      if ( index < 0 || index >= self.entries.length ) return;
      if ( self.entries[index].generatedMultiNight === true ) return;
      self.setInputCombine( index,
         self.entries[index].multiExposureSelected !== true );
   };

   this.imagesTree.onNodeUpdated = function( node, column )
   {
      if ( column != 0 || node == null ) return;
      let index = node.__index__;
      if ( index < 0 || index >= self.entries.length ) return;
      if ( self.entries[index].generatedMultiNight === true ) return;
      self.entries[index].enabled = node.checked;
      for ( let c = 0; c < 10; ++c )
         node.setTextColor( c, node.checked ? 0xffe4e8ed : 0xffef8178 );
      self.runButton.enabled = self.entries.some(
         function( entry ) { return entry.enabled; } ) &&
         self.integrationSeries.length == 0;
   };

   this.updateTree = function( preferredIndex )
   {
      if ( preferredIndex === undefined )
         preferredIndex = self.inputPreviewIndex === undefined ?
            0 : self.inputPreviewIndex;
      self.imagesTree.clear();
      for ( let i = 0; i < self.entries.length; ++i ) {
         let entry = self.entries[i];
         let displayWindow = entry.loaderPreviewWindow != null &&
            !entry.loaderPreviewWindow.isNull ?
            entry.loaderPreviewWindow : entry.window;
         let displayImage = displayWindow.mainView.image;
         let node = new TreeBoxNode( self.imagesTree );
         node.__index__ = i;
         node.checkable = entry.generatedMultiNight !== true;
         node.checked = entry.enabled;
         node.setText( 1, entry.generatedMultiNight === true ? "—" :
            (entry.multiExposureSelected ? "★" : "☆") );
         node.setText( 2, displayWindow.mainView.id );
         node.setText( 3, StartExposureText( entry.exposure ) );
         node.setText( 4, entry.filter );
         node.setText( 5, entry.camera );
         node.setText( 6, displayImage.width + " × " + displayImage.height );
         node.setText( 7, entry.quality == null ? "—" :
            format( "%.3f", entry.quality.score ) );
         node.setText( 8, entry.projectStatus );
         node.setText( 9, entry.id == self.referenceId ? "✓" : "" );
         if ( entry.generatedMultiNight === true )
            for ( let column = 0; column < 10; ++column ) {
               node.setBackgroundColor( column, 0xff284536 );
               node.setTextColor( column, 0xff7ccd99 );
            }
         else if ( entry.multiExposureSelected || entry.hdrCompatible )
            for ( let column = 0; column < 10; ++column ) {
               node.setBackgroundColor( column, 0xff254968 );
               node.setTextColor( column, 0xffe4e8ed );
            }
         else if ( !entry.enabled )
            for ( let column = 0; column < 10; ++column )
               node.setTextColor( column, 0xffef8178 );
      }
      if ( self.entries.length > 0 ) {
         preferredIndex = Math.range( preferredIndex, 0,
            self.entries.length - 1 );
         self.selectInputPreview( preferredIndex );
         let current = self.imagesTree.child( preferredIndex );
         if ( current != null ) self.imagesTree.currentNode = current;
      } else {
         self.inputPreviewIndex = -1;
         self.inputPreview.setBitmap( null );
         self.inputZoomInButton.enabled = false;
      self.inputFitButton.enabled = false;
         self.inputPanButton.enabled = false;
         self.inputZoomOutButton.enabled = false;
         self.inputQuickStretchLinkButton.enabled = false;
         self.inputInformationButton.enabled = false;
         self.inputCombineButton.enabled = false;
         self.inputCombineButton.checked = false;
         self.inputCropButton.enabled = false;
         self.inputResetBridgeButton.enabled = false;
      }
   };

   this.presentPreparedInBridge = function()
   {
      let sourceEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true )
            sourceEntries.push( self.entries[i] );
      self.entries = sourceEntries;
      let prepared = self.croppedSeries.length > 0 ?
         self.croppedSeries : self.registeredSeries;
      for ( let i = 0; i < self.entries.length; ++i )
         self.entries[i].loaderPreviewWindow = null;
      for ( let i = 0; i < prepared.length; ++i ) {
         let source = StartSeriesSourceEntry( prepared[i] );
         let preparedWindow = prepared[i].window || prepared[i];
         for ( let j = 0; j < self.entries.length; ++j )
            if ( self.entries[j] === source ||
                 self.entries[j].id == (source != null ? source.id : "") ) {
               self.entries[j].loaderPreviewWindow = preparedWindow;
               break;
            }
      }
      let resultIndex = self.inputPreviewIndex;
      for ( let i = 0; i < self.integrationSeries.length; ++i ) {
         let resultWindow = self.integrationSeries[i].window ||
            self.integrationSeries[i];
         if ( resultWindow == null || resultWindow.isNull ) continue;
         let resultEntry = StartImageEntry( resultWindow );
         resultEntry.generatedMultiNight = true;
         resultEntry.enabled = false;
         resultEntry.projectCompatible = false;
         resultEntry.projectStatus = InNovaTr( "✓ Multi-night result" );
         resultEntry.loaderPreviewWindow = resultWindow;
         self.entries.push( resultEntry );
         resultIndex = self.entries.length - 1;
      }
      self.updateTree( resultIndex );
      self.inputCropButton.enabled = self.registeredSeries.length >= 2;
      self.inputResetBridgeButton.enabled = prepared.length > 0;
      self.runButton.enabled = self.entries.some(
         function( entry ) { return entry.enabled; } ) &&
         self.integrationSeries.length == 0;
      let resultType = self.croppedSeries.length > 0 ? InNovaTr( "cropped" ) :
         (self.registeredSeries.length > 1 ? InNovaTr( "registered" ) : InNovaTr( "prepared" ));
      self.status.text = self.integrationSeries.length > 0 ?
         "<span style=\"color:#72b8f4\">" + InNovaTr( "<b>Multi-night integration completed.</b><br/>The combined result " +
         "is selected in the table. Registered copies and originals remain " +
         "unchanged." ) + "</span>" :
         InNovaTr( "<b>Multi-night preparation completed.</b><br/>" ) + prepared.length +
         " " + resultType + InNovaTr( " image(s) are ready. If registration borders " +
         "remain, use Crop to continue the combination." );
   };

   this.runUnifiedMultiNightCombination = function()
   {
      if ( !self.multiExposureConfigured ) return false;
      self.acquisitionCombo.currentItem = 1;
      self.combinationChoiceConfirmed = true;
      self.combinationPreviewGenerated = false;
      self.reviewNextButton.onClick();
      return self.integrationSeries.length > 0;
   };

   this.offerMultiNightSave = function()
   {
      if ( self.multiNightSaveOffered || self.integrationSeries.length == 0 )
         return;
      self.multiNightSaveOffered = true;
      self.runButton.enabled = false;
      self.runButton.update();
      let masterDirectory = StartSubframeMasterDirectory();
      let saveChoice = StartSubframeAskToSaveMasters( masterDirectory, {
         dialogTitle: InNovaTr( "🔭 InNova Multi-Night — Save master files" ),
         iconName: "bridge",
         heading: InNovaTr( "Save master files?" ),
         completedText: InNovaTr( "The multi-night combination has finished successfully." ),
         locationIntro: InNovaTr( "Combination completed successfully." )
      } );
      if ( saveChoice.answer != StdButton_Yes ) {
         self.status.text += InNovaTr( "<br/>The combined master remains open in PixInsight." );
         return;
      }
      let saved = [];
      let failed = [];
      for ( let i = 0; i < self.integrationSeries.length; ++i ) {
         let window = self.integrationSeries[i].window ||
            self.integrationSeries[i];
         if ( window == null || window.isNull || window.mainView.isNull )
            continue;
         let sourceName = StartSafeId( window.mainView.id ) + ".xisf";
         let target = StartSubframeUniqueMasterPath(
            saveChoice.directory, sourceName );
         try {
            if ( !window.saveAs( target, false, false, false, false ) )
               throw new Error( InNovaTr( "PixInsight did not save the image." ) );
            saved.push( target );
         } catch ( error ) {
            failed.push( window.mainView.id + ": " + error );
         }
      }
      if ( saved.length > 0 ) {
         self.status.text += InNovaTr( "<br/><b>Saved " ) + saved.length +
            InNovaTr( " combined master file(s)</b> in " ) +
            StartHTMLText( saveChoice.directory ) + ".";
         console.noteln( "✅ Saved " + saved.length +
            " combined Multi-Night master file(s) in: " +
            saveChoice.directory );
      }
      if ( failed.length > 0 )
         new InNovaNotice( InNovaTr( "Some combined master files could not be saved:\n\n" ) +
            failed.join( "\n" ),
            InNovaTr( "🔭 InNova Multi-Night — Save master files" ),
            StdIcon_Error, StdButton_Ok ).execute();
   };

   this.inputCropInteractionActive = false;
   this.inputCropControlStates = null;
   this.setInputCropInteractionActive = function( active )
   {
      active = active === true;
      if ( active == self.inputCropInteractionActive ) return;
      self.inputCropInteractionActive = active;
      if ( active ) {
         let controls = [ self.imagesTree, self.runButton, self.closeButton,
            self.consoleButton, self.arrangeButton, self.loadButton,
            self.subframeMastersButton, self.refreshButton, self.clearButton,
            self.cleanOutputsButton, self.inputZoomInButton, self.inputFitButton,
            self.inputPanButton, self.inputZoomOutButton,
            self.inputQuickStretchLinkButton, self.inputInformationButton, self.inputCombineButton ];
         self.inputCropControlStates = controls.map( function( control ) {
            let state = { control: control, enabled: control.enabled };
            control.enabled = false;
            return state;
         } );
         self.inputCropResetEnabled = self.inputResetBridgeButton.enabled;
         self.inputCropResetToolTip = self.inputResetBridgeButton.toolTip;
         self.inputResetBridgeButton.enabled = true;
         self.inputResetBridgeButton.toolTip =
            InNovaTr( "Cancel the crop selection and keep the prepared images" );
      } else {
         for ( let i = 0; i < self.inputCropControlStates.length; ++i ) {
            let state = self.inputCropControlStates[i];
            state.control.enabled = state.enabled;
         }
         self.inputCropControlStates = null;
         self.inputResetBridgeButton.enabled = self.inputCropResetEnabled;
         self.inputResetBridgeButton.toolTip = self.inputCropResetToolTip;
      }
   };

   this.inputCropButton.onClick = function()
   {
      if ( self.registeredSeries.length < 2 ) return;
      if ( self.inputPreview.cropSelection == null ) {
         self.inputPreview.setCropMode( true );
         if ( !self.inputPreview.cropMode ) return;
         self.setInputCropInteractionActive( true );
         self.inputCropButton.checked = true;
         self.status.text = InNovaTr( "<b>Visual crop:</b> Drag over the Preview to " +
            "draw the area to keep. Then click Crop again to apply it to " +
            "all registered images." );
         return;
      }
      let selectedCrop = self.inputPreview.cropSelection;
      if ( selectedCrop.width < 64 || selectedCrop.height < 64 ) {
         new InNovaNotice(
            InNovaTr( "The crop rectangle must be at least 64 × 64 pixels." ),
            InNovaTr( "🔭 InNova Multi-Night — Crop" ),
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      if ( StartAskCenteredQuestion(
           InNovaTr( "🔭 InNova Multi-Night — Confirm crop" ),
           InNovaTr( "Apply the selected crop to all registered images?" ),
           true, InNovaTr( "Apply this crop?" ) ) != StdButton_Yes ) return;
      self.cropRectangle = { x: selectedCrop.x, y: selectedCrop.y,
         width: selectedCrop.width, height: selectedCrop.height,
         sourceWidth: self.inputPreview.sourceWidth,
         sourceHeight: self.inputPreview.sourceHeight,
         coverage: 100*selectedCrop.width*selectedCrop.height/
            (self.inputPreview.sourceWidth*self.inputPreview.sourceHeight),
         step: 0 };
      self.applyCropButton.enabled = true;
      self.setInputCropInteractionActive( false );
      let inputDialogEnabled = self.enabled;
      self.enabled = false;
      try {
         self.inputPreview.clearCrop();
         self.inputCropButton.checked = false;
         self.combinationPreviewGenerated = false;
         if ( self.cropRectangle != null && self.applyCropButton.enabled ) {
            let cropApplied = self.applyCropButton.onClick() === true;
            if ( cropApplied ) {


               self.multiExposureCropRequired = false;
               self.multiExposureManualCropStarted = false;
               self.multiExposureSynchronizedCropAccepted = true;
               let completed = self.runUnifiedMultiNightCombination();
               self.presentPreparedInBridge();
               if ( completed ) {
                  self.offerMultiNightSave();
                  self.continueGuidedMultiNightToProcessor();
               }
            }
         }
      } finally {
         self.enabled = inputDialogEnabled;
      }
   };

   this.inputPreview.onCropSelected = function( rectangle )
   {
      self.status.text = InNovaTr( "<b>Visual crop ready:</b> " ) + rectangle.width +
         " × " + rectangle.height + InNovaTr( " pixels. Click Crop again to apply " +
         "it to the complete multi-night sequence." );
   };

   this.inputResetBridgeButton.onClick = function()
   {
      if ( self.inputCropInteractionActive ) {
         self.inputPreview.clearCrop();
         self.inputCropButton.checked = false;
         self.setInputCropInteractionActive( false );
         self.status.text = InNovaTr( "Crop selection cancelled. Prepared images are unchanged." );
         return;
      }
      StartCloseSeriesWindows( self.croppedSeries );
      StartCloseSeriesWindows( self.registeredSeries );
      self.croppedSeries = [];
      self.registeredSeries = [];
      self.clearDerivedSeries();
      self.cropRectangle = null;
      self.inputPreview.clearCrop();
      self.inputCropButton.checked = false;
      self.referenceId = "";
      self.combinationPreviewGenerated = false;
      self.multiNightSaveOffered = false;
      for ( let i = 0; i < self.entries.length; ++i ) {
         self.entries[i].loaderPreviewWindow = null;
         self.entries[i].quality = null;
         self.entries[i].projectStatus = InNovaTr( "Pending" );
      }
      self.updateTree( self.inputPreviewIndex );
      self.inputCropButton.enabled = false;
      self.inputResetBridgeButton.enabled = false;
      self.inputCropButton.hide();
      self.inputResetBridgeButton.hide();
      self.status.text = InNovaTr( "Multi-Night reset. The original input " +
         "images are shown and remain selected." );
   };

   this.deleteAuxiliaryImages = function( auxiliary )
   {
      let removed = {};
      let count = 0;
      for ( let i = 0; i < auxiliary.length; ++i ) {
         let entry = auxiliary[i];
         try {
            if ( entry.window != null && !entry.window.isNull )
               entry.window.forceClose();
            removed[entry.id] = true;
            ++count;
         } catch ( error ) {
            console.warningln( "⚠️ Could not close auxiliary image " +
               entry.id + ": " + error );
         }
      }
      let retained = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( !removed[self.entries[i].id] )
            retained.push( self.entries[i] );
      self.entries = retained;
      return count;
   };

   this.refreshImages = function( showWarning )
   {
      self.entries = [];
      self.registeredSeries = [];
      self.croppedSeries = [];


      self.integrationSeries = [];
      self.hdrSeries = [];
      self.multiNightSaveOffered = false;
      self.cropRectangle = null;
      self.referenceId = "";
      self.multiExposureConfigured = false;
      self.combinationPreviewGenerated = false;
      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;
      self.updateReviewNextButton();
      self.autoBrightTarget = false;
      self.acquisitionCombo.currentItem = 0;
      self.objectCombo.currentItem = 0;
      self.imageViewer.setSeries( [], "" );
      let windows = ImageWindow.windows;
      let auxiliary = [];
      for ( let i = 0; i < windows.length; ++i ) {
         if ( windows[i] == null || windows[i].isNull ||
              windows[i].mainView.isNull )
            continue;
         let id = windows[i].mainView.id;
         if ( StartIsTransientBridgeOutput( id ) )
            continue;
         let entry = StartImageEntry( windows[i] );
         self.entries.push( entry );
         if ( entry.auxiliaryReason.length > 0 )
            auxiliary.push( entry );
      }
      let deletedAuxiliary = 0;
      let deleteAccepted = false;
      if (self.reviewCropMode) {
         StartReviewCropFilterAuxiliary(self, self.entries);
      } else if ( showWarning && auxiliary.length > 0 ) {
         let auxiliaryDialog = new StartAuxiliaryImagesDialog( auxiliary );
         if ( auxiliaryDialog.execute() == StdDialogCode_Ok ) {
            deleteAccepted = true;
            deletedAuxiliary = self.deleteAuxiliaryImages( auxiliary );
         }
      }
      self.updateTree();
      let usableCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].enabled ) ++usableCount;
      self.runButton.enabled = usableCount > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.cropValueLabel.text =
         InNovaTr( "Click Crop, then drag over the image to select the area to keep." );
      if ( auxiliary.length > 0 ) {
         self.status.text = deleteAccepted ?
            "<b>" + deletedAuxiliary +
            InNovaTr( " auxiliary image(s) were deleted.</b> They were removed from " +
            "Input images and closed in PixInsight." ) :
            InNovaTr( "<b style=\"color:#b05a00\">Project warning:</b> " ) +
            auxiliary.length + InNovaTr( " auxiliary image(s) were left unchecked." );
      } else
         self.status.text = self.entries.length > 0 ?
            InNovaTr( "Detected:<br/><b>" ) + self.entries.length +
            InNovaTr( " open source image(s)</b>." ) :
            InNovaTr( "Load or open your astronomical images.<br/>" +
            "<b>To create a multi-night integration</b>, add compatible images " +
            "of the same target captured on different nights." );
      if ( usableCount > 0 )
         self.status.text +=
            InNovaTr( "<br/><span style=\"color:#165bb5\"><b>Check</b> that all the loaded images are correct." +
            "<br/>Click <b>Run</b> to begin processing.</span>" );
   };

   this.loadButton.onClick = function()
   {
      let dialog = new OpenFileDialog;
      dialog.multipleSelections = true;
      dialog.caption = InNovaTr( "🔭 InNova Multi-Night — Load images" );
      let rawExtensions =
         "*.raw *.RAW *.dng *.DNG *.cr2 *.CR2 *.cr3 *.CR3 " +
         "*.nef *.NEF *.nrw *.NRW *.arw *.ARW *.srf *.SRF *.sr2 *.SR2 " +
         "*.raf *.RAF *.orf *.ORF *.ori *.ORI *.rw2 *.RW2 *.rwl *.RWL " +
         "*.pef *.PEF *.ptx *.PTX *.3fr *.3FR *.fff *.FFF *.iiq *.IIQ " +
         "*.mos *.MOS *.mef *.MEF *.mrw *.MRW *.x3f *.X3F *.kdc *.KDC " +
         "*.dcr *.DCR *.erf *.ERF *.bay *.BAY *.cap *.CAP *.eip *.EIP";
      dialog.filters = [ [ InNovaTr( "Supported astronomical and camera images" ),
         "*.xisf *.fits *.fit *.fts *.tif *.tiff *.TIF *.TIFF " +
         rawExtensions ],
                         [ InNovaTr( "Camera RAW images — all manufacturers" ),
                           rawExtensions ],
                         [ InNovaTr( "Vaonis TIFF images" ), "*.tif *.tiff *.TIF *.TIFF" ],
                         [ InNovaTr( "All files" ), "*" ] ];
      if ( self.nextLoadInitialPath != null &&
           self.nextLoadInitialPath.length > 0 )
         dialog.initialPath = self.nextLoadInitialPath;
      self.nextLoadInitialPath = "";
      if ( !dialog.execute() )
         return;
      let paths = dialog.filePaths;
      let openedWindows = [];
      let failedPaths = [];
      self.beginElapsed( InNovaTr( "Loading 0 / " ) + paths.length + InNovaTr( " image(s)…" ) );
      for ( let i = 0; i < paths.length; ++i ) {
         self.elapsedMessage = InNovaTr( "Loading " ) + (i + 1) + " / " +
            paths.length + " image(s)…";
         self.elapsedTimer.onTimeout();
         CoreApplication.processEvents();
         try {
            let opened = ImageWindow.open( paths[i] );
            if ( opened.length == 0 ) failedPaths.push( paths[i] );
            for ( let j = 0; j < opened.length; ++j ) {
               opened[j].iconize();
               openedWindows.push( opened[j] );
            }
         } catch ( error ) {
            console.warningln( "⚠️ Could not open " + paths[i] + ": " + error );
            failedPaths.push( paths[i] );
         }
      }
      if ( openedWindows.length > 0 )
         MiraPrepareWorkspaceForRun( self );
      let loadElapsed = self.finishElapsed();
      let known = {};
      for ( let i = 0; i < self.entries.length; ++i )
         known[self.entries[i].id] = true;
      let auxiliary = [];
      for ( let i = 0; i < openedWindows.length; ++i ) {
         let entry = StartImageEntry( openedWindows[i] );
         if ( known[entry.id] ) continue;
         self.entries.push( entry );
         known[entry.id] = true;
         if ( entry.auxiliaryReason.length > 0 ) auxiliary.push( entry );
      }
      if (self.reviewCropMode) StartReviewCropFilterAuxiliary(self, self.entries.filter(function(entry) { return openedWindows.indexOf(entry.window) >= 0; }));
      let auxiliaryDialog = !self.reviewCropMode && auxiliary.length > 0 ?
         new StartAuxiliaryImagesDialog( auxiliary ) : null;
      let deleteAccepted = auxiliaryDialog != null &&
         auxiliaryDialog.execute() == StdDialogCode_Ok;
      let deletedAuxiliary = deleteAccepted ?
         self.deleteAuxiliaryImages( auxiliary ) : 0;
      self.registeredSeries = [];
      self.croppedSeries = [];
      self.clearDerivedSeries();
      self.cropRectangle = null;
      self.referenceId = "";
      self.autoBrightTarget = false;
      self.objectCombo.currentItem = 0;
      self.imageViewer.setSeries( [], "" );
      self.updateTree();
      let usableCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].enabled ) ++usableCount;
      self.runButton.enabled = usableCount > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.status.text = InNovaTr( "Loaded <b>" ) +
         Math.max( 0, openedWindows.length - deletedAuxiliary ) +
         InNovaTr( " image(s)</b> from disk. " ) + StartElapsedRichText( loadElapsed ) +
         (failedPaths.length > 0 ? " <b style=\"color:#b05a00\">" +
          failedPaths.length + InNovaTr( " file(s) could not be decoded by " +
          "PixInsight.</b>" ) : "") +
         (deleteAccepted ? " <b>" + deletedAuxiliary +
          InNovaTr( " auxiliary image(s) were deleted.</b>" ) :
          (auxiliary.length > 0 ? " <b style=\"color:#b05a00\">" +
           auxiliary.length +
           InNovaTr( " auxiliary image(s) were left unchecked.</b>" ) : ""));
      if ( usableCount > 0 )
         self.status.text +=
            InNovaTr( "<br/><span style=\"color:#165bb5\"><b>Check</b> that all the loaded images are correct." +
            "<br/>Click <b>Run</b> to begin processing.</span>" );
      if ( failedPaths.length > 0 ) {
         let failedNames = [];
         for ( let i = 0; i < failedPaths.length && i < 8; ++i )
            failedNames.push( "• " + failedPaths[i] );
         new InNovaNotice(
            InNovaTr( "PixInsight could not decode these selected camera RAW files:\n\n" ) +
            failedNames.join( "\n" ) +
            (failedPaths.length > 8 ? "\n• …" : "") +
            InNovaTr( "\n\nCheck that the DSLR_RAW format module in PixInsight supports " +
            "the camera model and that the file is not damaged." ),
            InNovaTr( "🔭 InNova Multi-Night — RAW decoding warning" ),
            StdIcon_Warning, StdButton_Ok ).execute();
      }
   };

   this.subframeMastersButton.onClick = function()
   {
      self.nextLoadInitialPath = StartSubframeMasterDirectory();
      self.loadButton.onClick();
   };

   this.refreshButton.onClick = function() { self.refreshImages( true ); };

   this.clearButton.onClick = function()
   {
      let nodes = self.imagesTree.selectedNodes;
      if ( nodes.length == 0 && self.imagesTree.currentNode != null )
         nodes = [ self.imagesTree.currentNode ];
      if ( nodes.length == 0 ) return;
      let selected = [];
      let preferredIndex = self.entries.length;
      for ( let i = 0; i < nodes.length; ++i ) {
         let index = nodes[i].__index__;
         if ( index < 0 || index >= self.entries.length ) continue;
         selected.push( self.entries[index] );
         preferredIndex = Math.min( preferredIndex, index );
      }
      if ( selected.length == 0 ) return;
      let answer = StartAskCenteredQuestion(
         InNovaTr( "🔭 InNova Multi-Night — Remove selected images" ),
         InNovaTr( "Do you want to remove the selected images from the list?" ), true );
      if ( answer != StdButton_Yes ) return;
      for ( let i = 0; i < selected.length; ++i )
         self.imageViewer.onRemoveRequested( selected[i], preferredIndex, true );
   };

   this.cleanOutputsButton.onClick = function()
   {
      let generated = [];
      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              StartIsGeneratedOutput( windows[i].mainView.id ) )
            generated.push( windows[i] );
      if ( generated.length == 0 ) {
         self.status.text = InNovaTr( "There are no generated registration, integration, crop or HDR " +
            "results to clean. Original input images remain ready." );
         return;
      }
      let answer = StartAskCenteredQuestion(
         InNovaTr( "🔭 InNova Multi-Night — Clean generated results" ),
         InNovaTr( "Do you want to close " ) + generated.length +
         InNovaTr( " generated registration/integration/crop/HDR image(s) in PixInsight?\n\n" +
         "Only generated results will be removed. Original input images " +
         "will remain open and loaded so you can run the project again." ), true );
      if ( answer != StdButton_Yes ) return;
      for ( let i = 0; i < generated.length; ++i )
         if ( !generated[i].isNull ) generated[i].forceClose();
      let kept = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( !StartIsGeneratedOutput( self.entries[i].id ) &&
              self.entries[i].window != null &&
              !self.entries[i].window.isNull )
            kept.push( self.entries[i] );
      self.entries = kept;
      self.registeredSeries = [];
      self.croppedSeries = [];
      self.integrationSeries = [];
      self.hdrSeries = [];
      self.cropRectangle = null;
      self.referenceId = "";
      self.imageViewer.setSeries( [], "" );
      self.updateTree();
      self.runButton.enabled = self.entries.length > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.status.text = InNovaTr( "Closed <b>" ) + generated.length +
         InNovaTr( " generated image(s)</b>. The original inputs remain ready to run again." );
   };

   this.analyzeProject = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length < 1 ) {
         new InNovaNotice( InNovaTr( "Select at least one image." ), "🔭 InNova Multi-Night",
            StdIcon_Warning, StdButton_Ok ).execute();
         return false;
      }
      self.enabled = false;
      console.noteln( "🔎 Analyzing image quality and metadata…" );
      self.status.text = InNovaTr( "Analyzing image quality and metadata…" );
      CoreApplication.processEvents();
      let best = null;
      let groups = {};
      let geometryGroups = {};
      for ( let i = 0; i < selected.length; ++i ) {
         selected[i].quality = StartImageQuality( selected[i].window );
         let key = StartExposureText( selected[i].exposure ) + " | " +
            selected[i].filter + " | " + selected[i].camera + " | " +
            selected[i].width + "x" + selected[i].height;
         groups[key] = (groups[key] || 0) + 1;
         let geometryKey = selected[i].width + "x" + selected[i].height +
            "x" + selected[i].channels;
         if ( geometryGroups[geometryKey] == null )
            geometryGroups[geometryKey] = [];
         geometryGroups[geometryKey].push( selected[i] );
         CoreApplication.processEvents();
      }
      let dominant = null;
      for ( let geometryKey in geometryGroups )
         if ( dominant == null ||
              geometryGroups[geometryKey].length > dominant.length )
            dominant = geometryGroups[geometryKey];
      for ( let i = 0; i < dominant.length; ++i )
         if ( best == null || dominant[i].quality.score > best.quality.score )
            best = dominant[i];
      self.referenceId = best.id;
      let issues = StartProjectIssues( selected, best );
      let acquisitionValues = [ "SINGLE_NIGHT", "MULTI_NIGHT", "HDR" ];
      self.projectDiagnosis = StartClassifyProject( selected,
         acquisitionValues[self.acquisitionCombo.currentItem] );
      self.projectDiagnosis.detail = InNovaTr( "Project: " ) +
         self.projectCombo.itemText( self.projectCombo.currentItem ) +
         InNovaTr( "; Object: " ) +
         self.objectCombo.itemText( self.objectCombo.currentItem ) + ". " +
         self.projectDiagnosis.detail;
      for ( let i = 0; i < selected.length; ++i )
      {
         selected[i].projectStatus = InNovaTr( "Compatible" );
         selected[i].projectCompatible = true;
      }
      let compatibleEntries = [];
      for ( let i = 0; i < selected.length; ++i ) {
         selected[i].hdrCompatible = false;
         selected[i].hdrGroup = "";
      }
      for ( let i = 0; i < selected.length; ++i ) {
         let hasIssue = false;
         for ( let j = 0; j < issues.length; ++j )
            if ( issues[j].entry === selected[i] ) {
               hasIssue = true;
               break;
            }
         if ( !hasIssue ) compatibleEntries.push( selected[i] );
      }
      let hdrDetectionEntries = [];
      for ( let i = 0; i < compatibleEntries.length; ++i )
         if ( !self.multiExposureConfigured ||
              compatibleEntries[i].multiExposureSelected === true )
            hdrDetectionEntries.push( compatibleEntries[i] );
      let hdrGroups = StartDetectHDRGroups( hdrDetectionEntries );
      for ( let i = 0; i < compatibleEntries.length; ++i )
         if ( compatibleEntries[i].hdrCompatible )
            compatibleEntries[i].projectStatus = InNovaTr( "HDR compatible" );
      for ( let i = 0; i < issues.length; ++i )
      {
         issues[i].entry.projectCompatible = false;
         issues[i].entry.projectStatus = InNovaTr( "⚠ Review" );
      }
      self.updateTree();
      let groupCount = 0;
      for ( let key in groups ) ++groupCount;
      self.status.text = InNovaTr( "<b>Project diagnosis: " ) +
         self.projectDiagnosis.title + ".</b> " +
         self.projectDiagnosis.detail + InNovaTr( "<br/>Reference selected from the " +
         "dominant geometry: <b>" ) +
         best.id + InNovaTr( "</b>. Detected <b>" ) + groupCount +
         InNovaTr( " exposure/filter/camera group(s)</b>." ) +
         (issues.length > 0 ? " <b style=\"color:#b05a00\">" +
          issues.length + InNovaTr( " image(s) require review before registration.</b>" ) :
          InNovaTr( " All selected images pass the project preflight." ));
      if ( hdrGroups.length > 0 ) {
         let hdrDescriptions = [];
         for ( let i = 0; i < hdrGroups.length; ++i ) {
            let names = [];
            for ( let j = 0; j < hdrGroups[i].entries.length; ++j )
               names.push( hdrGroups[i].entries[j].id );
            hdrDescriptions.push( hdrGroups[i].label + ": " +
               names.join( ", " ) );
         }
         self.status.text +=
            InNovaTr( "<br/><b style=\"color:#d66a00\">HDR-compatible images:</b> " ) +
            hdrDescriptions.join( "; " ) +
            InNovaTr( ". These images are compatible and will be combined in the HDR stage." );
      }
      self.enabled = true;
      console.noteln( "🔎 Project diagnosis: " + self.projectDiagnosis.title );
      console.writeln( "ℹ️ " + self.projectDiagnosis.detail );
      return true;
   };

   this.registerProject = function()
   {
      self.lastRegistrationFailure = "";
      let selected = self.selectedEntries();
      if ( selected.length < 2 || self.referenceId.length == 0 ) return false;
      let reference = null;
      for ( let i = 0; i < selected.length; ++i )
         if ( selected[i].id == self.referenceId ) reference = selected[i];
      if ( reference == null ) {
         self.status.text = InNovaTr( "The selected reference is no longer enabled. Analyze again." );
         return false;
      }
      let projectIssues = StartProjectIssues( selected, reference );
      if ( projectIssues.length > 0 ) {
         let warningDialog = new StartUnrelatedImagesDialog(
            reference.id, projectIssues );
         if ( warningDialog.execute() != StdDialogCode_Ok ) {
            self.status.text = InNovaTr( "Registration cancelled so the project " +
               "selection can be reviewed." );
            return false;
         }
      }
      self.beginElapsed( InNovaTr( "Registering images with StarAlignment…" ), false );
      self.enabled = false;
      console.noteln( "⭐ Registering copies with StarAlignment…" );
      CoreApplication.processEvents();
      let registrationSucceeded = false;
      try {
         let targets = [];
         for ( let i = 0; i < selected.length; ++i )
            if ( selected[i].id != reference.id )
               targets.push( [ true, false, selected[i].id ] );
         let idsBefore = StartWindowIdSet();
         let alignment = new StarAlignment;
         alignment.structureLayers = 5;
         alignment.noiseLayers = 1;
         alignment.referenceImage = reference.id;
         alignment.referenceIsFile = false;
         alignment.targets = targets;
         alignment.mode = 0;
         alignment.outputPrefix = "";
         alignment.outputPostfix = InNovaStartRegisteredSuffix;
         alignment.outputExtension = ".xisf";
         alignment.writeKeywords = true;
         let alignmentCompleted = alignment.executeGlobal();
         self.registeredSeries = [];
         let referenceCopy = StartCloneWindow( reference.window,
            reference.id + InNovaStartRegisteredSuffix );
         self.registeredSeries.push( { window: referenceCopy,
            source: reference } );
         let failed = [];
         for ( let i = 0; i < selected.length; ++i ) {
            if ( selected[i].id == reference.id ) continue;
            let registered = StartFindNewRegisteredWindow(
               selected[i].id, idsBefore );
            if ( registered == null || registered.isNull ) {
               failed.push( selected[i].id );
               selected[i].projectStatus = InNovaTr( "Registration failed" );
            } else {


               registered = StartRenameRegisteredWindow(
                  registered, selected[i].id );
               self.registeredSeries.push( { window: registered,
                  source: selected[i] } );


               selected[i].projectCompatible = true;
               selected[i].projectStatus = selected[i].hdrCompatible ?
                  InNovaTr( "HDR compatible · Registered" ) : InNovaTr( "Registered" );
            }
         }
         reference.projectCompatible = true;
         reference.projectStatus = reference.hdrCompatible ?
            InNovaTr( "HDR compatible · Reference" ) : InNovaTr( "Reference" );
         self.updateTree();
         if ( self.registeredSeries.length < 2 )
            throw new Error( InNovaTr( "No target image could be registered to " ) +
               reference.id + InNovaTr( ". The images may belong to different " +
               "objects or may not contain enough common stars." ) );
         self.autoCropButton.enabled = true;
         self.cropButton.enabled = true;
         self.croppedSeries = [];
         let registeredViewer = self.buildViewerSeries(
            self.registeredSeries, InNovaTr( "Registered images" ) );
         self.imageViewer.setSeries(
            registeredViewer.series, registeredViewer.label );
         registrationSucceeded = true;
         if ( failed.length > 0 ) {
            self.status.text = InNovaTr( "<b>Project diagnosis: " ) +
               self.projectDiagnosis.title + ".</b> " +
               self.projectDiagnosis.detail + InNovaTr( "<br/>" +
               "<b style=\"color:#b05a00\">Registration " +
               "warning:</b> " ) + (self.registeredSeries.length - 1) +
               InNovaTr( " target(s) succeeded and " ) + failed.length +
               InNovaTr( " failed. Failed images were excluded from the crop." );
            StartShowMultiNightRegistrationWarning( reference.id, failed );
         } else {
            self.status.text = InNovaTr( "<b>Project diagnosis: " ) +
               self.projectDiagnosis.title + ".</b> " +
               self.projectDiagnosis.detail + InNovaTr( "<br/>Created <b>" ) +
               self.registeredSeries.length +
               InNovaTr( " registered copies</b>. Originals remain unchanged." );
         }
         let hdrNamesByGroup = {};
         for ( let i = 0; i < self.registeredSeries.length; ++i ) {
            let source = StartSeriesSourceEntry( self.registeredSeries[i] );
            if ( source != null && source.hdrCompatible ) {
               if ( hdrNamesByGroup[source.hdrGroup] == null )
                  hdrNamesByGroup[source.hdrGroup] = [];
               hdrNamesByGroup[source.hdrGroup].push( source.id );
            }
         }
         let registeredHDRDescriptions = [];
         for ( let groupName in hdrNamesByGroup )
            registeredHDRDescriptions.push( groupName + ": " +
               hdrNamesByGroup[groupName].join( ", " ) );
         if ( registeredHDRDescriptions.length > 0 )
            self.status.text +=
               InNovaTr( "<br/><b style=\"color:#d66a00\">HDR-compatible images:</b> " ) +
               registeredHDRDescriptions.join( "; " ) +
               InNovaTr( ". These images are compatible and will be combined in " +
               "the HDR stage." );
         if ( self.hdrSeries.length > 0 )
            self.status.text += InNovaTr( "<br/><b style=\"color:#d66a00\">HDR " +
               "created:</b> " ) + self.hdrSeries.length +
               InNovaTr( " HDR composition(s) have been appended after the individual " +
               "images in the viewer." );
         if ( self.integrationSeries.length > 0 )
            self.status.text += InNovaTr( "<br/><b>Multi-night integration created:</b> " ) +
               self.integrationSeries.length +
               InNovaTr( " compatible same-capture group(s) were averaged and appended " +
               "after the individual images in the viewer." );
         if ( !alignmentCompleted && failed.length == 0 )
            console.warningln( "⚠️ StarAlignment reported an incomplete run, " +
               "but every requested registered view was recovered." );
      } catch ( error ) {
         self.lastRegistrationFailure = String( error );
         let recoverable =
            self.lastRegistrationFailure.indexOf("No target image could be registered") >= 0 ||
            self.lastRegistrationFailure.indexOf("not contain enough common stars") >= 0 ||
            self.lastRegistrationFailure.indexOf(
               InNovaTr( "No target image could be registered" ) ) >= 0 ||
            self.lastRegistrationFailure.indexOf(
               InNovaTr( "not contain enough common stars" ) ) >= 0;
         if ( recoverable ) {
            console.writeln(
               "⚙️ InNova Multi-Night registration adjustment: " + error );
            self.status.text =
               InNovaTr( "<b>Registration adjustment:</b> " ) + error;
         } else {
            console.criticalln(
               "❌ InNova Multi-Night registration failed: " + error );
            self.status.text =
               InNovaTr( "<b style=\"color:#c33\">Registration failed:</b> " ) + error;
         }
      }
      let registrationElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( registrationElapsed );
      self.enabled = true;
      return registrationSucceeded;
   };

   this.prepareSingleImage = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length != 1 ) return false;
      let source = selected[0];
      self.enabled = false;
      console.noteln( "🖼️ Preparing a non-destructive review copy…" );
      self.status.text = InNovaTr( "Preparing a non-destructive review copy…" );
      CoreApplication.processEvents();
      try {
         let copy = StartCloneWindow( source.window,
            source.id + InNovaStartRegisteredSuffix );
         self.registeredSeries = [ { window: copy, source: source } ];
         self.croppedSeries = [];
         self.clearDerivedSeries();
         self.cropRectangle = null;
         source.projectStatus = InNovaTr( "Reference" );
         self.updateTree();
         self.imageViewer.setSeries( self.registeredSeries,
            InNovaTr( "Review copy" ) );
         self.autoCropButton.enabled = false;
         self.cropButton.enabled = true;
         self.applyCropButton.enabled = false;
         self.status.text =
            InNovaTr( "Created a <b>non-destructive review copy</b> of " ) + source.id +
            InNovaTr( ". The original image remains unchanged." );
         self.imageViewer.updateInformation();
         return true;
      } catch ( error ) {
         console.criticalln( "❌ InNova Multi-Night single-image preparation failed: " +
            error );
         self.status.text =
            InNovaTr( "<b style=\"color:#c33\">Single-image preparation failed:</b> " ) +
            error;
         return false;
      } finally {
         self.enabled = true;
      }
   };

   this.prepareBrightTargetImages = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length < 2 ) return false;
      self.enabled = false;
      self.status.text =
         InNovaTr( "Preparing non-destructive Sun/Moon review copies without stellar alignment…" );
      console.noteln( "☀️ " + self.status.text );
      CoreApplication.processEvents();
      try {
         StartCloseSeriesWindows( self.registeredSeries );
         self.registeredSeries = [];
         self.croppedSeries = [];
         self.clearDerivedSeries();
         self.cropRectangle = null;
         let sameGeometry = true;
         let width = selected[0].width;
         let height = selected[0].height;
         let channels = selected[0].channels;
         for ( let i = 0; i < selected.length; ++i )
            if ( selected[i].width != width ||
                 selected[i].height != height ||
                 selected[i].channels != channels ) sameGeometry = false;
         for ( let i = 0; i < selected.length; ++i ) {
            let source = selected[i];
            let copy = StartCloneWindow( source.window,
               source.id + InNovaStartBrightTargetSuffix );
            self.registeredSeries.push( { window: copy, source: source } );
            source.projectCompatible = sameGeometry;
            source.projectStatus = source.id == self.referenceId ?
               InNovaTr( "Bright-target reference" ) : InNovaTr( "Bright-target review" );
         }
         self.updateTree();
         self.imageViewer.setSeries( self.registeredSeries,
            InNovaTr( "Bright-target review copies" ) );
         self.autoCropButton.enabled = sameGeometry;
         self.cropButton.enabled = true;
         self.applyCropButton.enabled = false;
         self.status.text =
            InNovaTr( "Created <b>" ) + self.registeredSeries.length +
            InNovaTr( " Sun/Moon review copies</b>. Stellar StarAlignment was skipped " +
            "because bright-target images do not provide a normal star field." ) +
            (sameGeometry ? InNovaTr( " Their geometry is compatible for synchronized crop." ) :
             InNovaTr( " <b style=\"color:#b05a00\">The source geometries differ; " +
             "inspect them before attempting a synchronized crop.</b>" ));
         self.imageViewer.updateInformation();
         return true;
      } catch ( error ) {
         console.criticalln( "❌ InNova Multi-Night bright-target preparation failed: " +
            error );
         self.status.text =
            InNovaTr( "<b style=\"color:#c33\">Bright-target preparation failed:</b> " ) +
            error;
         return false;
      } finally {
         self.enabled = true;
      }
   };

   this.runPreparationRequested = false;


   this.performRunPreparation = function()
   {
      try {
      self.combinationPreviewGenerated = false;
      self.updateReviewNextButton();
      if ( self.multiExposureConfigured ) {
         let configuredCount = 0;
         let activeEntries = self.selectedEntries();
         for ( let i = 0; i < activeEntries.length; ++i )
            if ( activeEntries[i].multiExposureSelected === true )
               ++configuredCount;
         let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
         if ( configuredCount < required ) {
            new InNovaNotice(
               InNovaTr( "The configured Multi-exposure group no longer has enough " +
               "enabled images. Open Multi-exposure and review the selection." ),
               InNovaTr( "🔭 InNova Multi-Night — Review Multi-exposure selection" ),
               StdIcon_Warning, StdButton_Ok ).execute();
            return;
         }
      }
      self.objectCombo.currentItem = self.autoBrightTarget ? 1 : 0;
      self.saveHandoffSelections();
      self.hideProcessConsole();
      console.noteln( "⚙️ InNova Multi-Night selection: Project = " +
         self.projectCombo.itemText( self.projectCombo.currentItem ) +
         " | Acquisition = " +
         self.acquisitionCombo.itemText( self.acquisitionCombo.currentItem ) +
         " | Object = " +
         self.objectCombo.itemText( self.objectCombo.currentItem ) );
      if ( !self.analyzeProject() ) return;
      if ( !self.autoBrightTarget && self.selectedEntries().length > 1 ) {
         let referenceEntry = null;
         let preflightEntries = self.selectedEntries();
         for ( let i = 0; i < preflightEntries.length; ++i )
            if ( preflightEntries[i].id == self.referenceId ) {
               referenceEntry = preflightEntries[i];
               break;
            }
         if ( referenceEntry != null ) {
            self.status.text = InNovaTr( "Checking the reference star field…" );
            CoreApplication.processEvents();
            let starCount = StartPreflightStarCount( referenceEntry.window );
            if ( starCount >= 0 )
               console.writeln(
                  "🔎 InNova Multi-Night star-field preflight: " + starCount +
                  " source(s) detected." );
            if ( starCount >= 0 && starCount < 3 ) {
               self.autoBrightTarget = true;
               self.objectCombo.currentItem = 1;
               self.saveHandoffSelections();
               console.writeln(
                  "⚙️ InNova Multi-Night adjustment: fewer than three stars were " +
                  "detected. Switching to Sun or Moon treatment." );
               self.status.text =
                  InNovaTr( "<b>Processing adjustment:</b> No usable stellar field " +
                  "was detected. Continuing with Sun or Moon treatment…" );
               CoreApplication.processEvents();
               if ( self.prepareBrightTargetImages() )
                  self.executeReviewStep();
               return;
            }
         }
      }
      if ( self.acquisitionCombo.currentItem == 2 &&
           self.projectDiagnosis.insufficientHDRFilters.length > 0 )
         new InNovaNotice(
            InNovaTr( "Only two compatible images with distinct exposure levels were detected for: " ) +
            self.projectDiagnosis.insufficientHDRFilters.join( ", " ) +
            InNovaTr( ".\n\nInNova Multi-Night requires at least three compatible exposure " +
            "levels for HDR. Registration will continue, but no HDR " +
            "composition will be created." ),
            InNovaTr( "🔭 InNova Multi-Night — HDR requires three exposures" ),
            StdIcon_Warning, StdButton_Ok ).execute();
      if ( self.selectedEntries().length == 1 ) {
         if ( self.prepareSingleImage() )
            self.executeReviewStep();
         return;
      }
      if ( self.objectCombo.currentItem == 1 ) {
         if ( self.prepareBrightTargetImages() )
            self.executeReviewStep();
         return;
      }
      if ( self.selectedEntries().length > 1 ) {
         if ( self.registerProject() ) {
            self.imageViewer.updateInformation();
            self.executeReviewStep();
            return;
         }
         let registrationText = String( self.lastRegistrationFailure );
         if ( registrationText.indexOf("No target image could be registered") >= 0 ||
              registrationText.indexOf("not contain enough common stars") >= 0 ||
              registrationText.indexOf(
                 InNovaTr( "No target image could be registered" ) ) >= 0 ||
              registrationText.indexOf( InNovaTr( "not contain enough common stars" ) ) >= 0 ) {
            self.autoBrightTarget = true;
            self.objectCombo.currentItem = 1;
            self.saveHandoffSelections();
            console.writeln(
               "⚙️ InNova Multi-Night automatic adjustment: stellar registration found " +
               "no usable star field. Switching to Sun or Moon treatment." );
            self.status.text =
               InNovaTr( "<b style=\"color:#168de2\">Sun or Moon detected " +
               "automatically.</b> Stellar registration found no usable " +
               "star field; retrying with bright-target preparation…" );
            CoreApplication.processEvents();
            if ( self.prepareBrightTargetImages() )
               self.executeReviewStep();
         }
      }
      } finally {
         self.runButton.enabled = self.integrationSeries.length == 0 &&
            self.entries.some( function( entry ) { return entry.enabled; } );
         self.runButton.update();
      }
   };

   this.runButton.onClick = function()
   {
      if ( self.inputCropInteractionActive || !self.runButton.enabled ) return;
      let combineCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true &&
              self.entries[i].enabled &&
              self.entries[i].multiExposureSelected === true )
            ++combineCount;
      if ( combineCount < 2 ) {
         new InNovaNotice(
            InNovaTr( "<p align=\"center\">Select at least <b>two images</b> in " +
            "the Combine column before clicking Run.</p>" ),
            InNovaTr( "🔭 InNova Multi-Night — More images required" ),
            StdIcon_Information, StdButton_Ok ).execute();
         return;
      }
      self.runButton.enabled = false;
      self.runButton.update();
      CoreApplication.processEvents();
      let confirmationTitle = InNovaTr( "🔭 InNova Multi-Night — Run" );
      let confirmationText = InNovaTr( "Do you want to combine the images?" );
      if ( StartAskCenteredQuestion(
           confirmationTitle, confirmationText,
           true, confirmationText ) == StdButton_Yes ) {
         if ( self.unifiedBridgeWindow ) {
            self.runPreparationRequested = false;
            self.performRunPreparation();
         } else {
            self.runPreparationRequested = true;
            self.ok();
         }
      } else {
         self.runButton.enabled = self.entries.some(
            function( entry ) { return entry.enabled; } );
         self.runButton.update();
      }
   };

   this.autoCropButton.onClick = function()
   {
      self.hideProcessConsole();
      self.reviewDialog.enabled = false;
      self.beginElapsed(
         InNovaTr( "Calculating the largest safe rectangle at 100% common coverage…" ),
         true );
      console.noteln(
         "✂️ Calculating the largest safe rectangle at 100% common coverage…" );
      CoreApplication.processEvents();
      try {
         self.cropRectangle = StartCommonCrop( self.registeredSeries,
            self.marginSpin.value );
         let r = self.cropRectangle;
         self.imageViewer.setCropMode( false );
         self.imageViewer.setCropSelection( r );
         self.cropValueLabel.text = InNovaTr( "<b>Automatic crop ready.</b> " +
            "The bright rectangle is kept; the shaded area is removed. " +
            "<b>Frame retained:</b> " ) +
            format( "%.1f%%", r.coverage );
         self.applyCropButton.enabled = true;
         self.status.text = InNovaTr( "The automatic crop is ready. The extra safety " +
            "margin is included; applying it will create new copies." );
         self.reviewStatus.text = self.status.text;
      } catch ( error ) {
         self.status.text = InNovaTr( "<b style=\"color:#c33\">Crop analysis failed:</b> " ) + error;
         self.reviewStatus.text = self.status.text;
      }
      let cropElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( cropElapsed );
      self.reviewStatus.text = self.status.text;
      self.reviewDialog.enabled = true;
   };

   this.cropButton.onClick = function()
   {
      if ( self.imageViewer.series.length < 1 ) return;
      self.imageViewer.setCropMode( true );
      self.cropValueLabel.text =
         InNovaTr( "<b>Draw on the image:</b> drag a rectangle around the area to keep." );
      self.reviewStatus.text =
         InNovaTr( "Crop selection is active. Drag over the image; everything outside " +
         "the rectangle will be removed." );
   };

   this.imageViewer.onCropRequested = function()
   {


      if ( self.imageViewer.cropSelection == null ) {
         if (new StartCropInstructionDialog().execute() != StdDialogCode_Ok)
            return;
         if ( self.multiExposureCropRequired )
            self.multiExposureManualCropStarted = true;
         self.imageViewer.setCropInteractionActive( true );
         self.updateReviewNextButton();
         self.cropButton.onClick();
         return;
      }
      if ( self.multiExposureCropRequired )
         self.multiExposureManualCropStarted = true;
      if ( !self.imageViewer.cropEditMode ) {
         self.imageViewer.setCropInteractionActive( true );
         self.updateReviewNextButton();
         self.imageViewer.setCropEditMode( true );
         self.reviewStatus.text =
            InNovaTr( "Crop editing is active. Drag inside to move; drag an edge or " +
            "corner handle to resize; click Crop again to apply." );
         return;
      }
      let answer = StartAskCenteredQuestion(
         InNovaTr( "🔭 InNova Multi-Night — Confirm crop" ),
         InNovaTr( "Is this crop correct?\n\nIf you choose Yes, the selected crop " +
         "will be synchronized and applied to all images in the sequence." ), true,
         InNovaTr( "Is this crop correct?" ) );
      if ( answer == StdButton_Yes ) {
         self.reviewStatus.text =
            InNovaTr( "Applying the synchronized crop to all images…" );


         self.imageViewer.setCropEditMode( false );
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_Arrow );
         self.imageViewer.cropToolButton.enabled = false;
         self.reviewDialog.enabled = false;
         self.confirmedCropApplyPending = true;
         self.confirmedCropApplyTimer.start();
      } else {
         self.imageViewer.setCropEditMode( false );
         self.imageViewer.panEnabled = true;
         self.imageViewer.panButton.checked = true;
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_OpenHand );
         self.imageViewer.setCropInteractionActive( false );
         self.updateReviewNextButton();
         self.status.text = InNovaTr( "Crop not applied." );
         self.reviewStatus.text =
            InNovaTr( "Crop not applied. All viewer controls are available." );
      }
   };

   this.imageViewer.onRestoreCropRequested = function()
   {
      let answer = StartAskCenteredQuestion(
         InNovaTr( "🔭 InNova Multi-Night — Restore crop" ),
         InNovaTr( "The image will be restored to its initial state. All crop " +
         "adjustments will be lost.\n\nDo you want to restore it?" ), true );
      if ( answer != StdButton_Yes ) return;

      self.imageViewer.setCropMode( false );
      self.imageViewer.setCropEditMode( false );
      self.imageViewer.setCropInteractionActive( false );
      self.updateReviewNextButton();
      self.cropRectangle = null;
      self.multiExposureSynchronizedCropAccepted = false;
      self.applyCropButton.enabled = false;

      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              String( windows[i].mainView.id ).toLowerCase().indexOf(
                 "innovastartcrop" ) >= 0 )
            windows[i].forceClose();

      self.croppedSeries = [];
      let restoredViewer = self.buildViewerSeries(
         self.registeredSeries, InNovaTr( "Registered images" ) );
      self.imageViewer.setSeries(
         restoredViewer.series, restoredViewer.label );
      self.autoCropButton.enabled = self.registeredSeries.length >= 2;
      self.cropValueLabel.text =
         InNovaTr( "Click Crop, then drag over the image to select the area to keep." );
      self.status.text =
         InNovaTr( "Crop adjustments discarded. The registered image sequence has " +
         "been restored." );
      self.reviewStatus.text = self.status.text;
   };

   this.imageViewer.onCropSelected = function( rectangle )
   {
      let window = self.imageViewer.currentWindow();
      if ( window == null ) return;
      let image = window.mainView.image;
      if ( rectangle.width < 64 || rectangle.height < 64 ) {
         self.imageViewer.setCropSelection( null );
         self.imageViewer.cropEditMode = false;
         self.imageViewer.panEnabled = true;
         self.imageViewer.panButton.checked = true;
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_OpenHand );
         self.imageViewer.setCropInteractionActive( false );
         self.updateReviewNextButton();
         new InNovaNotice(
            InNovaTr( "The crop rectangle must be at least 64 × 64 pixels." ),
            "🔭 InNova Multi-Night", StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      self.cropRectangle = { x: rectangle.x, y: rectangle.y,
         width: rectangle.width, height: rectangle.height,
         sourceWidth: image.width, sourceHeight: image.height,
         coverage: 100*rectangle.width*rectangle.height/
            (image.width*image.height), step: 0 };
      self.cropValueLabel.text =
         InNovaTr( "<b>Visual crop ready.</b> The bright rectangle is kept; the " +
         "shaded area is removed. <b>Frame retained:</b> " ) +
         format( "%.1f%%", self.cropRectangle.coverage );
      self.applyCropButton.enabled = true;
      self.status.text = InNovaTr( "Visual crop ready and editable." );
      self.reviewStatus.text =
         InNovaTr( "Drag inside the rectangle to move it. Drag an edge or corner " +
         "handle to resize it. Click Crop again to apply it to " +
         "the complete sequence." );
   };

   this.applyCropButton.onClick = function()
   {
      self.hideProcessConsole();
      if ( self.cropRectangle == null ) return false;
      let requiredCropApplied = self.multiExposureCropRequired;
      self.reviewDialog.enabled = false;
      self.beginElapsed( InNovaTr( "Applying crop to image copies…" ), true );
      self.croppedSeries = [];
      try {


         let sourceSeries = self.resolveLatestPreparedSeries(
            self.registeredSeries );
         for ( let i = 0; i < sourceSeries.length; ++i ) {
            let cropMessage = InNovaTr( "Cropping registered copy " ) + (i + 1) +
               " of " + sourceSeries.length + "…";
            self.updateElapsed( cropMessage );
            console.noteln( "✂️ " + cropMessage );
            let sourceItem = sourceSeries[i];
            let sourceWindow = sourceItem.window || sourceItem;
            let scale = StartCropAstrometryScale(sourceWindow);


            if (!scale) {
               let original = StartSeriesSourceEntry(sourceItem);
               if (original)
                  scale = original.astrometryScale || StartCropAstrometryScale(original.window);
            }
            if (scale) {
               console.noteln("🔭 Crop image scale: " + (scale * 3600) + " arcsec/pixel.");
            } else {
               console.warningln("⚠️ No angular scale or complete focal-length/pixel-size metadata found for " +
                  sourceWindow.mainView.id + " or its original source.");
            }
            let output = StartApplyCropToCopy(
               sourceWindow, self.cropRectangle );
            let croppedItem = { window: output,
               astrometryScale: scale, source: sourceItem,
               alreadyStretched: sourceItem.alreadyStretched === true };


            if ( croppedItem.alreadyStretched ) {
               let linearItem = self.resolveLatestProcessorPrepared(sourceItem);
               let linearWindow = linearItem.window || linearItem;
               if ( linearWindow != null && !linearWindow.isNull &&
                    linearWindow.mainView.id != sourceWindow.mainView.id ) {
                  croppedItem.astrometrySolveWindow = StartApplyCropToCopy(
                     linearWindow, self.cropRectangle );
                  croppedItem.astrometrySolveWindow.hide();
               }
            }
            self.croppedSeries.push( croppedItem );
            self.rememberLatestPrepared( sourceItem, croppedItem );
            if ( croppedItem.alreadyStretched )
               self.stretchedEditorSources[output.mainView.id] = output;
         }
         let croppedViewer = self.buildViewerSeries(
            self.croppedSeries, InNovaTr( "Cropped images" ) );
         self.imageViewer.setSeries(
            croppedViewer.series, croppedViewer.label );
         if ( requiredCropApplied && self.croppedSeries.length > 0 &&
              self.croppedSeries.length == sourceSeries.length ) {


            self.multiExposureCropRequired = false;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = true;
         }
         self.status.text = InNovaTr( "Created <b>" ) + self.croppedSeries.length +
            InNovaTr( " identically cropped copies</b>. These are ready for " +
            "inspection in the viewer, multi-night integration and HDR " +
            "composition." );
         self.reviewStatus.text = self.status.text;
         self.applyCropButton.enabled = false;
         self.autoCropButton.enabled = false;
      } catch ( error ) {
         for ( let i = 0; i < self.croppedSeries.length; ++i ) {
            let failedOutput = self.croppedSeries[i].window;
            if ( failedOutput != null && !failedOutput.isNull )
               failedOutput.forceClose();
            let failedProxy = self.croppedSeries[i].astrometrySolveWindow;
            if ( failedProxy != null && !failedProxy.isNull )
               failedProxy.forceClose();
         }
         self.croppedSeries = [];
         self.status.text = InNovaTr( "<b style=\"color:#c33\">Crop failed:</b> " ) + error;
         self.reviewStatus.text = self.status.text;
      }
      self.reviewDialog.enabled = true;


      if (self.reviewCropMode && self.croppedSeries.length > 0)
         self.solveReviewCropSeries(self.croppedSeries);
      if (self.croppedSeries.length > 0) {
         for ( let i = 0; i < self.croppedSeries.length; ++i ) {
            let proxy = self.croppedSeries[i].astrometrySolveWindow;
            if ( proxy != null && !proxy.isNull ) proxy.forceClose();
            self.croppedSeries[i].astrometrySolveWindow = null;
         }
         let result = self.reviewCropMode ? self.reviewCropAstrometryStatus :
            InNovaTr( "Cropped images are ready. Astrometry will be requested " +
            "only if a coordinate-dependent process is selected." );
         self.status.text += "<br/>" + result;
         self.reviewStatus.text = self.status.text;
      }
      let applyCropElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( applyCropElapsed );
      self.reviewStatus.text = self.status.text;
      return self.croppedSeries.length > 0;
   };

   this.consoleButton.onClick = function()
   {
      if ( self.consoleIsVisible ) self.hideProcessConsole();
      else self.showProcessConsole();
   };
   this.temporaryWindowsCleaned = false;
   this.cleanupTemporaryWindowsOnExit = function()
   {
      if ( self.temporaryWindowsCleaned ) return;
      self.temporaryWindowsCleaned = true;
      StartCloseMultiNightTemporaryWindows();
      self.registeredSeries = [];
      self.croppedSeries = [];
   };
   this.closeButton.onClick = function()
   {
      self.cleanupTemporaryWindowsOnExit();
      self.ok();
   };
   this.onClose = function()
   {
      self.cleanupTemporaryWindowsOnExit();
      return true;
   };

   if (this.reviewCropMode) StartConfigureReviewCrop(this);
   ["performRunPreparation", "runUnifiedMultiNightCombination", "prepareReviewCrop",
    "executeReviewCropRun", "solveReviewCropSeries"].forEach(function(name) {
      if (typeof self[name] == "function") self[name] = InNovaDiagnosticWrap(
         (self.reviewCropMode ? "Review & Crop: " : "Multi-night: ") + name, self[name]);
   });


   this.reviewOperationDepth = 0;
   function lockReviewNavigation(owner, name, rejectReentry)
   {
      let operation = owner[name];
      if (typeof operation != "function") return;
      owner[name] = function()
      {
         if (rejectReentry && self.reviewOperationDepth > 0) return;
         let outermost = self.reviewOperationDepth == 0;
         let backEnabled = self.reviewBackButton.enabled;
         let nextEnabled = self.reviewNextButton.enabled;
         ++self.reviewOperationDepth;
         self.reviewBackButton.enabled = false;
         self.reviewNextButton.enabled = false;
         try {
            return operation.apply(this, arguments);
         } finally {
            --self.reviewOperationDepth;
            if (outermost) {
               self.reviewBackButton.enabled = backEnabled;
               self.reviewNextButton.enabled = self.multiExposureCropRequired ?
                  false : nextEnabled;
            }
         }
      };
   }
   lockReviewNavigation(this.reviewNextButton, "onClick", true);
   lockReviewNavigation(this.autoCropButton, "onClick", true);
   lockReviewNavigation(this.applyCropButton, "onClick", false);
   ["onCropRequested", "onRestoreCropRequested", "onAdaptiveRequested",
      "onImageSolverRequested", "onColorCalibrationRequested",
      "onEditorRequested", "onProcessorRequested", "onRemoveRequested", "onMultiExposureRequested"].forEach(function(name) {
      lockReviewNavigation(self.imageViewer, name, true);
   });

   lockReviewNavigation(this, "buildViewerSeries", false);
   lockReviewNavigation(this.imageViewer, "setSeries", false);

   this.refreshImages( false );
   if ( !this.consoleIsVisible ) console.hide();
   this.adjustToContents();


   let bridgeScreen = this.availableScreenRect;
   if ( bridgeScreen ) {
      let availableBridgeWidth = bridgeScreen.x1 - bridgeScreen.x0 -
         Math.round( this.logicalPixelsToPhysical( 24 ) );
      this.resize( Math.min( this.width, availableBridgeWidth ), this.height );
   }


   this.bridgeCenterTimer = new Timer;
   this.bridgeCenterTimer.interval = 0.05;
   this.bridgeCenterTimer.periodic = false;
   this.bridgeCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self );
   };
   this.onShow = function()
   {
      MiraCenterDialog( this );
      self.bridgeCenterTimer.start();
   };
   MiraCenterDialog( this );
}
}


var StartLauncherRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);
#include "lib/LauncherAppearance.js"
#include "SubframeReview.js"
#include "lib/TemporaryCleanup.js"
#include "lib/ReviewCropWorkflow.js"
#include "lib/ConfigurationStatus.js"

function StartLauncherSelectorIcon(parent, module, compact, selectModule,
   openModule)
{
   let control = new Control(parent);
   control.styleSheet = InNovaStyleWithToolTips("background:transparent;");
   let slotSize = compact ? 86 : 104;
   let normalSize = compact ? 68 : 82;
   let hoverSize = compact ? 80 : 96;
   control.setScaledFixedSize(slotSize, slotSize);
   control.bitmap = StartLauncherBitmap("icons/" + module.icon + ".png");
   if (!control.bitmap)
      control.bitmap = StartLauncherBitmap("icons/" + module.icon + ".jpg");
   if (!control.bitmap)
      control.bitmap = StartLauncherBitmap("icons/" + module.icon + ".svg");
   control.module = module;
   control.selected = false;
   control.hovered = false;
   control.mouseTracking = true;
   control.toolTip = module.enabled === false ?
      InNovaTr(module.name) + (InNovaLanguage() === "es" ? " — Próximamente" : " — Coming soon!") :
      InNovaTr(module.name) + " — " + InNovaTr(module.subtitle) +
         (InNovaLanguage() === "es" ? "\nHaz clic para abrir." : "\nClick to open.");
   control.onPaint = function()
   {
      let graphics = new Graphics(this);


      let activeHover = module.enabled !== false && this.hovered;
      if (activeHover) {
         graphics.pen = new Pen(0xff0875dc,
            this.logicalPixelsToPhysical(2));
         graphics.drawRect(0, 0, this.width - 1, this.height - 1);
      }
      if (this.bitmap) {
         let logicalSize = activeHover ? hoverSize : normalSize;
         let drawSize = this.logicalPixelsToPhysical(logicalSize);
         let x = Math.round((this.width - drawSize)/2);
         let y = Math.round((this.height - drawSize)/2);
         StartLauncherDrawBitmap(graphics, this, this.bitmap,
            x, y, drawSize, drawSize);
      }
      graphics.end();
   };
   control.onMouseMove = function()
   {
      selectModule(module, control, true);
      return true;
   };
   control.onMousePress = function( x, y, button )
   {
      if (button != MouseButton_Left) return false;
      selectModule(module, control, true);
      if (module.enabled !== false) openModule();
      return true;
   };
   return control;
}

var _0x23b8390e41 =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiIwZThlNmI2My1hZTk1LTQ1MjctOWNjMS1iN2JlMzc2N2ViZmYiLCJjaGVja291dEZsb3dJZCI6ImVlNjNjNTliLWI1OTQtNGY3MS1iMTFiLWJmZjlmNDA2MTIzNyIsImlzVjMiOnRydWV9";

var _0x485e78fa9f =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiJiNDE5M2JlNi00NTg0LTRjYmMtOWEyOS1iYjE0YjJjYzRlM2IiLCJjaGVja291dEZsb3dJZCI6ImY4YTMyNmVjLTI4MDQtNGIzNi1iN2UxLTlmZTMyYTlmNGY0NiIsImlzVjMiOnRydWV9";

var _0xaec7c967bc =
   String.fromCharCode(104,116,116,112,115,58,47,47,119,119,119,46,116,101,111,114,105,97,100,101,108,99,111,108,111,114,46,101,115,47,97,99,99,111,117,110,116,47,109,121,45,115,117,98,115,99,114,105,112,116,105,111,110,115);

function _0x3fcba18785()
{
   let _0xdc8f7c5e80 = _0x15c01f125c();
   if (!_0xe880d30cd3(_0xdc8f7c5e80) || !_0x47cb641486(_0xdc8f7c5e80) ||
       _0x10a4c3120b(_0xdc8f7c5e80[String.fromCharCode(101,120,112,105,114,121)]))
      return "";
   let code = String(_0xdc8f7c5e80.code || "").toUpperCase();
   if (code.indexOf("INNOVA-M-") === 0)
      return "Monthly";
   if (code.indexOf("INNOVA-A-") === 0)
      return "Annual";
   return String.fromCharCode(65,99,116,105,118,101,32,115,117,98,115,99,114,105,112,116,105,111,110);
}


class _0x11120406f4 extends Dialog
{
   constructor(_0x16020b6c53)
   {
      super();
      InNovaApplyBlackTheme(this);

      let self = this;
      this.selectedUrl = "";
      this.recoverExisting = false;
      this.supportRecovery = false;
      let currentPlan = _0x3fcba18785();
      let paidRecoveryAvailable = currentPlan !== "" || _0x4aeb644d49();
      this.windowTitle = InNovaTr(String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110,32,80,108,97,110,115));

      let titleLabel = new Label(this);
      titleLabel.useRichText = true;
      titleLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      titleLabel.text =
         InNovaTr(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,67,104,111,111,115,101,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,60,47,112,62) +
         "<p align=\"center\">Select the billing period that suits you.</p>");


      titleLabel.onMousePress = function ()
      {
         if (paidRecoveryAvailable)
            return;
         paidRecoveryAvailable = true;
         transferGroup.visible = true;
         supportGroup.visible = true;
         self.adjustToContents();
         self.setFixedSize();
      };

      let monthlyGroup = new GroupBox(this);
      monthlyGroup.title = InNovaTr("Monthly");
      monthlyGroup.setScaledFixedWidth(260);
      monthlyGroup.sizer = new VerticalSizer;
      monthlyGroup.sizer.margin = 12;
      monthlyGroup.sizer.spacing = 10;

      let monthlyPriceLabel = new Label(monthlyGroup);
      monthlyPriceLabel.useRichText = true;
      monthlyPriceLabel.wordWrapping = true;
      monthlyPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      monthlyPriceLabel.text =
         InNovaTr("<p align=\"center\"><b>&euro;6.99 / month</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Billed every month until cancelled.</p>");

      let monthlyButton = new PushButton(monthlyGroup);
      monthlyButton.text = InNovaTr("Choose Monthly");
      monthlyButton.icon = this.scaledResource( ":/icons/internet.png" );
      monthlyButton.setScaledFixedHeight(34);
      monthlyButton.onClick = function ()
      {
         if (InNovaBlockPurchase()) return;
         self.selectedUrl = _0x23b8390e41;
         self.ok();
      };

      monthlyGroup.sizer.add(monthlyPriceLabel);
      monthlyGroup.sizer.addStretch();
      monthlyGroup.sizer.add(InNovaStyleBlackButton(monthlyButton));

      let annualGroup = new GroupBox(this);
      annualGroup.title = InNovaTr("Annual");
      annualGroup.setScaledFixedWidth(260);
      annualGroup.sizer = new VerticalSizer;
      annualGroup.sizer.margin = 12;
      annualGroup.sizer.spacing = 10;

      let annualPriceLabel = new Label(annualGroup);
      annualPriceLabel.useRichText = true;
      annualPriceLabel.wordWrapping = true;
      annualPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      annualPriceLabel.text =
         InNovaTr("<p align=\"center\"><b>&euro;69.99 / year</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Save &euro;13.89 compared with<br>12 monthly payments.</p>");

      let annualButton = new PushButton(annualGroup);
      annualButton.text = InNovaTr("Choose Annual - Best Value");
      annualButton.icon = this.scaledResource( ":/icons/ok.png" );
      annualButton.toolTip =
         InNovaTr("Recommended: save EUR 13.89 compared with 12 monthly payments.");
      annualButton.setScaledFixedHeight(34);
      annualButton.onClick = function ()
      {
         if (InNovaBlockPurchase()) return;
         self.selectedUrl = _0x485e78fa9f;
         self.ok();
      };

      annualGroup.sizer.add(annualPriceLabel);
      annualGroup.sizer.addStretch();
      annualGroup.sizer.add(InNovaStyleBlackButton(annualButton));


      monthlyButton.enabled = currentPlan === "";
      annualButton.enabled = currentPlan === "";

      let plansSizer = new HorizontalSizer;
      plansSizer.spacing = 12;
      plansSizer.add(monthlyGroup);
      plansSizer.add(annualGroup);

      let currentPlanPanel = new Control(this);
      currentPlanPanel.visible = currentPlan !== "";
      currentPlanPanel.sizer = new VerticalSizer;
      currentPlanPanel.sizer.spacing = 5;

      let currentPlanLabel = new Label(currentPlanPanel);
      currentPlanLabel.useRichText = true;
      currentPlanLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      currentPlanLabel.text =
         InNovaTr("<p align=\"center\">Your current plan is: <b>" + InNovaTr(currentPlan) +
         "</b>.</p>");

      let _0xd144aa35a0 = new Label(currentPlanPanel);
      _0xd144aa35a0.useRichText = true;
      _0xd144aa35a0.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      _0xd144aa35a0.text =
         InNovaTr("<p align=\"center\"><span style=\"color:#72b8f4;\"><u>" +
         String.fromCharCode(67,108,105,99,107,32,104,101,114,101,32,105,102,32,121,111,117,32,119,97,110,116,32,116,111,32,97,99,99,101,115,115,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,115,46,60,47,117,62,60,47,115,112,97,110,62,60,47,112,62));
      _0xd144aa35a0.toolTip = InNovaTr(String.fromCharCode(79,112,101,110,32,121,111,117,114,32,73,110,78,111,118,97,32,115,117,98,115,99,114,105,112,116,105,111,110,115,46));
      _0xd144aa35a0.cursor = new Cursor(StdCursor_PointingHand);
      _0xd144aa35a0.onMousePress = function ()
      {
         if (typeof _0x16020b6c53 === "function")
            _0x16020b6c53();
      };

      currentPlanPanel.sizer.add(currentPlanLabel);
      currentPlanPanel.sizer.add(_0xd144aa35a0);

      let bonusGroup = new GroupBox(this);
      bonusGroup.title = InNovaTr("InNova guidance");
      bonusGroup.sizer = new VerticalSizer;
      bonusGroup.sizer.margin = 12;

      let bonusLabel = new Label(bonusGroup);
      bonusLabel.useRichText = true;
      bonusLabel.wordWrapping = true;
      bonusLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      bonusLabel.text = InNovaTr("Private guidance dedicated exclusively to the operation of InNova Astro Photo Suite. Videos demonstrate InNova; the questions-and-answers channel covers its use.");
      bonusGroup.sizer.add(bonusLabel);

      let transferGroup = new GroupBox(this);
      transferGroup.title = InNovaTr(String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101));
      transferGroup.visible = paidRecoveryAvailable;
      transferGroup.sizer = new VerticalSizer;
      transferGroup.sizer.margin = 12;
      transferGroup.sizer.spacing = 10;

      let transferLabel = new Label(transferGroup);
      transferLabel.useRichText = true;
      transferLabel.wordWrapping = true;
      transferLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      transferLabel.text =
         InNovaTr(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,87,111,117,108,100,32,121,111,117,32,108,105,107,101,32,116,111,32,116,114,97,110,115,102,101,114,32,121,111,117,114,32,108,105,99,101,110,115,101,32,116,111,32,97,110,111,116,104,101,114,32,99,111,109,112,117,116,101,114,63,60,98,114,62) +
         "Open InNova Start on the other computer and click this button.</p>");

      let recoveryButton = new PushButton(transferGroup);
      recoveryButton.text = InNovaTr(String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101));
      recoveryButton.icon = this.scaledResource( ":/icons/internet.png" );
      recoveryButton.setScaledFixedWidth(230);
      recoveryButton.toolTip =
         InNovaTr("Authorize this computer with the purchasing platform account. No payment is made.");
      recoveryButton.onClick = function ()
      {
         self.recoverExisting = true;
         self.ok();
      };

      let recoverySizer = new HorizontalSizer;
      recoverySizer.addStretch();
      recoverySizer.add(InNovaStyleBlackButton(recoveryButton));
      recoverySizer.addStretch();
      transferGroup.sizer.add(transferLabel);
      transferGroup.sizer.add(recoverySizer);

      let supportGroup = new GroupBox(this);
      supportGroup.title = InNovaTr(String.fromCharCode(83,117,112,112,111,114,116,32,76,105,99,101,110,115,101,32,82,101,99,111,118,101,114,121));
      supportGroup.visible = paidRecoveryAvailable;
      supportGroup.sizer = new VerticalSizer;
      supportGroup.sizer.margin = 12;
      supportGroup.sizer.spacing = 10;

      let supportLabel = new Label(supportGroup);
      supportLabel.useRichText = true;
      supportLabel.wordWrapping = true;
      supportLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      supportLabel.text =
         InNovaTr(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,85,115,101,32,116,104,105,115,32,111,112,116,105,111,110,32,119,104,101,110,32,97,32,99,117,114,114,101,110,116,108,121,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,97,110,110,111,116,32) +
         "be recovered normally. The platform will verify the paid period automatically.</p>");

      let supportButton = new PushButton(supportGroup);
      supportButton.text = InNovaTr(String.fromCharCode(82,101,99,111,118,101,114,32,76,105,99,101,110,115,101,32,119,105,116,104,32,83,117,112,112,111,114,116));
      supportButton.icon = this.scaledResource( ":/icons/internet.png" );
      supportButton.setScaledFixedWidth(230);
      supportButton.toolTip =
         InNovaTr("Creates a 30-minute Linking Code for automatic paid-period recovery. No payment is made.");
      supportButton.onClick = function ()
      {
         self.supportRecovery = true;
         self.ok();
      };
      let supportSizer = new HorizontalSizer;
      supportSizer.addStretch();
      supportSizer.add(InNovaStyleBlackButton(supportButton));
      supportSizer.addStretch();
      supportGroup.sizer.add(supportLabel);
      supportGroup.sizer.add(supportSizer);

      let cancelButton = new PushButton(this);
      cancelButton.text = InNovaTr("Cancel");
      cancelButton.icon = this.scaledResource( ":/icons/close.png" );
      cancelButton.setScaledFixedWidth(120);
      cancelButton.onClick = function () { self.cancel(); };

      let cancelSizer = new HorizontalSizer;
      cancelSizer.addStretch();
      cancelSizer.add(InNovaStyleBlackButton(cancelButton));

      this.sizer = new VerticalSizer;
      this.sizer.margin = 14;
      this.sizer.spacing = 12;
      this.sizer.add(InNovaBlackHeader(this, this.windowTitle));
   this.sizer.add(titleLabel);
      this.sizer.add(plansSizer);
      this.sizer.add(currentPlanPanel);
      this.sizer.add(bonusGroup);


      this.sizer.add(transferGroup);
      this.sizer.add(supportGroup);
      this.sizer.add(cancelSizer);

      this.adjustToContents();
      this.setFixedSize();
   }
}


function _0x32c033ef5d()
{
   return MiraOpenSupportMail(String.fromCharCode(73,110,78,111,118,97,32,65,115,116,114,111,32,45,32,76,105,99,101,110,115,101,32,80,114,111,98,108,101,109), "");
}

function _0xd4fa91e4c4()
{
   _0xdc285b7cc2();
}


function StartLocalizedNotice(message, title, icon, button1, button2, button3)
{
   return new InNovaNotice(InNovaTr(message), InNovaTr(title), icon, button1, button2, button3);
}

function StartChooseGuidedInput( disableSubframes )
{
   let dialog = new Dialog; InNovaApplyBlackTheme(dialog);
   dialog.windowTitle = InNovaTr("✦ InNova Guided Workflow — Choose an option");
   dialog.choice = "";
   let background = StartLauncherPanel(dialog, false, true);
   background.sizer = new VerticalSizer;
   background.sizer.margin = 16;
   background.sizer.spacing = 12;

   let heading = new HorizontalSizer;
   heading.spacing = 14;
   heading.add(StartLauncherIcon(background, "guided-compass", 64));
   let headingText = new VerticalSizer;
   headingText.addStretch();
   headingText.add(StartLauncherLabel(background,
      "<b>How would you like to begin?</b>", 21, "#ffffff", false));
   headingText.add(StartLauncherLabel(background,
      "Choose the starting point for your images. <font color='#72b8f4'>InNova will guide you every step of the way.</font>", 12, "#c9def2", false));
   headingText.addStretch();
   heading.add(headingText, 100);
   background.sizer.add(heading);

   function choiceCard(iconName, number, title, description, route)
   {
      let disabled = disableSubframes === true && route == "subframes-guided";
      let card = new Control(background);
      card.setScaledFixedWidth(250);
      card.setScaledMinHeight(388);
      card.onPaint = function() {
         let g = new Graphics(this);
         g.fillRect(0, 0, this.width, this.height, new Brush(0xff2d353d));
         g.pen = new Pen(disabled ? 0xff535d68 : 0xff72b8f4, this.logicalPixelsToPhysical(1));
         g.drawRect(0, 0, this.width - 1, this.height - 1);
         g.end();
      };
      card.sizer = new VerticalSizer;
      card.sizer.margin = 8;
      card.sizer.spacing = 6;
      let illustration = new Control(card);
      illustration.setScaledFixedSize(234, 234);
      let artwork = new Bitmap(StartLauncherRoot + "/assets/illustrations/" + iconName + "-pro.png");
      illustration.onPaint = function() {
         let g = new Graphics(this);
         StartLauncherDrawBitmap(g, this, artwork, 0, 0, this.width, this.height);
         if (disabled) g.fillRect(0, 0, this.width, this.height, new Brush(0x9925282c));
         g.end();
      };
      card.sizer.add(illustration);
      card.sizer.addSpacing(6);
      let titleLabel = StartLauncherLabel(card,
         "<b><font color='#72b8f4'>" + number + "</font>  " + InNovaTr(title) + "</b>",
         12, disabled ? "#858b91" : "#ffffff", false);
      let descriptionLabel = StartLauncherLabel(card, description,
         11, disabled ? "#969ba0" : "#e4e8ed", false);


      for (let label of [titleLabel, descriptionLabel]) {
         label.setScaledFixedWidth(234);
         label.adjustToContents();
         label.setFixedHeight(label.height);
         card.sizer.add(label);
      }
      card.sizer.addStretch();
      let open = new PushButton(card);
      open.text = InNovaTr(disabled ? "Completed" : "Open  ▶");
      open.styleSheet = InNovaStyleWithToolTips(
         "QPushButton { background-color:#0b78dc; color:white; border:1px solid #72b8f4; } " +
         "QPushButton:hover { background-color:#278feb; } " +
         "QPushButton:disabled { background-color:#35485a; color:#8d98a5; border-color:#535d68; }");
      open.setScaledFixedHeight(28);
      open.enabled = !disabled;
      open.onClick = function() {
         if (disabled) return;
         dialog.choice = route;
         dialog.ok();
      };
      card.sizer.add(InNovaStyleBlackButton(open));
      card.adjustToContents();
      return card;
   }
   let choices = new HorizontalSizer;
   choices.spacing = 10;
   let cards = [];
   cards.push(choiceCard("subframe-review", "01", "Load and stack subframes",
      "Review your individual exposures, select the best, and stack them with <b>FBPP or WBPP</b>.",
      "subframes-guided"));
   cards.push(choiceCard("bridge", "02", "Combine multi-night",
      "Combine master images from different nights into one integrated image.", "guided"));
   cards.push(choiceCard("astro-processor", "03", "Open a single image",
      "Open a master image from <b>FBPP, WBPP, Multi-night</b> or a smart telescope. Review and crop before sending it to Astro Processor.", "review-crop"));
   let cardHeight = Math.max.apply(null, cards.map(function(card) { return card.height; }));
   cards.forEach(function(card) {
      card.setFixedHeight(cardHeight);
      choices.add(card);
   });
   background.sizer.add(choices);
   let compatibilityGap = Math.ceil(dialog.font.lineSpacing /
      (dialog.logicalPixelsToPhysical(100) / 100));
   background.sizer.addSpacing(Math.max(0, compatibilityGap - background.sizer.spacing));
   background.sizer.add(StartLauncherLabel(background,
      "All options support narrowband and OSC images, including those from Seestar and Vaonis.",
      11, "#c9def2", true));
   background.sizer.addSpacing(Math.max(0, compatibilityGap - background.sizer.spacing));
   let cancelRow = new HorizontalSizer;
   cancelRow.addStretch();
   let cancel = new PushButton(background);
   cancel.text = InNovaTr("Close");
   cancel.icon = dialog.scaledResource(":/icons/close.png");
   cancel.onClick = function() { dialog.cancel(); };
   cancelRow.add(InNovaStyleBlackButton(cancel));
   background.sizer.add(cancelRow);
   background.sizer.addSpacing(6);
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add(background);
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog(this); };
   MiraCenterDialog(dialog);
   return dialog.execute() == StdDialogCode_Ok ? dialog.choice : "";
}

class InNovaStartLauncherDialog extends Dialog
{
constructor(selectedRoute)
{
   super();
      InNovaApplyBlackTheme(this);
   let self = this;
   this.windowTitle = "✦ " + TITLE + " — " + InNovaStartVersion;
   this.route = "";
   let screenRect = this.availableScreenRect;
   let uiScale = Math.max(1, this.logicalPixelsToPhysical(100)/100);
   let availableLogicalWidth = screenRect ?
      (screenRect.x1 - screenRect.x0)/uiScale : 1200;
   let availableLogicalHeight = screenRect ?
      (screenRect.y1 - screenRect.y0)/uiScale : 900;


   let compact = availableLogicalHeight < 790 ||
      availableLogicalWidth < 940;
   console.writeln("InNova START display: usable area " +
      (screenRect ? Math.round(screenRect.x1-screenRect.x0) + " x " +
       Math.round(screenRect.y1-screenRect.y0) : "unknown") +
      " px; UI scale " + uiScale.toFixed(2) +
      "; logical area " + Math.round(availableLogicalWidth) + " x " +
      Math.round(availableLogicalHeight) + "; layout " + (compact ? "compact" : "standard"));
   this.sizer = new VerticalSizer;
   this.sizer.margin = compact ? 10 : 18;
   this.sizer.spacing = compact ? 6 : 12;


   let launcherContentWidth = compact ? 770 : 862;

   let header = new HorizontalSizer;
   header.spacing = compact ? 12 : 20;
   let brand = new Control(this);
   brand.sizer = new VerticalSizer;
   brand.sizer.spacing = 0;

   let logoBitmap = StartLauncherBitmap("branding/logo-black.svg") || StartLauncherBitmap("branding/logo.png");
   if (logoBitmap) {
      let logo = new Control(brand);
      logo.setScaledFixedSize(compact ? 140 : 170, compact ? 35 : 43);
      logo.onPaint = function() {
         let g = new Graphics(this);
         let scale = Math.min(this.width/logoBitmap.width, this.height/logoBitmap.height);
         let w=logoBitmap.width*scale, h=logoBitmap.height*scale;
         StartLauncherDrawBitmap(g, this, logoBitmap, 0, (this.height-h)/2, w, h);
         g.end();
      };
      brand.sizer.add(logo);
   } else {
      brand.sizer.add(StartLauncherLabel(brand, "In<span style=\"color:#075bdd\">N</span>ova", 42, "#0b1426", false));
      brand.sizer.add(StartLauncherLabel(brand, "ASTRO PHOTO SUITE", 13, "#182238", false));
   }
   header.add(brand);
   let tagline = new HorizontalSizer;
   tagline.addStretch();
   let taglineText = StartLauncherLabel(this, "A complete workflow for astrophotography", compact ? 11 : 13, "#484e57", true);
   tagline.add(taglineText);
   tagline.addStretch();
   header.add(tagline, 100);
   let _0xae0751d5d9 = new Control(this);
   _0xae0751d5d9.sizer = new HorizontalSizer;
   _0xae0751d5d9.sizer.addStretch();
   let _0x3e8e86c0fd = StartLauncherLabel(_0xae0751d5d9, "", compact ? 11 : 12, "#0066c4", false);
   _0xae0751d5d9.sizer.add(_0x3e8e86c0fd);
   _0x3e8e86c0fd.wordWrapping = false;
   function _0xb585168b56()
   {
      _0x3e8e86c0fd.text = _0x9012890e39();
      _0x3e8e86c0fd.adjustToContents();

      let sideWidth = Math.max(self.logicalPixelsToPhysical(compact ? 170 : 200), _0x3e8e86c0fd.width);
      brand.setFixedWidth(sideWidth);
      _0xae0751d5d9.setFixedWidth(sideWidth);
   }
   _0xb585168b56();


   header.add(_0xae0751d5d9);
   this.sizer.add(header);
   this.sizer.add(StartLauncherLabel(this, "<i>Choose how you want to begin.</i>", compact ? 12 : 13, "#0066c4", true));

   let guided = StartLauncherPanel(this, true);
   guided.inNovaFullBanner = true;


   guided.setScaledFixedWidth(launcherContentWidth);
   guided.setScaledMinHeight(compact ? 158 : 190);
   guided.sizer = new HorizontalSizer;
   guided.sizer.margin = compact ? 12 : 18;
   guided.sizer.spacing = compact ? 12 : 18;
   guided.sizer.add(StartLauncherIcon(guided, "guided-compass", compact ? 88 : 112));
   let heroText = new VerticalSizer;
   heroText.spacing = compact ? 4 : 8;
   heroText.add(StartLauncherLabel(guided, "<b>GUIDED WORKFLOW</b>", compact ? 15 : 17, "#102b50", false));
   heroText.add(StartLauncherLabel(guided, "From images to final result", compact ? 12 : 13, "#174675", false));
   heroText.add(StartLauncherLabel(guided, "Start with your images.<br/>Let InNova guide your workflow.", compact ? 11 : 13, "#243f5b", false));
   heroText.addStretch();
   let begin = new PushButton(guided);
   begin.text = InNovaTr("Start step by step  ▶");
   begin.setScaledFixedSize(compact ? 195 : 225, compact ? 30 : 34);
   begin.styleSheet =
      InNovaStyleWithToolTips("QPushButton { background-color:#0869d6; color:white; border:2px solid #79b5ff; " +
      "font-weight:bold; font-size:" + (compact ? 12 : 13) + "pt; }" +
      "QPushButton:hover { background-color:white; color:#0869d6; border:2px solid #0869d6; }" +
      "QPushButton:pressed { background-color:#e7f2ff; color:#075eb0; border:2px solid #075eb0; }");
   begin.onClick = function()
   {
      let choice = StartChooseGuidedInput();
      if ( choice.length > 0 ) {
         if (self.selectorHoverTimer) self.selectorHoverTimer.stop();
         self.route = choice;
         self.ok();
      }
   };
   heroText.add(InNovaStyleBlackButton(begin));
   guided.sizer.add(heroText, 100);
   let journeyPanel = new Control( guided );
   journeyPanel.styleSheet = InNovaStyleWithToolTips("background:transparent;");
   journeyPanel.setScaledFixedSize( compact ? 320 : 400,
      compact ? 108 : 132 );
   let journey = new HorizontalSizer;
   journey.spacing = compact ? 4 : 6;
   let steps = [["subframe-review", "Load files"],
      ["astro-processor", "Process a single-night<br/>or multi-night"],
      ["photo-editor", "Edit & Export"]];
   for (let i=0; i<steps.length; ++i) {
      let column = new VerticalSizer;
      column.addStretch();
      let iconRow = new HorizontalSizer;
      iconRow.addStretch();
      iconRow.add(StartLauncherIcon(guided, steps[i][0], compact ? 58 : 72));
      iconRow.addStretch();
      column.add(iconRow);
      column.add(StartLauncherLabel(guided, steps[i][1],
         compact ? 11 : 13, "#102b50", true));
      column.addStretch();
      journey.add(column);
      if (i<steps.length-1)
         journey.add(StartLauncherLabel(guided, "→",
            compact ? 14 : 17, "#075eb0", true));
   }
   journeyPanel.sizer = journey;
   guided.sizer.add(journeyPanel);
   this.sizer.add(guided);
   this.sizer.add(StartLauncherLabel(this, "OR OPEN A MODULE", compact ? 11 : 13, "#293344", true));
   this.sizer.addSpacing(compact ? 4 : 8);

   let launcherModules = [
      { name: "InNova Subframe Review & Integration", shortName: "Subframe Integrator",
        icon: "subframe-review", subtitle: "Review · Integrate · Create Masters",
        description: "Preview light subframes · Blink · Accept or reject · FBPP/WBPP",
        route: "subframes" },
      { name: "InNova Multi-Night", shortName: "Multi-Night", icon: "bridge",
        subtitle: "Register · Crop · Combine",
        description: "Combine master images captured over multiple nights",
        route: "quick" },
      { name: "InNova Review & Crop", shortName: "Review & Crop",
        icon: "review-crop", subtitle: "Review · Crop · Solve",
        description: "Prepare a single image or aligned channels for Astro Processor",
        route: "review-crop" },
      { name: "InNova Astro Processor", shortName: "Astro Processor",
        icon: "astro-processor", subtitle: "Process Images",
        description: "Align · Solve · Combine · Gradients · MGC · H-Alpha blend",
        route: "processor" },
      { name: "InNova Smart Stretch", shortName: "Smart Stretch",
        icon: "adaptive", subtitle: "Stretch Images",
        description: "Intelligent linear-to-nonlinear transformation",
        route: "stretch" },
      { name: "InNova Photo Editor", shortName: "Photo Editor",
        icon: "photo-editor", subtitle: "Edit and Export",
        description: "Light · Color · Contrast · Radial, Linear and Brush Masks · Detail · Noise · Stars · Export",
        route: "editor" }
   ];
   let selectedModule = launcherModules.filter(function(module) { return module.route === selectedRoute; })[0] || launcherModules[0];
   let selectorIcons = [];
   let moduleDetails = StartLauncherPanel(this, false);
   moduleDetails.setScaledFixedSize(launcherContentWidth, compact ? 90 : 102);
   moduleDetails.sizer = new HorizontalSizer;
   moduleDetails.sizer.margin = compact ? 8 : 10;
   moduleDetails.sizer.spacing = compact ? 8 : 12;
   let detailText = StartLauncherLabel(moduleDetails, "", compact ? 11 : 12,
      "#243f5b", true);
   function refreshModuleDetails()
   {
      detailText.text = InNovaPlatformTypography("<b style=\"font-size:" + (compact ? 14 : 16) +
         "pt;color:#e4e8ed\">" + InNovaTr(selectedModule.name) + "</b>" +
         "<br/><span style=\"color:#72b8f4\"><b>" +
         InNovaTr(selectedModule.subtitle) + "</b></span> · " +
         InNovaTr(selectedModule.description));
      self.selectedModuleRoute = selectedModule.route;
   }
   function openSelectedModule()
   {
      if (selectedModule.enabled === false) return;
      self.selectorHoverTimer.stop();
      self.route = selectedModule.route;
      self.ok();
   }
   function selectLauncherModule(module, iconControl, hovered)
   {
      if (selectedModule != module) {
         selectedModule = module;
         refreshModuleDetails();
      }
      for (let i = 0; i < selectorIcons.length; ++i) {
         let selected = selectorIcons[i].module == selectedModule;
         let underMouse = selectorIcons[i] == iconControl && hovered === true;
         if (selectorIcons[i].selected != selected ||
             selectorIcons[i].hovered != underMouse) {
            selectorIcons[i].selected = selected;
            selectorIcons[i].hovered = underMouse;
            selectorIcons[i].update();
         }
      }
   }
   moduleDetails.sizer.add(detailText, 100);

   let moduleRow = new HorizontalSizer;
   moduleRow.spacing = compact ? 2 : 4;
   moduleRow.addStretch();
   for (let i = 0; i < launcherModules.length; ++i) {
      let column = new VerticalSizer;
      column.spacing = 1;
      let iconControl = StartLauncherSelectorIcon(this, launcherModules[i],
         compact, selectLauncherModule, openSelectedModule);
      selectorIcons.push(iconControl);
      let iconLine = new HorizontalSizer;
      iconLine.addStretch();
      iconLine.add(iconControl);
      iconLine.addStretch();
      column.add(iconLine);
      let moduleNameLabel = StartLauncherLabel(this,
         launcherModules[i].shortName, compact ? 10 : 11,
         launcherModules[i].enabled === false ? "#8a8a8a" : "#102b50", true);
      moduleNameLabel.setScaledFixedWidth(compact ? 100 : 112);
      column.add(moduleNameLabel);
      moduleRow.add(column);
   }
   moduleRow.addStretch();
   this.sizer.add(moduleRow);
   this.sizer.addSpacing(compact ? 6 : 12);
   this.sizer.add(moduleDetails);
   refreshModuleDetails();
   selectLauncherModule(selectedModule, null, false);

   this.selectorHoverTimer = new Timer;
   this.selectorHoverTimer.interval = 0.05;
   this.selectorHoverTimer.periodic = true;
   this.selectorHoverTimer.onTimeout = function()
   {
      let hoveredIcon = null;
      for (let i = 0; i < selectorIcons.length; ++i)
         if (selectorIcons[i].isUnderMouse) {
            hoveredIcon = selectorIcons[i];
            break;
         }
      if (hoveredIcon != null)
         selectLauncherModule(hoveredIcon.module, hoveredIcon, true);
      else
         selectLauncherModule(selectedModule, null, false);
   };

   let footer = new HorizontalSizer;
   footer.spacing = 12;
   this.languageButton = new ToolButton(this);
   this.languageButton.icon = new Bitmap(StartLauncherRoot + "/assets/icons/" +
      (InNovaLanguage() === "es" ? "language-us.svg" : "language-es.svg"));
   this.languageButton.setScaledFixedSize(28, 28);
   this.languageButton.iconWidth = this.logicalPixelsToPhysical(26);
   this.languageButton.iconHeight = this.logicalPixelsToPhysical(26);
   this.languageButton.toolTip = InNovaLanguage() === "es" ? "Switch to English" : "Cambiar a español";
   this.languageButton.onClick = function() {
      try { InNovaSetLanguage(InNovaLanguage() === "es" ? "en" : "es"); }
      catch (error) {
         new InNovaNotice(String(error), "InNova — Language / Idioma", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      self.selectorHoverTimer.stop(); self.initialCenterTimer.stop();
      self.route = "language";
      self.ok();
   };
   footer.add(this.languageButton);
   this.configurationButton = new ToolButton(this);
   this.configurationButton.icon = new Bitmap(StartLauncherRoot + "/assets/icons/configuration.svg");
   this.configurationButton.setScaledFixedSize(28, 28);
   this.configurationButton.iconWidth = this.logicalPixelsToPhysical(24);
   this.configurationButton.iconHeight = this.logicalPixelsToPhysical(24);
   this.configurationButton.toolTip = StartConfigurationText("Module verification", "Verificación de módulos");
   this.configurationButton.onClick = function() { new InNovaConfigurationDialog().execute(); };
   footer.add(this.configurationButton);
   let web = new ToolButton(this);
   web.icon = new Bitmap(StartLauncherRoot + "/assets/icons/web.svg");
   web.setScaledFixedSize(28, 28);
   web.toolTip = InNovaTr("Visit the InNova Astro Photo Suite website");
   web.onClick = function() {
      Dialog.openBrowser("https://www.teoriadelcolor.es/innova-astro-photo-suite");
   };
   footer.add(web);
   let updates = new ToolButton(this);
   updates.icon = new Bitmap(StartLauncherRoot + "/assets/icons/updates-light.svg");
   updates.setScaledFixedSize(28, 28);
   updates.toolTip = "PixInsight updates — open the menu instructions";
   updates.onClick = function() {
      new StartLocalizedNotice(
         "<p align=\"center\">To check for updates, close InNova Start and use PixInsight's menu:<br/><br/>" +
         "<b>Resources &gt; Updates &gt; Check for Updates</b></p>",
         "Check for Updates", StdIcon_Information, StdButton_Ok).execute();
   };
   footer.add(updates);
   let bugReport = new ToolButton(this);
   bugReport.icon = new Bitmap(StartLauncherRoot + "/assets/icons/bug.svg");
   bugReport.setScaledFixedSize(28, 28);
   bugReport.toolTip = InNovaTr("Create and email a bug report");
   bugReport.onClick = function() {
      if (StartAskCenteredQuestion(
         "InNova Bug Report",
         "Do you want to send a bug report?",
         true, "Bug report") != StdButton_Yes)
         return;
      let reportPath = File.systemTempDirectory + "/bug-report.log";
      try {
         File.writeTextFile(reportPath, StartBugReportText());
      } catch (error) {
         new StartLocalizedNotice(
            "<p align=\"center\">The bug report could not be created.<br/><br/>" +
            StartHTMLText(String(error)) + "</p>",
            "InNova Bug Report", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      console.noteln("🐞 Bug report created: " + reportPath);
      if (!StartOpenBugReportEmail(reportPath))
         new StartLocalizedNotice(
            "<p align=\"center\">The bug report was created, but the mail " +
            "application could not be opened.<br/><br/><b>" +
            StartHTMLText(reportPath) + "</b></p>",
            "InNova Bug Report", StdIcon_Warning, StdButton_Ok).execute();
   };
   footer.add(bugReport);

   let whatsNew = new Label(this);
   whatsNew.useRichText = true;
   whatsNew.text = InNovaTr("<span style=\"color:#72b8f4;\">What's New</span>");
   whatsNew.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   whatsNew.wordWrapping = false;
   whatsNew.setScaledMinHeight(28);
   whatsNew.toolTip = InNovaTr("See what's new in this version");
   whatsNew.cursor = new Cursor(StdCursor_PointingHand);
   whatsNew.styleSheet = InNovaStyleWithToolTips("QLabel { color:#72b8f4; background-color:#383f46; font-size:11pt; }");

   whatsNew.adjustToContents();
   whatsNew.setMinWidth(whatsNew.width + this.logicalPixelsToPhysical(12));
   whatsNew.onMousePress = function() {
      Dialog.openBrowser("https://31ec875b-1942-46dd-b74b-6289964f61f6.usrfiles.com/ugd/31ec87_a334ed279ed6462bb42dd67d74d4f010.pdf");
   };
   footer.add(whatsNew);
   footer.addStretch();
   let close = new PushButton(this);
   close.text = InNovaTr("Close");
   close.styleSheet = InNovaStyleWithToolTips("font-size:13pt;");
   close.icon = this.scaledResource(":/icons/close.png");
   close.setScaledFixedSize(100, 24);
   this.exitConfirmed = false;
   this.exitLogged = false;
   function logSuiteExit()
   {
      if (self.exitLogged)
         return;
      self.exitLogged = true;
      StartCleanupTemporaryFiles();
      console.writeln("\n👋 Exiting InNova Astro Photo Suite...");
   }
   function confirmSuiteExit()
   {
      return StartAskCenteredQuestion(
         "Exit InNova Astro Photo Suite",
         "Do you want to exit\nInNova Astro Photo Suite?",
         true, "InNova Astro Photo Suite", "guided-compass" ) == StdButton_Yes;
   }
   close.onClick = function() {
      if (confirmSuiteExit()) {
         self.selectorHoverTimer.stop();
         self.exitConfirmed = true;
         logSuiteExit();
         self.cancel();
      }
   };
   this.onClose = function() {
      if (self.exitConfirmed)
         return true;
      if (!confirmSuiteExit())
         return false;
      self.exitConfirmed = true;
      self.selectorHoverTimer.stop();
      logSuiteExit();
      return true;
   };
   footer.add(InNovaStyleBlackButton(close));
   InNovaAddDialogActionSpace(this, this.sizer); this.sizer.add(footer);
   this.compatibilityLabel = StartLauncherLabel(this, "Compatible with <b>PixInsight 1.9.5 Lockhart</b>",
      10, "#606670", true);
   this.sizer.add(this.compatibilityLabel);
   this[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)] = StartLauncherLabel(this, "In<span style=\"color:#075bdd\">N</span>ova Astro Photo Suite © Jesús Manuel García Flores · " + InNovaTr("Mode") + " " +
      InNovaLocalizedSuiteStatus(InNovaStartSuiteStatus.replace(/ · \d+ day\(s\)/, "")), 10, "#606670", true);
   this.sizer.add(this[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)]);
   this.adjustToContents();
   this.setFixedSize();


   this.initialCenterTimer = new Timer;
   this.initialCenterTimer.interval = 0.05;
   this.initialCenterTimer.periodic = false;
   this.initialCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self );
   };
   this.onShow = function()
   {
      MiraCenterDialog( this );
      self.selectorHoverTimer.start();
      self.initialCenterTimer.start();
   };
   MiraCenterDialog(this);
}
}


#define INNOVA_ADAPTIVE_EMBEDDED
#include "../InNova/InNova03.js"
#undef INNOVA_ADAPTIVE_EMBEDDED
#define INNOVA_EDITOR_EMBEDDED
#include "../InNova/InNova02.js"
#undef INNOVA_EDITOR_EMBEDDED

function StartRunEditorEmbedded(source)
{
   let savedName = ProjecTname;
   let savedVersion = ProjecTver;
   let savedToken = _0xbe2d41ec95;
   let _0xc055682c54 = _0xde359df820;
   let savedTitle = InNovaEditorTitle;
   let savedType = ProjecTypevar;
   let savedTypeRec = ProjecTypevarRec;
   let output = null;
   try {
      ProjecTname = InNovaEditorTitle = "🪐 InNova Photo Editor";
      ProjecTver = "v1.19.build 0244";
      if (!_0xade19a62f3()) return;
      InitializeInNovaProviderPaths();
      InNovaEditorResetEditorState();
      if (!source) {
         originalFilePathMLDenoisefin = MiraResolveMLDenoisePath();
   if (!IsUsableMLDenoisePath(originalFilePathMLDenoisefin))
      MiraWarnMissingMLDenoiseModel();
         let selector = new InNovaEditorDialog;
         selector.onShow = function() { MiraCenterDialog(this); };
         selector.adjustToContents();
         MiraCenterDialog(selector);
         return selector.runDirect();
      }
      ProjecTypevar = ProjecTypevarRec =
         InNovaEditorInferProjectType(source.mainView.id);
      output = InNovaEditorCloneWindow(source,
         MiraUniqueWindowId(source.mainView.id + "_InNovaPhotoEditor"));


      if (output.mainView.image.numberOfChannels < 3) {
         let image = output.mainView.image;
         let rgb = InNovaEditorImageFromRgb(image.width, image.height,
            InNovaEditorReadRgb(image));
         output.mainView.beginProcess(UndoFlag_NoSwapFile);
         try { output.mainView.image.assign(rgb); }
         finally { output.mainView.endProcess(); rgb.free(); }
      }
      let result = InNovaEditorRunProEditor(output.mainView, ProjecTypevar);
      if (result.accepted) {
         output.show();
         output.bringToFront();
         let acceptedOutput = output;
         output = null;
         return acceptedOutput;
      } else if (result.openRequested && result.requestedSourceId) {
         output.forceClose();
         output = null;
         return StartRunEditorEmbedded(ImageWindow.windowById(result.requestedSourceId));
      } else if (!result.cancelled && !result.openRequested)
         throw new Error("The selected image could not be prepared for editing.");
   } finally {
      if (output && !output.isNull) output.forceClose();
      ProjecTname = savedName;
      ProjecTver = savedVersion;
      _0xbe2d41ec95 = savedToken;
      _0xde359df820 = _0xc055682c54;
      InNovaEditorTitle = savedTitle;
      ProjecTypevar = savedType;
      ProjecTypevarRec = savedTypeRec;
   }
}

function StartRunAdaptiveEmbedded(showSelector)
{
   let savedName = ProjecTname;
   let savedVersion = ProjecTver;
   let savedToken = _0xbe2d41ec95;
   let _0xc055682c54 = _0xde359df820;
   try {
      ProjecTname = "💫 InNova Smart Stretch";
      ProjecTver = "v1.19.build 0104";
      if (_0x13298fd2a1()) return InNovaAdaptiveRunMain(showSelector);
   } finally {
      ProjecTname = savedName;
      ProjecTver = savedVersion;
      _0xbe2d41ec95 = savedToken;
      _0xde359df820 = _0xc055682c54;
   }
}

function StartConsumeBridgeReturn()
{
   let value = Settings.read("InNova/BridgeReturn", DataType_String);
   let valid = Settings.lastReadOK;
   Settings.remove("InNova/BridgeReturn");
   if (!valid || !value) return null;
   try {
      let request = JSON.parse(value);
      let age = Date.now() - request.created;
      return age >= 0 && age < 120000 ? request : null;
   } catch (error) {
      return null;
   }
}

function StartRestoreBridgeAfterProcessor(request)
{
   if ( !_0x8fd8025167("InNova Multi-Night") ) return;
   let dialog = new InNovaStartDialog(false);
   dialog.windowTitle = InNovaTr("🔭 InNova Multi-Night — Prepare Images — ") +
      InNovaStartVersion + " — " + _0x690bbf5e93(true);
   let result = request && request.resultId ?
      ImageWindow.windowById(request.resultId) : null;
   if ((result == null || result.isNull) && request && request.sourceId)
      result = ImageWindow.windowById(request.sourceId);
   if (result != null && !result.isNull && !result.mainView.isNull) {
      let processed = request != null && request.processed === true &&
         request.resultId && request.resultId != request.sourceId;
      let resultItem = StartImageEntry(result);
      resultItem.alreadyStretched = processed;
      if (processed)
         dialog.stretchedEditorSources[result.mainView.id] = result;
      dialog.imageViewer.setSeries([resultItem],
         processed ? "Astro Processor result" : "Prepared image", 0);
      dialog.reviewStatus.text = processed ?
         "Returned from <b>InNova Astro Processor</b>. Showing <b>" +
            result.mainView.id + "</b>." :
         "Returned from <b>InNova Astro Processor</b> without processing. " +
            "Showing the prepared image <b>" + result.mainView.id + "</b>.";
      result.show();
      result.bringToFront();
      dialog.reviewDialog.adjustToContents();
      MiraCenterDialog(dialog.reviewDialog);
      dialog.reviewDialog.execute();
      if (dialog.processorDirectLaunchRequested) {
         StartLaunchInNovaIntegrator(dialog.processorReturnSourceId);
         return true;
      }
   }
   dialog.execute();
   if (dialog.processorDirectLaunchRequested) {
      StartLaunchInNovaIntegrator(dialog.processorReturnSourceId);
      return true;
   }
   return false;
}

function StartLoadSubframeMasterWindows( paths, cleanupDirectory )
{
   let opened = [];
   let failed = [];
   for ( let i = 0; i < paths.length; ++i ) {
      try {
         let windows = ImageWindow.open( paths[i] );
         if ( windows == null || windows.length == 0 )
            failed.push( paths[i] );
         else
            for ( let j = 0; j < windows.length; ++j ) {
               windows[j].iconize();
               opened.push( windows[j] );
            }
      } catch ( error ) {
         failed.push( paths[i] );
         console.warningln( "⚠️ FBPP master could not be opened: " +
            paths[i] + " — " + error );
      }
   }
   if ( failed.length > 0 )
      new InNovaNotice( failed.length + InNovaTr(" FBPP master image(s) could not be opened.\n\n") + failed.join( "\n" ),
         InNovaTr("InNova Subframe Review & Integration — Multi-Night"),
         StdIcon_Warning, StdButton_Ok ).execute();


   if ( opened.length > 0 && failed.length == 0 && cleanupDirectory &&
        cleanupDirectory.length > 0 ) {
      try {
         StartSubframeRemoveTemporaryDirectory( cleanupDirectory );
         console.noteln( "🧹 Temporary Subframe Review files removed from: " +
            cleanupDirectory );
      }
      catch ( error ) {
         console.warningln( "⚠️ Temporary Subframe Review files could not be " +
            "removed: " + error );
      }
   }

   return opened;
}

function main()
{
   StartBeginBugReportCapture();
   console.writeln();
   console.writeln( "✦ " + TITLE + " " + InNovaStartVersion );
   console.writeln( "-------------------------------------" );
   console.noteln( "🟢 Ready..." );
   if ( !MiraRequireCompatiblePixInsight( TITLE ) )
      return;
   _0x76b548f683();
   console.hide();
   let bridgeReturn = StartConsumeBridgeReturn();
   if (bridgeReturn != null && StartRestoreBridgeAfterProcessor(bridgeReturn))
      return;
   let launcher = new InNovaStartLauncherDialog;
   while ( launcher.execute() ) {

      launcher.hide();
      if ( launcher.route == "language" ) {
         launcher = new InNovaStartLauncherDialog(launcher.selectedModuleRoute);
         continue;
      }
      if ( launcher.route == "subframes" ||
           launcher.route == "subframes-guided" ) {
         try {
            let guidedFromSubs = launcher.route == "subframes-guided";
            let review = StartRunSubframeReview( guidedFromSubs );


            if ( !guidedFromSubs ) {
               if ( review.cleanupDirectory &&
                    review.cleanupDirectory.length > 0 ) {
                  try {
                     StartSubframeRemoveTemporaryDirectory(
                        review.cleanupDirectory );
                     console.noteln( "🧹 Temporary Subframe Review files " +
                        "removed after stand-alone processing." );
                  } catch ( cleanupError ) {
                     console.warningln( "⚠️ Temporary Subframe Review files " +
                        "could not be removed: " + cleanupError );
                  }
               }
               continue;
            }
            if ( !review.continueToBridge )
               continue;


            let loadedSubframeMasters = StartLoadSubframeMasterWindows(
               review.masterPaths, review.cleanupDirectory );
            if ( loadedSubframeMasters.length == 0 )
               continue;
            if ( loadedSubframeMasters.length == review.masterPaths.length )
               review.cleanupDirectory = "";
            if ( !StartPrepareSubframeMastersForProcessor(
                    loadedSubframeMasters ) )
               continue;
            StartLaunchInNovaIntegrator( "" );
            return;
         } catch ( error ) {
            console.criticalln( "❌ Subframe Review failed: " + error );
            new InNovaNotice( InNovaTr("InNova Subframe Review & Integration could not complete the workflow.\n\n") + error, InNovaTr("InNova Subframe Review & Integration"),
               StdIcon_Error, StdButton_Ok ).execute();
         }
         continue;
      }
      if ( launcher.route == "processor-guided" ) {
         StartPrepareProcessorLaunchWithoutImages();
         StartLaunchInNovaIntegrator( "" );
         return;
      }
      let moduleScripts = { processor: "InNova01.js",
         stretch: "InNova03.js", editor: "InNova02.js" };
      if ( moduleScripts[launcher.route] ) {
         try {
            if (launcher.route == "stretch") {
               StartRunAdaptiveEmbedded(true);
               continue;
            }
            if (launcher.route == "editor") {
               try { StartRunEditorEmbedded(); }
               finally { console.hide(); }
               continue;
            }
            let scriptPath = File.extractDrive(#__FILE__) +
               File.extractDirectory(#__FILE__) + "/../InNova/" +
               moduleScripts[launcher.route];
            let returnRequest = "InNova/ProcessorReturnToStart";
            Settings.write(returnRequest, DataType_String, JSON.stringify({
               path: File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/InNovaStart.js",
               created: Date.now()
            }));
            try { StartLaunchModule( scriptPath ); }
            catch (error) {
               Settings.write(returnRequest, DataType_String, "");
               throw error;
            }
            return;
         } catch ( error ) {
            new InNovaNotice( "The module could not be opened.\n\n" + error,
               TITLE, StdIcon_Error, StdButton_Ok ).execute();
         }
         continue;
      }
      let reviewCrop = launcher.route == "review-crop";
      if ( !reviewCrop && !_0x8fd8025167("InNova Multi-Night") )
         continue;
      let dialog = new InNovaStartDialog( launcher.route == "guided", reviewCrop );
      dialog.windowTitle = reviewCrop ?
         InNovaTr("InNova Review & Crop — ") + InNovaStartVersion : launcher.route == "guided" ?
         InNovaTr("🔭 InNova Guided Workflow — Step 1: InNova Multi-Night — ") +
            InNovaStartVersion + " — " + _0x690bbf5e93(true) :
         InNovaTr("🔭 InNova Multi-Night — ") + InNovaStartVersion +
            " — " + _0x690bbf5e93(true);
      for ( ;; ) {
         dialog.runPreparationRequested = false;
         dialog.execute();
         if ( !dialog.runPreparationRequested ) break;
         dialog.runPreparationRequested = false;
         dialog.performRunPreparation();
         if ( dialog.preparationFinished ||
              dialog.processorDirectLaunchRequested ||
              (dialog.guidedWorkflow && dialog.integratorLaunchRequested) )
            break;

      }
      if ( dialog.preparationFinished ) continue;
      if ( dialog.processorDirectLaunchRequested ||
           (dialog.guidedWorkflow && dialog.integratorLaunchRequested) ) {
         try {
            StartLaunchInNovaIntegrator(
               dialog.processorDirectLaunchRequested && !dialog.guidedWorkflow ?
                  dialog.processorReturnSourceId : "", dialog.reviewCropMode );
            return;
         } catch ( error ) {
            console.criticalln( "❌ Could not launch InNova Astro Processor: " + error );
            new InNovaNotice(
               InNovaTr("InNova Astro Processor could not be opened automatically.\n\n") + error,
               InNovaTr("🔭 InNova Multi-Night — InNova Astro Processor launch failed"),
               StdIcon_Error, StdButton_Ok ).execute();
         }
      }
   }


   if ( launcher.exitConfirmed ) {


      MiraOrdena1();
      console.hide();
      CoreApplication.processEvents();
      console.hide();
   }
}

#ifndef INNOVA_START_NATIVE_TEST
InNovaDiagnosticRun("START", main);
#endif

#endif
