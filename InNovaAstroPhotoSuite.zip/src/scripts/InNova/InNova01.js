


#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaIntegrator : InNova Astro Photo Suite > InNova Astro Processor
#feature-icon  InNovaIcon.svg
#feature-info  Integration and astrophotography processing for InNova Astro Photo Suite. \
<br/>\
Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Astro Processor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

function InNovaProcessorProgressPanel(dialog, showInformationBox)
{
   let panel = new Control(dialog);
   let header = new Control(panel);
   header.setScaledFixedHeight(92);
   let artworkRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/assets/headers/";
   let background = File.exists(artworkRoot + "guided.png") ? new Bitmap(artworkRoot + "guided.png") : null;
   header.onPaint = function() {
      let g = new Graphics(this);
      g.fillRect(0, 0, this.width, this.height, new Brush(0xffe5f2ff));
      if (background && !background.isNull)
         g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), background);
      g.pen = new Pen(0xff237aca, this.logicalPixelsToPhysical(1));
      g.drawRect(0, 0, this.width-1, this.height-1);
      g.end();
   };
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   let icon = new Control(header);
   icon.setScaledFixedSize(68, 68);
   let artwork = File.exists(artworkRoot + "processor.png") ? new Bitmap(artworkRoot + "processor.png") : null;
   icon.onPaint = function() {
      if (!artwork || artwork.isNull) return;
      let g = new Graphics(this);
      g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), artwork);
      g.end();
   };
   header.sizer.add(icon);
   let text = new VerticalSizer;
   text.spacing = 5;
   text.addStretch();
   function headerLabel(value, size) {
      let label = new Label(header);
      label.useRichText = true;
      label.wordWrapping = true;
      label.text = value;
      label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      label.styleSheet = "font-size:" + size + "pt;color:#102b50;background:transparent;";
      text.add(label);
   }
   headerLabel("<b>InNova Astro Processor</b>", 20);
   text.addStretch();
   header.sizer.add(text, 100);
   panel.setScaledMinWidth(600);
   panel.setScaledFixedHeight(showInformationBox === true ? 180 : 150);
   panel.sizer = new VerticalSizer;
   panel.sizer.spacing = 12;
   panel.sizer.add(header);
   let statusParent = panel;
   let informationBox = null;
   if (showInformationBox === true) {
      informationBox = new GroupBox(panel);
      informationBox.title = "Information";
      informationBox.sizer = new VerticalSizer;
      informationBox.sizer.margin = 10;
      statusParent = informationBox;
   }
   panel.status = new Label(statusParent);
   panel.status.text = "Loading...";
   panel.status.textAlignment = TextAlign_Center | TextAlign_VertCenter;
   panel.status.wordWrapping = true;
   panel.status.setScaledMinHeight(46);
   if (informationBox) {
      informationBox.sizer.add(panel.status);
      panel.sizer.add(informationBox);
   } else
      panel.sizer.add(panel.status);
   return panel;
}

function InNovaProcessorLoading()
{
   let splash = new Dialog;
   splash.windowTitle = "🚀 InNova Astro Processor";
   splash.sizer = new VerticalSizer;
   splash.sizer.margin = 12;
   splash.sizer.spacing = 10;
   splash.sizer.add(InNovaProcessorProgressPanel(splash));
   let close = new PushButton(splash);
   close.text = "Close";
   close.icon = splash.scaledResource(":/icons/close.png");
   close.onClick = function() { splash.cancel(); };
   let row = new HorizontalSizer;
   row.addStretch(); row.add(close); row.addStretch();
   splash.sizer.add(row);
   splash.adjustToContents();
   splash.show();
   CoreApplication.processEvents();
   return splash;
}


var InNovaStartupSplash = InNovaProcessorLoading();
try {
#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaIntegratorImageSolver"
#include "lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Astro Processor"

var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);

#include "lib/lite01.js"


var InNovaReturnToStartPath = "";
var InNovaReturnToBridgeRequest = null;
try {
   let request = Settings.read("InNova/ProcessorReturnToStart", DataType_String);
   let valid = Settings.lastReadOK;
   Settings.write("InNova/ProcessorReturnToStart", DataType_String, "");
   if (valid && request) {
      let parsed = JSON.parse(request);
      let age = Date.now() - parsed.created;
      if (age >= 0 && age < 60000 && typeof parsed.path == "string" && File.exists(parsed.path)) {
         InNovaReturnToStartPath = parsed.path;
         if (parsed.returnMode == "bridge")
            InNovaReturnToBridgeRequest = parsed;
      }
   }
} catch (error) {}

#include "lib/process04.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process01.js"
#include "lib/process12.js"
#include "lib/color-calibration.js"
#include "lib/process02.js"


var ProjecTname = "🚀 InNova Astro Processor";


var ProjecTver  = "v.1.0.build.0409";


var _0x277f0b5adb = false;
var InNovaAdaptiveStretchBuild = "0076";
var _0x470f5b15dc = String.fromCharCode(48,53,97,100,48,57,120,106,114);
var _0xcefea98f25 = String.fromCharCode(98,99,51,53,48,99,55,52,97,100,97,48,50,102,101,52,55,100,98,52,54,102,100,99,99,54,102,97,48,52,51,48,50,48,57,97,52,48,102,52,98,49,100,57,51,97,99,57,100,99,100,100,49,52,48,57,51,57,50,56,51,102,57,50);
var CanStartApp = MiraRequireCompatiblePixInsight("InNova Astro Processor");
var ProjecTypevar = "SHO";
var ProjecTypevar2 = "0";
var ProjecTypevarRec = "SHO";
var InNovaProjectSelectionLoggingEnabled = false;
var InNovaIntegratorHandoffImageIds = {};
var InNovaIntegratorHandoffPendingSetting =
   "InNovaGetStartedIntegratorHandoffPending";
var InNovaIntegratorHandoffProjectSetting =
   "InNovaGetStartedIntegratorProject";
var InNovaIntegratorHandoffImagePrefix =
   "InNovaGetStartedIntegratorImage_";


var InNovaIntegratorMainDialog = null;
var AlignmenTypevar = "Ha";
var OptionLinkRGB = "false";
var PimageSii = "EMPTY";
var PimageHa = "EMPTY";
var PimageOiii = "EMPTY";
var PimageRed = "EMPTY";
var PimageGreen = "EMPTY";
var PimageBlue = "EMPTY";
var PimageLuminance = "EMPTY";
var PimageOsc = "EMPTY";
var Option1var = "OFF";
var OptionHavar = "OFF";
var OptionColorCalibration = "OFF";
var InNovaColorCalibrationStartupConsoleState = "";
var VarProcesStar = "OFF";
var Option2var2 = "OFF";
var OptionGraXNoise = "OFF";


var OptionNarrowbandToRGB = "OFF";
var OptionOpenInNovaEditor = "ON";
var InNovaEditorPendingLaunch = false;
var InNovaEditorPendingSourceId = "";
var InNovaEditorPendingProjectType = "RGB";
var InNovaRunActive = false;
var InNovaStopRequested = false;
var InNovaStopCleanupRequested = false;

function InNovaRequestStop(origin)
{
   if (!InNovaRunActive)
      return false;

   InNovaStopRequested = true;
   InNovaStopCleanupRequested = true;
   InNovaEditorPendingLaunch = false;
   console.show();
   console.warningln(
      "\n⛔ STOP requested" +
      (origin && origin.length > 0 ? " from " + origin : "") +
      ". InNova will stop at the nearest safe checkpoint and clean the project.");

   if (typeof dialog !== "undefined" && dialog) {
      dialog.workingLabel.foregroundColor = 0xd71920;
      dialog.workingStatusText =
         "⛔ Stopping safely. Cleaning the project next...";
      dialog.elapsedStartTime = Date.now();
      dialog.refreshWorkingLabel();
      dialog.exitButton.toolTip = "Stopping...";
      dialog.exitButton.enabled = false;
      dialog.exitButton.update();
   }
   CoreApplication.processEvents();
   return true;
}

function InNovaAbortCheckpoint()
{
   CoreApplication.processEvents();
   if (!InNovaStopRequested)
      return;

   let stopError = new Error("InNova project stopped by the user.");
   stopError.inNovaUserStop = true;
   throw stopError;
}
var OptionDarkStructureEnhance = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var OptionNoiseXterminator  = "OFF";
var OptionMLDenoise = "OFF";
var OptionStarXterminator = "OFF";
var OptionBlurXterminator = "OFF";
var OptionHighpass = "OFF";
var OptionGradient ="ON";
var OptionImageSolver = "OFF";


var OptionObjectType = "STARS";
var OptionDBE = "OFF";
var OptionVarStars = "OFF";
var OptionMgc ="OFF";
var OptionVaonisVespera = "OFF";


var OptionSeestar = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionFast = "OFF";
var VarPGlobal = "EMPTY";
var _0xc7fa59117d ="EMPTY";
var NewGreenValue = 0.0;
var NewMagentaValue = 1;
var NewStarsValue = 1;
var isStarProcess = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var OptionHSOvar = "OFF";
var OptionSharpenNonstellar = 0.20;


function MiraRequirePipelineWindow(windowId, stageName)
{
   let window = ImageWindow.windowById(windowId);
   if (window && !window.isNull && window.mainView &&
       !window.mainView.isNull)
      return true;

   console.criticalln(
      "❌ " + stageName + " did not create the required window: " +
      windowId + ". Processing has been stopped safely.");
   return false;
}

function MiraValidateFinalWindowContract(requireStars, stageName)
{
   if (!MiraRequirePipelineWindow("Final_starless", stageName))
      return false;

   if (requireStars) {
      if (!MiraRequirePipelineWindow("Final_stars", stageName))
         return false;
      if (!MiraRequirePipelineWindow("Final_Result", stageName))
         return false;
   }

   return true;
}


var InteractiveProcessStrengths = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var InteractiveProcessMaskModes = {
   DeepSNR: "none",
   MLDenoise: "none",
   NoiseXTerminator: "none",
   BlurXTerminator: "none",
   HighPass: "none",
   NarrowbandToRGB: "none"
};
var InteractiveProcessMaskBanks = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};


var InNovaEditorTitle = "🪐 InNova Photo Editor";

function InNovaIntegratorResetInNovaEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaIntegratorCloneForInNovaEditor(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      image.isColor,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaIntegratorOpenInNovaEditor(sourceId, projectType)
{
   InNovaEditorPendingLaunch = false;

   let source = ImageWindow.windowById(sourceId);
   if (!source || source.isNull || !source.mainView ||
       source.mainView.isNull || !source.mainView.image ||
       source.mainView.image.numberOfChannels < 3) {
      console.show();
      console.warningln(
         "⚠️ 🪐 InNova Photo Editor was not opened because the final color image is no longer available.");
      return false;
   }

   let editorProjectType =
      projectType === "SHO" || projectType === "HOO" ||
      projectType === "LRGB" || projectType === "OSC" ?
      projectType : "RGB";
   let outputId = MiraUniqueWindowId(sourceId + "_InNovaPhotoEditor");
   let output = null;

   try {
      output = InNovaIntegratorCloneForInNovaEditor(source, outputId);
      InNovaIntegratorResetInNovaEditorState();
      ProjecTypevar = editorProjectType;
      ProjecTypevarRec = editorProjectType;

      console.noteln("\n🪐 Opening InNova Photo Editor: " + sourceId);
      console.writeln("🔭 Project type received from InNova Astro Processor: " +
                      editorProjectType);

      let editorLaunchContext = {
         source: "InNova Integrator",
         requestedModule: ""
      };
      let detectedStarPair =
         typeof InNovaEditorFindStandaloneStarPair === "function" ?
         InNovaEditorFindStandaloneStarPair(output) : null;

      if (detectedStarPair) {
         editorLaunchContext.starlessId = detectedStarPair.starlessId;
         editorLaunchContext.starsId = detectedStarPair.starsId;
         console.noteln("\n🌟 InNova Star Refinement layers linked:");
         console.writeln("   Starless: " + detectedStarPair.starlessId);
         console.writeln("   Stars: " + detectedStarPair.starsId);
      }

      let editorResult = InNovaEditorRunProEditor(
         output.mainView,
         editorProjectType,
         editorLaunchContext);
      if (!editorResult.accepted && editorResult.openRequested) {
         output.forceClose();
         output = null;
         let requestedId = InNovaEditorChooseOpenColorImage();
         if (requestedId.length === 0)
            return false;
         let upperId = requestedId.toUpperCase();
         let requestedType =
            upperId.indexOf("SHO") !== -1 ? "SHO" :
            upperId.indexOf("HOO") !== -1 ? "HOO" :
            upperId.indexOf("LRGB") !== -1 ? "LRGB" :
            upperId.indexOf("OSC") !== -1 ||
            upperId.indexOf("VAONIS") !== -1 ||
            upperId.indexOf("SEESTAR") !== -1 ? "OSC" : "RGB";
         return InNovaIntegratorOpenInNovaEditor(
            requestedId, requestedType);
      }
      if (!editorResult.accepted && editorResult.cancelled) {
         output.forceClose();
         output = null;
         console.noteln("🪐 InNova Photo Editor editing cancelled.");
         return false;
      }
      if (!editorResult.accepted)
         throw new Error(
            "The image editor could not prepare the final image.");

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Photo Editor result created: " + outputId);
      return true;
   }
   catch (error) {
      if (output && !output.isNull)
         output.forceClose();

      console.show();
      console.criticalln("❌ 🪐 InNova Photo Editor could not be opened: " +
                         (error.message || error));
      new MessageBox(
         "InNova Photo Editor could not open the final image.\n\n" +
         "Review the Process Console for details.",
         "InNova Photo Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }
}
var _0x8a60858f5f = "";
var OptionMergePro1  = "<Select an Image>";
var OptionshowConsolRadio = "ON";
var OptionRemaind2 = null;
var OptionSTFvar = "OFF";
var OptionEnabledPreview2 ="OFF";
var OptionGreen = "OFF";
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
var defaultProjectPath = _0xb3f8d42772() + "/";
var originalFilePathMars1 = defaultProjectPath;
var originalFilePathMars2 = defaultProjectPath;
var originalFilePathMarsfin1 = defaultProjectPath;
var originalFilePathMarsfin2 = defaultProjectPath;
var originalFilePathMLDenoise = defaultProjectPath;
var originalFilePathMLDenoisefin = defaultProjectPath;
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MLDenoiseFound ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMarsFirst ="MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond ="MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel ="MLDenoise_v5.xmlm";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;


console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
if (CanStartApp)
   _0x825e4dd6fe();
console.writeln("");
console.noteln("Checking third-party software:");

defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";


let savedMgcSensorName = Settings.read("MgcSensorName", DataType_String);
if (typeof savedMgcSensorName === "string" &&
    savedMgcSensorName.trim().length > 0)
   SensorName = savedMgcSensorName;

let savedMgcNarrowband = Settings.read("MgcNarrowband", DataType_String);
if (savedMgcNarrowband === "ON" || savedMgcNarrowband === "OFF")
   Narrowband = savedMgcNarrowband;

function MiraRestorePositiveMgcNumber(key, fallback)
{
   let savedValue = Settings.read(key, DataType_Double);
   return typeof savedValue === "number" && isFinite(savedValue) &&
          savedValue > 0 ? savedValue : fallback;
}

defaultGrayWavelength = MiraRestorePositiveMgcNumber(
   "MgcGrayWavelength", defaultGrayWavelength);
defaultGrayBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGrayBandwidth", defaultGrayBandwidth);
defaultRedWavelength = MiraRestorePositiveMgcNumber(
   "MgcRedWavelength", defaultRedWavelength);
defaultRedBandwidth = MiraRestorePositiveMgcNumber(
   "MgcRedBandwidth", defaultRedBandwidth);
defaultGreenWavelength = MiraRestorePositiveMgcNumber(
   "MgcGreenWavelength", defaultGreenWavelength);
defaultGreenBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGreenBandwidth", defaultGreenBandwidth);
defaultBlueWavelength = MiraRestorePositiveMgcNumber(
   "MgcBlueWavelength", defaultBlueWavelength);
defaultBlueBandwidth = MiraRestorePositiveMgcNumber(
   "MgcBlueBandwidth", defaultBlueBandwidth);

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


getFilePath(originalFilePathMars1, originalFilePathMars2);

if (CanStartApp && !RuntimeReady())
{
   CanStartApp = false;

   console.criticalln("Initialization cancelled.");

   new MessageBox(
      "Unable to initialize processing engine.",
      "InNova Astro Processor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
}
else if (CanStartApp)
{
   CanStartApp = true;
}

const _0xd4d475122b =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiIwZThlNmI2My1hZTk1LTQ1MjctOWNjMS1iN2JlMzc2N2ViZmYiLCJjaGVja291dEZsb3dJZCI6ImVlNjNjNTliLWI1OTQtNGY3MS1iMTFiLWJmZjlmNDA2MTIzNyIsImlzVjMiOnRydWV9";

const _0xd0deaf5abb =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiJiNDE5M2JlNi00NTg0LTRjYmMtOWEyOS1iYjE0YjJjYzRlM2IiLCJjaGVja291dEZsb3dJZCI6ImY4YTMyNmVjLTI4MDQtNGIzNi1iN2UxLTlmZTMyYTlmNGY0NiIsImlzVjMiOnRydWV9";

const INNOVA_MORE_INFORMATION_PDF_URL =
   "https://31ec875b-1942-46dd-b74b-6289964f61f6.usrfiles.com/ugd/" +
   "31ec87_f1e89feb5ec04cabb3fcbc91123e3742.pdf";

class _0x5917ae487e extends Dialog
{
   constructor()
   {
      super();

      let self = this;
      this.selectedUrl = "";
      this.recoverExisting = false;
      this.supportRecovery = false;
      let paidRecoveryAvailable = _0x842d83d5c4();
      this.windowTitle = String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110,32,80,108,97,110,115);

      let titleLabel = new Label(this);
      titleLabel.useRichText = true;
      titleLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      titleLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,67,104,111,111,115,101,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,60,47,112,62) +
         "<p align=\"center\">Select the billing period that suits you.</p>";


      titleLabel.onMousePress = function ()
      {
         if (paidRecoveryAvailable)
            return;
         paidRecoveryAvailable = true;
         transferGroup.visible = true;
         supportGroup.visible = true;
         self.adjustToContents();
         self.setFixedSize();
      };

      let monthlyGroup = new GroupBox(this);
      monthlyGroup.title = "Monthly";
      monthlyGroup.setFixedWidth(260);
      monthlyGroup.sizer = new VerticalSizer;
      monthlyGroup.sizer.margin = 12;
      monthlyGroup.sizer.spacing = 10;

      let monthlyPriceLabel = new Label(monthlyGroup);
      monthlyPriceLabel.useRichText = true;
      monthlyPriceLabel.wordWrapping = true;
      monthlyPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      monthlyPriceLabel.text =
         "<p align=\"center\"><b>&euro;6.99 / month</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Billed every month until cancelled.</p>";

      let monthlyButton = new PushButton(monthlyGroup);
      monthlyButton.text = "Choose Monthly";
      monthlyButton.setFixedHeight(34);
      monthlyButton.onClick = function ()
      {
         self.selectedUrl = _0xd4d475122b;
         self.ok();
      };

      monthlyGroup.sizer.add(monthlyPriceLabel);
      monthlyGroup.sizer.addStretch();
      monthlyGroup.sizer.add(monthlyButton);

      let annualGroup = new GroupBox(this);
      annualGroup.title = "Annual";
      annualGroup.setFixedWidth(260);
      annualGroup.sizer = new VerticalSizer;
      annualGroup.sizer.margin = 12;
      annualGroup.sizer.spacing = 10;

      let annualPriceLabel = new Label(annualGroup);
      annualPriceLabel.useRichText = true;
      annualPriceLabel.wordWrapping = true;
      annualPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      annualPriceLabel.text =
         "<p align=\"center\"><b>&euro;69.99 / year</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Save &euro;13.89 compared with<br>12 monthly payments.</p>";

      let annualButton = new PushButton(annualGroup);
      annualButton.text = "Choose Annual - Best Value";
      annualButton.icon = this.scaledResource( ":/icons/ok.png" );
      annualButton.toolTip =
         "Recommended: save EUR 13.89 compared with 12 monthly payments.";
      annualButton.setFixedHeight(34);
      annualButton.onClick = function ()
      {
         self.selectedUrl = _0xd0deaf5abb;
         self.ok();
      };

      annualGroup.sizer.add(annualPriceLabel);
      annualGroup.sizer.addStretch();
      annualGroup.sizer.add(annualButton);

      let plansSizer = new HorizontalSizer;
      plansSizer.spacing = 12;
      plansSizer.add(monthlyGroup);
      plansSizer.add(annualGroup);

      let bonusGroup = new GroupBox(this);
      bonusGroup.title = "Bonus";
      bonusGroup.sizer = new VerticalSizer;
      bonusGroup.sizer.margin = 12;

      let bonusLabel = new Label(bonusGroup);
      bonusLabel.useRichText = true;
      bonusLabel.wordWrapping = true;
      bonusLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      bonusLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,42,32,66,111,116,104,32,115,117,98,115,99,114,105,112,116,105,111,110,115,32,105,110,99,108,117,100,101,32,97,99,99,101,115,115,32,116,111,32,116,104,101,32) +
         "<b>Premium site</b> with exclusive learning videos<br>" +
         "and early access to new tools.</p>" +
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,42,32,84,104,101,32,97,110,110,117,97,108,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,110,99,108,117,100,101,115,32,97,99,99,101,115,115,32) +
         "to a questions and answers channel.</b></p>";
      bonusGroup.sizer.add(bonusLabel);

      let transferGroup = new GroupBox(this);
      transferGroup.title = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      transferGroup.visible = paidRecoveryAvailable;
      transferGroup.sizer = new VerticalSizer;
      transferGroup.sizer.margin = 12;
      transferGroup.sizer.spacing = 10;

      let transferLabel = new Label(transferGroup);
      transferLabel.useRichText = true;
      transferLabel.wordWrapping = true;
      transferLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      transferLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,87,111,117,108,100,32,121,111,117,32,108,105,107,101,32,116,111,32,116,114,97,110,115,102,101,114,32,121,111,117,114,32,108,105,99,101,110,115,101,32,116,111,32,97,110,111,116,104,101,114,32,99,111,109,112,117,116,101,114,63,60,98,114,62) +
         "Open InNova Astro Processor on the other computer and click this button.</p>";

      let recoveryButton = new PushButton(transferGroup);
      recoveryButton.text = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      recoveryButton.icon = this.scaledResource( ":/icons/internet.png" );
      recoveryButton.toolTip =
         "Authorize this computer with the purchasing Wix account. No payment is made.";
      recoveryButton.onClick = function ()
      {
         self.recoverExisting = true;
         self.ok();
      };

      let recoverySizer = new HorizontalSizer;
      recoverySizer.addStretch();
      recoverySizer.add(recoveryButton);
      recoverySizer.addStretch();
      transferGroup.sizer.add(transferLabel);
      transferGroup.sizer.add(recoverySizer);

      let supportGroup = new GroupBox(this);
      supportGroup.title = String.fromCharCode(83,117,112,112,111,114,116,32,76,105,99,101,110,115,101,32,82,101,99,111,118,101,114,121);
      supportGroup.visible = paidRecoveryAvailable;
      supportGroup.sizer = new VerticalSizer;
      supportGroup.sizer.margin = 12;
      supportGroup.sizer.spacing = 10;

      let supportLabel = new Label(supportGroup);
      supportLabel.useRichText = true;
      supportLabel.wordWrapping = true;
      supportLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      supportLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,85,115,101,32,116,104,105,115,32,111,112,116,105,111,110,32,119,104,101,110,32,97,32,99,117,114,114,101,110,116,108,121,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,97,110,110,111,116,32) +
         "be recovered normally. Wix will verify the paid period automatically.</p>";

      let supportButton = new PushButton(supportGroup);
      supportButton.text = String.fromCharCode(82,101,99,111,118,101,114,32,76,105,99,101,110,115,101,32,119,105,116,104,32,83,117,112,112,111,114,116);
      supportButton.icon = this.scaledResource( ":/icons/internet.png" );
      supportButton.toolTip =
         "Creates a 30-minute Linking Code for automatic paid-period recovery. No payment is made.";
      supportButton.onClick = function ()
      {
         self.supportRecovery = true;
         self.ok();
      };
      let supportSizer = new HorizontalSizer;
      supportSizer.addStretch();
      supportSizer.add(supportButton);
      supportSizer.addStretch();
      supportGroup.sizer.add(supportLabel);
      supportGroup.sizer.add(supportSizer);

      let cancelButton = new PushButton(this);
      cancelButton.text = "Cancel";
      cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      cancelButton.setFixedWidth(120);
      cancelButton.onClick = function () { self.cancel(); };

      let cancelSizer = new HorizontalSizer;
      cancelSizer.addStretch();
      cancelSizer.add(cancelButton);
      cancelSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 14;
      this.sizer.spacing = 12;
      this.sizer.add(titleLabel);
      this.sizer.add(plansSizer);
      this.sizer.add(bonusGroup);


      this.sizer.add(transferGroup);
      this.sizer.add(supportGroup);
      this.sizer.add(cancelSizer);

      this.adjustToContents();
      this.setFixedSize();
   }
}


class IntegratorDialog extends Dialog {

    constructor() {

        super();

        this.windowTitle = ProjecTname;

    var self = this;


    function createIntegrationOptionRadioButton(parent) {
       let container = new Control(parent);
       container.sizer = new HorizontalSizer;
       container.sizer.margin = 0;
       container.sizer.spacing = 0;

       let radioButton = new RadioButton(container);
       container.sizer.add(radioButton);
       radioButton.integrationOptionContainer = container;
       radioButton.checkedBeforeInteraction = false;

       radioButton.onMousePress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       radioButton.onKeyPress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       return radioButton;
    }

    function preserveIntegrationOptionToggle(radioButton) {
       let originalOnClick = radioButton.onClick;

       radioButton.onClick = function () {

          this.checked = !this.checkedBeforeInteraction;
          this.checkedBeforeInteraction = this.checked;

          if (originalOnClick)
             originalOnClick.call(this);
       };
    }

    function addIntegrationOption(sizer, radioButton) {
       let container = radioButton.integrationOptionContainer;


       container.adjustToContents();
       container.setFixedHeight(container.height);
       sizer.add(container);
    }


    this.userResizable = true;

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 650;


    this.tabBox = new TabBox(this);


    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;


    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;


    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "2. Gradients:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.ImageSolverCheckBox = new CheckBox(this.integrationPage);
    this.ImageSolverCheckBox.text = "Run ImageSolver";
    this.ImageSolverCheckBox.checked = false;
    this.ImageSolverCheckBox.enabled = true;
    this.ImageSolverCheckBox.toolTip =
       "Run ImageSolver on every selected project image before processing.";

    this.ImageSolverCheckBox.onClick = function () {
       OptionImageSolver = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Run ImageSolver = " + OptionImageSolver);
       this.dialog.update();
    };

    this.gradientCorrectionLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientCorrectionLabel.text = "Select gradient correction:";
    this.gradientCorrectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.gradientCorrectionComboBox = new ComboBox(this.CropprojectTypeGroupBox);
    this.gradientCorrectionComboBox.addItem("Run Gradient Correction");
    this.gradientCorrectionComboBox.addItem("Run Multiscale Gradient Correction");
    this.gradientCorrectionComboBox.currentItem = 0;
    this.gradientCorrectionComboBox.setScaledMinWidth(240);

    this.gradientCorrectionComboBox.onItemSelected = function (itemIndex) {
       if (itemIndex === 0) {
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.noteln("⚙️ Gradient Correction = ON");
          console.noteln("⚙️ Multiscale Gradient Correction : OFF");
          return;
       }

       new MessageBox(
          "Remember to adjust the SFC parameters using the 'Settings' button before running the script.\n\n" +
          "MGC requires SFC calibration, MARS and Gaia DR3/SP databases.",
          "Multiscale Gradient Correction",
          StdIcon_Information,
          StdButton_Ok
       ).execute();

       try {
          new MultiscaleGradientCorrection();
          console.noteln("🟢 MultiscaleGradientCorrection is available.");
       } catch (error) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
          new MessageBox(
             "MultiscaleGradientCorrection is not available in this PixInsight version.",
             "InNova Astro Processor",
             StdIcon_Error,
             StdButton_Ok
          ).execute();
          return;
       }

       if (!MiraValidateMgcConfiguration(true)) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          return;
       }

       OptionGradient = "OFF";
       OptionMgc = "ON";
       console.noteln("⚙️ Gradient Correction = OFF");
       console.noteln("⚙️ Multiscale Gradient Correction : ON");
    };


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionLabel);
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionComboBox);
    this.gradientSettingsLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientSettingsLabel.text = "Clic on 'Settings' for SFC and MGC options";
    this.gradientSettingsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientSettingsLabel);
    this.CropprojectTypeGroupBox.adjustToContents();
    this.CropprojectTypeGroupBox.setFixedHeight(
       this.CropprojectTypeGroupBox.height
    );


    this.HalphaCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.HalphaCheckBox.text = "Create 'HAlpha' for blending (RGB/LRGB)";
    this.HalphaCheckBox.checked = false;

    this.colorCalibrationCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.colorCalibrationCheckBox.text = "Color Calibration";
    this.colorCalibrationCheckBox.checked = false;
    let colorCalibrationLastConsoleState =
       InNovaColorCalibrationStartupConsoleState;

    function updateColorCalibrationAvailability(selectWhenAvailable) {
       if (!self.colorCalibrationCheckBox) return;
       let reason = "";
       let projectIndex = self.projectTypeComboBox ?
          self.projectTypeComboBox.currentItem : -1;
       let lrgbProject = projectIndex === 0;
       let rgbProject = projectIndex === 1;
       let oscProject = projectIndex === 4;
       let seestarProject = projectIndex >= 5 && projectIndex <= 8;
       let vaonisProject = projectIndex >= 9 && projectIndex <= 10;

       if (!lrgbProject && !rgbProject && !oscProject &&
           !seestarProject && !vaonisProject)
          reason = "Color Calibration is available for LRGB, RGB, OSC, Seestar and Vaonis projects.";
       else if (OptionObjectType === "MOON_SUN")
          reason = "Color Calibration is unavailable in Moon or Sun mode.";
       else if (typeof SpectrophotometricColorCalibration == "undefined")
          reason = "SpectrophotometricColorCalibration is not installed.";
       else {
          let gaia = MiraGaiaDr3SpStatus();
          if (!gaia.processInstalled || !gaia.supported || !gaia.ready)
             reason = gaia.error ||
                "Color Calibration requires a configured Gaia DR3/SP database.";
          else {
             let source = null;
             if (PimageOsc && PimageOsc !== "EMPTY")
                source = ImageWindow.windowById(PimageOsc);
             let context = {
                forceSeestar: seestarProject,
                forceVaonis: vaonisProject,
                identity: OptionSmartTelescopeModel,
                allowDefaultRgb: lrgbProject || rgbProject || oscProject,
                sourceWindows: source && !source.isNull ? [source] : []
             };
             let profile = MiraColorCalibrationProfile(source, context);
             if (profile == null)
                reason = vaonisProject ?
                   "Select a supported Vaonis Vespera II, III or Pro image." :
                   "No supported Seestar RGB response profile was detected.";
             else {
                let curves = MiraColorCalibrationLoadCurves(profile);
                if (curves.error) reason = curves.error;
             }
          }
       }

       self.colorCalibrationCheckBox.enabled = reason.length === 0;
       self.colorCalibrationCheckBox.toolTip = reason.length === 0 ?
          "Run SPCC on a copy of the linear combined image and review it before continuing. ImageSolver is enabled automatically." :
          reason;
       if (reason.length > 0) {
          self.colorCalibrationCheckBox.checked = false;
          OptionColorCalibration = "OFF";
       }
       else if (selectWhenAvailable === true) {
          self.colorCalibrationCheckBox.checked = true;
          OptionColorCalibration = "ON";
          if (self.ImageSolverCheckBox) {
             self.ImageSolverCheckBox.checked = true;
             OptionImageSolver = "ON";
             self.ImageSolverCheckBox.update();
          }
       }
       let consoleState = reason.length > 0 ? "OFF: " + reason : "AVAILABLE";
       if (consoleState !== colorCalibrationLastConsoleState) {
          if (reason.length > 0)
             console.writeln(
                "🌈 Color Calibration Disabled: " + reason);
          else
             console.writeln("🌈 Color Calibration Enabled.");
          colorCalibrationLastConsoleState = consoleState;
       }
       self.colorCalibrationCheckBox.update();
    }


    function MiraComboProyect() {

    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].enabled = false;
        self.comboBoxReferences[key].update();
    }


    switch (ProjecTypevar) {
        case "RGB":
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            self.comboBoxReferences["PimageLuminance"].enabled = true;
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            self.comboBoxReferences["PimageSii"].enabled = true;
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            self.comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }


    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "1. Project:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    let imageSolverWasEnabledBeforeVaonis = false;
    let imageSolverWasCheckedBeforeVaonis = false;
    let imageSolverForcedByVaonis = false;

    function selectProjectType(projectType, enableFast, vaonisMode,
                               seestarMode, smartModel) {
       ProjecTypevar = projectType;
       let smartTelescopeMode = vaonisMode || seestarMode;
       OptionSeestar = seestarMode ? "ON" : "OFF";
       OptionSmartTelescopeModel = smartTelescopeMode ? smartModel : "NONE";

       OptionVaonisVespera = smartTelescopeMode ? "ON" : "OFF";

       if (self.oscImageLabel) {
          self.oscImageLabel.text = seestarMode ? "SEESTAR:" :
             (vaonisMode ? "VAONIS Vespera:" : "OSC Image:");
          self.oscImageLabel.update();
       }

       if (smartTelescopeMode && OptionObjectType === "STARS") {
          if (!imageSolverForcedByVaonis) {
             imageSolverWasEnabledBeforeVaonis = self.ImageSolverCheckBox.enabled;
             imageSolverWasCheckedBeforeVaonis = self.ImageSolverCheckBox.checked;
          }

          self.ImageSolverCheckBox.checked = true;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "ON";
          imageSolverForcedByVaonis = true;
          console.noteln("⚙️ " +
             (seestarMode ? "SEESTAR" : "VAONIS Vespera") +
             " mode: interactive ImageSolver enabled.");
       }
       else if (imageSolverForcedByVaonis) {
          self.ImageSolverCheckBox.enabled = imageSolverWasEnabledBeforeVaonis;
          self.ImageSolverCheckBox.checked = imageSolverWasCheckedBeforeVaonis;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;
       }

       if (OptionObjectType === "MOON_SUN") {
          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;
       }

       self.FastCheckBox.enabled = enableFast;
       if (!enableFast) {
          self.FastCheckBox.checked = false;
          self.FastCheckBox.text = "Fast integration mode 'OFF' ";
          self.FastCheckBox.styleSheet = "color: black;";
          OptionFast = "OFF";
       }

       let narrowbandProject = projectType === "SHO" || projectType === "HOO";
       let rgbProject = projectType === "RGB" || projectType === "LRGB";

       if (self.finalStarsComboBox && !narrowbandProject &&
           self.finalStarsComboBox.currentItem === 2) {
          self.finalStarsComboBox.currentItem = 0;
          Option1var = "OFF";
          OptionHSOvar = "OFF";
       }

       if (self.HalphaCheckBox) {
          self.HalphaCheckBox.enabled = rgbProject;
          if (!rgbProject) {
             self.HalphaCheckBox.checked = false;
             OptionHavar = "OFF";
          }
       }

       MiraComboProyect();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.projectTypeComboBox = new ComboBox(this.projectTypeGroupBox);
    this.projectTypeComboBox.addItem("LRGB");
    this.projectTypeComboBox.addItem("RGB");
    this.projectTypeComboBox.addItem("SHO");
    this.projectTypeComboBox.addItem("HOO");
    this.projectTypeComboBox.addItem("OSC (RGB Color camera .xisf or Raw)");
    this.projectTypeComboBox.addItem("Seestar S30 Pro");
    this.projectTypeComboBox.addItem("Seestar S50");
    this.projectTypeComboBox.addItem("Seestar S50 Pro");
    this.projectTypeComboBox.addItem("Seestar (Automatic)");
    this.projectTypeComboBox.addItem("VAONIS Vespera III");
    this.projectTypeComboBox.addItem("VAONIS Vespera (Automatic)");
    this.projectTypeComboBox.currentItem = 2;
    this.projectTypeComboBox.setScaledMinWidth(285);
    this.projectTypeComboBox.toolTip =
       "Select the project type. SEESTAR and VAONIS VESPERA FITS/TIFF modes " +
       "automatically open ImageSolver when an astrometric solution is required.";

    this.projectTypeComboBox.onItemSelected = function (itemIndex) {
       let projectTypes = [
          "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
          "OSC", "OSC", "OSC"
       ];
       let smartModels = [
          "NONE", "NONE", "NONE", "NONE", "NONE",
          "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
          "VAONIS_VESPERA_III", "VAONIS_AUTO"
       ];
       let enableFast = itemIndex < 4;
       selectProjectType(
          projectTypes[itemIndex], enableFast,
          itemIndex >= 9, itemIndex >= 5 && itemIndex <= 8,
          smartModels[itemIndex]);
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;
    this.projectTypeLabel = new Label(this.projectTypeGroupBox);
    this.projectTypeLabel.text = "Select project type:";
    this.projectTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.projectTypeGroupBox.sizer.add(this.projectTypeLabel);
    this.projectTypeGroupBox.sizer.add(this.projectTypeComboBox);
    this.projectTypeGroupBox.sizer.add(this.ImageSolverCheckBox);
    this.projectTypeGroupBox.adjustToContents();
    this.projectTypeGroupBox.setFixedHeight(this.projectTypeGroupBox.height);


    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);


    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "3. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    self.comboBoxReferences = {};


    let taggingLabelWidth = this.font.width("Luminance Image:M");

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer;
       rowSizer.spacing = 6;

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(taggingLabelWidth);

       if (variableKey === "PimageOsc")
          self.oscImageLabel = label;

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];

           if (!window || window.isNull || !window.mainView || window.mainView.isNull)
               continue;


           comboBox.addItem(window.mainView.id);
       }

       self.comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = index === 0 ? "EMPTY" : comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
           if (variableKey === "PimageOsc")
              updateColorCalibrationAvailability(true);
       };


       rowSizer.add(label);
       rowSizer.add(comboBox, 1);


       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;


      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC Image:", "PimageOsc");
      this.taggingGroupBox.sizer.addSpacing(6);


    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "4. Object:";
    this.optionsGroupBox.sizer = new VerticalSizer;


    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;


      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.FastCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
   this.FastCheckBox.text = "Fast integration mode 'OFF' ";
   this.FastCheckBox.checked = false;

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' ";
           this.styleSheet = "color: blue;";
           console.writeln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = "Fast integration mode 'OFF' ";
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


    this.darkStructureEnhanceCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.darkStructureEnhanceCheckBox.text =
       "InNova Dark Structure Enhance";
    this.darkStructureEnhanceCheckBox.checked = true;
    this.darkStructureEnhanceCheckBox.onClick = function () {
        OptionDarkStructureEnhance = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ InNova Dark Structure Enhance: " +
                       OptionDarkStructureEnhance);
    };

    this.finalStarRefinementCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.finalStarRefinementCheckBox.text = "InNova Star Refinement";
    this.finalStarRefinementCheckBox.checked = false;
    this.finalStarRefinementCheckBox.enabled = false;
    this.finalStarRefinementCheckBox.onClick = function () {
       if (this.checked && OptionVarStars !== "ON") {
          this.checked = false;
          OptionFinalStarRefinement = "OFF";
          console.warningln(
             "⚠️ InNova Star Refinement requires a Final_starless method.");
          return;
       }
       OptionFinalStarRefinement = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ InNova Star Refinement: " +
                      OptionFinalStarRefinement);
    };


    ProjecTypevar = "SHO";
    MiraComboProyect();


    this.OptionVarStarsCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.OptionVarStarsCheckBox.integrationOptionContainer.visible = false;
    this.starsHSOCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsHSOCheckBox.integrationOptionContainer.visible = false;


    this.starsRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    var self = this;


    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.warningln("\n⚠️ Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


    if (!this.checked) {
        Option1var = "OFF";
        console.noteln("⚙️ Create RGB 'Final_stars' : OFF");
        return;
    }


    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            OptionHSOvar = "OFF";
            self.starsHSOCheckBox.checked = false;

            ProjecTypevar2 = "1";
            self.starsRGBCheckBox.checked = true;

    } else {

        self.comboBoxReferences["PimageRed"].enabled = false;
        self.comboBoxReferences["PimageGreen"].enabled = false;
        self.comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
};

    this.colorCalibrationCheckBox.onClick = function () {
       if (!this.enabled) {
          this.checked = false;
          OptionColorCalibration = "OFF";
          return;
       }
       OptionColorCalibration = this.checked ? "ON" : "OFF";
       if (this.checked && self.ImageSolverCheckBox) {
          self.ImageSolverCheckBox.checked = true;
          OptionImageSolver = "ON";
          self.ImageSolverCheckBox.update();
       }
       console.noteln("⚙️ Color Calibration: " + OptionColorCalibration);
    };


var self = this;


self.starXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
self.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
self.starXterminatorCheckBox.checked = true;


this.starNetCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;


this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           if (starXterminatorInstalled) {
              self.starXterminatorCheckBox.checked = true;
              self.starNetCheckBox.checked = false;
              OptionStarXterminator = "ON";
           } else if (starNet2Installed) {
              self.starXterminatorCheckBox.checked = false;
              self.starNetCheckBox.checked = true;
              OptionStarXterminator = "OFF";
           } else {
              this.checked = false;
              OptionVarStars = "OFF";
              OptionStarXterminator = "OFF";
              console.warningln("⚠️ StarXTerminator or StarNet2 must be installed to create a starless image.");
              return;
           }

           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = starXterminatorInstalled;
           self.starNetCheckBox.enabled = starNet2Installed;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           OptionHSOvar = "ON";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = false;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "OFF";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           OptionHSOvar = "OFF";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };


let starRemovalMethodLabel = "Star Removal by StarXterminator";
OptionStarXterminator = "ON";


self.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        if (!starXterminatorInstalled) {
            this.checked = false;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";

        console.writeln("Fast Process !!!");
    } else {
        if (!starNet2Installed) {
            this.checked = true;
            OptionStarXterminator = "ON";
            console.warningln("⚠️ StarNet2 is not installed. StarXTerminator remains selected.");
            return;
        }


        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};


this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        if (!starNet2Installed) {
            this.checked = false;
            console.warningln("⚠️ StarNet2 is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        console.writeln("Slow Process !!!");
    } else {
        if (!starXterminatorInstalled) {
            this.checked = true;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed. StarNet2 remains selected.");
            return;
        }


        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};


    this.blurXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;


    this.highPassCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.highPassCheckBox.text = "Sharpen by InNova Focus";
    this.highPassCheckBox.checked = false;


    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.warningln("⚠️ Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;


    let msgBox = new MessageBox("Enable Ha Image for blending?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {

        self.comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
};

    this.blurXterminatorCheckBox.onClick = function () {
        if (this.checked && !blurXterminatorInstalled) {
           this.checked = false;
           self.highPassCheckBox.checked = true;
           OptionBlurXterminator = "OFF";
           OptionHighpass = "ON";
           console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus remains enabled.");
           return;
        }

        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {

         self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
         OptionHighpass = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");

           } else {

         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
         OptionHighpass = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator : ON");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";

         if (!this.checked && !blurXterminatorInstalled) {
            this.checked = true;
            self.blurXterminatorCheckBox.checked = false;
            OptionHighpass = "ON";
            OptionBlurXterminator = "OFF";
            console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus is required.");
            return;
         }

         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: ON. InNova Focus disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");
       }
      };


    let legacyHiddenControls = [
       this.OptionVarStarsCheckBox,
       this.starsHSOCheckBox,
       this.starsRGBCheckBox,
       self.starXterminatorCheckBox,
       this.starNetCheckBox,
       this.blurXterminatorCheckBox,
       this.highPassCheckBox,
       this.darkStructureEnhanceCheckBox,
       this.finalStarRefinementCheckBox
    ];
    for (let i = 0; i < legacyHiddenControls.length; ++i)
       legacyHiddenControls[i].integrationOptionContainer.visible = false;

    let integrationOptionRadioButtons = [
       this.FastCheckBox,
       this.HalphaCheckBox,
       this.colorCalibrationCheckBox
    ];

    for (let i = 0; i < integrationOptionRadioButtons.length; ++i)
       preserveIntegrationOptionToggle(integrationOptionRadioButtons[i]);


    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    function addThirdPartyCombo(combo, items) {
       combo.setScaledMinWidth(240);
       for (let i = 0; i < items.length; ++i)
          combo.addItem(items[i]);
       combo.currentItem = 0;
       self.optionsGroupBox.sizer.add(combo);
    }

    function warnMissingThirdPartyPlugin(pluginName) {
       console.warningln("⚠️ " + pluginName +
          " plugin is not installed. Choose another option.");
    }

    this.objectTypeLabel = new Label(this.optionsGroupBox);
    this.objectTypeLabel.text = "Object Type:";
    this.objectTypeLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.objectTypeLabel);

    this.objectTypeComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.objectTypeComboBox, [
       "Nebula or Galaxy",
       "Moon or Sun"
    ]);
    this.objectTypeComboBox.toolTip =
       "Nebula or Galaxy uses the normal astrometry and star-processing workflow. " +
       "Moon or Sun skips ImageSolver and all star-dependent processes.";

    this.optionsGroupBox.sizer.addSpacing(3);

    this.starlessImageLabel = new Label(this.optionsGroupBox);
    this.starlessImageLabel.text = "Starless Image:";
    this.starlessImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.starlessImageLabel);

    this.starlessMethodComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.starlessMethodComboBox, [
       "No create 'Final_starless'",
       "Create 'Final_starless' by StarXTerminator",
       "Create 'Final_starless' by StarXNet2"
    ]);

    this.optionsGroupBox.sizer.addSpacing(3);
    this.finalStarsImageLabel = new Label(this.optionsGroupBox);
    this.finalStarsImageLabel.text = "Final stars Image:";
    this.finalStarsImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.finalStarsImageLabel);

    this.finalStarsComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.finalStarsComboBox, [
       "<Create 'Final_stars' image (Project stars)>",
       "Create 'Final_stars' image (Project stars)",
       "Create RGB 'Final_stars' (SHO/HOO)"
    ]);
    this.finalStarsComboBox.enabled = false;

    function resetFinalStarsSelection() {
       self.finalStarsComboBox.currentItem = 0;
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.finalStarRefinementCheckBox.checked = false;
       self.finalStarRefinementCheckBox.enabled = false;
       OptionFinalStarRefinement = "OFF";
       FinalStarRefinementReady = false;
       MiraComboProyect();
    }

    function enableFinalStarRefinement() {
       self.finalStarRefinementCheckBox.enabled = true;
       self.finalStarRefinementCheckBox.checked = true;
       OptionFinalStarRefinement = "ON";
       FinalStarRefinementReady = false;
    }

    let objectModeSavedImageSolverChecked =
       this.ImageSolverCheckBox.checked;

    function applyObjectTypeMode(itemIndex, announce) {
       let moonSunMode = itemIndex === 1;
       OptionObjectType = moonSunMode ? "MOON_SUN" : "STARS";

       if (moonSunMode) {
          objectModeSavedImageSolverChecked =
             self.ImageSolverCheckBox.checked;

          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;

          self.gradientCorrectionComboBox.currentItem = 0;
          self.gradientCorrectionComboBox.enabled = false;
          OptionGradient = "ON";
          OptionMgc = "OFF";

          self.starlessMethodComboBox.currentItem = 0;
          self.starlessMethodComboBox.enabled = false;
          self.starlessImageLabel.enabled = false;
          self.finalStarsImageLabel.enabled = false;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          OptionVarStars = "OFF";
          OptionStarXterminator = "OFF";
          OptionFinalStarRefinement = "OFF";
          OptionHavar = "OFF";
          OptionColorCalibration = "OFF";

          if (self.HalphaCheckBox) {
             self.HalphaCheckBox.checked = false;
             self.HalphaCheckBox.enabled = false;
          }
          self.colorCalibrationCheckBox.checked = false;
          self.colorCalibrationCheckBox.enabled = false;

          if (announce !== false)
             console.noteln(
                "🌙 Moon or Sun mode: ImageSolver, MGC and star-dependent " +
                "processes are disabled.");
       }
       else {
          self.starlessMethodComboBox.enabled = true;
          self.starlessImageLabel.enabled = true;
          self.finalStarsImageLabel.enabled = true;
          self.finalStarsComboBox.enabled = false;
          self.gradientCorrectionComboBox.enabled = true;

          let smartTelescopeMode =
             self.projectTypeComboBox.currentItem >= 5;
          self.ImageSolverCheckBox.checked = smartTelescopeMode ?
             true : objectModeSavedImageSolverChecked;
          self.ImageSolverCheckBox.enabled = !smartTelescopeMode;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = smartTelescopeMode;

          let selectedProject = [
             "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
             "OSC", "OSC", "OSC"
          ][self.projectTypeComboBox.currentItem];
          let rgbProject = selectedProject === "RGB" ||
             selectedProject === "LRGB";
          self.HalphaCheckBox.enabled = rgbProject;

          if (announce !== false)
             console.noteln(
                "⭐ Stars mode: normal astrometry and star processing enabled.");
       }

       self.ImageSolverCheckBox.update();
       self.gradientCorrectionComboBox.update();
       self.starlessMethodComboBox.update();
       self.finalStarsComboBox.update();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.objectTypeComboBox.onItemSelected = function (itemIndex) {
       applyObjectTypeMode(itemIndex, true);
    };

    this.starlessMethodComboBox.onItemSelected = function (itemIndex) {
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionVarStars = "OFF";
       OptionStarXterminator = "OFF";

       if (itemIndex === 1 && !starXterminatorInstalled) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarXTerminator");
          return;
       }

       if (itemIndex === 2 && !starNet2Installed) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarNet2");
          return;
       }

       if (itemIndex === 0) {
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          console.noteln("⚙️ Final_starless creation: OFF");
          return;
       }

       OptionVarStars = "ON";
       OptionStarXterminator = itemIndex === 1 ? "ON" : "OFF";
       self.finalStarsComboBox.enabled = true;


       self.finalStarsComboBox.currentItem = 1;
       OptionHSOvar = "ON";
       Option1var = "OFF";
       enableFinalStarRefinement();
       MiraComboProyect();
       console.noteln("⚙️ Final_starless method: " +
          (itemIndex === 1 ? "StarXTerminator" : "StarNet2"));
       console.noteln("⚙️ Final_stars: Project stars (default)");
    };

    let finalStarsSelectionResetInProgress = false;
    this.finalStarsComboBox.onItemSelected = function (itemIndex) {
       if (finalStarsSelectionResetInProgress)
          return;
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionHSOvar = "OFF";
       Option1var = "OFF";

       if (itemIndex === 0) {
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
          console.noteln("⚙️ Final_stars creation: OFF");
          return;
       }

       if (OptionVarStars !== "ON") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ Select a Final_starless method first.");
          return;
       }

       if (itemIndex === 1) {
          OptionHSOvar = "ON";
          enableFinalStarRefinement();
          MiraComboProyect();
          console.noteln("⚙️ Final_stars: Project stars");
          return;
       }

       if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
          finalStarsSelectionResetInProgress = true;
          try {
             this.currentItem = 0;
             self.finalStarRefinementCheckBox.checked = false;
             self.finalStarRefinementCheckBox.enabled = false;
             OptionFinalStarRefinement = "OFF";
             FinalStarRefinementReady = false;
             console.warningln(
                "⚠️ RGB Final_stars is only available for SHO and HOO projects.");
             new MessageBox(
                "RGB Final_stars is only available for SHO and HOO " +
                "projects. The current " + ProjecTypevar +
                " project is not compatible with this stellar-layer " +
                "mode. Select Project stars instead, or change the " +
                "project type to SHO or HOO.",
                "InNova Astro Processor — RGB stars unavailable",
                StdIcon_Warning,
                StdButton_Ok
             ).execute();
          }
          finally {
             finalStarsSelectionResetInProgress = false;
          }
          return;
       }

       let msgBox = new MessageBox(
          "Enable RGB Images for stars?",
          "Confirmation",
          StdIcon_Question,
          StdButton_Yes,
          StdButton_No
       );

       if (msgBox.execute() === StdButton_Yes) {
          self.comboBoxReferences["PimageRed"].enabled = true;
          self.comboBoxReferences["PimageGreen"].enabled = true;
          self.comboBoxReferences["PimageBlue"].enabled = true;
          Option1var = "ON";
          ProjecTypevar2 = "1";
          enableFinalStarRefinement();
          console.noteln("⚙️ Final_stars: RGB stars");
       }
       else {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
       }
    };


    this.finalOptionsGroupBox = new GroupBox(this.integrationPage);
    this.finalOptionsGroupBox.title = "5. Options:";
    this.finalOptionsGroupBox.sizer = new VerticalSizer;
    this.finalOptionsGroupBox.sizer.margin = 6;
    this.finalOptionsGroupBox.sizer.spacing = 6;

    this.finalOptionsGroupBox.sizer.addSpacing(10);
    let linkRgbOptionRow = new HorizontalSizer;
    linkRgbOptionRow.margin = 0;
    linkRgbOptionRow.spacing = 0;
    linkRgbOptionRow.add(this.linkRGBChannels);
    this.finalOptionsGroupBox.sizer.add(linkRgbOptionRow);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.FastCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.HalphaCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer,
       this.colorCalibrationCheckBox);
    updateColorCalibrationAvailability(false);


    this.optionsGroupBox.adjustToContents();
    this.finalOptionsGroupBox.adjustToContents();
    let commonOptionsGroupHeight = Math.max(
       this.optionsGroupBox.height,
       this.finalOptionsGroupBox.height);
    this.optionsGroupBox.setFixedHeight(commonOptionsGroupHeight);
    this.finalOptionsGroupBox.setFixedHeight(commonOptionsGroupHeight);

    this.optionsGroupsSizer = new HorizontalSizer;
    this.optionsGroupsSizer.spacing = 10;
    this.optionsGroupsSizer.add(this.optionsGroupBox);
    this.optionsGroupsSizer.add(this.finalOptionsGroupBox);


    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)] = new Control(this);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer = new VerticalSizer;
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.margin = 10;
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.spacing = 6;

      let _0x7897b534dd = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      _0x7897b534dd.title = String.fromCharCode(76,105,99,101,110,115,101,32,73,110,102,111,114,109,97,116,105,111,110);
      _0x7897b534dd.sizer = new VerticalSizer;
      _0x7897b534dd.sizer.margin = 6;
      _0x7897b534dd.sizer.spacing = 4;

      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      emailLabel.setFixedWidth(105);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";
      this.emailEdit.enabled = false;

      let emailSizer = new HorizontalSizer;
      emailSizer.spacing = 8;
      emailSizer.add(emailLabel);
      emailSizer.add(this.emailEdit, 1);
      _0x7897b534dd.sizer.add(emailSizer);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      codeLabel.setFixedWidth(105);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";
      this.codeEdit.enabled = false;

      let codeSizer = new HorizontalSizer;
      codeSizer.spacing = 8;
      codeSizer.add(codeLabel);
      codeSizer.add(this.codeEdit, 1);
      _0x7897b534dd.sizer.add(codeSizer);

      let _0x30b56038e7 = new Label(this);
      _0x30b56038e7.text = String.fromCharCode(69,120,112,105,114,121,58);
      _0x30b56038e7.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      _0x30b56038e7.setFixedWidth(105);

      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)] = new Edit(this);
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].minWidth = 300;
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = "";
      this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].enabled = false;

      let _0xe622fc5170 = new HorizontalSizer;
      _0xe622fc5170.spacing = 8;
      _0xe622fc5170.add(_0x30b56038e7);
      _0xe622fc5170.add(this[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)], 1);
      _0x7897b534dd.sizer.add(_0xe622fc5170);

      let _0x3cc06eb8ff = new Label(this);
      _0x3cc06eb8ff.text = String.fromCharCode(77,97,99,104,105,110,101,32,73,68,58);
      _0x3cc06eb8ff.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      _0x3cc06eb8ff.setFixedWidth(105);

      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)] = new Edit(this);
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].minWidth = 300;
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0x2223f2e758();
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].enabled = true;
      this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].readOnly = true;

      let _0xa07d1d1ed2 = new HorizontalSizer;
      _0xa07d1d1ed2.spacing = 8;
      _0xa07d1d1ed2.add(_0x3cc06eb8ff);
      _0xa07d1d1ed2.add(this[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)], 1);
      _0x7897b534dd.sizer.add(_0xa07d1d1ed2);

      let signatureLabel = new Label(this);
      signatureLabel.text = "Signature:";
      signatureLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      signatureLabel.setFixedWidth(105);

      this.signatureEdit = new Edit(this);
      this.signatureEdit.minWidth = 300;
      this.signatureEdit.text = "";
      this.signatureEdit.enabled = false;
      this.signatureEdit.toolTip = String.fromCharCode(80,97,115,116,101,32,116,104,101,32,99,111,109,112,108,101,116,101,32,108,105,99,101,110,115,101,32,115,105,103,110,97,116,117,114,101,46);

      let signatureSizer = new HorizontalSizer;
      signatureSizer.spacing = 8;
      signatureSizer.add(signatureLabel);
      signatureSizer.add(this.signatureEdit, 1);
      _0x7897b534dd.sizer.add(signatureSizer);

      let profileNoteControl = new Control(_0x7897b534dd);
      profileNoteControl.visible = false;
      let NotaLabel = new Label(profileNoteControl);
      NotaLabel.text = String.fromCharCode(42,32,67,108,105,99,107,32,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,32,116,111,32,99,97,110,99,101,108,32,111,114,32,99,104,97,110,103,101,32,121,111,117,114,32,99,117,114,114,101,110,116,32,115,117,98,115,99,114,105,112,116,105,111,110,46);
      NotaLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      NotaLabel.adjustToContents();
      let profileNoteSizer = new HorizontalSizer;
      profileNoteSizer.spacing = 0;
      profileNoteSizer.add(NotaLabel);
      profileNoteSizer.addStretch();
      let profileNoteLayout = new VerticalSizer;
      profileNoteLayout.margin = 0;
      profileNoteLayout.spacing = 0;
      profileNoteLayout.addSpacing(12);
      profileNoteLayout.add(profileNoteSizer);
      profileNoteLayout.addSpacing(4);
      profileNoteControl.sizer = profileNoteLayout;
      profileNoteControl.setFixedHeight(16 + NotaLabel.height);


      let firstPurchaseControlsRequested = false;
      let purchaseStepButtonStates = null;
      let accountLinkControl = new Control(_0x7897b534dd);
      accountLinkControl.visible = false;
      let linkLabel = new Label(accountLinkControl);
      linkLabel.text = "Linking code:";
      linkLabel.setFixedWidth(105);
      this.accountLinkEdit = new Edit(accountLinkControl);
      this.accountLinkEdit.readOnly = true;
      this.accountLinkEdit.text = SoftwareLinkCode();
      this.accountLinkEdit.toolTip = "Copy this code to the InNova website while signed in as the purchaser. Valid for 30 minutes.";
      let accountLinkSizer = new HorizontalSizer;
      accountLinkSizer.spacing = 8;
      accountLinkSizer.add(linkLabel);
      accountLinkSizer.add(this.accountLinkEdit, 1);
      let activatePurchaseButton = new PushButton(accountLinkControl);
      activatePurchaseButton.text = "Activate Purchase";
      activatePurchaseButton.icon = this.scaledResource(":/icons/ok.png");
      activatePurchaseButton.toolTip = String.fromCharCode(65,102,116,101,114,32,112,97,121,109,101,110,116,44,32,99,104,101,99,107,32,87,105,120,32,99,111,110,102,105,114,109,97,116,105,111,110,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,78,111,32,112,114,111,102,105,108,101,32,115,105,103,110,97,116,117,114,101,32,111,114,32,97,100,100,105,116,105,111,110,97,108,32,112,97,121,109,101,110,116,32,105,115,32,110,101,101,100,101,100,32,102,111,114,32,97,32,110,101,119,32,112,117,114,99,104,97,115,101,46);
      activatePurchaseButton.onClick = function () { _0xc95bb935aa(); };
      accountLinkSizer.add(activatePurchaseButton);


      linkLabel.adjustToContents();
      this.accountLinkEdit.adjustToContents();
      activatePurchaseButton.adjustToContents();
      let accountLinkLayout = new VerticalSizer;
      accountLinkLayout.margin = 0;
      accountLinkLayout.spacing = 0;
      accountLinkLayout.addSpacing(8);
      accountLinkLayout.add(accountLinkSizer);
      accountLinkControl.sizer = accountLinkLayout;
      accountLinkControl.setFixedHeight(8 + Math.max(linkLabel.height,
         this.accountLinkEdit.height, activatePurchaseButton.height));


      var self = this;

      let filePath = _0x3560669f98();

      if (File.exists(filePath))
      {
        let _0x005b54a9d2 = _0x7799a174a1();

            if (_0x1d80a60689(_0x005b54a9d2))
            {
               self.emailEdit.text = _0x005b54a9d2.email;
               self.codeEdit.text = _0x005b54a9d2.code;
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = _0x005b54a9d2[String.fromCharCode(101,120,112,105,114,121)];
               self.signatureEdit.text = _0x005b54a9d2[String.fromCharCode(115,105,103,110,97,116,117,114,101)];
            }
            else
            {
               console.warningln(String.fromCharCode(82,117,110,110,105,110,103,32,105,110,32,116,114,105,97,108,32,109,111,100,101,46));

               self.emailEdit.text = "";
               self.codeEdit.text = "";
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = "";
            }
      }
      else
      {
         self.emailEdit.text = "";
         self.codeEdit.text = "";
      }


      _0x7897b534dd.sizer.addSpacing(6);


      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;
      buttonSizer.addStretch();


      function CopyTextToSystemClipboard(text)
      {
         let platform = String(CoreApplication.platform).toLowerCase();
         let commands = [];

         if (platform.indexOf("mac") >= 0)
            commands.push(["/usr/bin/pbcopy", []]);
         else if (platform.indexOf("win") >= 0)
            commands.push(["cmd.exe", ["/c", "clip"]]);
         else
         {
            commands.push(["xclip", ["-selection", "clipboard"]]);
            commands.push(["xsel", ["--clipboard", "--input"]]);
         }

         for (let i = 0; i < commands.length; ++i)
         {
            try
            {
               let process = new ExternalProcess;
               process.start(commands[i][0], commands[i][1]);
               if (!process.waitForStarted(3000))
                  continue;

               process.standardInput = text;
               if (!process.waitForDataWritten(3000))
               {
                  process.closeStandardInput();
                  continue;
               }
               process.closeStandardInput();

               if (process.waitForFinished(3000) && process.exitCode === 0)
                  return true;
            }
            catch (error)
            {

            }
         }

         return false;
      }

      function _0x70e6e0d26d(url, browserTitle)
      {

         if (!RequireInNovaServerConnection()) return null;
         let platform = String(CoreApplication.platform).toLowerCase();
         let command;

         if (platform.indexOf("mac") >= 0)
            command = ["/usr/bin/open", [url]];
         else if (platform.indexOf("win") >= 0)
            command = ["cmd.exe", ["/c", "start", "", url]];
         else
            command = ["xdg-open", [url]];

         try
         {
            let process = new ExternalProcess;
            process.start(command[0], command[1]);
            if (process.waitForStarted(3000))
               return true;
         }
         catch (error)
         {

         }

         try
         {
            Dialog.openBrowser(url, browserTitle || String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110));
            return true;
         }
         catch (error)
         {
            return false;
         }
      }

      function _0x091c858271()
      {
         let mailUrl = "mailto:soporte@teoriadelcolor.net" +
            String.fromCharCode(63,115,117,98,106,101,99,116,61,73,110,78,111,118,97,37,50,48,65,115,116,114,111,37,50,48,45,37,50,48,76,105,99,101,110,115,101,37,50,48,80,114,111,98,108,101,109);
         let platform = String(CoreApplication.platform).toLowerCase();
         let command;

         if (platform.indexOf("mac") >= 0)
            command = ["/usr/bin/open", [mailUrl]];
         else if (platform.indexOf("win") >= 0)
            command = ["cmd.exe", ["/c", "start", "", mailUrl]];
         else
            command = ["xdg-open", [mailUrl]];

         try
         {
            let process = new ExternalProcess;
            process.start(command[0], command[1]);
            if (process.waitForStarted(3000))
               return true;
         }
         catch (error)
         {

         }

         try
         {
            Dialog.openBrowser(mailUrl, String.fromCharCode(73,110,78,111,118,97,32,76,105,99,101,110,115,101,32,83,117,112,112,111,114,116));
            return true;
         }
         catch (error)
         {
            return false;
         }
      }

      function SetPurchaseStepPending(pending)
      {
         if (pending)
         {
            if (purchaseStepButtonStates === null)
               purchaseStepButtonStates = [_0x99f786dc4a.enabled,
                  _0x2bd6194bd2.enabled, _0x8fdb2c1ca3.enabled,
                  premiumSiteButton.enabled];
            _0x99f786dc4a.enabled = false;
            _0x2bd6194bd2.enabled = false;
            _0x8fdb2c1ca3.enabled = false;
            premiumSiteButton.enabled = false;
         }
         else if (purchaseStepButtonStates !== null)
         {
            _0x99f786dc4a.enabled = purchaseStepButtonStates[0];
            _0x2bd6194bd2.enabled = purchaseStepButtonStates[1];
            _0x8fdb2c1ca3.enabled = purchaseStepButtonStates[2];
            premiumSiteButton.enabled = purchaseStepButtonStates[3];
            purchaseStepButtonStates = null;
         }
      }

      function _0xc95bb935aa()
      {


         SetPurchaseStepPending(false);
         firstPurchaseControlsRequested = true;
         try {
            let _0xefc94a90f2 = _0xd1bab61334(self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);
            let result = RequestInNovaFirstActivation(_0xefc94a90f2, true);
            self.accountLinkEdit.text = SoftwareLinkCode();
            if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
                !(_0x2dfa1a45fa && _0x2dfa1a45fa.pending && _0x2dfa1a45fa.pending.autoPurchase)) {
               _0xe8c10b0eaf("InNova Astro Processor",
                  "After completing your purchase, authorize this computer.",
                  { firstPurchase: true });
               result = RequestInNovaFirstActivation(_0xefc94a90f2, false);
            }
            if (result === "ACTIVATED") {
               let saved = _0x7799a174a1();
               self.emailEdit.text = saved.email;
               self.codeEdit.text = saved.code;
               self[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = saved[String.fromCharCode(101,120,112,105,114,121)];
               self.signatureEdit.text = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)];
               self.accountLinkEdit.text = SoftwareLinkCode();
               _0x8a60858f5f = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
               _0xc7fa59117d = _0x881275c82f(saved[String.fromCharCode(101,120,112,105,114,121)]) ? "FULL_GRACE" : "FULL";
               _0x4137afe4c6();
               self.runButton.enabled = CanProcess();
               if (_0xc7fa59117d === "FULL_GRACE") _0xe94ca2a3e7("InNova Astro Processor", saved, true);
               else new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,112,117,114,99,104,97,115,101,100,32,108,105,99,101,110,115,101,32,105,115,32,110,111,119,32,97,99,116,105,118,97,116,101,100,46,60,47,112,62),
                  "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
            } else if (result === "PAYMENT_PENDING") {
               new MessageBox("<p align=\"center\" style=\"color:#168bc1;font-size:32pt\">ⓘ</p>" +
                  "<p align=\"center\">The platform has not yet confirmed your payment.</p>" +
                  "<p align=\"center\">If you have completed payment, click <b>Activate Purchase</b><br/>in a few seconds.</p>" +
                  "<p align=\"center\"><b>Do not pay again.</b></p>",
                  "InNova Astro Processor", 0, StdButton_Ok).execute();
            } else if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
                       _0x2dfa1a45fa && _0x2dfa1a45fa.pending && _0x2dfa1a45fa.pending.autoPurchase) {
               throw new Error(String.fromCharCode(84,104,105,115,32,112,117,114,99,104,97,115,101,32,114,101,113,117,105,114,101,115,32,97,99,99,111,117,110,116,32,114,101,99,111,118,101,114,121,32,111,114,32,114,101,110,101,119,97,108,32,97,117,116,104,111,114,105,122,97,116,105,111,110,46,32,67,111,110,116,97,99,116,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,59,32,100,111,32,110,111,116,32,112,97,121,32,97,103,97,105,110,46));
            } else if (result !== String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68)) {
               throw new Error("Activation status: " + result);
            }
         } catch (error) {
            if (error.innovaServerUnavailable) return;
            new MessageBox("Purchase activation could not be completed.\n\n" +
               "Check your connection and retry. Contact InNova support if the problem persists.\n" +
               "Do not purchase again.\n\n" + String(error.message || error),
               "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
         } finally {
            UpdatePurchaseActivationControls();
         }
      }

      let _0x99f786dc4a = new PushButton(this);
      _0x99f786dc4a.text = String.fromCharCode(77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110);
      _0x99f786dc4a.icon =
         this.scaledResource( ":/icons/clipboard-internet.png" );
      _0x99f786dc4a.setFixedWidth(190);
      _0x99f786dc4a.setFixedHeight(WindowsOsx1 + 5);
      _0x99f786dc4a.toolTip =
         String.fromCharCode(80,117,114,99,104,97,115,101,32,121,111,117,114,32,102,105,114,115,116,32,115,117,98,115,99,114,105,112,116,105,111,110,32,111,114,32,111,112,101,110,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,32,116,111,32,109,97,110,97,103,101,32,97,110,32,101,120,105,115,116,105,110,103,32,115,117,98,115,99,114,105,112,116,105,111,110,46);
      buttonSizer.add(_0x99f786dc4a);

      _0x99f786dc4a.onClick = function ()
      {


         let _0x82c0abbf44 = _0x7799a174a1();
         if (_0x842d83d5c4() && _0x1d80a60689(_0x82c0abbf44) &&
             _0x54354d7f32(_0x82c0abbf44) && !_0x881275c82f(_0x82c0abbf44[String.fromCharCode(101,120,112,105,114,121)]))
         {
            let accountUrl = String.fromCharCode(104,116,116,112,115,58,47,47,119,119,119,46,116,101,111,114,105,97,100,101,108,99,111,108,111,114,46,101,115,47,97,99,99,111,117,110,116,47,109,121,45,115,117,98,115,99,114,105,112,116,105,111,110,115);
            if (_0x70e6e0d26d(accountUrl, "InNova profile") === false)
               new MessageBox("Your InNova profile could not be opened.\n\n" + accountUrl,
                  "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
            return;
         }
         let _0xefc94a90f2 = _0xd1bab61334(self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);

         if (_0xefc94a90f2 === "")
         {
            new MessageBox(
               String.fromCharCode(65,32,118,97,108,105,100,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,114,101,113,117,105,114,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,105,110,103,32,97,32,115,117,98,115,99,114,105,112,116,105,111,110,46),
               "InNova Astro Processor",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }

         let planDialog = new _0x5917ae487e;
         if (!planDialog.execute())
            return;

         if (planDialog.recoverExisting || planDialog.supportRecovery)
         {
            try
            {
               let recovery = RequestInNovaFirstActivation(_0xefc94a90f2, true);
               self.accountLinkEdit.text = SoftwareLinkCode();
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               if (recovery === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68))
                  _0xe8c10b0eaf("InNova Astro Processor",
                     planDialog.supportRecovery ?
                        "Recover this computer with the one-time code supplied by InNova Support." :
                        "Authorize this computer with the account used for your purchase.",
                     planDialog.supportRecovery ? { supportRecovery: true } : { [String.fromCharCode(108,105,99,101,110,115,101,84,114,97,110,115,102,101,114)]: true });
               else
                  throw new Error("Recovery status: " + recovery);
            }
            catch (error)
            {
               if (error.innovaServerUnavailable) return;
               new MessageBox(String.fromCharCode(84,104,101,32,108,105,99,101,110,115,101,32,114,101,99,111,118,101,114,121,32,114,101,113,117,101,115,116,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,114,101,97,116,101,100,46,10,10) +
                  String(error.message || error), "InNova Astro Processor",
                  StdIcon_Warning, StdButton_Ok).execute();
            }
            return;
         }

         if (planDialog.selectedUrl === "")
            return;

         try
         {
            _0xefc94a90f2 = _0xc2106fa104(_0xefc94a90f2);
            self[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0xefc94a90f2;
            PrepareInNovaFirstPurchase(_0xefc94a90f2);
         }
         catch (error)
         {
            if (error.innovaServerUnavailable) return;
            let purchaseError = String(error.message || error);
            if (purchaseError === "PURCHASE_ACTIVATION_REQUIRED")
            {
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               new MessageBox(
                  String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,105,115,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,97,108,114,101,97,100,121,32,97,115,115,111,99,105,97,116,101,100,32,119,105,116,104,32,97,32,112,117,114,99,104,97,115,101,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(60,98,62,89,111,117,114,32,77,97,99,104,105,110,101,32,73,68,32,104,97,115,32,98,101,101,110,32,107,101,112,116,32,117,110,99,104,97,110,103,101,100,46,60,47,98,62,60,98,114,47,62,60,98,114,47,62) +
                  "If you have already paid, click <b>Activate Purchase</b> and sign in<br/>" +
                  "with the account used for your purchase. Do not purchase again.<br/><br/>" +
                  "If this is not your purchase, contact InNova support.</p>",
                  "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
               return;
            }
            if (purchaseError.indexOf(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)) === 0)
            {
               firstPurchaseControlsRequested = true;
               UpdatePurchaseActivationControls();
               let _0x259c8adf94 = purchaseError.substring(
                  String(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)).length);
               let _0x7adf128734 = _0x259c8adf94 !== "" ?
                  String.fromCharCode(10,10,69,120,112,105,114,121,32,40,121,121,121,121,47,109,109,47,100,100,41,58,32) + [String.fromCharCode(97,99,116,105,118,101,69,120,112,105,114,121)] : "";
               new MessageBox(
                  String.fromCharCode(89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,115,32,97,108,114,101,97,100,121,32,97,99,116,105,118,101,46) + _0x7adf128734 +
                  String.fromCharCode(10,10,85,115,101,32,65,99,116,105,118,97,116,101,32,80,117,114,99,104,97,115,101,32,116,111,32,97,117,116,104,111,114,105,122,101,32,116,104,105,115,32,99,111,109,112,117,116,101,114,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,68,111,32,110,111,116,32,112,117,114,99,104,97,115,101,32,97,103,97,105,110,46),
                  "InNova Astro Processor",
                  StdIcon_Information,
                  StdButton_Ok
               ).execute();
               return;
            }
            new MessageBox(
               String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,101,46,10,10) +
               purchaseError + "\n\n" +
               "Check your Internet connection and try again.",
               "InNova Astro Processor",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }


         if (!CopyTextToSystemClipboard(_0xefc94a90f2))
         {
            new MessageBox(
               String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,111,112,105,101,100,46,10,10) +
               "Select it manually and press Cmd+C or Ctrl+C.",
               "InNova Astro Processor",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
            return;
         }

         SetPurchaseStepPending(true);
         let pageOpened = false;
         try {
         new MessageBox(
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46,60,47,112,62) +
            "<p align=\"center\">" +
            String.fromCharCode(84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,99,104,101,99,107,111,117,116,32,112,97,103,101,32,119,105,108,108,32,110,111,119,32,111,112,101,110,46,60,47,112,62) +
            "<p align=\"center\"><b>" +
            String.fromCharCode(80,97,115,116,101,32,116,104,101,32,77,97,99,104,105,110,101,32,73,68,32,105,110,116,111,32,116,104,101,32,112,117,114,99,104,97,115,101,32,102,111,114,109,32,119,105,116,104,32,67,109,100,43,86,32,111,114,32,67,116,114,108,43,86,46) +
            "</b></p>",
            "InNova Astro Processor",
            StdIcon_Information,
            StdButton_Ok
         ).execute();

         console.noteln(String.fromCharCode(9989,32,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46));

         let _0xb015e2da58 = planDialog.selectedUrl;
         pageOpened = _0x70e6e0d26d(_0xb015e2da58);
         if (pageOpened === false)
         {
            new MessageBox(
               String.fromCharCode(84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,112,97,103,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,111,112,101,110,101,100,46,10,10) +
               _0xb015e2da58,
               "InNova Astro Processor",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
         }
         else if (pageOpened === true) {


            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();


            ShowInNovaPurchaseReminderDialog();
         }
         } finally {


            if (pageOpened !== true) SetPurchaseStepPending(false);
         }
      };
      this[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)] = _0x99f786dc4a.onClick;

      let _0x2bd6194bd2 = new PushButton(this);
      _0x2bd6194bd2.text = String.fromCharCode(67,104,101,99,107,32,76,105,99,101,110,115,101,32,83,116,97,116,117,115);
      _0x2bd6194bd2.icon = this.scaledResource( ":/icons/ok.png" );
      _0x2bd6194bd2.setFixedWidth(190);
      _0x2bd6194bd2.setFixedHeight(WindowsOsx1 + 5);
      _0x2bd6194bd2.toolTip = String.fromCharCode(82,101,97,100,32,116,104,101,32,115,116,97,116,117,115,32,102,114,111,109,32,87,105,120,46,32,68,111,101,115,32,110,111,116,32,114,101,110,101,119,32,111,114,32,97,99,116,105,118,97,116,101,32,116,104,101,32,108,105,99,101,110,115,101,46);
      buttonSizer.add(_0x2bd6194bd2);
      _0x2bd6194bd2.onClick = function ()
      {
         try {
            let _0x34ce1117e3 = _0x7799a174a1();
            if (!_0x1d80a60689(_0x34ce1117e3) || !_0x54354d7f32(_0x34ce1117e3)) {
               if (!_0x1d80a60689(_0x34ce1117e3) && _0xc7fa59117d === "PROJECT" && IsProjectDateValid()) {
                  _0x9e2a39d587(_0xed0ef1cb02());
                  return;
               }
               console.writeln(String.fromCharCode(78,111,32,118,97,108,105,100,32,115,97,118,101,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,97,118,97,105,108,97,98,108,101,46,32,89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46));
               new MessageBox(
                  String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,78,111,32,118,97,108,105,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,115,97,118,101,100,32,111,110,32,116,104,105,115,32,99,111,109,112,117,116,101,114,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46,60,98,114,47,62,60,98,114,47,62) +
                  String.fromCharCode(84,104,105,115,32,99,104,101,99,107,32,100,111,101,115,32,110,111,116,32,112,117,114,99,104,97,115,101,32,111,114,32,97,99,116,105,118,97,116,101,32,97,32,108,105,99,101,110,115,101,46,60,47,112,62),
                  "InNova Astro Processor", 0, StdButton_Ok
               ).execute();
               return;
            }
            let statusText = _0x402020882f();
            console.writeln(statusText);
            let centeredStatus = "<p align=\"center\">" + statusText
               .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
               .replace(new RegExp(String.fromCharCode(94,40,83,117,98,115,99,114,105,112,116,105,111,110,32,115,116,97,116,117,115,32,92,40,87,105,120,92,41,58,32,41,40,65,67,84,73,86,69,124,71,82,65,67,69,124,69,88,80,73,82,69,68,124,82,69,86,79,75,69,68,41,36), "m"), "$1<b>$2</b>")
               .replace(new RegExp(String.fromCharCode(94,40,69,120,112,105,114,121,32,92,40,121,121,121,121,92,47,109,109,92,47,100,100,92,41,58,32,41,40,92,100,123,52,125,45,92,100,123,50,125,45,92,100,123,50,125,41,36), "m"), "$1<b>$2</b>")
               .replace(/^(✅ Installation authorized for this period: )(YES)$/m, "$1<b>$2</b>")
               .replace(/^(Installation authorized for this period: )(NO)$/m, "$1<b>$2</b>")
               .replace(new RegExp(String.fromCharCode(94,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,92,46,36), "m"),
                  String.fromCharCode(60,98,62,60,115,112,97,110,32,115,116,121,108,101,61,34,99,111,108,111,114,58,35,100,48,48,48,48,48,34,62,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,46,60,47,115,112,97,110,62,60,47,98,62))
               .replace(/^(You can continue using InNova for \d+ more day\(s\), until )(\d{4}-\d{2}-\d{2})(\.)$/m,
                  "$1<b>$2</b>$3")
               .replace(/\n/g, "<br/>") + "</p>";


            new MessageBox(centeredStatus, "InNova Astro Processor", 0, StdButton_Ok).execute();
         } catch (error) {
            if (error.innovaServerUnavailable) return;
            new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,76,105,99,101,110,115,101,32,115,116,97,116,117,115,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,104,101,99,107,101,100,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(67,104,101,99,107,32,121,111,117,114,32,73,110,116,101,114,110,101,116,32,99,111,110,110,101,99,116,105,111,110,32,111,114,32,99,111,110,116,97,99,116,32,115,117,112,112,111,114,116,46,32,89,111,117,114,32,108,105,99,101,110,115,101,32,104,97,115,32,110,111,116,32,98,101,101,110,32,99,104,97,110,103,101,100,46,60,47,112,62),
               "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
         }
      };

      let _0x8fdb2c1ca3 = new PushButton(this);
      _0x8fdb2c1ca3.text = String.fromCharCode(76,105,99,101,110,115,101,32,112,114,111,98,108,101,109,115,63);
      _0x8fdb2c1ca3.icon = this.scaledResource( ":/icons/info.png" );
      _0x8fdb2c1ca3.setFixedWidth(190);
      _0x8fdb2c1ca3.setFixedHeight(WindowsOsx1 + 5);
      _0x8fdb2c1ca3.toolTip =
         String.fromCharCode(69,109,97,105,108,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,32,97,98,111,117,116,32,97,32,108,105,99,101,110,115,101,32,112,114,111,98,108,101,109,46);
      buttonSizer.add(_0x8fdb2c1ca3);

      let premiumSiteButton = new PushButton(this);
      premiumSiteButton.text = "Premium site";
      premiumSiteButton.icon = this.scaledResource( ":/icons/internet.png" );
      premiumSiteButton.setFixedWidth(190);
      premiumSiteButton.setFixedHeight(WindowsOsx1 + 5);
      premiumSiteButton.toolTip =
         "Open the InNova Premium site. Available with an active paid plan.";
      premiumSiteButton.enabled = false;
      buttonSizer.add(premiumSiteButton);
      buttonSizer.addStretch();

      _0x8fdb2c1ca3.onClick = function ()
      {
         if (!_0x091c858271())
            new MessageBox(
               "Your email application could not be opened.\n\n" +
               "Email: soporte@teoriadelcolor.net\n" +
               String.fromCharCode(83,117,98,106,101,99,116,58,32,73,110,78,111,118,97,32,65,115,116,114,111,32,45,32,76,105,99,101,110,115,101,32,80,114,111,98,108,101,109),
               "InNova Astro Processor",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      };

      premiumSiteButton.onClick = function ()
      {
         let premiumUrl = "https://www.teoriadelcolor.es/innova-premium";
         if (_0x70e6e0d26d(premiumUrl, "InNova Premium") === false)
            new MessageBox(
               "The InNova Premium site could not be opened.\n\n" + premiumUrl,
               "InNova Astro Processor",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      };

      _0x7897b534dd.sizer.add(buttonSizer);
      _0x7897b534dd.sizer.add(accountLinkControl);
      _0x7897b534dd.sizer.add(profileNoteControl);
      _0x7897b534dd.sizer.addSpacing(14);
      _0x7897b534dd.adjustToContents();


      let _0x32f5008ff2 = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      _0x32f5008ff2.title = String.fromCharCode(76,105,99,101,110,115,101,32,65,99,116,105,118,97,116,105,111,110);
      _0x32f5008ff2.sizer = new VerticalSizer;
      _0x32f5008ff2.sizer.margin = 6;
         _0x32f5008ff2.sizer.spacing = 4;


      let activationInfoLabel = new Label(this);
      activationInfoLabel.useRichText = true;

      function UpdatePurchaseActivationControls()
      {
         let paid = _0x842d83d5c4();
         let code = SoftwareLinkCode();
         let hasCode = /^[A-F0-9]{4}(?:-[A-F0-9]{4}){5}$/.test(code);
         let showCode = hasCode && (paid || firstPurchaseControlsRequested);
         let showActivate = !paid && firstPurchaseControlsRequested;
         let layoutChanged = accountLinkControl.visible !== (showCode || showActivate) ||
            linkLabel.visible !== showCode || activatePurchaseButton.visible !== showActivate ||
            profileNoteControl.visible !== paid;
         self.accountLinkEdit.text = hasCode ? code : "";
         linkLabel.visible = showCode;
         self.accountLinkEdit.visible = showCode;
         activatePurchaseButton.visible = showActivate;
         accountLinkControl.visible = showCode || showActivate;
         profileNoteControl.visible = paid;


         if (layoutChanged && self.sizer)
         {
            _0x7897b534dd.adjustToContents();
            self[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].adjustToContents();
            self.tabBox.adjustToContents();
            self.adjustToContents();
         }
      }

      function _0x4137afe4c6()
      {


         UpdatePurchaseActivationControls();
         let _0x8a1f648a58 = "NOT ACTIVATED";
         let remainingTimeText = "";

         if (_0xc7fa59117d === "PROJECT")
         {
            _0x8a1f648a58 = String.fromCharCode(84,82,73,65,76);
            remainingTimeText =
               String.fromCharCode(84,114,105,97,108,32,100,97,121,115,32,108,101,102,116,58,32) + _0xed0ef1cb02() + "<br>";
         }
         else if (_0xc7fa59117d === "FULL" || _0xc7fa59117d === "FULL_GRACE")
         {
            _0x8a1f648a58 = _0xc7fa59117d === "FULL_GRACE" ?
               [String.fromCharCode(76,73,67,69,78,83,69,68,32,40,52,56,45,72,79,85,82,32,71,82,65,67,69,41)] : String.fromCharCode(76,73,67,69,78,83,69,68);

            let _0xba469e22f7 = _0x7799a174a1();
            if (_0x1d80a60689(_0xba469e22f7))
            {
               remainingTimeText =
                  "Days until renewal: " +
                  _0x20bcf0f500(_0xba469e22f7[String.fromCharCode(101,120,112,105,114,121)]) + "<br>" +
                  "Renewal date (yyyy/mm/dd): " +
                  String(_0xba469e22f7[String.fromCharCode(101,120,112,105,114,121)]).replace(/-/g, "/") + "<br>";
            }
         }


         let _0x1a9176ec59 = _0x7799a174a1();
         premiumSiteButton.enabled = _0xc7fa59117d === "FULL" &&
            _0x61ceb2dad9 &&
            _0x1d80a60689(_0x1a9176ec59) &&
            _0x54354d7f32(_0x1a9176ec59) &&
            !_0x881275c82f(_0x1a9176ec59[String.fromCharCode(101,120,112,105,114,121)]) &&
            _0xf215114029(_0x1a9176ec59);

         activationInfoLabel.text =
            "" + ProjecTname + " " + ProjecTver + "<br>" +
            "🪐 InNova Photo Editor v.1.0.build." + INNOVA_EDITOR_BUILD + "<br>" +
            "💫 InNova Adaptive Stretch v.1.0.build." +
               InNovaAdaptiveStretchBuild + "<br>" +
            String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,109,111,100,101,58,32) + _0x8a1f648a58 + "</b><br>" +
            remainingTimeText +
            "Written by Jesús Manuel García Flores<br>" +
            "<a href=\"https://www.teoriadelcolor.es/innovaastrophotosuite\">www.teoriadelcolor.es/innovaastrophotosuite</a>";
      }

      _0x4137afe4c6();
      activationInfoLabel.textAlignment = TextAlign_Center;
      _0x32f5008ff2.sizer.add(activationInfoLabel);

      let informationGroupBox = new GroupBox(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)]);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;

      let informationLogoBitmap = null;
      try {
         let informationLogoPath = File.extractDrive(#__FILE__) +
            File.extractDirectory(#__FILE__) +
            "/InNova-Astro_Photo_Suite_logo.jpg";
         if (File.exists(informationLogoPath))
            informationLogoBitmap = new Bitmap(informationLogoPath);
      }
      catch (informationLogoError) {
         informationLogoBitmap = null;
      }

      let informationLogoControl = null;
      if (informationLogoBitmap && !informationLogoBitmap.isNull) {
         informationLogoControl = new Control(this);
         informationLogoControl.bitmap = informationLogoBitmap;
         informationLogoControl.setScaledFixedSize(160, 120);
         informationLogoControl.onPaint = function() {
            let graphics = new Graphics(this);
            graphics.drawScaledBitmap(
               new Rect(0, 0, this.width, this.height), this.bitmap);
            graphics.end();
         };

         let informationLogoRow = new HorizontalSizer;
         informationLogoRow.addStretch();
         informationLogoRow.add(informationLogoControl);
         informationLogoRow.addStretch();
         informationGroupBox.sizer.add(informationLogoRow);
         informationGroupBox.sizer.addSpacing(8);
      }

      let moreInformationButton = new PushButton(this);
      moreInformationButton.text = "FAQ";
      moreInformationButton.icon = this.scaledResource(":/icons/info.png");
      moreInformationButton.setFixedWidth(102);
      moreInformationButton.setFixedHeight(WindowsOsx1);
      moreInformationButton.onClick = function() {
         let opened = _0x70e6e0d26d(
            INNOVA_MORE_INFORMATION_PDF_URL,
            "InNova Astro Processor - More Information");
         if (opened === false)
            new MessageBox(
               "The InNova information PDF could not be opened.\n\n" +
               INNOVA_MORE_INFORMATION_PDF_URL,
               "InNova Astro Processor - More Information",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      };

      let moreInformationRow = new HorizontalSizer;
      moreInformationRow.addStretch();
      moreInformationRow.add(moreInformationButton);
      moreInformationRow.addStretch();
      informationGroupBox.sizer.add(moreInformationRow);


      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(_0x7897b534dd);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(_0x32f5008ff2);
      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].sizer.add(informationGroupBox);

      _0x7897b534dd.adjustToContents();
      _0x32f5008ff2.adjustToContents();
      informationGroupBox.adjustToContents();

      this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].adjustToContents();


this.tabBox.addPage(this.integrationPage, "Integration");
this.tabBox.addPage(this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)], String.fromCharCode(76,105,99,101,110,115,101));


      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;
      CropprojectTypeSizer.spacing = 10;
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);


      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;
      projectTypeSizer.spacing = 10;
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;
      alignmentSizer.spacing = 10;


      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;
      projectAndAlignmentSizer.spacing = 10;
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);


      this.integrationPage.sizer.add(projectAndAlignmentSizer);


      this.integrationPage.sizer.add(this.taggingGroupBox);


      this.integrationPage.sizer.add(this.optionsGroupsSizer);


      this.runButton = new PushButton(this);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select Project type\nSelect Gradient Correction\nSelect images\nSelect Integration options\nand click on Run";
      this.runButton.setFixedWidth(102);
      this.runButton.setScaledFixedHeight(28);


      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";
      this.workingLabel.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;
      this.workingLabel.setFixedHeight(WindowsOsx1);

      this.workingStatusText = "";
      this.elapsedStartTime = 0;
      this.elapsedTimer = new Timer(1, true, this);

      this.formatElapsedTime = function (elapsedMilliseconds) {
         let totalSeconds = Math.max(0, Math.floor(elapsedMilliseconds/1000));
         let hours = Math.floor(totalSeconds/3600);
         let minutes = Math.floor((totalSeconds % 3600)/60);
         let seconds = totalSeconds % 60;

         function twoDigits(value) {
            return value < 10 ? "0" + value : "" + value;
         }

         return twoDigits(hours) + ":" + twoDigits(minutes) + ":" +
            twoDigits(seconds);
      };

      this.refreshWorkingLabel = function () {
         if (this.elapsedStartTime <= 0)
            return;

         this.workingLabel.text = this.workingStatusText +
            "  ⏱ Elapsed: " +
            this.formatElapsedTime(Date.now() - this.elapsedStartTime);
         this.workingLabel.update();
         if (this.progressPanel) {
            this.progressPanel.status.text = this.workingLabel.text;
            this.progressPanel.status.update();
         }
      };

      this.setWorkingStatus = function (statusText) {
         if (InNovaRunActive)
            InNovaAbortCheckpoint();
         this.workingStatusText = statusText;
         this.refreshWorkingLabel();
      };

      this.startElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.elapsedStartTime = Date.now();
         this.refreshWorkingLabel();
         this.elapsedTimer.start();
      };

      this.stopElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.refreshWorkingLabel();
      };

      this.elapsedTimer.onTimeout = function () {
         self.refreshWorkingLabel();
      };

      this.setProcessingLock = function (locked) {
         let configurationEnabled = !locked;


         this.projectTypeGroupBox.enabled = configurationEnabled;
         this.CropprojectTypeGroupBox.enabled = configurationEnabled;
         this.taggingGroupBox.enabled = configurationEnabled;
         this.optionsGroupBox.enabled = configurationEnabled;
         this.finalOptionsGroupBox.enabled = configurationEnabled;
         this[String.fromCharCode(108,105,99,101,110,115,101,80,97,103,101)].enabled = configurationEnabled;

         if (locked) {
            this.runButton.enabled = false;
            this.Iconize3.enabled = false;
            this.Iconize6.enabled = false;

            this.exitButton.text = "STOP";
            this.exitButton.icon =
               this.scaledResource( ":/icons/cancel.png" );
            this.exitButton.toolTip =
               "Stop the current project safely and delete its temporary results";
            this.exitButton.enabled = true;
         } else {
            this.runButton.enabled = CanProcess();
            this.Iconize3.enabled = true;
            this.Iconize6.enabled = true;

            this.exitButton.text = "Close";
            this.exitButton.icon =
               this.scaledResource( ":/icons/close.png" );
            this.exitButton.toolTip = "Close InNova Astro Processor";
            this.exitButton.enabled = true;
         }

         if (this.progressPanel) {
            if (locked) this.configurationWindowSize = { width: this.width, height: this.height };
            this.tabBox.visible = !locked;
            this.progressPanel.visible = locked;
            this.consoleButton.visible = !locked;
            this.openImagesButton.visible = !locked;
            this.Iconize3.visible = !locked;
            this.Iconize6.visible = !locked;
            this.runButton.visible = !locked;
            this.progressButtonSpacer.visible = locked;
            this.progressConsoleButton.visible = locked;
            this.progressConsoleBalance.visible = locked;

            this.minHeight = 0;
            this.maxHeight = 16777215;
            this.adjustToContents();
            if (locked) {
               this.setScaledFixedHeight(250);
               this.resize(this.logicalPixelsToPhysical(624), this.logicalPixelsToPhysical(250));
            } else if (this.configurationWindowSize)
               this.resize(this.configurationWindowSize.width, this.configurationWindowSize.height);
            MiraCenterDialog(this);
         }
         this.update();
      };


      let horizontalSizer2 = new HorizontalSizer;
      horizontalSizer2.spacing = 5;
      horizontalSizer2.margin = 0;


      horizontalSizer2.add(this.workingLabel, 100);


      this.integrationPage.sizer.add(horizontalSizer2);


      this.Iconize3 = new ToolButton(this);

      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setScaledFixedSize(28, 28);
      this.Iconize3.toolTip = "Delete actual project";
      if (!CanProcess())
      {
         self.runButton.enabled = false;
      }
      else
      {
         self.runButton.enabled = true;
      }


      self.Iconize6 = new ToolButton(this);

      self.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      self.Iconize6.setScaledFixedSize(28, 28);
      self.Iconize6.toolTip = "Options and Settings";
      self.Iconize6.enabled = true;


      var self = this;

      this.runButton.onClick = function () {
      if (!CanProcess())
      {
         new MessageBox(
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,116,114,105,97,108,32,111,114,32,108,105,99,101,110,115,101,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
            String.fromCharCode(80,108,101,97,115,101,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32,60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32) +
            String.fromCharCode(116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
            "InNova Astro Processor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }


     let selectedProjectTypes = [
        "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
        "OSC", "OSC", "OSC"
     ];
     let selectedSmartModels = [
        "NONE", "NONE", "NONE", "NONE", "NONE",
        "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
        "VAONIS_VESPERA_III", "VAONIS_AUTO"
     ];
     let selectedProjectType = selectedProjectTypes[self.projectTypeComboBox.currentItem];
     OptionObjectType = self.objectTypeComboBox.currentItem === 1 ?
        "MOON_SUN" : "STARS";
     OptionSeestar = self.projectTypeComboBox.currentItem >= 5 &&
        self.projectTypeComboBox.currentItem <= 8 ? "ON" : "OFF";
     OptionVaonisVespera =
        self.projectTypeComboBox.currentItem >= 5 ? "ON" : "OFF";
     OptionSmartTelescopeModel =
        selectedSmartModels[self.projectTypeComboBox.currentItem];


     function selectedImageFromCombo(key) {
        let combo = self.comboBoxReferences[key];
        return combo && combo.currentItem > 0 ?
           combo.itemText(combo.currentItem) : "EMPTY";
     }
     PimageSii = selectedImageFromCombo("PimageSii");
     PimageHa = selectedImageFromCombo("PimageHa");
     PimageOiii = selectedImageFromCombo("PimageOiii");
     PimageRed = selectedImageFromCombo("PimageRed");
     PimageGreen = selectedImageFromCombo("PimageGreen");
     PimageBlue = selectedImageFromCombo("PimageBlue");
     PimageLuminance = selectedImageFromCombo("PimageLuminance");
     PimageOsc = selectedImageFromCombo("PimageOsc");

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS") {
        self.ImageSolverCheckBox.checked = true;
        self.ImageSolverCheckBox.enabled = false;
        OptionImageSolver = "ON";
     }

     ProjecTypevar = selectedProjectType;
     ProjecTypevarRec = selectedProjectType;


     OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
     OptionFast = self.FastCheckBox.enabled && self.FastCheckBox.checked ?
        "ON" : "OFF";
     OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";


     OptionDarkStructureEnhance = "ON";
     OptionOpenInNovaEditor = "ON";
     OptionHavar = self.HalphaCheckBox.enabled &&
        self.HalphaCheckBox.checked ? "ON" : "OFF";
     updateColorCalibrationAvailability(false);
     OptionColorCalibration = self.colorCalibrationCheckBox.enabled &&
        self.colorCalibrationCheckBox.checked ? "ON" : "OFF";
     OptionGradient = self.gradientCorrectionComboBox.currentItem === 0 ?
        "ON" : "OFF";
     OptionMgc = self.gradientCorrectionComboBox.currentItem === 1 ?
        "ON" : "OFF";

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS")
        OptionImageSolver = "ON";


     OptionGraXNoise = "OFF";
     OptionMLDenoise = "OFF";
     OptionNoiseXterminator = "OFF";
     OptionBlurXterminator = "OFF";
     OptionHighpass = "OFF";
     OptionVarStars = self.starlessMethodComboBox.currentItem > 0 ? "ON" : "OFF";
     OptionStarXterminator = self.starlessMethodComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionFinalStarRefinement =
        OptionVarStars === "ON" ? "ON" : "OFF";
     FinalStarRefinementReady = false;


     if (OptionVarStars === "ON" && self.finalStarsComboBox.currentItem === 0)
        self.finalStarsComboBox.currentItem = 1;
     OptionHSOvar = self.finalStarsComboBox.currentItem === 1 ? "ON" : "OFF";
     Option1var = self.finalStarsComboBox.currentItem === 2 ? "ON" : "OFF";
     ProjecTypevar2 = Option1var === "ON" ? "1" : "0";


     if (OptionObjectType === "MOON_SUN") {
        if (selectedProjectType !== "OSC") {
           new MessageBox(
              "Moon or Sun mode requires an OSC, SEESTAR or VAONIS Vespera " +
              "project with one selected image.",
              "InNova Astro Processor - Moon or Sun",
              StdIcon_Error,
              StdButton_Ok
           ).execute();
           return;
        }

        self.ImageSolverCheckBox.checked = false;
        self.ImageSolverCheckBox.enabled = false;
        self.gradientCorrectionComboBox.currentItem = 0;
        self.gradientCorrectionComboBox.enabled = false;
        self.starlessMethodComboBox.currentItem = 0;
        self.starlessMethodComboBox.enabled = false;
        self.finalStarsComboBox.currentItem = 0;
        self.finalStarsComboBox.enabled = false;
        self.HalphaCheckBox.checked = false;
        self.HalphaCheckBox.enabled = false;
        self.colorCalibrationCheckBox.checked = false;
        self.colorCalibrationCheckBox.enabled = false;

        OptionImageSolver = "OFF";
        OptionGradient = "ON";
        OptionMgc = "OFF";
        OptionVarStars = "OFF";
        OptionStarXterminator = "OFF";
        OptionFinalStarRefinement = "OFF";
        OptionHSOvar = "OFF";
        Option1var = "OFF";
        OptionHavar = "OFF";
        OptionColorCalibration = "OFF";
        ProjecTypevar2 = "0";

        console.noteln(
           "🌙 Moon or Sun project: ImageSolver, MGC, Final_starless " +
           "creation and final-star processing will be skipped.");
     }


     if (OptionFast === "ON" && Option1var === "ON") {
        console.warningln(
           "⚠️ FAST mode does not run the separate RGB star integration. " +
           "Using project stars for this run.");
        self.finalStarsComboBox.currentItem = 1;
        Option1var = "OFF";
        OptionHSOvar = "ON";
        ProjecTypevar2 = "0";
     }
     VarProcesStar = "OFF";
     VarPGlobal = "EMPTY";
     isStarProcess = false;
     OptionRemaind2 = null;
     OptionEnabledPreview2 = "OFF";
     InteractiveProcessStrengths.DeepSNR = null;
     InteractiveProcessStrengths.MLDenoise = null;
     InteractiveProcessStrengths.NoiseXTerminator = null;
     InteractiveProcessStrengths.BlurXTerminator = null;
     InteractiveProcessStrengths.HighPass = null;
     InteractiveProcessStrengths.NarrowbandToRGB = null;
     InteractiveProcessMaskModes.DeepSNR = "none";
     InteractiveProcessMaskModes.MLDenoise = "none";
     InteractiveProcessMaskModes.NoiseXTerminator = "none";
     InteractiveProcessMaskModes.BlurXTerminator = "none";
     InteractiveProcessMaskModes.HighPass = "none";
     InteractiveProcessMaskModes.NarrowbandToRGB = "none";
     InteractiveProcessMaskBanks.DeepSNR = null;
     InteractiveProcessMaskBanks.MLDenoise = null;
     InteractiveProcessMaskBanks.NoiseXTerminator = null;
     InteractiveProcessMaskBanks.BlurXTerminator = null;
     InteractiveProcessMaskBanks.HighPass = null;
     InteractiveProcessMaskBanks.NarrowbandToRGB = null;


     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {

            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {

            self.finalStarsComboBox.currentItem = 0;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");


      if (!MiraRestoreSelectedSourceIds()) {
         console.criticalln(
            "❌ Source-window identifiers are ambiguous. Close or rename the duplicate window reported above, then run the script again.");
         return;
      }


      if (!MiraCheckWindowsABE()) {
         console.warningln("\n⚠️ Run cancelled because previous intermediate windows are still open.");
         return;
      }

      let msgBox = new MessageBox(
         "<p align=\"center\">Do you want to run <b>Astro Processor</b>?</p>",
         "Confirmation", StdIcon_Question,
         StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {


        MiraPrepareWorkspaceForRun(dialog);

        FinalFocusWindowId = "";
        FinalConvertedFocusWindowId = "";
        let startTime = Date.now();
        dialog.workingStatusText = String.fromCharCode(83,116,97,114,116,105,110,103,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46);
        dialog.startElapsedTimer();
        let processCompleted = false;
        InNovaStopRequested = false;
        InNovaStopCleanupRequested = false;
        InNovaRunActive = true;
        try {
        dialog.setProcessingLock(true);

        MiraConsoleSection("🚀 Launching InNova Astro Processor project...");

        dialog.workingLabel.foregroundColor = 0x0000FF;
        dialog.workingLabel.update();


         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln(String.fromCharCode(10,10060,32,86,97,108,105,100,97,116,105,111,110,32,102,97,105,108,101,100,46,32,80,108,101,97,115,101,32,115,101,108,101,99,116,32,105,109,97,103,101,115,46));
          return;
        } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
        }


        if (OptionObjectType === "STARS" &&
            OptionImageSolver !== "ON" &&
            !MiraValidateSelectedImageAstrometry(ProjecTypevar)) {
           OptionImageSolver = "ON";
           self.ImageSolverCheckBox.checked = true;
           self.ImageSolverCheckBox.update();

           console.noteln(
              "🔭 Astrometric data are missing. ImageSolver has been enabled automatically."
           );

           new MessageBox(
              "InNova has detected that one or more selected images require an " +
              "astrometric solution.<br><br>" +
              "<b>ImageSolver will now run automatically.</b> You do not need to enable " +
              "the option or restart the process.<br><br>" +
              "InNova will continue the integration as soon as the astrometric " +
              "solution has been generated.",
              "InNova Astro Processor - Automatic ImageSolver",
              StdIcon_Information,
              StdButton_Ok
           ).execute();
        }


        if (OptionObjectType === "STARS" && OptionImageSolver === "ON") {
           dialog.setWorkingStatus(String.fromCharCode(82,117,110,110,105,110,103,32,73,109,97,103,101,83,111,108,118,101,114,32,111,110,32,115,101,108,101,99,116,101,100,32,105,109,97,103,101,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
           let imageSolverBaselineWindows = ImageWindow.windows.slice();
           if (!MiraRunImageSolverForSelectedImages(ProjecTypevar)) {
              MiraCleanupImageSolverAttempt(imageSolverBaselineWindows);

              let imageSolverRequiredByColorCalibration =
                 OptionColorCalibration === "ON";
              let imageSolverCanContinue = OptionMgc !== "ON" &&
                 !imageSolverRequiredByColorCalibration;
              let imageSolverDetail =
                 (typeof MiraImageSolverLastError === "string" &&
                  MiraImageSolverLastError.length > 0) ?
                    MiraImageSolverLastError :
                    "ImageSolver could not generate a valid astrometric solution.";
              imageSolverDetail = String(imageSolverDetail)
                 .replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
              let imageSolverMessage =
                 "ImageSolver could not solve the selected image.<br><br>" +
                 "If this is an image of the Moon or the Sun, restart InNova and, " +
                 "in the Object section, choose <b>Moon or Sun</b>.<br><br>";

              if (imageSolverCanContinue) {
                 imageSolverMessage +=
                    "The options currently enabled do not require astrometry, so " +
                    "InNova Astro Processor will continue without ImageSolver.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Warning,
                    StdButton_Ok
                 ).execute();
                 OptionImageSolver = "OFF";
                 self.ImageSolverCheckBox.checked = false;
                 self.ImageSolverCheckBox.update();
                 console.warningln(
                    "⚠️ ImageSolver failed, but no active process requires astrometry. Continuing safely without ImageSolver.");
              }
              else {
                 let astrometryRequirement = OptionMgc === "ON" &&
                    imageSolverRequiredByColorCalibration ?
                       "Multiscale Gradient Correction and Color Calibration require" :
                    OptionMgc === "ON" ?
                       "Multiscale Gradient Correction requires" :
                       "Color Calibration requires";
                 imageSolverMessage +=
                    "The active " + astrometryRequirement + " astrometry. " +
                    "InNova Astro Processor must stop.<br><br>" +
                    "All temporary ImageSolver results have been removed and the " +
                    "original selected image has been preserved.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Error,
                    StdButton_Ok
                 ).execute();
                 console.criticalln(
                    "\n❌ 🔭 ImageSolver failed. Astrometry is required by " +
                    (OptionMgc === "ON" && imageSolverRequiredByColorCalibration ?
                       "Multiscale Gradient Correction and Color Calibration" :
                     OptionMgc === "ON" ? "Multiscale Gradient Correction" :
                       "Color Calibration") +
                    ", so InNova Astro Processor stopped before processing.");
                 return;
              }
           }
        }

        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
        if (!MiraProyecto())
            {
               console.criticalln("Process cancelled.");
               return;
            }


        if (OptionMgc ==="ON") {


           if (!MiraValidateMgcConfiguration(true)) {
              OptionMgc = "OFF";
              OptionGradient = "ON";
              dialog.gradientCorrectionComboBox.currentItem = 0;
           }
           else {
              MiraConsoleSection("Launching MARS databases...");
              dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,77,117,108,116,105,115,99,97,108,101,32,71,114,97,100,105,101,110,116,32,67,111,114,114,101,99,116,105,111,110,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
              console.noteln("Launching Multiscale Gradient Correction process...");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin1) + ": \n" + originalFilePathMarsfin1);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin2) + ": \n" + originalFilePathMarsfin2);


              if (!MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, MiraImageSolverSelectedIds(ProjecTypevar))) {
                 console.criticalln(
                    "❌ Multiscale Gradient Correction did not complete on every selected image. Processing has been stopped to avoid mixing corrected and uncorrected channels.");
                 return;
              }
           }
        }


        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));

            if (MiraVentana()) {


            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraRenombre();
            if (ProjecTypevar === "OSC" &&
                !MiraPrepareOscColorSource(OptionObjectType === "MOON_SUN")) {
               console.criticalln(
                  "❌ OSC colour preparation failed. Processing has been stopped safely.");
               return;
            }
            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return;
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }


            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,53,47,57,46,32,77,97,105,110,32,112,114,111,99,101,115,115,44,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraProcesoGeneral01();
            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,54,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!MiraChannelCom()) {
               console.criticalln(
                  "❌ Channel combination or final-window creation failed. Processing has been stopped safely.");
               return;
            }

            if (!MiraValidateFinalWindowContract(
                   OptionFast === "ON" && OptionVarStars === "ON",
                   "Channel combination"))
               return;

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,55,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


               let finalColorTarget = ImageWindow.windowById("Final_starless");
               if (finalColorTarget && !finalColorTarget.isNull)
                  finalColorTarget.bringToFront();
               MiraGreen();


            dialog.setWorkingStatus(
               "Adjusting background, denoise and sharpen on the visible final image...");
            if (!MiraApplyVisibleFinalProcesses())
               return;

            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (Option1var === "ON") {
                        if (OptionFast === "OFF"){
                              console.noteln("\n" + "Launching RGB stars process.");
                              try {
                                 MiraRGBStars();
                              } finally {


                                 VarProcesStar = "OFF";
                                 ProjecTypevar = ProjecTypevarRec;
                              }
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                } else if (OptionHSOvar === "ON") {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars2();

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars();

                              }
                        }
                }
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            if (!MiraValidateFinalWindowContract(
                   OptionVarStars === "ON", "Final star creation"))
               return;


            if (OptionHavar ==="ON"){
               let imageWindow = "Filter_Ha_registered_ABE";
               if (!InNovaEditorRunHAlphaStage(
                     imageWindow, ProjecTypevarRec))
                  return;
            }

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,57,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            dialog.setWorkingStatus(
               String.fromCharCode(73,110,78,111,118,97,32,68,97,114,107,32,83,116,114,117,99,116,117,114,101,32,69,110,104,97,110,99,101,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!InNovaEditorRunDarkStructuresStage(
                  ProjecTypevarRec))
               return;


            if (OptionVarStars === "ON") {
               dialog.setWorkingStatus(
                  String.fromCharCode(82,101,102,105,110,105,110,103,32,116,104,101,32,102,105,110,97,108,32,115,116,97,114,32,108,97,121,101,114,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
               if (!InNovaEditorRunStarRefinementStage(
                     ProjecTypevarRec))
                  return;
            }

              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break;
                         }
                   }
              }

            MiraRenProyectos();

            InNovaAbortCheckpoint();
            MirashowTotalTime(startTime);
            Option2var2 = "ON";


            dialog.stopElapsedTimer();
            MiraBorraVentanas();

            MiraOrdena1();
            MiraFocusFinalOutput();
            InNovaAbortCheckpoint();


            if (OptionOpenInNovaEditor === "ON") {
               let finalId = FinalConvertedFocusWindowId ||
                             FinalFocusWindowId;
               if (!finalId || finalId.length === 0) {
                  let finalWindow = ImageWindow.activeWindow;
                  finalId = finalWindow && !finalWindow.isNull &&
                            finalWindow.mainView &&
                            !finalWindow.mainView.isNull ?
                            finalWindow.mainView.id : "";
               }
               let verifiedFinal = ImageWindow.windowById(finalId);
               if (verifiedFinal && !verifiedFinal.isNull &&
                   verifiedFinal.mainView &&
                   !verifiedFinal.mainView.isNull) {
                  InNovaEditorPendingSourceId = finalId;
                  InNovaEditorPendingProjectType = ProjecTypevarRec;
                  InNovaEditorPendingLaunch = true;
                  console.noteln(
                     "🪐 InNova Photo Editor queued for: " + finalId);
               }
               else {
                  console.warningln(
                     "⚠️ 🪐 InNova Photo Editor was not opened because no valid final image was found.");
               }
            }

            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            if (!InNovaEditorPendingLaunch)
               console.noteln("\n✅ End of project.");
            dialog.setWorkingStatus("✅ Process completed.");
            processCompleted = true;
            if (InNovaEditorPendingLaunch)
               dialog.ok();


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
        } catch (processingError) {
            console.show();
            let processingMessage = processingError && processingError.message ?
               processingError.message : processingError;
            if ((processingError && processingError.inNovaUserStop) ||
                InNovaStopRequested) {
               console.warningln(
                  "\n⛔ InNova Astro Processor stopped by the user at a safe checkpoint.");
            }
            else {
               console.criticalln(
                  "\n❌ 🔭 InNova Astro Processor stopped after an unexpected processing error: " +
                  processingMessage);
               if (processingError && processingError.stack)
                  console.criticalln(processingError.stack);
               new MessageBox(
                  "InNova Astro Processor stopped safely.\n\n" + processingMessage +
                  "\n\nReview the Process Console for the stage and missing window details.",
                  "InNova Astro Processor processing error",
                  StdIcon_Error,
                  StdButton_Ok
               ).execute();
            }
        } finally {

            InNovaRunActive = false;


            try {
               MiraRestoreSelectedSourceIds();
            } catch (restoreError) {
               console.warningln(
                  "⚠️ Source-window names could not be fully restored: " +
                  restoreError.message);
            }
            VarProcesStar = "OFF";
            VarPGlobal = "EMPTY";
            isStarProcess = false;
            ProjecTypevar = ProjecTypevarRec;
            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            dialog.stopElapsedTimer();
            let stoppedByUser = InNovaStopRequested;


            InNovaRunActive = false;
            if (stoppedByUser && InNovaStopCleanupRequested) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Stopped. Cleaning project windows...";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
               try {
                  MiraCheckWindowsTrash(true);
                  MiraOrdena1();
                  console.noteln(
                     "✅ STOP cleanup completed. Original source images were preserved.");
               }
               catch (cleanupError) {
                  console.criticalln(
                     "❌ STOP cleanup could not remove every project window: " +
                     (cleanupError.message || cleanupError));
               }
            }
            InNovaStopRequested = false;
            InNovaStopCleanupRequested = false;
            dialog.setProcessingLock(false);

            if (stoppedByUser) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Process stopped. Project workspace cleaned.";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
            }
            else if (!processCompleted)
               dialog.setWorkingStatus("⚠️ Process stopped.");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};


      this.Iconize3.onClick = function() {


               self.projectTypeComboBox.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };


self.Iconize6.onClick = function() {

   let mgcDialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
   mgcDialog.adjustToContents();
   MiraCenterDialog(mgcDialog);
   mgcDialog.execute();
   MiraRefreshConfiguredDataPaths();
};


     this.exitButton = new PushButton(this);
     this.exitButton.text = "Close";

     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.toolTip = "Close InNova Astro Processor";
      this.exitButton.setFixedWidth(102);
      this.exitButton.setScaledFixedHeight(28);


     this.exitButton.onClick = function () {
        if (InNovaRunActive) {
           InNovaRequestStop("the main window");
           return;
        }
        this.dialog.cancel();
    };


      this.consoleButton = new ToolButton(this);

      this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
      this.consoleButton.setScaledFixedSize(28, 28);
      this.consoleButton.toolTip = "Show or hide the PixInsight Process Console";
      this.consoleButton.onClick = function () {
         if (OptionshowConsolRadio === "ON") {
            OptionshowConsolRadio = "OFF";
            this.toolTip = "Show the PixInsight Process Console";
            console.hide();
         }
         else {
            OptionshowConsolRadio = "ON";
            this.toolTip = "Hide the PixInsight Process Console";
            console.show();
         }
      };


    this.actionButtonsSizer = new HorizontalSizer;
    this.actionButtonsSizer.spacing = 10;
    this.progressConsoleBalance = new Control(this);
    this.progressConsoleBalance.setScaledFixedSize(28, 28);
    this.progressConsoleBalance.hide();
    this.actionButtonsSizer.add(this.consoleButton);
    this.openImagesButton = new ToolButton(this);
    this.openImagesButton.icon = this.scaledResource(":/icons/folder-open.png");
    this.openImagesButton.setScaledFixedSize(28, 28);
    this.openImagesButton.toolTip = "Open image files";
    this.openImagesButton.onClick = function() {
       if (InNovaRunActive) return;
       let chooser = new OpenFileDialog;
       chooser.caption = "Open images for InNova Astro Processor";
       chooser.multipleSelections = true;
       chooser.filters = [["Image files", "*.xisf", "*.fit", "*.fits", "*.fts", "*.tif", "*.tiff"], ["All files", "*.*"]];
       if (!chooser.execute()) return;
       try {
          for (let path of chooser.fileNames) {
             let opened = ImageWindow.open(path);
             for (let window of opened) {
                window.show();
                for (let key in self.comboBoxReferences)
                   self.comboBoxReferences[key].addItem(window.mainView.id);
             }
          }
       } catch (error) {
          new MessageBox(String(error), "Open images", StdIcon_Error, StdButton_Ok).execute();
       }
    };
    this.actionButtonsSizer.add(this.openImagesButton);
    this.actionButtonsSizer.add(this.Iconize3);
    this.actionButtonsSizer.add(this.Iconize6);
    this.actionButtonsSizer.addStretch();
    this.actionButtonsSizer.add(this.runButton);
    this.progressButtonSpacer = new Control(this);
    this.progressButtonSpacer.setFixedHeight(1);
    this.progressButtonSpacer.hide();
    this.progressConsoleButton = new ToolButton(this);
    this.progressConsoleButton.icon = this.scaledResource(":/toolbar/view-process-console.png");
    this.progressConsoleButton.setScaledFixedSize(28, 28);
    this.progressConsoleButton.toolTip = "Show or hide the PixInsight Process Console";
    this.progressConsoleButton.onClick = function() {
       self.consoleButton.onClick.call(self.consoleButton);
    };
    this.progressConsoleButton.hide();
    this.actionButtonsSizer.insert(0, this.progressConsoleButton);
    this.actionButtonsSizer.add(this.exitButton);
    this.actionButtonsSizer.add(this.progressButtonSpacer, 100);
    this.actionButtonsSizer.add(this.progressConsoleBalance);


    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;


    this.onClose = function() {
       if (InNovaRunActive) {
          InNovaRequestStop("the progress window");
          return false;
       }
       return true;
    };
    this.progressPanel = InNovaProcessorProgressPanel(this, true);
    this.progressPanel.hide();
    this.sizer.add(this.progressPanel);
    this.sizer.add(this.tabBox, 100);
    this.sizer.addSpacing(10);
    this.sizer.add(this.actionButtonsSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}
}


let dialog = new IntegratorDialog();
InNovaIntegratorMainDialog = dialog;
InNovaProjectSelectionLoggingEnabled = true;
UpdateInstalledAppsUI(dialog);

function InNovaIntegratorConsumeGetStartedHandoff(targetDialog)
{
   let pending = Settings.read(
      InNovaIntegratorHandoffPendingSetting, DataType_String );
   if (!Settings.lastReadOK || pending !== "1") return false;

   let project = Settings.read(
      InNovaIntegratorHandoffProjectSetting, DataType_String );
   if (!Settings.lastReadOK || typeof project !== "string") project = "SHO";
   let projectIndexes = { LRGB: 0, RGB: 1, SHO: 2, HOO: 3, OSC: 4,
      SEESTAR_S30_PRO: 5, SEESTAR_S50: 6, SEESTAR_S50_PRO: 7,
      SEESTAR: 8, VAONIS_VESPERA: 10 };
   let projectIndex = projectIndexes[project];
   if (projectIndex === undefined) projectIndex = 2;
   targetDialog.projectTypeComboBox.currentItem = projectIndex;
   if (typeof targetDialog.projectTypeComboBox.onItemSelected === "function")
      targetDialog.projectTypeComboBox.onItemSelected(projectIndex);

   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   let assigned = 0;
   for (let k = 0; k < keys.length; ++k) {
      let id = Settings.read(
         InNovaIntegratorHandoffImagePrefix + keys[k], DataType_String );
      if (!Settings.lastReadOK || typeof id !== "string" || id.length === 0)
         continue;
      let combo = targetDialog.comboBoxReferences[keys[k]];
      if (!combo) continue;
      InNovaIntegratorHandoffImageIds[id] = true;
      let itemIndex = -1;
      for (let i = 0; i < combo.numberOfItems; ++i)
         if (combo.itemText(i) === id) {
            itemIndex = i;
            break;
         }
      if (itemIndex < 0 && !ImageWindow.windowById(id).isNull) {
         combo.addItem(id);
         itemIndex = combo.numberOfItems - 1;
      }
      if (itemIndex >= 0) {
         combo.currentItem = itemIndex;
         if (typeof combo.onItemSelected === "function")
            combo.onItemSelected(itemIndex);
         ++assigned;
      }
   }

   let objectMode = Settings.read("InNovaHandoffObjectType", DataType_String);
   if (Settings.lastReadOK && objectMode === "MOON_SUN") {
      targetDialog.objectTypeComboBox.currentItem = 1;
      if (typeof targetDialog.objectTypeComboBox.onItemSelected === "function")
         targetDialog.objectTypeComboBox.onItemSelected(1);
   }

   Settings.remove(InNovaIntegratorHandoffPendingSetting);
   console.noteln("🚀 InNova Get Started handoff: " + assigned +
      " prepared channel image(s) assigned automatically.");
   return assigned > 0;
}

function InNovaIntegratorShowGetStartedHandoffNotice()
{


   let notice = new Dialog;
   notice.windowTitle = "InNova Astro Processor";

   let information = new Label(notice);
   information.useRichText = true;
   information.wordWrapping = true;
   information.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span>" +
      "<br/><br/><b>Make sure:</b><br/><br/>" +
      "• Project type<br/>" +
      "• Gradient correction<br/>" +
      "• Object type<br/>" +
      "• Starless image<br/>" +
      "• Any other options<br/><br/>" +
      "<b>Are correct.</b></p>";
   information.setFixedWidth(notice.logicalPixelsToPhysical(460));

   let okButton = new PushButton(notice);
   okButton.text = "OK";
   okButton.icon = notice.scaledResource(":/icons/ok.png");
   okButton.setFixedWidth(notice.logicalPixelsToPhysical(120));
   okButton.defaultButton = true;
   okButton.onClick = function () { notice.ok(); };

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add(okButton);
   buttons.addStretch();

   notice.sizer = new VerticalSizer;
   notice.sizer.margin = 16;
   notice.sizer.spacing = 16;
   notice.sizer.add(information);
   notice.sizer.add(buttons);
   notice.adjustToContents();
   MiraCenterDialog(notice);
   notice.execute();
}

let InNovaIntegratorGetStartedHandoffApplied =
   InNovaIntegratorConsumeGetStartedHandoff(dialog);
if (InNovaIntegratorGetStartedHandoffApplied)
   InNovaIntegratorShowGetStartedHandoffNotice();


dialog.initialCenterTimer = new Timer;
dialog.initialCenterTimer.interval = 0.05;
dialog.initialCenterTimer.periodic = false;
dialog.initialCenterTimer.onTimeout = function ()
{
   MiraCenterDialog(dialog);
};
dialog.onShow = function ()
{
   MiraCenterDialog(this);
   dialog.initialCenterTimer.start();
};


dialog.actualizarComboBoxesDesdeGUI = function () {

   var self = dialog;


   let availableImageIds = [];
   let windows = ImageWindow.windows;

   for (let i = 0; i < windows.length; ++i) {
      if (!windows[i] || windows[i].isNull || !windows[i].mainView || windows[i].mainView.isNull)
         continue;

      let id = windows[i].mainView.id;
      if (
         id.indexOf("Final_") === 0 ||
         id.indexOf("Base_") === 0 ||


         id.indexOf("Image_") === 0 ||
         id.indexOf("Gray") === 0 ||
         (id.indexOf("_registered") !== -1 &&
          !InNovaIntegratorHandoffImageIds[id]) ||
         id.indexOf("_ABE") !== -1 ||
         id.indexOf("_stars") !== -1
      )
         continue;

      availableImageIds.push(id);
   }

   function actualizarCombo(comboBox) {
      if (!comboBox)
         return;

      comboBox.clear();
      comboBox.addItem("<Select an Image>");

      for (let i = 0; i < availableImageIds.length; ++i)
         comboBox.addItem(availableImageIds[i]);

      comboBox.currentItem = 0;
   }

   for (let key in self.comboBoxReferences) {
      actualizarCombo(self.comboBoxReferences[key]);
   }

   PimageSii = "EMPTY";
   PimageHa = "EMPTY";
   PimageOiii = "EMPTY";
   PimageRed = "EMPTY";
   PimageGreen = "EMPTY";
   PimageBlue = "EMPTY";
   PimageLuminance = "EMPTY";
   PimageOsc = "EMPTY";
   updateColorCalibrationAvailability(false);

   CoreApplication.processEvents();
   self.update();
};


if (CanStartApp)
{
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   if (_0x277f0b5adb &&
       typeof dialog[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)] === "function")
   {
      _0x277f0b5adb = false;
      dialog[String.fromCharCode(111,112,101,110,83,117,98,115,99,114,105,112,116,105,111,110,80,108,97,110,115)]();
   }
   InNovaStartupSplash.hide();
   dialog.execute();

   if (InNovaEditorPendingLaunch) {
      let editorCompleted = InNovaIntegratorOpenInNovaEditor(
         InNovaEditorPendingSourceId,
         InNovaEditorPendingProjectType);
      console.noteln("\n✅ End of project.");
      if (editorCompleted) console.hide();
   }
}
else
{
   console.criticalln("Application startup blocked.");
}

if (InNovaReturnToStartPath.length > 0) {
   try {
      if (InNovaReturnToBridgeRequest != null) {
         let resultId = "";
         let preferredIds = [FinalConvertedFocusWindowId, FinalFocusWindowId];
         for (let i = 0; i < preferredIds.length; ++i)
            if (preferredIds[i] && !ImageWindow.windowById(preferredIds[i]).isNull) {
               resultId = preferredIds[i];
               break;
            }
         let baseline = {};
         let baselineIds = InNovaReturnToBridgeRequest.baselineIds || [];
         for (let i = 0; i < baselineIds.length; ++i)
            baseline[String(baselineIds[i])] = true;
         if (resultId.length == 0) {
            let active = ImageWindow.activeWindow;
            if (active != null && !active.isNull && !active.mainView.isNull &&
                !baseline[active.mainView.id])
               resultId = active.mainView.id;
         }
         if (resultId.length == 0) {
            let current = ImageWindow.windows;
            for (let i = current.length - 1; i >= 0; --i) {
               if (current[i] == null || current[i].isNull ||
                   current[i].mainView.isNull) continue;
               let id = current[i].mainView.id;
               if (!baseline[id] && id.indexOf("_Preview") < 0 &&
                   id.indexOf("mask") < 0) {
                  resultId = id;
                  break;
               }
            }
         }
         if (resultId.length == 0 && InNovaReturnToBridgeRequest.sourceId &&
             !ImageWindow.windowById(InNovaReturnToBridgeRequest.sourceId).isNull)
            resultId = InNovaReturnToBridgeRequest.sourceId;
         Settings.write("InNova/BridgeReturn", DataType_String, JSON.stringify({
            created: Date.now(),
            sourceId: InNovaReturnToBridgeRequest.sourceId || "",
            resultId: resultId
         }));
      }
      console.hide();
      MiraLaunchSuiteScript(InNovaReturnToStartPath);
   } catch (error) {
      new MessageBox("InNova Start could not be reopened.\n\n" + error,
         "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
   }
}

} finally {
   InNovaStartupSplash.hide();
}

#endif
