#include "lib/InNovaEditorTheme.js"
#include "lib/InNovaNotice.js"


#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaIntegrator : InNova Astro Photo Suite > InNova Astro Processor
#feature-icon  InNovaIcon.svg
#feature-info  Integration and astrophotography processing for InNova Astro Photo Suite. \
<br/>\
Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   InNovaTr("This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.");

console.criticalln( InNovaMinimumVersionMessage );
new InNovaNotice(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Astro Processor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

function InNovaProcessorHeader(dialog)
{
   return InNovaBlackHeader(dialog,"InNova Astro Processor","","astro-processor");
}

function InNovaDocumentsFolderIcon()
{
   return new Bitmap(":/icons/documents-import.png");
}

function InNovaProcessorProgressPanel(dialog, showInformationBox)
{
   let panel = new Control(dialog);
   let header = InNovaProcessorHeader(panel);
   panel.setScaledMinWidth(600);
   panel.setScaledFixedHeight(showInformationBox === true ? 180 : 150);
   panel.sizer = new VerticalSizer;
   panel.sizer.spacing = 12;
   panel.sizer.add(header);
   let statusParent = panel;
   let informationBox = null;
   if (showInformationBox === true) {
      informationBox = new GroupBox(panel);
      informationBox.title = "";
      informationBox.sizer = new VerticalSizer;
      informationBox.sizer.margin = 10;
      statusParent = informationBox;
   }
   panel.status = new Label(statusParent);
   panel.status.text = InNovaTr("Loading...");
   panel.status.textAlignment = TextAlign_Center | TextAlign_VertCenter;
   panel.status.wordWrapping = true;
   panel.status.setScaledMinHeight(46);
   if (informationBox) {
      informationBox.sizer.add(panel.status);
      panel.sizer.add(informationBox);
   } else
      panel.sizer.add(panel.status);
   return panel;
}

function InNovaProcessorLoading()
{
   let splash = new Dialog; InNovaApplyBlackTheme(splash);
   splash.windowTitle = "🚀 InNova Astro Processor — " + ProjecTver;
   splash.sizer = new VerticalSizer;
   splash.sizer.margin = 12;
   splash.sizer.spacing = 10;
   splash.sizer.add(InNovaProcessorProgressPanel(splash));
   let consoleButton = new ToolButton(splash);
   consoleButton.icon = splash.scaledResource(":/toolbar/view-process-console.png");
   consoleButton.setScaledFixedSize(28, 28);
   consoleButton.toolTip = InNovaTr("Show the PixInsight Process Console");
   let consoleShown = false;
   console.hide();
   consoleButton.onClick = function() {
      consoleShown = !consoleShown;
      if (consoleShown) console.show();
      else console.hide();
      consoleButton.toolTip = consoleShown ?
         InNovaTr("Hide the PixInsight Process Console") :
         InNovaTr("Show the PixInsight Process Console");
   };
   let close = new PushButton(splash);
   close.text = InNovaTr("Close");
   close.icon = splash.scaledResource(":/icons/close.png");
   close.onClick = function() { splash.cancel(); };
   let row = new HorizontalSizer;
   let balance = new Control(splash);
   balance.setScaledFixedSize(28, 28);
   row.add(consoleButton);
   row.addStretch(); row.add(InNovaStyleBlackButton(close)); row.addStretch();
   row.add(balance);
   splash.sizer.add(row);
   splash.adjustToContents();
   splash.show();
   CoreApplication.processEvents();
   return splash;
}

function InNovaProcessorConfirmRun()
{
   let prompt = new Dialog; InNovaApplyBlackTheme(prompt);
   prompt.windowTitle = InNovaTr("✦ InNova Astro Processor — Confirmation");
   prompt.confirmed = false;

   let information = new Label(prompt);
   information.useRichText = true;
   information.text =
      "<span style=\"font-size:32pt;color:#168dcc\">ⓘ</span>";
   information.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   information.setScaledFixedHeight(54);

   let question = new Label(prompt);
   question.useRichText = true;
   question.wordWrapping = true;
   question.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   question.text =
      InNovaTr("<p align=\"center\">Do you want to run <b>Astro Processor</b>?</p>");
   question.setScaledMinWidth(520);

   let yesButton = new PushButton(prompt);
   yesButton.text = InNovaTr("Yes");
   yesButton.icon = prompt.scaledResource(":/icons/ok.png");
   yesButton.defaultButton = true;
   yesButton.onClick = function() {
      prompt.confirmed = true;
      prompt.ok();
   };

   let noButton = new PushButton(prompt);
   noButton.text = InNovaTr("No");
   noButton.icon = prompt.scaledResource(":/icons/cancel.png");
   noButton.onClick = function() {
      prompt.confirmed = false;
      prompt.cancel();
   };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add(InNovaStyleBlackButton(yesButton));
   buttons.add(InNovaStyleBlackButton(noButton));
   buttons.addStretch();

   prompt.sizer = new VerticalSizer;
   prompt.sizer.margin = 12;
   prompt.sizer.spacing = 12;
   prompt.sizer.add(InNovaProcessorHeader(prompt));
   prompt.sizer.add(information);
   prompt.sizer.add(question);
   InNovaAddDialogActionSpace(prompt, prompt.sizer); prompt.sizer.add(buttons);
   prompt.sizer.addSpacing(6);
   prompt.adjustToContents();
   prompt.onShow = function() { MiraCenterDialog(this); };
   return prompt.execute() && prompt.confirmed;
}

function InNovaProcessorChooseRunMode(targetDialog)
{
   let prompt = new Dialog; InNovaApplyBlackTheme(prompt);
   prompt.windowTitle = InNovaTr("🔭 InNova Astro Processor — Processing mode");
   prompt.accepted = false;

   let modeTitle = new Label(prompt);
   modeTitle.useRichText = true;
   modeTitle.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   modeTitle.setScaledMinWidth(520);
   modeTitle.text =
      InNovaTr("<p align=\"center\"><b><span style=\"color:#72b8f4\">" +
      "Select the Astro Processor processing mode</span></b></p>");

   let basicGroup = new GroupBox(prompt);
   basicGroup.title = "";
   basicGroup.sizer = new VerticalSizer;
   basicGroup.sizer.margin = 10;
   let basic = new RadioButton(basicGroup);
   basic.text = InNovaTr("Basic Mode:  Photo Editor");
   basic.checked = true;
   let basicRow = new HorizontalSizer;
   basicRow.addStretch();
   basicRow.add(basic);
   basicRow.addStretch();
   basicGroup.sizer.add(basicRow);

   let advancedGroup = new GroupBox(prompt);
   advancedGroup.title = "";
   advancedGroup.sizer = new VerticalSizer;
   advancedGroup.sizer.margin = 10;
   advancedGroup.sizer.spacing = 5;
   let advanced = new RadioButton(advancedGroup);
   advanced.text = InNovaTr("Advanced Mode:");
   let advancedRow = new HorizontalSizer;
   advancedRow.addStretch();
   advancedRow.add(advanced);
   advancedRow.addStretch();
   advancedGroup.sizer.add(advancedRow);
   advancedGroup.sizer.addSpacing(8);

   let definitions = [
      { key: "BackgroundCorrection", label: InNovaTr("Background Correction") },
      { key: "Denoise", label: "Denoise" },
      { key: "Sharpen", label: "Sharpen" },
      { key: "DarkStructureEnhance", label: InNovaTr("Dark Structure Enhance") },
      { key: "StarRefinement", label: InNovaTr("Star Refinement") },
      { key: "PhotoEditor", label: "Photo Editor" }
   ];
   let checks = {};
   let remembered = {};
   let columns = new HorizontalSizer;
   columns.spacing = 36;
   columns.addStretch();
   let left = new VerticalSizer;
   left.spacing = 10;
   let right = new VerticalSizer;
   right.spacing = 10;
   for (let i = 0; i < definitions.length; ++i) {
      let definition = definitions[i];
      let check = new CheckBox(advancedGroup);
      check.text = InNovaTr(definition.label);
      check.setScaledMinHeight(24);
      check.checked = false;
      check.enabled = false;
      checks[definition.key] = check;
      remembered[definition.key] = true;
      let row = new HorizontalSizer;
      row.add(check);
      row.addStretch();
      (i < 3 ? left : right).add(row);
   }
   columns.add(left, 50);
   columns.add(right, 50);
   columns.addStretch();
   advancedGroup.sizer.add(columns);

   function setAdvancedMode(enabled)
   {
      for (let i = 0; i < definitions.length; ++i) {
         let key = definitions[i].key;
         if (enabled) {
            checks[key].checked = remembered[key] !== false;
            checks[key].enabled = true;
         }
         else {
            remembered[key] = checks[key].checked;
            checks[key].checked = false;
            checks[key].enabled = false;
         }
      }
   }
   basic.onCheck = function(checked) {
      if (checked) {
         advanced.checked = false;
         setAdvancedMode(false);
      }
   };
   advanced.onCheck = function(checked) {
      if (checked) {
         basic.checked = false;
         setAdvancedMode(true);
      }
   };

   function setProcessFlag(key, enabled)
   {
      switch (key) {
      case "BackgroundCorrection": InNovaBridgeRunBackgroundCorrection = enabled; break;
      case "Denoise": InNovaBridgeRunDenoise = enabled; break;
      case "Sharpen": InNovaBridgeRunSharpen = enabled; break;
      case "DarkStructureEnhance": InNovaBridgeRunDarkStructureEnhance = enabled; break;
      case "StarRefinement": InNovaBridgeRunStarRefinement = enabled; break;
      case "PhotoEditor": InNovaBridgeRunPhotoEditor = enabled; break;
      }
   }

   let run = new PushButton(prompt);
   run.text = InNovaTr("Run");
   run.icon = InNovaBlackPlaybackIcon(prompt, "play");
   run.defaultButton = true;
   run.setFixedWidth(102);
   run.setScaledFixedHeight(28);
   run.onClick = function() {
      for (let i = 0; i < definitions.length; ++i) {
         let key = definitions[i].key;
         setProcessFlag(key,
            basic.checked ? key === "PhotoEditor" : checks[key].checked);
      }
      if (InNovaBridgeRunStarRefinement && targetDialog &&
          typeof InNovaIntegratorSelectGuidedStarRemoval === "function")
         InNovaIntegratorSelectGuidedStarRemoval(targetDialog);
      prompt.accepted = true;
      prompt.ok();
   };

   let cancel = new PushButton(prompt);
   cancel.text = InNovaTr("Cancel");
   cancel.icon = prompt.scaledResource(":/icons/cancel.png");
   cancel.setFixedWidth(102);
   cancel.setScaledFixedHeight(28);
   cancel.onClick = function() { prompt.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 10;
   buttons.addStretch();
   buttons.add(InNovaStyleBlackButton(run));
   buttons.add(InNovaStyleBlackButton(cancel));

   prompt.sizer = new VerticalSizer;
   prompt.sizer.margin = 12;
   prompt.sizer.spacing = 12;
   prompt.sizer.add(InNovaProcessorHeader(prompt));
   prompt.sizer.addSpacing(8);
   prompt.sizer.add(modeTitle);
   prompt.sizer.addSpacing(18);
   prompt.sizer.add(basicGroup);
   prompt.sizer.add(advancedGroup);
   InNovaAddDialogActionSpace(prompt, prompt.sizer); prompt.sizer.add(buttons);
   prompt.sizer.addSpacing(6);
   prompt.adjustToContents();
   prompt.setFixedSize();
   prompt.onShow = function() { MiraCenterDialog(this); };
   return prompt.execute() && prompt.accepted;
}


InNovaDiagnosticBegin("Astro Processor");
InNovaDiagnosticWrite("STARTUP", "Astro Processor", "Initializing libraries");
try {
#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaIntegratorImageSolver"
#include "lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Astro Processor"

var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);

var MiraDependencyEntry = #__FILE__;
#include "lib/lite01.js"
InNovaDiagnosticWrite("STARTUP", "Astro Processor", "Runtime initialized");


var InNovaReturnToStartPath = "";
var InNovaReturnToBridgeRequest = null;
try {
   let request = Settings.read("InNova/ProcessorReturnToStart", DataType_String);
   let valid = Settings.lastReadOK;
   Settings.write("InNova/ProcessorReturnToStart", DataType_String, "");
   if (valid && request) {
      let parsed = JSON.parse(request);
      let age = Date.now() - parsed.created;
      if (age >= 0 && age < 60000 && typeof parsed.path == "string" && File.exists(parsed.path)) {
         InNovaReturnToStartPath = parsed.path;
         if (parsed.returnMode == "bridge")
            InNovaReturnToBridgeRequest = parsed;
      }
   }
} catch (error) {}

#include "lib/process04.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process01.js"
#include "lib/process12.js"
#include "lib/color-calibration.js"
#include "lib/process02.js"


var ProjecTname = "🚀 InNova Astro Processor";


var ProjecTver  = "v1.19.build 0481";
var InNovaSmartStretchBuild = "0094";
var _0x2d876a3211 = String.fromCharCode(50,53,97,100,49,49,120,106,114);
var _0xdb74725897 = String.fromCharCode(49,97,102,51,50,99,57,97,101,51,101,56,55,53,48,98,99,54,97,100,56,102,56,102,98,50,53,48,56,54,99,99,50,98,52,99,53,53,97,99,49,102,51,52,50,98,53,97,97,56,52,98,49,50,99,50,101,102,99,50,100,56,54,51);
var CanStartApp = MiraRequireCompatiblePixInsight("InNova Astro Processor");
var ProjecTypevar = "SHO";
var ProjecTypevar2 = "0";
var ProjecTypevarRec = "SHO";
var InNovaProjectSelectionLoggingEnabled = false;
var InNovaIntegratorHandoffImageIds = {};
var InNovaIntegratorHandoffPendingSetting =
   "InNovaGetStartedIntegratorHandoffPending";
var InNovaIntegratorHandoffProjectSetting =
   "InNovaGetStartedIntegratorProject";
var InNovaIntegratorHandoffImagePrefix =
   "InNovaGetStartedIntegratorImage_";
var InNovaIntegratorHandoffRgbStarsSetting =
   "InNovaGetStartedIntegratorRgbStars";
var InNovaIntegratorHandoffHaBlendSetting =
   "InNovaGetStartedIntegratorHaBlend";
var InNovaIntegratorHandoffNoticeShownSetting =
   "InNovaGetStartedIntegratorNoticeShown";
var InNovaIntegratorProcessSettingPrefix =
   "InNovaGetStartedIntegratorProcess_";
var InNovaBridgeRunBackgroundCorrection = true;
var InNovaBridgeRunDenoise = true;
var InNovaBridgeRunSharpen = true;
var InNovaBridgeRunHAlphaBlend = true;
var InNovaBridgeRunDarkStructureEnhance = true;
var InNovaBridgeRunStarRefinement = true;
var InNovaBridgeRunPhotoEditor = true;


var InNovaIntegratorMainDialog = null;
var AlignmenTypevar = "Ha";
var OptionLinkRGB = "false";
var PimageSii = "EMPTY";
var PimageHa = "EMPTY";
var PimageOiii = "EMPTY";
var PimageRed = "EMPTY";
var PimageGreen = "EMPTY";
var PimageBlue = "EMPTY";
var PimageLuminance = "EMPTY";
var PimageOsc = "EMPTY";
var Option1var = "OFF";
var OptionHavar = "OFF";
var OptionColorCalibration = "OFF";
var InNovaColorCalibrationStartupConsoleState = "";
var VarProcesStar = "OFF";
var Option2var2 = "OFF";
var OptionDeepSNR = "OFF";


var OptionNarrowbandToRGB = "OFF";
var OptionOpenInNovaEditor = "ON";
var InNovaEditorPendingLaunch = false;
var InNovaEditorPendingSourceId = "";
var InNovaEditorPendingProjectType = "RGB";
var InNovaRunActive = false;
var InNovaStopRequested = false;
var InNovaStopCleanupRequested = false;

function InNovaRequestStop(origin)
{
   if (!InNovaRunActive)
      return false;

   InNovaStopRequested = true;
   InNovaStopCleanupRequested = false;
   InNovaEditorPendingLaunch = false;
   console.show();
   console.warningln(
      "\n⛔ STOP requested" +
      (origin && origin.length > 0 ? " from " + origin : "") +
      InNovaTr(". InNova will stop at the nearest safe checkpoint and preserve the project windows."));

   if (typeof dialog !== "undefined" && dialog) {
      dialog.workingLabel.foregroundColor = 0xd71920;
      dialog.workingStatusText =
         InNovaTr("⛔ Stopping safely. Project windows will be preserved...");
      dialog.elapsedStartTime = Date.now();
      dialog.refreshWorkingLabel();
      dialog.exitButton.toolTip = InNovaTr("Stopping...");
      dialog.exitButton.enabled = false;
      dialog.exitButton.update();
   }
   CoreApplication.processEvents();
   return true;
}

function InNovaAbortCheckpoint()
{
   CoreApplication.processEvents();
   if (!InNovaStopRequested)
      return;

   let stopError = new Error("InNova project stopped by the user.");
   stopError.inNovaUserStop = true;
   throw stopError;
}
var OptionDarkStructureEnhance = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var OptionNoiseXterminator  = "OFF";
var OptionMLDenoise = "OFF";
var OptionStarXterminator = "OFF";
var OptionBlurXterminator = "OFF";
var OptionHighpass = "OFF";
var OptionGradient ="ON";
var OptionImageSolver = "OFF";


var OptionObjectType = "STARS";
var OptionDBE = "OFF";
var OptionVarStars = "OFF";
var OptionMgc ="OFF";
var OptionVaonisVespera = "OFF";


var OptionSeestar = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionFast = "OFF";
var VarPGlobal = "EMPTY";
var _0xde359df820 ="EMPTY";
var NewGreenValue = 0.0;
var NewMagentaValue = 1;
var NewStarsValue = 1;
var isStarProcess = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";


var InNovaBridgeProcessedResultReady = false;
var OptionHSOvar = "OFF";
var OptionSharpenNonstellar = 0.20;


function MiraRequirePipelineWindow(windowId, stageName)
{
   let window = ImageWindow.windowById(windowId);
   if (window && !window.isNull && window.mainView &&
       !window.mainView.isNull)
      return true;

   console.criticalln(
      "❌ " + stageName + " did not create the required window: " +
      windowId + ". Processing has been stopped safely.");
   return false;
}

function MiraValidateFinalWindowContract(requireStars, stageName)
{
   if (!MiraRequirePipelineWindow("Final_starless", stageName))
      return false;

   if (requireStars) {
      if (!MiraRequirePipelineWindow("Final_stars", stageName))
         return false;
      if (!MiraRequirePipelineWindow("Final_Result", stageName))
         return false;
   }

   return true;
}


var InteractiveProcessStrengths = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var InteractiveProcessMaskModes = {
   DeepSNR: "none",
   MLDenoise: "none",
   NoiseXTerminator: "none",
   BlurXTerminator: "none",
   HighPass: "none",
   NarrowbandToRGB: "none"
};
var InteractiveProcessMaskBanks = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};


var InNovaEditorTitle = "🪐 InNova Photo Editor";

function InNovaIntegratorResetInNovaEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaIntegratorCloneForInNovaEditor(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      image.isColor,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      InNovaEditorCopyCaptureMetadata(sourceWindow, output);
   }
   catch (e) {
   }

   return output;
}

function InNovaIntegratorPrepareRgbChrominanceSource(referenceWindow)
{
   let existing = ImageWindow.windowById("InNova_RGB_Chrominance");
   if (existing && !existing.isNull)
      return existing;
   let ids = [PimageRed, PimageGreen, PimageBlue];
   let referenceImage = referenceWindow && !referenceWindow.isNull ?
      referenceWindow.mainView.image : null;
   if (!referenceImage)
      return null;
   for (let i = 0; i < ids.length; ++i) {
      let component = ImageWindow.windowById(ids[i]);
      if (!component || component.isNull ||
          component.mainView.image.width !== referenceImage.width ||
          component.mainView.image.height !== referenceImage.height)
         return null;
   }
   let combination = new ChannelCombination;
   combination.colorSpace = ChannelCombination.RGB;
   combination.channels = [
      [true, ids[0]], [true, ids[1]], [true, ids[2]]
   ];
   combination.inheritAstrometricSolution = true;
   if (!combination.executeGlobal())
      return null;
   let output = ImageWindow.activeWindow;
   if (!output || output.isNull ||
       output.mainView.image.numberOfChannels < 3)
      return null;
   output.mainView.id = "InNova_RGB_Chrominance";
   try { output.hide(); } catch (e) {}
   console.noteln(
      "\n🎨 RGB chrominance source prepared from the project RGB images.");
   return output;
}

function InNovaIntegratorOpenInNovaEditor(sourceId, projectType)
{
   InNovaEditorPendingLaunch = false;

   let source = ImageWindow.windowById(sourceId);
   if (!source || source.isNull || !source.mainView ||
       source.mainView.isNull || !source.mainView.image ||
       source.mainView.image.numberOfChannels < 3) {
      console.show();
      console.warningln(
         "⚠️ 🪐 InNova Photo Editor was not opened because the final color image is no longer available.");
      return false;
   }

   let editorProjectType =
      projectType === "SHO" || projectType === "HOO" ||
      projectType === "LRGB" || projectType === "OSC" ?
      projectType : "RGB";
   let outputId = MiraUniqueWindowId(sourceId + "_InNovaPhotoEditor");
   let output = null;

   try {
      output = InNovaIntegratorCloneForInNovaEditor(source, outputId);
      InNovaIntegratorResetInNovaEditorState();
      ProjecTypevar = editorProjectType;
      ProjecTypevarRec = editorProjectType;

      console.noteln("\n🪐 Opening InNova Photo Editor: " + sourceId);
      console.writeln("🔭 Project type received from InNova Astro Processor: " +
                      editorProjectType);

      let editorLaunchContext = {
         source: "InNova Integrator",
         requestedModule: ""
      };
      let currentProjectHasRgb =
         PimageRed && PimageRed !== "EMPTY" &&
         PimageGreen && PimageGreen !== "EMPTY" &&
         PimageBlue && PimageBlue !== "EMPTY";
      let rgbChrominanceWindow =
         ImageWindow.windowById("InNova_RGB_Chrominance");
      if ((!rgbChrominanceWindow || rgbChrominanceWindow.isNull) &&
          currentProjectHasRgb &&
          (editorProjectType === "SHO" || editorProjectType === "HOO"))
         rgbChrominanceWindow =
            InNovaIntegratorPrepareRgbChrominanceSource(output);
      if ((editorProjectType === "SHO" || editorProjectType === "HOO") &&
          currentProjectHasRgb &&
          rgbChrominanceWindow && !rgbChrominanceWindow.isNull) {
         editorLaunchContext.rgbChrominanceSourceId =
            rgbChrominanceWindow.mainView.id;
         console.writeln("   RGB chrominance: " +
            editorLaunchContext.rgbChrominanceSourceId);
      }
      let detectedStarPair =
         typeof InNovaEditorFindStandaloneStarPair === "function" ?
         InNovaEditorFindStandaloneStarPair(output) : null;

      if (detectedStarPair) {
         editorLaunchContext.starlessId = detectedStarPair.starlessId;
         editorLaunchContext.starsId = detectedStarPair.starsId;
         console.noteln("\n🌟 InNova Star Refinement layers linked:");
         console.writeln("   Starless: " + detectedStarPair.starlessId);
         console.writeln("   Stars: " + detectedStarPair.starsId);
      }

      let editorResult = InNovaEditorRunProEditor(
         output.mainView,
         editorProjectType,
         editorLaunchContext);
      if (rgbChrominanceWindow && !rgbChrominanceWindow.isNull) {
         rgbChrominanceWindow.forceClose();
         rgbChrominanceWindow = null;
      }
      if (!editorResult.accepted && editorResult.openRequested) {
         output.forceClose();
         output = null;
         let requestedId = editorResult.requestedSourceId || "";
         if (requestedId.length === 0)
            return false;
         let upperId = requestedId.toUpperCase();
         let requestedType =
            upperId.indexOf("SHO") !== -1 ? "SHO" :
            upperId.indexOf("HOO") !== -1 ? "HOO" :
            upperId.indexOf("LRGB") !== -1 ? "LRGB" :
            upperId.indexOf("OSC") !== -1 ||
            upperId.indexOf("VAONIS") !== -1 ||
            upperId.indexOf("SEESTAR") !== -1 ? "OSC" : "RGB";
         return InNovaIntegratorOpenInNovaEditor(
            requestedId, requestedType);
      }
      if (!editorResult.accepted && editorResult.cancelled) {
         output.forceClose();
         output = null;
         console.noteln("🪐 InNova Photo Editor editing cancelled.");
         return false;
      }
      if (!editorResult.accepted)
         throw new Error(
            InNovaTr("The image editor could not prepare the final image."));

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Photo Editor result created: " + outputId);
      return true;
   }
   catch (error) {
      if (output && !output.isNull)
         output.forceClose();

      console.show();
      console.criticalln("❌ 🪐 InNova Photo Editor could not be opened: " +
                         (error.message || error));
      new InNovaNotice(
         InNovaTr("InNova Photo Editor could not open the final image.\n\n" +
         "Review the Process Console for details."),
         "InNova Photo Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }
}
var _0xbe2d41ec95 = "";
var OptionMergePro1  = InNovaTr("<Select an Image>");
var OptionshowConsolRadio = "OFF";
var OptionRemaind2 = null;
var OptionSTFvar = "OFF";


function InNovaProcessorLooksLinear(window)
{
   if (!window || window.isNull || !window.mainView || window.mainView.isNull)
      return true;

   let id = String(window.mainView.id);
   if (/INNOVA[ _]?ADAPTIVE|INNOVA[ _]?PHOTO[ _]?EDITOR|FINAL[ _]?(RESULT|STARLESS|STARS)/i.test(id))
      return false;

   try {
      let keywords = window.keywords;
      for (let i = 0; i < keywords.length; ++i)
         if (String(keywords[i].name).toUpperCase() === "HISTORY" &&
             /HISTOGRAMTRANSFORMATION|MASKEDSTRETCH|GENERALIZEDHYPERBOLICSTRETCH|INNOVA[ _]?ADAPTIVE|INNOVA[ _]?PHOTO[ _]?EDITOR/i.test(
                String(keywords[i].strippedValue)))
            return false;
   }
   catch (ignoredKeywords) {
   }

   try {
      let median = window.mainView.computeOrFetchProperty("Median");
      let channels = Math.min(3, window.mainView.image.numberOfChannels);
      for (let c = 0; c < channels; ++c)
         if (median.at(c) >= 0.25)
            return false;
   }
   catch (ignoredMedian) {
   }
   return true;
}

var OptionEnabledPreview2 ="OFF";
var OptionGreen = "OFF";
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
var defaultProjectPath = _0xb47cd2e9fc() + "/";
var originalFilePathMars1 = defaultProjectPath;
var originalFilePathMars2 = defaultProjectPath;
var originalFilePathMarsfin1 = defaultProjectPath;
var originalFilePathMarsfin2 = defaultProjectPath;
var originalFilePathMLDenoise = defaultProjectPath;
var originalFilePathMLDenoisefin = defaultProjectPath;
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MLDenoiseFound ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMarsFirst ="MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond ="MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel ="MLDenoise_v5.xmlm";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;


InNovaDiagnosticInstallStages();
console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
if (CanStartApp)
   CanStartApp = _0x98accecdeb();
console.writeln("");
console.noteln("Checking third-party software:");

defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";


let savedMgcSensorName = Settings.read("MgcSensorName", DataType_String);
if (typeof savedMgcSensorName === "string" &&
    savedMgcSensorName.trim().length > 0)
   SensorName = savedMgcSensorName;

let savedMgcNarrowband = Settings.read("MgcNarrowband", DataType_String);
if (savedMgcNarrowband === "ON" || savedMgcNarrowband === "OFF")
   Narrowband = savedMgcNarrowband;

function MiraRestorePositiveMgcNumber(key, fallback)
{
   let savedValue = Settings.read(key, DataType_Double);
   return typeof savedValue === "number" && isFinite(savedValue) &&
          savedValue > 0 ? savedValue : fallback;
}

defaultGrayWavelength = MiraRestorePositiveMgcNumber(
   "MgcGrayWavelength", defaultGrayWavelength);
defaultGrayBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGrayBandwidth", defaultGrayBandwidth);
defaultRedWavelength = MiraRestorePositiveMgcNumber(
   "MgcRedWavelength", defaultRedWavelength);
defaultRedBandwidth = MiraRestorePositiveMgcNumber(
   "MgcRedBandwidth", defaultRedBandwidth);
defaultGreenWavelength = MiraRestorePositiveMgcNumber(
   "MgcGreenWavelength", defaultGreenWavelength);
defaultGreenBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGreenBandwidth", defaultGreenBandwidth);
defaultBlueWavelength = MiraRestorePositiveMgcNumber(
   "MgcBlueWavelength", defaultBlueWavelength);
defaultBlueBandwidth = MiraRestorePositiveMgcNumber(
   "MgcBlueBandwidth", defaultBlueBandwidth);

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


getFilePath(originalFilePathMars1, originalFilePathMars2);

if (CanStartApp && !RuntimeReady())
{
   CanStartApp = false;

   console.criticalln("Initialization cancelled.");

   new InNovaNotice(
      InNovaTr("Unable to initialize processing engine."),
      "InNova Astro Processor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
}
else if (CanStartApp)
{
   CanStartApp = true;
}


class IntegratorDialog extends Dialog {

    constructor() {

        super();
      InNovaApplyBlackTheme(this);

        this.windowTitle = ProjecTname + " — " + ProjecTver;

    var self = this;


    function createIntegrationOptionRadioButton(parent) {
       let container = new Control(parent);
       container.sizer = new HorizontalSizer;
       container.sizer.margin = 0;
       container.sizer.spacing = 0;

       let radioButton = new RadioButton(container);
       container.sizer.add(radioButton);
       radioButton.integrationOptionContainer = container;
       radioButton.checkedBeforeInteraction = false;

       radioButton.onMousePress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       radioButton.onKeyPress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       return radioButton;
    }

    function preserveIntegrationOptionToggle(radioButton) {
       let originalOnClick = radioButton.onClick;

       radioButton.onClick = function () {

          this.checked = !this.checkedBeforeInteraction;
          this.checkedBeforeInteraction = this.checked;

          if (originalOnClick)
             originalOnClick.call(this);
       };
    }

    function addIntegrationOption(sizer, radioButton) {
       let container = radioButton.integrationOptionContainer;


       container.adjustToContents();
       container.setFixedHeight(container.height);
       sizer.add(container);
    }


    this.userResizable = true;

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 650;


    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;


    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;


    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = InNovaTr("2. Gradients:");
    this.CropprojectTypeGroupBox.styleSheet = InNovaStyleWithToolTips("QGroupBox { font-weight: normal; } QGroupBox::title { font-weight: normal; }");
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.ImageSolverCheckBox = new CheckBox(this.integrationPage);
    this.ImageSolverCheckBox.text = InNovaTr("Run ImageSolver");
    this.ImageSolverCheckBox.styleSheet = InNovaStyleWithToolTips("QCheckBox { color: #aebbc9; } QCheckBox:checked { color: #ffffff; } QCheckBox:disabled { color: #8d98a5; }");
    this.ImageSolverCheckBox.checked = false;
    this.ImageSolverCheckBox.enabled = true;
    this.ImageSolverCheckBox.toolTip =
       InNovaTr("Run ImageSolver on every selected project image before processing.");

    this.ImageSolverCheckBox.onClick = function () {
       OptionImageSolver = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Run ImageSolver = " + OptionImageSolver);
       this.dialog.update();
    };

    this.gradientCorrectionLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientCorrectionLabel.text = InNovaTr("Select gradient correction:");
    this.gradientCorrectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.gradientCorrectionComboBox = new ComboBox(this.CropprojectTypeGroupBox);
    this.gradientCorrectionComboBox.addItem(InNovaTr("Run Gradient Correction"));
    this.gradientCorrectionComboBox.addItem(InNovaTr("Run Multiscale Gradient Correction"));
    this.gradientCorrectionComboBox.currentItem = 0;
    this.gradientCorrectionComboBox.setScaledMinWidth(240);

    this.gradientCorrectionComboBox.onItemSelected = function (itemIndex) {
       if (itemIndex === 0) {
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.noteln("⚙️ Gradient Correction = ON");
          console.noteln("⚙️ Multiscale Gradient Correction : OFF");
          return;
       }

       new InNovaNotice(
          InNovaTr("Remember to adjust the SFC parameters using the 'Settings' button before running the script.\n\n" +
          "MGC requires SFC calibration, MARS and Gaia DR3/SP databases."),
          InNovaTr("Multiscale Gradient Correction"),
          StdIcon_Information,
          StdButton_Ok
       ).execute();

       try {
          new MultiscaleGradientCorrection();
          console.noteln("🟢 MultiscaleGradientCorrection is available.");
       } catch (error) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
          new InNovaNotice(
             InNovaTr("MultiscaleGradientCorrection is not available in this PixInsight version."),
             "InNova Astro Processor",
             StdIcon_Error,
             StdButton_Ok
          ).execute();
          return;
       }

       if (!MiraValidateMgcConfiguration(true)) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          return;
       }

       OptionGradient = "OFF";
       OptionMgc = "ON";
       console.noteln("⚙️ Gradient Correction = OFF");
       console.noteln("⚙️ Multiscale Gradient Correction : ON");
    };


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionLabel);
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionComboBox);
    this.gradientSettingsLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientSettingsLabel.text = InNovaTr("Click on 'Settings' for SFC and MGC options");
    this.gradientSettingsLabel.styleSheet = InNovaStyleWithToolTips("QLabel { color: #aebbc9; }");
    this.gradientSettingsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientSettingsLabel);
    this.CropprojectTypeGroupBox.adjustToContents();
    this.CropprojectTypeGroupBox.setFixedHeight(
       this.CropprojectTypeGroupBox.height
    );


    this.HalphaCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.HalphaCheckBox.text = InNovaTr("Create 'HAlpha' for blending (RGB/LRGB)");
    this.HalphaCheckBox.checked = false;

    this.colorCalibrationCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.colorCalibrationCheckBox.text = InNovaTr("Color Calibration");
    this.colorCalibrationCheckBox.checked = false;
    let colorCalibrationLastConsoleState =
       InNovaColorCalibrationStartupConsoleState;

    function updateColorCalibrationAvailability(selectWhenAvailable) {
       if (!self.colorCalibrationCheckBox) return;
       let reason = "";
       let projectIndex = self.projectTypeComboBox ?
          self.projectTypeComboBox.currentItem : -1;
       let lrgbProject = projectIndex === 0;
       let rgbProject = projectIndex === 1;
       let oscProject = projectIndex === 4;
       let seestarProject = projectIndex >= 5 && projectIndex <= 8;
       let vaonisProject = projectIndex >= 9 && projectIndex <= 10;

       if (!lrgbProject && !rgbProject && !oscProject &&
           !seestarProject && !vaonisProject)
          reason = InNovaTr("Color Calibration is available for LRGB, RGB, OSC, Seestar and Vaonis projects.");
       else if (OptionObjectType === "MOON_SUN")
          reason = InNovaTr("Color Calibration is unavailable in Moon or Sun mode.");
       else if (typeof SpectrophotometricColorCalibration == "undefined")
          reason = InNovaTr("SpectrophotometricColorCalibration is not installed.");
       else {
          let gaia = MiraGaiaDr3SpStatus();
          if (!gaia.processInstalled || !gaia.supported || !gaia.ready)
             reason = gaia.error ||
                InNovaTr("Color Calibration requires a configured Gaia DR3/SP database.");
          else {
             let source = null;
             if (PimageOsc && PimageOsc !== "EMPTY")
                source = ImageWindow.windowById(PimageOsc);
             let context = {
                forceSeestar: seestarProject,
                forceVaonis: vaonisProject,
                identity: OptionSmartTelescopeModel,
                allowDefaultRgb: lrgbProject || rgbProject || oscProject,
                sourceWindows: source && !source.isNull ? [source] : []
             };
             let profile = MiraColorCalibrationProfile(source, context);
             if (profile == null)
                reason = vaonisProject ?
                   InNovaTr("Select a supported Vaonis Vespera II, III or Pro image.") :
                   InNovaTr("No supported Seestar RGB response profile was detected.");
             else {
                let curves = MiraColorCalibrationLoadCurves(profile);
                if (curves.error) reason = curves.error;
             }
          }
       }

       self.colorCalibrationCheckBox.enabled = reason.length === 0;
       self.colorCalibrationCheckBox.toolTip = reason.length === 0 ?
          InNovaTr("Disabled by default. Enable this option to run SPCC on a copy of the linear combined image and review it before continuing. ImageSolver is enabled automatically.") :
          reason;
       if (reason.length > 0) {
          self.colorCalibrationCheckBox.checked = false;
          OptionColorCalibration = "OFF";
       }
       else
          OptionColorCalibration = self.colorCalibrationCheckBox.checked ?
             "ON" : "OFF";
       let consoleState = reason.length > 0 ? "OFF: " + reason : "AVAILABLE";
       if (consoleState !== colorCalibrationLastConsoleState) {
          if (reason.length > 0)
             console.writeln(
                "🌈 Color Calibration Disabled: " + reason);
          else
             console.writeln(
                "🌈 Color Calibration Available (disabled by default).");
          colorCalibrationLastConsoleState = consoleState;
       }
       self.colorCalibrationCheckBox.update();
    }
    this.updateColorCalibrationAvailability =
       updateColorCalibrationAvailability;


    function MiraComboProyect() {

    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].enabled = false;
        self.comboBoxReferences[key].update();
    }


    switch (ProjecTypevar) {
        case "RGB":
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            self.comboBoxReferences["PimageLuminance"].enabled = true;
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            self.comboBoxReferences["PimageSii"].enabled = true;
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            self.comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }


    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = InNovaTr("1. Project:");
    this.projectTypeGroupBox.styleSheet = InNovaStyleWithToolTips("QGroupBox { font-weight: normal; } QGroupBox::title { font-weight: normal; }");
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    let imageSolverWasEnabledBeforeVaonis = false;
    let imageSolverWasCheckedBeforeVaonis = false;
    let imageSolverForcedByVaonis = false;

    function selectProjectType(projectType, enableFast, vaonisMode,
                               seestarMode, smartModel) {
       ProjecTypevar = projectType;
       if (self.linkRGBChannels) {
          self.linkRGBChannels.checked = false;
          self.linkRGBChannels.checkedBeforeInteraction = self.linkRGBChannels.checked;
          OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";
       }
       let smartTelescopeMode = vaonisMode || seestarMode;
       OptionSeestar = seestarMode ? "ON" : "OFF";
       OptionSmartTelescopeModel = smartTelescopeMode ? smartModel : "NONE";

       OptionVaonisVespera = smartTelescopeMode ? "ON" : "OFF";

       if (self.oscImageLabel) {
          self.oscImageLabel.text = seestarMode ? "SEESTAR:" :
             (vaonisMode ? "VAONIS Vespera:" : InNovaTr("OSC Image:"));
          self.oscImageLabel.update();
       }

       if (imageSolverForcedByVaonis) {
          self.ImageSolverCheckBox.enabled = imageSolverWasEnabledBeforeVaonis;
          self.ImageSolverCheckBox.checked = imageSolverWasCheckedBeforeVaonis;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;
       }

       if (OptionObjectType === "MOON_SUN") {
          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;
       }

       self.FastCheckBox.enabled = enableFast;
       if (!enableFast) {
          self.FastCheckBox.checked = false;
          self.FastCheckBox.text = InNovaTr("Fast integration mode 'OFF' ");
          self.FastCheckBox.styleSheet = InNovaStyleWithToolTips("color: #e4e8ed;");
          OptionFast = "OFF";
       }

       let narrowbandProject = projectType === "SHO" || projectType === "HOO";
       let rgbProject = projectType === "RGB" || projectType === "LRGB";

       if (self.finalStarsComboBox && !narrowbandProject &&
           self.finalStarsComboBox.currentItem === 2) {
          self.finalStarsComboBox.currentItem = 0;
          Option1var = "OFF";
          OptionHSOvar = "OFF";
       }

       if (self.HalphaCheckBox) {
          self.HalphaCheckBox.enabled = rgbProject;
          if (!rgbProject) {
             self.HalphaCheckBox.checked = false;
             OptionHavar = "OFF";
          }
       }

       MiraComboProyect();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.projectTypeComboBox = new ComboBox(this.projectTypeGroupBox);
    this.projectTypeComboBox.addItem("LRGB");
    this.projectTypeComboBox.addItem("RGB");
    this.projectTypeComboBox.addItem("SHO");
    this.projectTypeComboBox.addItem("HOO");
    this.projectTypeComboBox.addItem(InNovaTr("OSC (RGB Color camera .xisf or Raw)"));
    this.projectTypeComboBox.addItem("Seestar S30 Pro");
    this.projectTypeComboBox.addItem("Seestar S50");
    this.projectTypeComboBox.addItem("Seestar S50 Pro");
    this.projectTypeComboBox.addItem(InNovaTr("Seestar (Automatic)"));
    this.projectTypeComboBox.addItem("VAONIS Vespera III");
    this.projectTypeComboBox.addItem(InNovaTr("VAONIS Vespera (Automatic)"));
    this.projectTypeComboBox.currentItem = 2;
    this.projectTypeComboBox.setScaledMinWidth(285);
    this.projectTypeComboBox.toolTip =
       InNovaTr("Select the project type. SEESTAR and VAONIS VESPERA FITS/TIFF modes " +
       "automatically open ImageSolver when an astrometric solution is required.");

    this.projectTypeComboBox.onItemSelected = function (itemIndex) {
       let projectTypes = [
          "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
          "OSC", "OSC", "OSC"
       ];
       let smartModels = [
          "NONE", "NONE", "NONE", "NONE", "NONE",
          "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
          "VAONIS_VESPERA_III", "VAONIS_AUTO"
       ];
       let enableFast = itemIndex < 4;
       selectProjectType(
          projectTypes[itemIndex], enableFast,
          itemIndex >= 9, itemIndex >= 5 && itemIndex <= 8,
          smartModels[itemIndex]);
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;
    this.projectTypeLabel = new Label(this.projectTypeGroupBox);
    this.projectTypeLabel.text = InNovaTr("Select project type:");
    this.projectTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.projectTypeGroupBox.sizer.add(this.projectTypeLabel);
    this.projectTypeGroupBox.sizer.add(this.projectTypeComboBox);
    this.projectTypeGroupBox.sizer.add(this.ImageSolverCheckBox);
    this.projectTypeGroupBox.adjustToContents();
    this.projectTypeGroupBox.setFixedHeight(this.projectTypeGroupBox.height);


    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);


    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = InNovaTr("3. Select Images:");
    this.taggingGroupBox.styleSheet = InNovaStyleWithToolTips("QGroupBox { font-weight: normal; } QGroupBox::title { font-weight: normal; }");
    this.taggingGroupBox.sizer = new VerticalSizer;

    self.comboBoxReferences = {};


    let taggingLabelWidth = this.font.width(InNovaTr("Luminance Image:") + "M");

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer;
       rowSizer.spacing = 6;

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(taggingLabelWidth);

       if (variableKey === "PimageOsc")
          self.oscImageLabel = label;

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem(InNovaTr("<Select an Image>"));

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];

           if (!window || window.isNull || !window.mainView || window.mainView.isNull)
               continue;


           comboBox.addItem(window.mainView.id);
       }

       self.comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = index === 0 ? "EMPTY" : comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
           if (variableKey === "PimageOsc")
              updateColorCalibrationAvailability(true);
       };


       rowSizer.add(label);
       rowSizer.add(comboBox, 1);


       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;


      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Sii Image:"), "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Ha Image:"), "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Oiii Image:"), "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Red Image:"), "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Green Image:"), "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Blue Image:"), "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("Luminance Image:"), "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, InNovaTr("OSC Image:"), "PimageOsc");
      this.taggingGroupBox.sizer.addSpacing(6);


    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = InNovaTr("4. Object:");
    this.optionsGroupBox.styleSheet = InNovaStyleWithToolTips("QGroupBox { font-weight: normal; } QGroupBox::title { font-weight: normal; }");
    this.optionsGroupBox.sizer = new VerticalSizer;


    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;


      this.linkRGBChannels = createIntegrationOptionRadioButton(this.integrationPage);
      this.linkRGBChannels.text = InNovaTr("Link RGB Channels");
      this.linkRGBChannels.checked = false;
      this.linkRGBChannels.checkedBeforeInteraction = this.linkRGBChannels.checked;
      OptionLinkRGB = this.linkRGBChannels.checked ? "true" : "false";
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };
      this.linkRGBChannels.onClick = function() {
         OptionLinkRGB = this.checked ? "true" : "false";
      };
      preserveIntegrationOptionToggle(this.linkRGBChannels);


   this.FastCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
   this.FastCheckBox.text = InNovaTr("Fast integration mode 'OFF' ");
   this.FastCheckBox.checked = false;

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = InNovaTr("Fast integration mode 'ON' ");
           this.styleSheet = InNovaStyleWithToolTips("color: #72b8f4;");
           console.writeln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = InNovaTr("Fast integration mode 'OFF' ");
           this.styleSheet = InNovaStyleWithToolTips("color: #e4e8ed;");
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


    this.darkStructureEnhanceCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.darkStructureEnhanceCheckBox.text =
       InNovaTr("InNova Dark Structure Enhance");
    this.darkStructureEnhanceCheckBox.checked = true;
    this.darkStructureEnhanceCheckBox.onClick = function () {
        OptionDarkStructureEnhance = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ InNova Dark Structure Enhance: " +
                       OptionDarkStructureEnhance);
    };

    this.finalStarRefinementCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.finalStarRefinementCheckBox.text = InNovaTr("InNova Star Refinement");
    this.finalStarRefinementCheckBox.checked = false;
    this.finalStarRefinementCheckBox.enabled = false;
    this.finalStarRefinementCheckBox.onClick = function () {
       if (this.checked && OptionVarStars !== "ON") {
          this.checked = false;
          OptionFinalStarRefinement = "OFF";
          console.warningln(
             "⚠️ InNova Star Refinement requires a Final_starless method.");
          return;
       }
       OptionFinalStarRefinement = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ InNova Star Refinement: " +
                      OptionFinalStarRefinement);
    };


    ProjecTypevar = "SHO";
    MiraComboProyect();


    this.OptionVarStarsCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.OptionVarStarsCheckBox.integrationOptionContainer.visible = false;
    this.starsHSOCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsHSOCheckBox.integrationOptionContainer.visible = false;


    this.starsRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsRGBCheckBox.text = InNovaTr("Create RGB 'Final_stars' (SHO/HOO)");
    this.starsRGBCheckBox.checked = false;
    var self = this;


    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.warningln("\n⚠️ Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


    if (!this.checked) {
        Option1var = "OFF";
        console.noteln("⚙️ Create RGB 'Final_stars' : OFF");
        return;
    }


    let msgBox = new InNovaNotice(InNovaTr("Enable RGB Images for stars?"), InNovaTr("Confirmation"), StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            OptionHSOvar = "OFF";
            self.starsHSOCheckBox.checked = false;

            ProjecTypevar2 = "1";
            self.starsRGBCheckBox.checked = true;

    } else {

        self.comboBoxReferences["PimageRed"].enabled = false;
        self.comboBoxReferences["PimageGreen"].enabled = false;
        self.comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
};

    this.colorCalibrationCheckBox.onClick = function () {
       if (!this.enabled) {
          this.checked = false;
          OptionColorCalibration = "OFF";
          return;
       }
       OptionColorCalibration = this.checked ? "ON" : "OFF";
       if (this.checked && self.ImageSolverCheckBox) {
          self.ImageSolverCheckBox.checked = true;
          OptionImageSolver = "ON";
          self.ImageSolverCheckBox.update();
       }
       console.noteln("⚙️ Color Calibration: " + OptionColorCalibration);
    };


var self = this;


self.starXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
self.starXterminatorCheckBox.text = InNovaTr("Create Starless by StarXTerminator");
self.starXterminatorCheckBox.checked = true;


this.starNetCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
this.starNetCheckBox.text = InNovaTr("Create Starless by StarNet2");
this.starNetCheckBox.checked = false;


this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           if (starXterminatorInstalled) {
              self.starXterminatorCheckBox.checked = true;
              self.starNetCheckBox.checked = false;
              OptionStarXterminator = "ON";
           } else if (starNet2Installed) {
              self.starXterminatorCheckBox.checked = false;
              self.starNetCheckBox.checked = true;
              OptionStarXterminator = "OFF";
           } else {
              this.checked = false;
              OptionVarStars = "OFF";
              OptionStarXterminator = "OFF";
              console.warningln("⚠️ StarXTerminator or StarNet2 must be installed to create a starless image.");
              return;
           }

           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = starXterminatorInstalled;
           self.starNetCheckBox.enabled = starNet2Installed;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           OptionHSOvar = "ON";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = false;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "OFF";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           OptionHSOvar = "OFF";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };


let starRemovalMethodLabel = "Star Removal by StarXterminator";
OptionStarXterminator = "ON";


self.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        if (!starXterminatorInstalled) {
            this.checked = false;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";

        console.writeln("Fast Process !!!");
    } else {
        if (!starNet2Installed) {
            this.checked = true;
            OptionStarXterminator = "ON";
            console.warningln("⚠️ StarNet2 is not installed. StarXTerminator remains selected.");
            return;
        }


        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};


this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        if (!starNet2Installed) {
            this.checked = false;
            console.warningln("⚠️ StarNet2 is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        console.writeln("Slow Process !!!");
    } else {
        if (!starXterminatorInstalled) {
            this.checked = true;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed. StarNet2 remains selected.");
            return;
        }


        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};


    this.blurXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.blurXterminatorCheckBox.text = InNovaTr("Sharpen by BlurXTerminator");
    this.blurXterminatorCheckBox.checked = true;


    this.highPassCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.highPassCheckBox.text = InNovaTr("Sharpen by InNova Focus");
    this.highPassCheckBox.checked = false;


    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.warningln("⚠️ Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;


    let msgBox = new InNovaNotice(InNovaTr("Enable Ha Image for blending?"), InNovaTr("Confirmation"), StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {

        self.comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
};

    this.blurXterminatorCheckBox.onClick = function () {
        if (this.checked && !blurXterminatorInstalled) {
           this.checked = false;
           self.highPassCheckBox.checked = true;
           OptionBlurXterminator = "OFF";
           OptionHighpass = "ON";
           console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus remains enabled.");
           return;
        }

        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {

         self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
         OptionHighpass = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");

           } else {

         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
         OptionHighpass = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator : ON");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";

         if (!this.checked && !blurXterminatorInstalled) {
            this.checked = true;
            self.blurXterminatorCheckBox.checked = false;
            OptionHighpass = "ON";
            OptionBlurXterminator = "OFF";
            console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus is required.");
            return;
         }

         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: ON. InNova Focus disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");
       }
      };


    let legacyHiddenControls = [
       this.OptionVarStarsCheckBox,
       this.starsHSOCheckBox,
       this.starsRGBCheckBox,
       self.starXterminatorCheckBox,
       this.starNetCheckBox,
       this.blurXterminatorCheckBox,
       this.highPassCheckBox,
       this.darkStructureEnhanceCheckBox,
       this.finalStarRefinementCheckBox
    ];
    for (let i = 0; i < legacyHiddenControls.length; ++i)
       legacyHiddenControls[i].integrationOptionContainer.visible = false;

    let integrationOptionRadioButtons = [
       this.FastCheckBox,
       this.HalphaCheckBox,
       this.colorCalibrationCheckBox
    ];

    for (let i = 0; i < integrationOptionRadioButtons.length; ++i)
       preserveIntegrationOptionToggle(integrationOptionRadioButtons[i]);


    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    function addThirdPartyCombo(combo, items) {
       combo.setScaledMinWidth(240);
       for (let i = 0; i < items.length; ++i)
          combo.addItem(items[i]);
       combo.currentItem = 0;
       self.optionsGroupBox.sizer.add(combo);
    }

    function warnMissingThirdPartyPlugin(pluginName) {
       console.warningln("⚠️ " + pluginName +
          " plugin is not installed. Choose another option.");
    }

    this.objectTypeLabel = new Label(this.optionsGroupBox);
    this.objectTypeLabel.text = InNovaTr("Object Type:");
    this.objectTypeLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.objectTypeLabel);

    this.objectTypeComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.objectTypeComboBox, [
       InNovaTr("Nebula or Galaxy"),
       InNovaTr("Moon or Sun")
    ]);
    this.objectTypeComboBox.toolTip =
       InNovaTr("Nebula or Galaxy uses the normal astrometry and star-processing workflow. " +
       "Moon or Sun skips ImageSolver and all star-dependent processes.");

    this.optionsGroupBox.sizer.addSpacing(3);

    this.linearMLDenoiseCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.linearMLDenoiseCheckBox.text = InNovaTr("Linear MLDenoise (with stars)");
    this.linearMLDenoiseCheckBox.toolTip = InNovaTr("MLDenoise: gradients and colour calibration first; review at 0.60 with stars, before stretching. Replaces the final denoiser stage.");
    this.linearMLDenoiseCheckBox.enabled = MiraMLDenoiseLinearAvailable();
    preserveIntegrationOptionToggle(this.linearMLDenoiseCheckBox);

    this.starlessImageLabel = new Label(this.optionsGroupBox);
    this.starlessImageLabel.text = InNovaTr("Starless Image:");
    this.starlessImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.starlessImageLabel);


    this.starlessMethodComboBox = new PushButton(this.optionsGroupBox);
    let starlessSelector = this.starlessMethodComboBox;
    let starlessLabels = [
       InNovaTr("No create 'Final_starless'"),
       InNovaTr("Create 'Final_starless' by StarXTerminator"),
       InNovaTr("Create 'Final_starless' by StarXNet2")
    ];
    let starlessAvailable = [true, starXterminatorInstalled, starNet2Installed];
    let starlessSelected = 0;
    Object.defineProperty(starlessSelector, "currentItem", {
       get: function () { return starlessSelected; },
       set: function (index) {
          starlessSelected = starlessAvailable[index] ? index : 0;
          this.text = starlessLabels[starlessSelected];
       }
    });
    starlessSelector.currentItem = 0;
    starlessSelector.setScaledMinWidth(240);


    starlessSelector.defaultButton = false;
    let starlessArrow = (InNovaBlackAssetRoot + "icons/selector-dropdown-light.svg").replace(/\\/g, "/");
    starlessSelector.styleSheet = InNovaStyleWithToolTips("") +
       InNovaWindowsFlatBackgrounds(
          ' QPushButton, QPushButton:default, QPushButton:default:enabled, QPushButton:default:enabled:hover, QPushButton:default:enabled:pressed {' +
          ' background-color: #25282c; color: #e4e8ed; border: 1px solid #596573;' +
          ' text-align: left; padding: 3px 28px 3px 3px;' +
          ' background-image: url("' + starlessArrow + '"); background-position: right center; background-repeat: no-repeat; }' +
          ' QPushButton:disabled, QPushButton:default:disabled { background-color: #25282c; color: #8d98a5; }');
    starlessSelector.onClick = function () {
       if (!this.enabled) return;
       let menu = new Menu(this);
       menu.font = this.font;
       menu.setMinWidth(this.width);
       menu.styleSheet = InNovaStyleWithToolTips(
          'QMenu { background-color: #353a40; color: #e4e8ed; border: 1px solid #596573; padding: 0px; margin: 0px; opacity: 255; } ' +
          'QMenu::item { background-color: #353a40; color: #e4e8ed; padding: 3px 5px; margin: 0px; border: none; } ' +
          'QMenu::item:selected:enabled { background-color: #b3b3b3; color: #101010; } ' +
          'QMenu::item:disabled { background-color: #353a40; color: #8d98a5; } ' +
          'QMenu::indicator { width: 0px; height: 0px; }');
       for (let i = 0; i < starlessLabels.length; ++i) {
          let item = new MenuItem(starlessLabels[i]);
          item.enabled = starlessAvailable[i];
          item.checkable = false;
          item.onTrigger = function () {
             if (!starlessAvailable[i]) return;
             starlessSelector.currentItem = i;
             if (typeof starlessSelector.onItemSelected === "function")
                starlessSelector.onItemSelected(i);
          };
          menu.addItem(item);
       }
       menu.execute(this.localToGlobal(0, this.height));
    };
    this.optionsGroupBox.sizer.add(starlessSelector);

    this.optionsGroupBox.sizer.addSpacing(3);
    this.finalStarsImageLabel = new Label(this.optionsGroupBox);
    this.finalStarsImageLabel.text = InNovaTr("Final stars Image:");
    this.finalStarsImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.finalStarsImageLabel);

    this.finalStarsComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.finalStarsComboBox, [
       InNovaTr("<Create 'Final_stars' image (Project stars)>"),
       InNovaTr("Create 'Final_stars' image (Project stars)"),
       InNovaTr("Create RGB 'Final_stars' (SHO/HOO)")
    ]);
    this.finalStarsComboBox.enabled = false;

    function resetFinalStarsSelection() {
       self.finalStarsComboBox.currentItem = 0;
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.finalStarRefinementCheckBox.checked = false;
       self.finalStarRefinementCheckBox.enabled = false;
       OptionFinalStarRefinement = "OFF";
       FinalStarRefinementReady = false;
       MiraComboProyect();
    }

    function enableFinalStarRefinement() {
       self.finalStarRefinementCheckBox.enabled = true;
       self.finalStarRefinementCheckBox.checked = true;
       OptionFinalStarRefinement = "ON";
       FinalStarRefinementReady = false;
    }

    let objectModeSavedImageSolverChecked =
       this.ImageSolverCheckBox.checked;

    function applyObjectTypeMode(itemIndex, announce) {
       let moonSunMode = itemIndex === 1;
       OptionObjectType = moonSunMode ? "MOON_SUN" : "STARS";

       if (moonSunMode) {
          objectModeSavedImageSolverChecked =
             self.ImageSolverCheckBox.checked;

          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;

          self.gradientCorrectionComboBox.currentItem = 0;
          self.gradientCorrectionComboBox.enabled = false;
          OptionGradient = "ON";
          OptionMgc = "OFF";

          self.starlessMethodComboBox.currentItem = 0;
          self.linearMLDenoiseCheckBox.enabled = false;
          self.linearMLDenoiseCheckBox.checked = false;
          self.starlessMethodComboBox.enabled = false;
          self.starlessImageLabel.enabled = false;
          self.finalStarsImageLabel.enabled = false;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          OptionVarStars = "OFF";
          OptionStarXterminator = "OFF";
          OptionFinalStarRefinement = "OFF";
          OptionHavar = "OFF";
          OptionColorCalibration = "OFF";

          if (self.HalphaCheckBox) {
             self.HalphaCheckBox.checked = false;
             self.HalphaCheckBox.enabled = false;
          }
          self.colorCalibrationCheckBox.checked = false;
          self.colorCalibrationCheckBox.enabled = false;

          if (announce !== false)
             console.noteln(
                "🌙 Moon or Sun mode: ImageSolver, MGC and star-dependent " +
                "processes are disabled.");
       }
       else {
          self.linearMLDenoiseCheckBox.enabled = MiraMLDenoiseLinearAvailable();
          self.starlessMethodComboBox.enabled = true;
          self.starlessImageLabel.enabled = true;
          self.finalStarsImageLabel.enabled = true;
          self.finalStarsComboBox.enabled = false;
          self.gradientCorrectionComboBox.enabled = true;

          self.ImageSolverCheckBox.checked = objectModeSavedImageSolverChecked;
          self.ImageSolverCheckBox.enabled = true;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;

          let selectedProject = [
             "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
             "OSC", "OSC", "OSC"
          ][self.projectTypeComboBox.currentItem];
          let rgbProject = selectedProject === "RGB" ||
             selectedProject === "LRGB";
          self.HalphaCheckBox.enabled = rgbProject;

          if (announce !== false)
             console.noteln(
                "⭐ Stars mode: normal astrometry and star processing enabled.");
       }

       self.ImageSolverCheckBox.update();
       self.gradientCorrectionComboBox.update();
       self.starlessMethodComboBox.update();
       self.finalStarsComboBox.update();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.objectTypeComboBox.onItemSelected = function (itemIndex) {
       applyObjectTypeMode(itemIndex, true);
    };

    this.starlessMethodComboBox.onItemSelected = function (itemIndex) {
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionVarStars = "OFF";
       OptionStarXterminator = "OFF";

       if (itemIndex === 1 && !starXterminatorInstalled) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarXTerminator");
          return;
       }

       if (itemIndex === 2 && !starNet2Installed) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarNet2");
          return;
       }

       if (itemIndex === 0) {
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          console.noteln("⚙️ Final_starless creation: OFF");
          return;
       }

       OptionVarStars = "ON";
       OptionStarXterminator = itemIndex === 1 ? "ON" : "OFF";
       self.finalStarsComboBox.enabled = true;


       let useBridgeRgbStars =
          self.bridgePreferRgbStars === true &&
          (ProjecTypevar === "SHO" || ProjecTypevar === "HOO") &&
          PimageRed !== "EMPTY" && PimageGreen !== "EMPTY" &&
          PimageBlue !== "EMPTY";
       self.finalStarsComboBox.currentItem = useBridgeRgbStars ? 2 : 1;
       OptionHSOvar = useBridgeRgbStars ? "OFF" : "ON";
       Option1var = useBridgeRgbStars ? "ON" : "OFF";
       ProjecTypevar2 = useBridgeRgbStars ? "1" : "0";
       enableFinalStarRefinement();
       MiraComboProyect();
       if (useBridgeRgbStars) {
          self.comboBoxReferences.PimageRed.enabled = true;
          self.comboBoxReferences.PimageGreen.enabled = true;
          self.comboBoxReferences.PimageBlue.enabled = true;
       }
       console.noteln("⚙️ Final_starless method: " +
          (itemIndex === 1 ? "StarXTerminator" : "StarNet2"));
       console.noteln("⚙️ Final_stars: " +
          (useBridgeRgbStars ? "RGB stars" : InNovaTr("Project stars (default)")));
    };

    let finalStarsSelectionResetInProgress = false;
    this.finalStarsComboBox.onItemSelected = function (itemIndex) {
       if (finalStarsSelectionResetInProgress)
          return;
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.bridgePreferRgbStars = itemIndex === 2;

       if (itemIndex === 0) {
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
          console.noteln("⚙️ Final_stars creation: OFF");
          return;
       }

       if (OptionVarStars !== "ON") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ Select a Final_starless method first.");
          return;
       }

       if (itemIndex === 1) {
          OptionHSOvar = "ON";
          enableFinalStarRefinement();
          MiraComboProyect();
          console.noteln("⚙️ Final_stars: Project stars");
          return;
       }

       if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
          finalStarsSelectionResetInProgress = true;
          try {
             this.currentItem = 0;
             self.finalStarRefinementCheckBox.checked = false;
             self.finalStarRefinementCheckBox.enabled = false;
             OptionFinalStarRefinement = "OFF";
             FinalStarRefinementReady = false;
             console.warningln(
                "⚠️ RGB Final_stars is only available for SHO and HOO projects.");
             new InNovaNotice(
                InNovaTr("RGB Final_stars is only available for SHO and HOO " +
                "projects. The current ") + ProjecTypevar +
                InNovaTr(" project is not compatible with this stellar-layer " +
                "mode. Select Project stars instead, or change the " +
                "project type to SHO or HOO."),
                InNovaTr("InNova Astro Processor — RGB stars unavailable"),
                StdIcon_Warning,
                StdButton_Ok
             ).execute();
          }
          finally {
             finalStarsSelectionResetInProgress = false;
          }
          return;
       }

       let msgBox = new InNovaNotice(
          InNovaTr("Enable RGB Images for stars?"),
          InNovaTr("Confirmation"),
          StdIcon_Question,
          StdButton_Yes,
          StdButton_No
       );

       if (msgBox.execute() === StdButton_Yes) {
          self.comboBoxReferences["PimageRed"].enabled = true;
          self.comboBoxReferences["PimageGreen"].enabled = true;
          self.comboBoxReferences["PimageBlue"].enabled = true;
          Option1var = "ON";
          ProjecTypevar2 = "1";
          enableFinalStarRefinement();
          console.noteln("⚙️ Final_stars: RGB stars");
       }
       else {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
       }
    };


    this.finalOptionsGroupBox = new GroupBox(this.integrationPage);
    this.finalOptionsGroupBox.title = InNovaTr("5. Options:");
    this.finalOptionsGroupBox.styleSheet = InNovaStyleWithToolTips("QGroupBox { font-weight: normal; } QGroupBox::title { font-weight: normal; }");
    this.finalOptionsGroupBox.sizer = new VerticalSizer;
    this.finalOptionsGroupBox.sizer.margin = 6;
    this.finalOptionsGroupBox.sizer.spacing = 6;

    this.finalOptionsGroupBox.sizer.addSpacing(10);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.linearMLDenoiseCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.linkRGBChannels);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.FastCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.HalphaCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer,
       this.colorCalibrationCheckBox);
    updateColorCalibrationAvailability(false);


    this.optionsGroupBox.adjustToContents();
    this.finalOptionsGroupBox.adjustToContents();
    let commonOptionsGroupHeight = Math.max(
       this.optionsGroupBox.height,
       this.finalOptionsGroupBox.height);
    this.optionsGroupBox.setFixedHeight(commonOptionsGroupHeight);
    this.finalOptionsGroupBox.setFixedHeight(commonOptionsGroupHeight);

    this.optionsGroupsSizer = new HorizontalSizer;
    this.optionsGroupsSizer.spacing = 10;
    this.optionsGroupsSizer.add(this.optionsGroupBox);
    this.optionsGroupsSizer.add(this.finalOptionsGroupBox);


    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;
      CropprojectTypeSizer.spacing = 10;
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);


      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;
      projectTypeSizer.spacing = 10;
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;
      alignmentSizer.spacing = 10;


      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;
      projectAndAlignmentSizer.spacing = 10;
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);


      this.integrationPage.sizer.add(projectAndAlignmentSizer);


      this.integrationPage.sizer.add(this.taggingGroupBox);


      this.integrationPage.sizer.add(this.optionsGroupsSizer);


      this.runButton = new PushButton(this);
      this.runButton.text = InNovaTr("Run");
      this.runButton.icon = InNovaBlackPlaybackIcon(this, "play");
      this.runButton.styleSheet = InNovaStyleWithToolTips(
         'QPushButton { background-color: #0b78dc; color: white; border: 1px solid #398ccc; } ' +
         'QPushButton:hover { background-color: #1269b5; } ' +
         'QPushButton:pressed { background-color: #084e88; } ' +
         'QPushButton:disabled { background-color: #35485a; color: #9ca9b7; border-color: #535d68; }');
      this.runButton.toolTip = InNovaTr("Select Project type\nSelect Gradient Correction\nSelect images\nSelect Integration options\nand click on Run");
      this.runButton.setFixedWidth(102);
      this.runButton.setScaledFixedHeight(28);


      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";
      this.workingLabel.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;
      this.workingLabel.setFixedHeight(WindowsOsx1);


      this.workingLabel.hide();

      this.workingStatusText = "";
      this.elapsedStartTime = 0;
      this.elapsedStopTime = 0;
      this.elapsedTimer = new Timer(1, true, this);

      this.formatElapsedTime = function (elapsedMilliseconds) {
         let totalSeconds = Math.max(0, Math.floor(elapsedMilliseconds/1000));
         let hours = Math.floor(totalSeconds/3600);
         let minutes = Math.floor((totalSeconds % 3600)/60);
         let seconds = totalSeconds % 60;

         function twoDigits(value) {
            return value < 10 ? "0" + value : "" + value;
         }

         return twoDigits(hours) + ":" + twoDigits(minutes) + ":" +
            twoDigits(seconds);
      };

      this.refreshWorkingLabel = function () {
         if (this.elapsedStartTime <= 0)
            return;

         this.workingLabel.text = this.workingStatusText +
            InNovaTr("  ⏱ Elapsed: ") +
            this.formatElapsedTime(
               (this.elapsedStopTime > 0 ?
                  this.elapsedStopTime : Date.now()) -
               this.elapsedStartTime);
         this.workingLabel.styleSheet = InNovaStyleWithToolTips("color: #72b8f4;");
         this.workingLabel.update();
         if (this.progressPanel) {
            this.progressPanel.status.styleSheet = InNovaStyleWithToolTips("color: #72b8f4;");
            this.progressPanel.status.text = this.workingLabel.text;
            this.progressPanel.status.update();
         }
      };

      this.setWorkingStatus = function (statusText) {
         if (InNovaRunActive)
            InNovaAbortCheckpoint();


         if (statusText !== this.workingStatusText) {
            this.elapsedStartTime = Date.now();
            this.elapsedStopTime = 0;
         }
         this.workingStatusText = statusText;
         this.refreshWorkingLabel();
      };

      this.startElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.elapsedStartTime = Date.now();
         this.elapsedStopTime = 0;
         this.refreshWorkingLabel();
         this.elapsedTimer.start();
      };

      this.stopElapsedTimer = function () {
         this.elapsedTimer.stop();
         if (this.elapsedStartTime > 0 && this.elapsedStopTime <= 0)
            this.elapsedStopTime = Date.now();
         this.refreshWorkingLabel();
      };

      this.elapsedTimer.onTimeout = function () {
         self.refreshWorkingLabel();
      };

      this.setProcessingLock = function (locked) {
         let configurationEnabled = !locked;


         this.projectTypeGroupBox.enabled = configurationEnabled;
         this.CropprojectTypeGroupBox.enabled = configurationEnabled;
         this.taggingGroupBox.enabled = configurationEnabled;
         this.optionsGroupBox.enabled = configurationEnabled;
         this.finalOptionsGroupBox.enabled = configurationEnabled;

         if (locked) {
            this.runButton.enabled = false;
            this.Iconize3.enabled = false;
            this.Iconize6.enabled = false;

            this.exitButton.text = InNovaTr("STOP");
            this.exitButton.icon =
               this.scaledResource( ":/icons/cancel.png" );
            this.exitButton.toolTip =
               InNovaTr("Stop the current project safely and delete its temporary results");
            this.exitButton.enabled = true;
         } else {
            this.runButton.enabled = CanProcess();
            this.Iconize3.enabled = true;
            this.Iconize6.enabled = true;

            this.exitButton.text = InNovaTr("Close");
            this.exitButton.icon =
               this.scaledResource( ":/icons/close.png" );
            this.exitButton.toolTip = InNovaTr("Close InNova Astro Processor");
            this.exitButton.enabled = true;
         }

         if (this.progressPanel) {
            if (locked) this.configurationWindowSize = { width: this.width, height: this.height };
            this.configurationHeader.visible = !locked;
            this.integrationPage.visible = !locked;
            this.progressPanel.visible = locked;
            this.actionGapAbove.visible = locked;
            this.actionGapBelow.visible = locked;
            this.consoleButton.visible = !locked;
            this.openImagesButton.visible = !locked;
            this.documentsImagesButton.visible = !locked;
            this.Iconize3.visible = !locked;
            this.Iconize6.visible = !locked;
            this.runButton.visible = !locked;
            this.progressButtonSpacer.visible = locked;
            this.progressConsoleButton.visible = locked;
            this.progressConsoleBalance.visible = locked;

            this.minHeight = 0;
            this.maxHeight = 16777215;
            this.adjustToContents();
            if (locked) {
               this.setScaledFixedHeight(296);
               this.resize(this.logicalPixelsToPhysical(624), this.logicalPixelsToPhysical(296));
            } else if (this.configurationWindowSize)
               this.resize(this.configurationWindowSize.width, this.configurationWindowSize.height);
            MiraCenterDialog(this);
         }
         this.update();
      };


      this.Iconize3 = new ToolButton(this);

      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setScaledFixedSize(28, 28);
      this.Iconize3.toolTip = InNovaTr("Delete actual project");
      if (!CanProcess())
      {
         self.runButton.enabled = false;
      }
      else
      {
         self.runButton.enabled = true;
      }


      self.Iconize6 = new ToolButton(this);

      self.Iconize6.icon = InNovaBlackPlaybackIcon(this, "settings");
      self.Iconize6.setScaledFixedSize(28, 28);
      self.Iconize6.toolTip = InNovaTr("Options and Settings");
      self.Iconize6.enabled = true;


      var self = this;

      this.runButton.onClick = function () {
      if (!CanProcess())
      {
         new InNovaNotice(
            InNovaTr(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,116,114,105,97,108,32,111,114,32,108,105,99,101,110,115,101,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
            String.fromCharCode(79,112,101,110,32,60,98,62,73,110,78,111,118,97,32,83,116,97,114,116,60,47,98,62,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32) +
            String.fromCharCode(116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62)),
            "InNova Astro Processor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }


     if (!InNovaProcessorChooseRunMode(self))
        return;


     let selectedProjectTypes = [
        "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
        "OSC", "OSC", "OSC"
     ];
     let selectedSmartModels = [
        "NONE", "NONE", "NONE", "NONE", "NONE",
        "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
        "VAONIS_VESPERA_III", "VAONIS_AUTO"
     ];
     let selectedProjectType = selectedProjectTypes[self.projectTypeComboBox.currentItem];
     OptionObjectType = self.objectTypeComboBox.currentItem === 1 ?
        "MOON_SUN" : "STARS";
     OptionSeestar = self.projectTypeComboBox.currentItem >= 5 &&
        self.projectTypeComboBox.currentItem <= 8 ? "ON" : "OFF";
     OptionVaonisVespera =
        self.projectTypeComboBox.currentItem >= 5 ? "ON" : "OFF";
     OptionSmartTelescopeModel =
        selectedSmartModels[self.projectTypeComboBox.currentItem];


     function selectedImageFromCombo(key) {
        let combo = self.comboBoxReferences[key];
        return combo && combo.currentItem > 0 ?
           combo.itemText(combo.currentItem) : "EMPTY";
     }
     PimageSii = selectedImageFromCombo("PimageSii");
     PimageHa = selectedImageFromCombo("PimageHa");
     PimageOiii = selectedImageFromCombo("PimageOiii");
     PimageRed = selectedImageFromCombo("PimageRed");
     PimageGreen = selectedImageFromCombo("PimageGreen");
     PimageBlue = selectedImageFromCombo("PimageBlue");
     PimageLuminance = selectedImageFromCombo("PimageLuminance");
     PimageOsc = selectedImageFromCombo("PimageOsc");

     ProjecTypevar = selectedProjectType;
     ProjecTypevarRec = selectedProjectType;


     OptionSTFvar = "OFF";
     if (selectedProjectType === "OSC" && PimageOsc !== "EMPTY") {
        let selectedOscWindow = ImageWindow.windowById(PimageOsc);
        if (selectedOscWindow && !selectedOscWindow.isNull &&
            !InNovaProcessorLooksLinear(selectedOscWindow)) {
           OptionSTFvar = "ON";
           new InNovaNotice(
              InNovaTr("<p align=\"center\"><b>The selected image is already stretched.</b></p>" +
              "<p align=\"center\">Smart Stretch will be skipped to prevent " +
              "a second stretch.</p>"),
              "InNova Astro Processor",
              StdIcon_Information,
              StdButton_Ok
           ).execute();
        }
     }


     OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
     OptionFast = self.FastCheckBox.enabled && self.FastCheckBox.checked ?
        "ON" : "OFF";
     OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";


     OptionDarkStructureEnhance = InNovaBridgeRunDarkStructureEnhance ?
        "ON" : "OFF";
     OptionOpenInNovaEditor = InNovaBridgeRunPhotoEditor ? "ON" : "OFF";
     OptionHavar = InNovaBridgeRunHAlphaBlend &&
        self.HalphaCheckBox.enabled &&
        self.HalphaCheckBox.checked ? "ON" : "OFF";
     updateColorCalibrationAvailability(false);
     OptionColorCalibration = self.colorCalibrationCheckBox.enabled &&
        self.colorCalibrationCheckBox.checked ? "ON" : "OFF";
     OptionGradient = self.gradientCorrectionComboBox.currentItem === 0 ?
        "ON" : "OFF";
     OptionMgc = self.gradientCorrectionComboBox.currentItem === 1 ?
        "ON" : "OFF";


     OptionDeepSNR = "OFF";
     OptionMLDenoise = "OFF";
     MiraMLDenoiseLinearPrepared = false;


     MiraMLDenoiseUseLinear = self.linearMLDenoiseCheckBox.enabled &&
        self.linearMLDenoiseCheckBox.checked && MiraMLDenoiseLinearAvailable() &&
        OptionObjectType !== "MOON_SUN";
     if (MiraMLDenoiseUseLinear && OptionFast === "ON") {
        new InNovaNotice(
           InNovaTr("Linear MLDenoise requires Fast integration mode to be disabled. Disable Fast mode or uncheck Linear MLDenoise before running."),
           "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
        return;
     }
     console.writeln(InNovaTr(MiraMLDenoiseUseLinear ?
        "MLDenoise linear stage: enabled, before star removal and stretching." :
        "MLDenoise linear stage: disabled."));
     OptionNoiseXterminator = "OFF";
     OptionBlurXterminator = "OFF";
     OptionHighpass = "OFF";
     OptionVarStars = self.starlessMethodComboBox.currentItem > 0 ? "ON" : "OFF";
     OptionStarXterminator = self.starlessMethodComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionFinalStarRefinement =
        OptionVarStars === "ON" && InNovaBridgeRunStarRefinement ?
           "ON" : "OFF";
     FinalStarRefinementReady = false;


     if (OptionVarStars === "ON" && self.finalStarsComboBox.currentItem === 0)
        self.finalStarsComboBox.currentItem = 1;
     OptionHSOvar = self.finalStarsComboBox.currentItem === 1 ? "ON" : "OFF";
     Option1var = self.finalStarsComboBox.currentItem === 2 ? "ON" : "OFF";
     ProjecTypevar2 = Option1var === "ON" ? "1" : "0";


     if (OptionObjectType === "MOON_SUN") {
        if (selectedProjectType !== "OSC") {
           new InNovaNotice(
              InNovaTr("Moon or Sun mode requires an OSC, SEESTAR or VAONIS Vespera " +
              "project with one selected image."),
              InNovaTr("InNova Astro Processor - Moon or Sun"),
              StdIcon_Error,
              StdButton_Ok
           ).execute();
           return;
        }

        self.ImageSolverCheckBox.checked = false;
        self.ImageSolverCheckBox.enabled = false;
        self.gradientCorrectionComboBox.currentItem = 0;
        self.gradientCorrectionComboBox.enabled = false;
        self.starlessMethodComboBox.currentItem = 0;
        self.starlessMethodComboBox.enabled = false;
        self.finalStarsComboBox.currentItem = 0;
        self.finalStarsComboBox.enabled = false;
        self.HalphaCheckBox.checked = false;
        self.HalphaCheckBox.enabled = false;
        self.colorCalibrationCheckBox.checked = false;
        self.colorCalibrationCheckBox.enabled = false;

        OptionImageSolver = "OFF";
        OptionGradient = "ON";
        OptionMgc = "OFF";
        OptionVarStars = "OFF";
        OptionStarXterminator = "OFF";
        OptionFinalStarRefinement = "OFF";
        OptionHSOvar = "OFF";
        Option1var = "OFF";
        OptionHavar = "OFF";
        OptionColorCalibration = "OFF";
        ProjecTypevar2 = "0";

        console.noteln(
           "🌙 Moon or Sun project: ImageSolver, MGC, Final_starless " +
           "creation and final-star processing will be skipped.");
     }


     if (OptionFast === "ON" && Option1var === "ON") {
        console.warningln(
           "⚠️ FAST mode does not run the separate RGB star integration. " +
           "Using project stars for this run.");
        self.finalStarsComboBox.currentItem = 1;
        Option1var = "OFF";
        OptionHSOvar = "ON";
        ProjecTypevar2 = "0";
     }
     VarProcesStar = "OFF";
     VarPGlobal = "EMPTY";
     isStarProcess = false;
     OptionRemaind2 = null;
     OptionEnabledPreview2 = "OFF";
     InteractiveProcessStrengths.DeepSNR = null;
     InteractiveProcessStrengths.MLDenoise = null;
     InteractiveProcessStrengths.NoiseXTerminator = null;
     InteractiveProcessStrengths.BlurXTerminator = null;
     InteractiveProcessStrengths.HighPass = null;
     InteractiveProcessStrengths.NarrowbandToRGB = null;
     InteractiveProcessMaskModes.DeepSNR = "none";
     InteractiveProcessMaskModes.MLDenoise = "none";
     InteractiveProcessMaskModes.NoiseXTerminator = "none";
     InteractiveProcessMaskModes.BlurXTerminator = "none";
     InteractiveProcessMaskModes.HighPass = "none";
     InteractiveProcessMaskModes.NarrowbandToRGB = "none";
     InteractiveProcessMaskBanks.DeepSNR = null;
     InteractiveProcessMaskBanks.MLDenoise = null;
     InteractiveProcessMaskBanks.NoiseXTerminator = null;
     InteractiveProcessMaskBanks.BlurXTerminator = null;
     InteractiveProcessMaskBanks.HighPass = null;
     InteractiveProcessMaskBanks.NarrowbandToRGB = null;


     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {

            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {

            self.finalStarsComboBox.currentItem = 0;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");


      if (!MiraRestoreSelectedSourceIds()) {
         console.criticalln(
            "❌ Source-window identifiers are ambiguous. Close or rename the duplicate window reported above, then run the script again.");
         return;
      }


      if (!MiraCheckWindowsABE()) {
         console.warningln("\n⚠️ Run cancelled because previous intermediate windows are still open.");
         return;
      }

      if (InNovaProcessorConfirmRun()) {


        MiraPrepareWorkspaceForRun(dialog);

        FinalFocusWindowId = "";
        FinalConvertedFocusWindowId = "";
        InNovaBridgeProcessedResultReady = false;
        let startTime = Date.now();
        dialog.workingStatusText = InNovaTr(String.fromCharCode(83,116,97,114,116,105,110,103,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
        dialog.startElapsedTimer();
        let processCompleted = false;
        let deleteBridgeRegisteredAfterRestore = false;
        InNovaStopRequested = false;
        InNovaStopCleanupRequested = false;
        InNovaRunActive = true;
        OptionshowConsolRadio = "ON";
        dialog.consoleButton.toolTip = InNovaTr("Hide the PixInsight Process Console");
        console.show();
        try {
        dialog.setProcessingLock(true);

        MiraConsoleSection("🚀 Launching InNova Astro Processor project...");

        dialog.workingLabel.foregroundColor = 0x0000FF;
        dialog.workingLabel.update();


         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln(String.fromCharCode(10,10060,32,86,97,108,105,100,97,116,105,111,110,32,102,97,105,108,101,100,46,32,80,108,101,97,115,101,32,115,101,108,101,99,116,32,105,109,97,103,101,115,46));
          return;
        } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
        }


        let astrometryRequiredForRun =
           OptionMgc === "ON" || OptionColorCalibration === "ON";
        if (OptionObjectType === "STARS" &&
            OptionImageSolver !== "ON" &&
            astrometryRequiredForRun &&
            !MiraValidateSelectedImageAstrometry(ProjecTypevar)) {
           OptionImageSolver = "ON";
           self.ImageSolverCheckBox.checked = true;
           self.ImageSolverCheckBox.update();

           console.noteln(
              "🔭 Astrometric data are missing. ImageSolver has been enabled automatically."
           );

           new InNovaNotice(
              InNovaTr("<div align=\"center\">InNova has detected that one or more " +
              "selected images require an astrometric solution.<br><br>" +
              "<b>ImageSolver will now run automatically.</b><br><br>" +
              "Astro Processor will continue the integration as soon as the " +
              "astrometric solution has been generated.</div>"),
              "InNova Astro Processor",
              StdIcon_Information,
              StdButton_Ok
           ).execute();
        }


        if (OptionObjectType === "STARS" && OptionImageSolver === "ON") {
           dialog.setWorkingStatus(InNovaTr(String.fromCharCode(82,117,110,110,105,110,103,32,73,109,97,103,101,83,111,108,118,101,114,32,111,110,32,115,101,108,101,99,116,101,100,32,105,109,97,103,101,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
           let imageSolverBaselineWindows = ImageWindow.windows.slice();
           if (!MiraRunImageSolverForSelectedImages(ProjecTypevar)) {
              MiraCleanupImageSolverAttempt(imageSolverBaselineWindows);

              let imageSolverRequiredByColorCalibration =
                 OptionColorCalibration === "ON";
              let imageSolverCanContinue = OptionMgc !== "ON" &&
                 !imageSolverRequiredByColorCalibration;
              let imageSolverDetail =
                 (typeof MiraImageSolverLastError === "string" &&
                  MiraImageSolverLastError.length > 0) ?
                    MiraImageSolverLastError :
                    InNovaTr("ImageSolver could not generate a valid astrometric solution.");
              imageSolverDetail = String(imageSolverDetail)
                 .replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
              let imageSolverMessage =
                 InNovaTr("ImageSolver could not solve the selected image.<br><br>" +
                 "If this is an image of the Moon or the Sun, restart InNova and, " +
                 "in the Object section, choose <b>Moon or Sun</b>.<br><br>");

              if (imageSolverCanContinue) {
                 imageSolverMessage +=
                    InNovaTr("The options currently enabled do not require astrometry, so " +
                    "InNova Astro Processor will continue without ImageSolver.<br><br>" +
                    "Details: ") + imageSolverDetail;
                 new InNovaNotice(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Warning,
                    StdButton_Ok
                 ).execute();
                 OptionImageSolver = "OFF";
                 self.ImageSolverCheckBox.checked = false;
                 self.ImageSolverCheckBox.update();
                 console.warningln(
                    "⚠️ ImageSolver failed, but no active process requires astrometry. Continuing safely without ImageSolver.");
              }
              else {
                 let astrometryRequirement = OptionMgc === "ON" &&
                    imageSolverRequiredByColorCalibration ?
                       InNovaTr("Multiscale Gradient Correction and Color Calibration require") :
                    OptionMgc === "ON" ?
                       InNovaTr("Multiscale Gradient Correction requires") :
                       InNovaTr("Color Calibration requires");
                 imageSolverMessage +=
                    InNovaTr("The active ") + astrometryRequirement + InNovaTr(" astrometry. " +
                    "InNova Astro Processor must stop.<br><br>" +
                    "All temporary ImageSolver results have been removed and the " +
                    "original selected image has been preserved.<br><br>" +
                    "Details: ") + imageSolverDetail;
                 new InNovaNotice(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Error,
                    StdButton_Ok
                 ).execute();
                 console.criticalln(
                    "\n❌ 🔭 ImageSolver failed. Astrometry is required by " +
                    (OptionMgc === "ON" && imageSolverRequiredByColorCalibration ?
                       "Multiscale Gradient Correction and Color Calibration" :
                     OptionMgc === "ON" ? InNovaTr("Multiscale Gradient Correction") :
                       InNovaTr("Color Calibration")) +
                    ", so InNova Astro Processor stopped before processing.");
                 return;
              }
           }
        }

        dialog.setWorkingStatus(InNovaTr(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
        if (!MiraProyecto())
            {
               console.criticalln("Process cancelled.");
               return;
            }


        if (OptionMgc ==="ON") {


           if (!MiraValidateMgcConfiguration(true)) {
              OptionMgc = "OFF";
              OptionGradient = "ON";
              dialog.gradientCorrectionComboBox.currentItem = 0;
           }
           else {
              MiraConsoleSection(InNovaTr("Launching MARS databases..."));
              dialog.setWorkingStatus(InNovaTr(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,77,117,108,116,105,115,99,97,108,101,32,71,114,97,100,105,101,110,116,32,67,111,114,114,101,99,116,105,111,110,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
              console.noteln("Launching Multiscale Gradient Correction process...");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin1) + ": \n" + originalFilePathMarsfin1);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin2) + ": \n" + originalFilePathMarsfin2);


              if (!MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, MiraImageSolverSelectedIds(ProjecTypevar))) {
                 console.criticalln(
                    "❌ Multiscale Gradient Correction did not complete on every selected image. Processing has been stopped to avoid mixing corrected and uncorrected channels.");
                 return;
              }
           }
        }


        dialog.setWorkingStatus(InNovaTr(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));

            if (MiraVentana()) {


            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
            MiraRenombre();
            if (ProjecTypevar === "OSC" &&
                !MiraPrepareOscColorSource(OptionObjectType === "MOON_SUN")) {
               console.criticalln(
                  "❌ OSC colour preparation failed. Processing has been stopped safely.");
               return;
            }
            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));


            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return;
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }


            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(83,116,101,112,32,53,47,57,46,32,77,97,105,110,32,112,114,111,99,101,115,115,44,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
            if (MiraMLDenoiseUseLinear) {


               if (!MiraRunLinearMLDenoiseWorkflow()) return;
            } else MiraProcesoGeneral01();
            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(83,116,101,112,32,54,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
            MiraAdaptiveStretchCancelledByUser = false;
            if (!MiraChannelCom()) {
               console.writeln();
               if (MiraAdaptiveStretchCancelledByUser)
                  console.writeln("Processing has been stopped safely by user. Smart Stretch was closed without Apply.");
               else
                  console.criticalln(
                     "❌ Channel combination or final-window creation failed. Processing has been stopped safely.");
               console.writeln();
               return;
            }

            if (!MiraValidateFinalWindowContract(
                   OptionFast === "ON" && OptionVarStars === "ON",
                   "Channel combination"))
               return;

            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(83,116,101,112,32,55,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));


               let finalColorTarget = ImageWindow.windowById("Final_starless");
               if (finalColorTarget && !finalColorTarget.isNull)
                  finalColorTarget.bringToFront();
               MiraGreen();


            dialog.setWorkingStatus(
               InNovaTr("Adjusting background, denoise and sharpen on the visible final image..."));
            if (!MiraApplyVisibleFinalProcesses())
               return;

            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (Option1var === "ON") {
                        if (OptionFast === "OFF"){
                              console.noteln("\n" + "Launching RGB stars process.");
                              try {
                                 MiraRGBStars();
                              } finally {


                                 VarProcesStar = "OFF";
                                 ProjecTypevar = ProjecTypevarRec;
                              }
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                } else if (OptionHSOvar === "ON") {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars2();

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars();

                              }
                        }
                }
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            if (!MiraValidateFinalWindowContract(
                   OptionVarStars === "ON", "Final star creation"))
               return;


            if (OptionHavar ==="ON" && InNovaBridgeRunHAlphaBlend){
               let imageWindow = "Filter_Ha_registered_ABE";
               dialog.setWorkingStatus(
                  InNovaTr(String.fromCharCode(73,110,78,111,118,97,32,72,45,97,108,112,104,97,32,66,108,101,110,100,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
               dialog.stopElapsedTimer();
               CoreApplication.processEvents();
               if (!InNovaEditorRunHAlphaStage(
                     imageWindow, ProjecTypevarRec))
                  return;
            } else if (OptionHavar === "ON")
               console.noteln(
                  "⏭️ H-alpha Blend skipped by the Bridge process selection.");

            dialog.setWorkingStatus(InNovaTr(String.fromCharCode(83,116,101,112,32,57,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));


            dialog.setWorkingStatus(
               InNovaTr(String.fromCharCode(73,110,78,111,118,97,32,68,97,114,107,32,83,116,114,117,99,116,117,114,101,32,69,110,104,97,110,99,101,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
            dialog.stopElapsedTimer();
            CoreApplication.processEvents();
            if (InNovaBridgeRunDarkStructureEnhance) {
               if (!InNovaEditorRunDarkStructuresStage(
                     ProjecTypevarRec))
                  return;
            } else
               console.noteln(
                  "⏭️ Dark Structure Enhance skipped by the Bridge process selection.");


            if (OptionVarStars === "ON" && InNovaBridgeRunStarRefinement) {
               dialog.setWorkingStatus(
                  InNovaTr(String.fromCharCode(82,101,102,105,110,105,110,103,32,116,104,101,32,102,105,110,97,108,32,115,116,97,114,32,108,97,121,101,114,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46)));
               dialog.stopElapsedTimer();
               CoreApplication.processEvents();
               if (!InNovaEditorRunStarRefinementStage(
                     ProjecTypevarRec))
                  return;
            } else if (OptionVarStars === "ON")
               console.noteln(
                  "⏭️ Star Refinement skipped by the Bridge process selection.");

              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break;
                         }
                   }
              }

            MiraRenProyectos();

            InNovaAbortCheckpoint();


            InNovaRunActive = false;
            MirashowTotalTime(startTime);
            Option2var2 = "ON";


            dialog.stopElapsedTimer();
            deleteBridgeRegisteredAfterRestore =
               MiraBorraVentanas() === true;


            MiraFocusFinalOutput();
            InNovaAbortCheckpoint();


            if (OptionOpenInNovaEditor === "ON") {
               let finalId = FinalConvertedFocusWindowId ||
                             FinalFocusWindowId;
               if (!finalId || finalId.length === 0) {
                  let finalWindow = ImageWindow.activeWindow;
                  finalId = finalWindow && !finalWindow.isNull &&
                            finalWindow.mainView &&
                            !finalWindow.mainView.isNull ?
                            finalWindow.mainView.id : "";
               }
               let verifiedFinal = ImageWindow.windowById(finalId);
               if (verifiedFinal && !verifiedFinal.isNull &&
                   verifiedFinal.mainView &&
                   !verifiedFinal.mainView.isNull) {
                  InNovaEditorPendingSourceId = finalId;
                  InNovaEditorPendingProjectType = ProjecTypevarRec;
                  InNovaEditorPendingLaunch = true;
                  console.noteln(
                     "🪐 InNova Photo Editor queued for: " + finalId);
               }
               else {
                  console.warningln(
                     "⚠️ 🪐 InNova Photo Editor was not opened because no valid final image was found.");
               }
            }

            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            if (!InNovaEditorPendingLaunch)
               console.noteln("\n✅ End of project.");
            dialog.setWorkingStatus(InNovaTr("✅ Process completed."));
            processCompleted = true;
            InNovaBridgeProcessedResultReady = true;
            if (InNovaEditorPendingLaunch)
               dialog.ok();


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
        } catch (processingError) {
            console.show();
            let processingMessage = processingError && processingError.message ?
               processingError.message : processingError;
            if ((processingError && processingError.inNovaUserStop) ||
                InNovaStopRequested) {
               console.warningln(
                  "\n⛔ InNova Astro Processor stopped by the user at a safe checkpoint.");
            }
            else {
               console.criticalln(
                  "\n❌ 🔭 InNova Astro Processor stopped after an unexpected processing error: " +
                  processingMessage);
               if (processingError && processingError.stack)
                  console.criticalln(processingError.stack);
               new InNovaNotice(
                  InNovaTr("InNova Astro Processor stopped safely.\n\n") + processingMessage +
                  InNovaTr("\n\nReview the Process Console for the stage and missing window details."),
                  InNovaTr("InNova Astro Processor processing error"),
                  StdIcon_Error,
                  StdButton_Ok
               ).execute();
            }
        } finally {

            InNovaRunActive = false;


            try {
               MiraRestoreSelectedSourceIds();
               if (deleteBridgeRegisteredAfterRestore) {
                  CoreApplication.processEvents();
                  MiraDeleteGetStartedRegisteredWindows();
               }
            } catch (restoreError) {
               console.warningln(
                  "⚠️ Source-window names could not be fully restored: " +
                  restoreError.message);
            }
            VarProcesStar = "OFF";
            VarPGlobal = "EMPTY";
            isStarProcess = false;
            ProjecTypevar = ProjecTypevarRec;
            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            dialog.stopElapsedTimer();
            let stoppedByUser = InNovaStopRequested;


            InNovaRunActive = false;
            if (stoppedByUser)
               console.noteln("✅ STOP completed. Project windows and available results were preserved.");
            InNovaStopRequested = false;
            InNovaStopCleanupRequested = false;
            dialog.setProcessingLock(false);

            if (stoppedByUser) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  InNovaTr("⛔ Process stopped. Project windows preserved.");
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
            }
            else if (!processCompleted)
               dialog.setWorkingStatus(InNovaTr("⚠️ Process stopped."));
        }
    } else {
        console.warningln("\nFinished script...");
    }
};


      this.Iconize3.onClick = function() {


               self.projectTypeComboBox.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };


self.Iconize6.onClick = function() {

   let mgcDialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
   mgcDialog.adjustToContents();
   MiraCenterDialog(mgcDialog);
   mgcDialog.execute();
   MiraDependencyInvalidate();
   MiraRefreshConfiguredDataPaths();
   self.linearMLDenoiseCheckBox.enabled = OptionObjectType !== "MOON_SUN" &&
      MiraMLDenoiseLinearAvailable();
   if (!self.linearMLDenoiseCheckBox.enabled)
      self.linearMLDenoiseCheckBox.checked = false;
};


     this.exitButton = new PushButton(this);
     this.exitButton.text = InNovaTr("Close");

     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.toolTip = InNovaTr("Close InNova Astro Processor");
      this.exitButton.setFixedWidth(102);
      this.exitButton.setScaledFixedHeight(28);


     this.exitButton.onClick = function () {
        if (InNovaRunActive) {
           InNovaRequestStop(InNovaTr("the main window"));
           return;
        }
        this.dialog.cancel();
    };


      this.consoleButton = new ToolButton(this);

      this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
      this.consoleButton.setScaledFixedSize(28, 28);
      this.consoleButton.toolTip = InNovaTr("Show the PixInsight Process Console");
      this.consoleButton.onClick = function () {
         if (OptionshowConsolRadio === "ON") {
            OptionshowConsolRadio = "OFF";
            this.toolTip = InNovaTr("Show the PixInsight Process Console");
            console.hide();
         }
         else {
            OptionshowConsolRadio = "ON";
            this.toolTip = InNovaTr("Hide the PixInsight Process Console");
            console.show();
         }
      };


    this.actionButtonsSizer = new HorizontalSizer;
    this.actionButtonsSizer.spacing = 10;
    this.actionButtonsSizer.margin = this.integrationPage.sizer.margin;
    this.progressConsoleBalance = new Control(this);
    this.progressConsoleBalance.setScaledFixedSize(28, 28);
    this.progressConsoleBalance.hide();
    this.actionButtonsSizer.add(this.consoleButton);
    this.openImageFiles = function(initialPath) {
       if (InNovaRunActive) return;
       let chooser = new OpenFileDialog;
       chooser.caption = InNovaTr("Open images for InNova Astro Processor");
       chooser.multipleSelections = true;
       let rawExtensions =
          "*.raw *.RAW *.dng *.DNG *.cr2 *.CR2 *.cr3 *.CR3 " +
          "*.nef *.NEF *.nrw *.NRW *.arw *.ARW *.srf *.SRF *.sr2 *.SR2 " +
          "*.raf *.RAF *.orf *.ORF *.ori *.ORI *.rw2 *.RW2 *.rwl *.RWL " +
          "*.pef *.PEF *.ptx *.PTX *.3fr *.3FR *.fff *.FFF *.iiq *.IIQ " +
          "*.mos *.MOS *.mef *.MEF *.mrw *.MRW *.x3f *.X3F *.kdc *.KDC " +
          "*.dcr *.DCR *.erf *.ERF *.bay *.BAY *.cap *.CAP *.eip *.EIP";
       chooser.filters = [
          [InNovaTr("Supported astronomical and camera images"),
             "*.xisf *.fit *.fits *.fts *.tif *.tiff *.TIF *.TIFF " + rawExtensions],
          [InNovaTr("Camera RAW images — all manufacturers"), rawExtensions],
          [InNovaTr("All files"), "*"]
       ];
       if (initialPath && File.directoryExists(initialPath))
          chooser.initialPath = initialPath;
       if (!chooser.execute()) return;
       try {
          for (let path of chooser.fileNames) {
             let opened = ImageWindow.open(path);
             for (let window of opened) {
                window.show();
                for (let key in self.comboBoxReferences)
                   self.comboBoxReferences[key].addItem(window.mainView.id);
             }
          }
       } catch (error) {
          new InNovaNotice(String(error), InNovaTr("Open images"), StdIcon_Error, StdButton_Ok).execute();
       }
    };
    this.openImagesButton = new ToolButton(this);
    this.openImagesButton.icon = this.scaledResource(":/icons/folder-open.png");
    this.openImagesButton.setScaledFixedSize(28, 28);
    this.openImagesButton.toolTip = InNovaTr("Open image files");
    this.openImagesButton.onClick = function() {
       self.openImageFiles("");
    };
    this.actionButtonsSizer.add(this.openImagesButton);
    this.documentsImagesButton = new ToolButton(this);
    this.documentsImagesButton.icon = this.scaledResource(":/icons/documents-import.png");
    this.documentsImagesButton.setScaledFixedSize(28, 28);
    this.documentsImagesButton.toolTip = InNovaTr("Open saved work in Documents/InNova");
    this.documentsImagesButton.onClick = function() {
       let dataRoot = _0xb47cd2e9fc();
       try {
          if (!File.directoryExists(dataRoot))
             File.createDirectory(dataRoot);
          self.openImageFiles(dataRoot + "/");
       } catch (error) {
          new InNovaNotice(
             InNovaTr("The InNova user folder could not be opened.\n\n") +
             String(error),
             InNovaTr("Open saved InNova work"),
             StdIcon_Error, StdButton_Ok).execute();
       }
    };
    this.actionButtonsSizer.add(this.documentsImagesButton);
    this.actionButtonsSizer.add(this.Iconize3);
    this.actionButtonsSizer.add(this.Iconize6);
    this.actionButtonsSizer.addStretch();
    this.actionButtonsSizer.add(InNovaStyleBlackButton(this.runButton));
    this.progressButtonSpacer = new Control(this);
    this.progressButtonSpacer.setFixedHeight(1);
    this.progressButtonSpacer.hide();
    this.progressConsoleButton = new ToolButton(this);
    this.progressConsoleButton.icon = this.scaledResource(":/toolbar/view-process-console.png");
    this.progressConsoleButton.setScaledFixedSize(28, 28);
    this.progressConsoleButton.toolTip = InNovaTr("Show or hide the PixInsight Process Console");
    this.progressConsoleButton.onClick = function() {
       self.consoleButton.onClick.call(self.consoleButton);
    };
    this.progressConsoleButton.hide();
    this.actionButtonsSizer.insert(0, this.progressConsoleButton);
    this.actionButtonsSizer.add(InNovaStyleBlackButton(this.exitButton));
    this.actionButtonsSizer.add(this.progressButtonSpacer, 100);
    this.actionButtonsSizer.add(this.progressConsoleBalance);


    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;


    this.onClose = function() {
       if (InNovaRunActive) {
          InNovaRequestStop(InNovaTr("the progress window"));
          return false;
       }
       return true;
    };
    this.progressPanel = InNovaProcessorProgressPanel(this, true);
    this.progressPanel.hide();
    this.configurationHeader = InNovaProcessorHeader(this);
    this.sizer.add(this.configurationHeader);
    this.sizer.addSpacing(10);
    this.sizer.add(this.progressPanel);
    this.sizer.add(this.integrationPage, 100);

    this.actionGapAbove = new Control(this);
    this.actionGapBelow = new Control(this);
    let actionGapHeight = 2 * this.font.lineSpacing;
    this.actionGapAbove.setFixedHeight(actionGapHeight);
    this.actionGapBelow.setScaledFixedHeight(18);
    this.actionGapBelow.hide();
    this.actionGapAbove.hide();
    this.sizer.add(this.actionGapAbove);
    this.sizer.add(this.actionButtonsSizer);
    this.sizer.add(this.actionGapBelow);


    this.windowTitle = ProjecTname + " — " + ProjecTver;


}
}


function InNovaProcessorEditorProcessStatus(moduleName, state)
{
   InNovaDiagnosticWrite("STATUS", moduleName, state);
   if (!InNovaRunActive || !dialog)
      return;

   let labels = {
      adaptiveStretch: "InNova Smart Stretch",
      neutralization: "InNova Background Correction",
      denoiser: "InNova Denoiser",
      sharpen: "InNova Sharpen",
      luminanceEnhancement: "InNova Luminance Enhance",
      hAlpha: "InNova H-alpha Blend",
      darkStructures: InNovaTr("InNova Dark Structure Enhance"),
      starRefinement: InNovaTr("InNova Star Refinement")
   };
   let label = labels[moduleName] || moduleName;
   if (!label || label.length === 0)
      return;

   if (state === "processing") {
      dialog.workingStatusText = label + InNovaTr(String.fromCharCode(46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
      dialog.startElapsedTimer();
      return;
   }

   if (state === "finished" || state === "failed") {
      dialog.stopElapsedTimer();
      dialog.workingStatusText = label +
         (state === "finished" ? InNovaTr(" process finished.") : InNovaTr(" process failed."));
      dialog.refreshWorkingLabel();
   }
}

let dialog = new IntegratorDialog();
InNovaIntegratorMainDialog = dialog;
InNovaProjectSelectionLoggingEnabled = true;
UpdateInstalledAppsUI(dialog);

function InNovaIntegratorSelectGuidedStarRemoval(targetDialog)
{
   if (OptionObjectType === "MOON_SUN") return;
   let method = starXterminatorInstalled ? 1 : (starNet2Installed ? 2 : 0);
   targetDialog.starlessMethodComboBox.currentItem = method;
   targetDialog.starlessMethodComboBox.onItemSelected(method);
   if (method === 0)
      console.warningln("⚠️ Star Refinement requires StarXTerminator or StarNet2. " +
         "Neither is installed; Final_starless creation remains disabled.");
}

function InNovaIntegratorConsumeGetStartedHandoff(targetDialog)
{
   let pending = Settings.read(
      InNovaIntegratorHandoffPendingSetting, DataType_String );
   if (!Settings.lastReadOK || pending !== "1") return false;

   let guidedStarRefinementSelected = false;
   let bridgeProcessOptions = [
      { key: "BackgroundCorrection", variable: "InNovaBridgeRunBackgroundCorrection" },
      { key: "Denoise", variable: "InNovaBridgeRunDenoise" },
      { key: "Sharpen", variable: "InNovaBridgeRunSharpen" },
      { key: "HAlphaBlend", variable: "InNovaBridgeRunHAlphaBlend" },
      { key: "DarkStructureEnhance", variable: "InNovaBridgeRunDarkStructureEnhance" },
      { key: "StarRefinement", variable: "InNovaBridgeRunStarRefinement" },
      { key: "PhotoEditor", variable: "InNovaBridgeRunPhotoEditor" }
   ];
   for (let processIndex = 0;
        processIndex < bridgeProcessOptions.length; ++processIndex) {
      let processOption = bridgeProcessOptions[processIndex];
      let settingKey = InNovaIntegratorProcessSettingPrefix + processOption.key;
      let settingValue = Settings.read(settingKey, DataType_String);
      let enabled = !Settings.lastReadOK || settingValue !== "0";
      if (processOption.key === "StarRefinement")
         guidedStarRefinementSelected = Settings.lastReadOK && settingValue === "1";
      switch (processOption.variable) {
      case "InNovaBridgeRunBackgroundCorrection":
         InNovaBridgeRunBackgroundCorrection = enabled; break;
      case "InNovaBridgeRunDenoise":
         InNovaBridgeRunDenoise = enabled; break;
      case "InNovaBridgeRunSharpen":
         InNovaBridgeRunSharpen = enabled; break;
      case "InNovaBridgeRunHAlphaBlend":
         InNovaBridgeRunHAlphaBlend = enabled; break;
      case "InNovaBridgeRunDarkStructureEnhance":
         InNovaBridgeRunDarkStructureEnhance = enabled; break;
      case "InNovaBridgeRunStarRefinement":
         InNovaBridgeRunStarRefinement = enabled; break;
      case "InNovaBridgeRunPhotoEditor":
         InNovaBridgeRunPhotoEditor = enabled; break;
      }
      Settings.remove(settingKey);
   }

   let project = Settings.read(
      InNovaIntegratorHandoffProjectSetting, DataType_String );
   if (!Settings.lastReadOK || typeof project !== "string") project = "SHO";
   let projectIndexes = { LRGB: 0, RGB: 1, SHO: 2, HOO: 3, OSC: 4,
      SEESTAR_S30_PRO: 5, SEESTAR_S50: 6, SEESTAR_S50_PRO: 7,
      SEESTAR: 8, VAONIS_VESPERA_III: 9, VAONIS_VESPERA: 10 };
   let projectIndex = projectIndexes[project];
   if (projectIndex === undefined) projectIndex = 2;
   targetDialog.projectTypeComboBox.currentItem = projectIndex;
   if (typeof targetDialog.projectTypeComboBox.onItemSelected === "function")
      targetDialog.projectTypeComboBox.onItemSelected(projectIndex);

   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   let assigned = 0;
   for (let k = 0; k < keys.length; ++k) {
      let id = Settings.read(
         InNovaIntegratorHandoffImagePrefix + keys[k], DataType_String );
      if (!Settings.lastReadOK || typeof id !== "string" || id.length === 0)
         continue;
      let combo = targetDialog.comboBoxReferences[keys[k]];
      if (!combo) continue;
      InNovaIntegratorHandoffImageIds[id] = true;
      let itemIndex = -1;
      for (let i = 0; i < combo.numberOfItems; ++i)
         if (combo.itemText(i) === id) {
            itemIndex = i;
            break;
         }
      if (itemIndex < 0 && !ImageWindow.windowById(id).isNull) {
         combo.addItem(id);
         itemIndex = combo.numberOfItems - 1;
      }
      if (itemIndex >= 0) {
         combo.currentItem = itemIndex;
         if (typeof combo.onItemSelected === "function")
            combo.onItemSelected(itemIndex);
         ++assigned;
      }
   }

   let rgbStarsSetting = Settings.read(
      InNovaIntegratorHandoffRgbStarsSetting, DataType_String );
   let useRgbStars = Settings.lastReadOK && rgbStarsSetting === "1" &&
      (project === "SHO" || project === "HOO") &&
      PimageRed !== "EMPTY" && PimageGreen !== "EMPTY" &&
      PimageBlue !== "EMPTY";
   targetDialog.bridgePreferRgbStars = useRgbStars;
   if (useRgbStars) {
      targetDialog.comboBoxReferences.PimageRed.enabled = true;
      targetDialog.comboBoxReferences.PimageGreen.enabled = true;
      targetDialog.comboBoxReferences.PimageBlue.enabled = true;


      targetDialog.starlessMethodComboBox.currentItem = 1;
      if (typeof targetDialog.starlessMethodComboBox.onItemSelected ===
          "function")
         targetDialog.starlessMethodComboBox.onItemSelected(1);
      if (targetDialog.starlessMethodComboBox.currentItem === 1 &&
          OptionVarStars === "ON") {
         targetDialog.finalStarsComboBox.enabled = true;
         targetDialog.finalStarsComboBox.currentItem = 2;
         OptionHSOvar = "OFF";
         Option1var = "ON";
         ProjecTypevar2 = "1";
      }
   }

   let haBlendSetting = Settings.read(
      InNovaIntegratorHandoffHaBlendSetting, DataType_String );
   let useHaBlend = InNovaBridgeRunHAlphaBlend &&
      Settings.lastReadOK && haBlendSetting === "1" &&
      (project === "RGB" || project === "LRGB") &&
      PimageHa !== "EMPTY";
   if (useHaBlend) {
      targetDialog.comboBoxReferences.PimageHa.enabled = true;
      targetDialog.HalphaCheckBox.enabled = true;
      targetDialog.HalphaCheckBox.checked = true;
      OptionHavar = "ON";
   }

   let objectMode = Settings.read("InNovaHandoffObjectType", DataType_String);
   if (Settings.lastReadOK && objectMode === "MOON_SUN") {
      targetDialog.objectTypeComboBox.currentItem = 1;
      if (typeof targetDialog.objectTypeComboBox.onItemSelected === "function")
         targetDialog.objectTypeComboBox.onItemSelected(1);
   }

   if (guidedStarRefinementSelected)
      InNovaIntegratorSelectGuidedStarRemoval(targetDialog);

   Settings.remove(InNovaIntegratorHandoffPendingSetting);
   console.noteln("🚀 InNova Get Started handoff: " + assigned +
      " prepared channel image(s) assigned automatically.");
   return assigned > 0;
}

function InNovaIntegratorShowGetStartedHandoffNotice()
{


   let notice = new Dialog; InNovaApplyBlackTheme(notice);
   notice.windowTitle = "InNova Astro Processor";

   let information = new Label(notice);
   information.useRichText = true;
   information.wordWrapping = true;
   information.text =
      InNovaTr("<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span>" +
      "<br/><br/><b>Make sure:</b><br/><br/>" +
      "• Project type<br/>" +
      "• Gradient correction<br/>" +
      "• Object type<br/>" +
      "• Starless image<br/>" +
      "• Any other options<br/><br/>" +
      "<b>Are correct.</b></p>");
   information.setFixedWidth(notice.logicalPixelsToPhysical(460));

   let okButton = new PushButton(notice);
   okButton.text = InNovaTr("OK");
   okButton.icon = notice.scaledResource(":/icons/ok.png");
   okButton.setFixedWidth(notice.logicalPixelsToPhysical(120));
   okButton.defaultButton = true;
   okButton.onClick = function () { notice.ok(); };

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add(InNovaStyleBlackButton(okButton));
   buttons.addStretch();

   notice.sizer = new VerticalSizer;
   notice.sizer.margin = 16;
   notice.sizer.spacing = 16;
   notice.sizer.add(InNovaBlackHeader(notice, notice.windowTitle));
   notice.sizer.add(information);
   InNovaAddDialogActionSpace(notice, notice.sizer); notice.sizer.add(buttons);
   notice.adjustToContents();
   MiraCenterDialog(notice);
   notice.execute();
}

let InNovaIntegratorGetStartedHandoffApplied =
   InNovaIntegratorConsumeGetStartedHandoff(dialog);
Settings.remove( InNovaIntegratorHandoffNoticeShownSetting );


dialog.initialCenterTimer = new Timer;
dialog.initialCenterTimer.interval = 0.05;
dialog.initialCenterTimer.periodic = false;
dialog.initialCenterTimer.onTimeout = function ()
{
   MiraCenterDialog(dialog);
   if (!InNovaRunActive && OptionshowConsolRadio === "OFF")
      console.hide();
};
dialog.onShow = function ()
{
   if (!InNovaRunActive && OptionshowConsolRadio === "OFF")
      console.hide();
   MiraCenterDialog(this);
   dialog.initialCenterTimer.start();
};


dialog.actualizarComboBoxesDesdeGUI = function () {

   var self = dialog;


   let availableImageIds = [];
   let windows = ImageWindow.windows;

   for (let i = 0; i < windows.length; ++i) {
      if (!windows[i] || windows[i].isNull || !windows[i].mainView || windows[i].mainView.isNull)
         continue;

      let id = windows[i].mainView.id;
      if (
         id.indexOf("Final_") === 0 ||
         id.indexOf("Base_") === 0 ||


         id.indexOf("Image_") === 0 ||
         id.indexOf("Gray") === 0 ||
         (id.indexOf("_registered") !== -1 &&
          !InNovaIntegratorHandoffImageIds[id]) ||
         id.indexOf("_ABE") !== -1 ||
         id.indexOf("_stars") !== -1
      )
         continue;

      availableImageIds.push(id);
   }

   function actualizarCombo(comboBox) {
      if (!comboBox)
         return;

      comboBox.clear();
      comboBox.addItem(InNovaTr("<Select an Image>"));

      for (let i = 0; i < availableImageIds.length; ++i)
         comboBox.addItem(availableImageIds[i]);

      comboBox.currentItem = 0;
   }

   for (let key in self.comboBoxReferences) {
      actualizarCombo(self.comboBoxReferences[key]);
   }

   PimageSii = "EMPTY";
   PimageHa = "EMPTY";
   PimageOiii = "EMPTY";
   PimageRed = "EMPTY";
   PimageGreen = "EMPTY";
   PimageBlue = "EMPTY";
   PimageLuminance = "EMPTY";
   PimageOsc = "EMPTY";
   if (typeof self.updateColorCalibrationAvailability === "function")
      self.updateColorCalibrationAvailability(false);

   CoreApplication.processEvents();
   self.update();
};


if (CanStartApp)
{
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   InNovaDiagnosticWrite("STARTUP", "Astro Processor", "Main interface ready");
   console.hide();
   InNovaDiagnosticWrite("STARTUP", "Astro Processor", "Executing main dialog");
   dialog.execute();

   if (InNovaEditorPendingLaunch) {
      let editorCompleted = InNovaIntegratorOpenInNovaEditor(
         InNovaEditorPendingSourceId,
         InNovaEditorPendingProjectType);
      console.noteln("\n✅ End of project.");
      if (editorCompleted) console.hide();
   }
}
else
{
   console.criticalln("Application startup blocked.");
}

if (InNovaReturnToStartPath.length > 0) {
   try {
      if (InNovaReturnToBridgeRequest != null) {
         let resultId = "";
         let processed = InNovaBridgeProcessedResultReady;


         if (!processed && InNovaReturnToBridgeRequest.sourceId &&
             !ImageWindow.windowById(InNovaReturnToBridgeRequest.sourceId).isNull)
            resultId = InNovaReturnToBridgeRequest.sourceId;
         if (processed) {
            let preferredIds = [FinalConvertedFocusWindowId, FinalFocusWindowId];
            for (let i = 0; i < preferredIds.length; ++i)
               if (preferredIds[i] && !ImageWindow.windowById(preferredIds[i]).isNull) {
                  resultId = preferredIds[i];
                  break;
               }
            let baseline = {};
            let baselineIds = InNovaReturnToBridgeRequest.baselineIds || [];
            for (let i = 0; i < baselineIds.length; ++i)
               baseline[String(baselineIds[i])] = true;
            if (resultId.length == 0) {
               let active = ImageWindow.activeWindow;
               if (active != null && !active.isNull && !active.mainView.isNull &&
                   !baseline[active.mainView.id])
                  resultId = active.mainView.id;
            }
            if (resultId.length == 0) {
               let current = ImageWindow.windows;
               for (let i = current.length - 1; i >= 0; --i) {
                  if (current[i] == null || current[i].isNull ||
                      current[i].mainView.isNull) continue;
                  let id = current[i].mainView.id;
                  if (!baseline[id] && id.indexOf("_Preview") < 0 &&
                      id.indexOf("mask") < 0) {
                     resultId = id;
                     break;
                  }
               }
            }
         }
         if (resultId.length == 0 && InNovaReturnToBridgeRequest.sourceId &&
             !ImageWindow.windowById(InNovaReturnToBridgeRequest.sourceId).isNull) {
            resultId = InNovaReturnToBridgeRequest.sourceId;
            processed = false;
         }
         Settings.write("InNova/BridgeReturn", DataType_String, JSON.stringify({
            created: Date.now(),
            sourceId: InNovaReturnToBridgeRequest.sourceId || "",
            resultId: resultId,
            processed: processed
         }));
      }
      console.hide();


      MiraLaunchSuiteScript(InNovaReturnToStartPath, 0.20);
   } catch (error) {
      new InNovaNotice(InNovaTr("InNova Start could not be reopened.\n\n") + error,
         "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
   }
}

} catch (error) {
   InNovaDiagnosticWrite("ERROR", "Astro Processor", String(error));
   throw error;
} finally {
   InNovaDiagnosticWrite("STARTUP", "Astro Processor", "Leaving processor");
}
InNovaDiagnosticClose();

#endif
