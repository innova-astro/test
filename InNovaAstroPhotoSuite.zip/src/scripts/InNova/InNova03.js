#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaAdaptiveStretch : InNova Astro Photo Suite > InNova Adaptive Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open color images. \
Uses the shared InNova Astro Photo Suite trial and license. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   "InNova requires PixInsight 1.9.4 or later. Please update PixInsight " +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8

/*
 ****************************************************************************
 * InNova Adaptive Stretch
 *
 * Standalone progressive stretch application for InNova Astro Photo Suite.
 * Copyright (C) 2024-2026 Jesús Manuel García Flores
 ****************************************************************************
 */

#define TITLE "InNova Adaptive Stretch"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

var ProjecTname = "💫 InNova Adaptive Stretch";
var ProjecTver = "v.1.0.build.0051";
var ProjectND = "29ad08xjr";
var ProjectHash =
   "c9a0ca583fd9c1955e1ddc0561d6c6f6c7b078c13c294644f7caca81e6cf8906";
var RuntimeToken = "";
var VarLicense = "EMPTY";
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);

// Compatibility state required by the shared Suite processing engine.
var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var Option300 = "OFF";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Adaptive Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function InNovaAdaptiveStretchInitializeLicense()
{
   if (!IsProjectHashValid()) {
      RuntimeToken = "";
      VarLicense = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Adaptive Stretch",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let license = ReadLicenseData();
   let complete = IsLicenseComplete(license);
   let signatureValid = complete && IsLicenseSignatureValid(license);
   let expired = signatureValid && IsLicenseExpired(license.expiry);

   let refreshOutcome = {};
   if (signatureValid && RefreshLicenseFromServer(license, expired, refreshOutcome)) {
      license = ReadLicenseDataSilent();
      complete = IsLicenseComplete(license);
      signatureValid = complete && IsLicenseSignatureValid(license);
      expired = signatureValid && IsLicenseExpired(license.expiry);
   }

   if (signatureValid) RememberInNovaPaidLicense();
   let paidHistory = HasInNovaPaidHistory();
   expired = signatureValid && IsLicenseExpired(license.expiry);
   let grace = signatureValid && expired && InNovaDeviceAuthorizationValid &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState.lease && InNovaSoftwareState.lease.status === "GRACE" &&
      IsLicenseWithinOnlineGrace(license.expiry);

   if (signatureValid && refreshOutcome.status === "ACCOUNT_AUTHORIZATION_REQUIRED" &&
       refreshOutcome.paidRenewalPending && !InNovaDeviceAuthorizationValid) {
      RuntimeToken = "LICENSE_REQUIRED";
      VarLicense = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Adaptive Stretch");
      return false;
   }

   if (signatureValid && InNovaDeviceAuthorizationValid && (!expired || grace)) {
      RuntimeToken = license.signature.substr(0, 8);
      VarLicense = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         ShowInNovaLicenseExpiryNotice("InNova Adaptive Stretch", license, true);
      else
         console.noteln("✅ InNova Astro Photo Suite license activated.");
      return true;
   }

   if (!complete && !paidHistory && IsProjectDateValid()) {
      RuntimeToken = CreateProjectHash().substr(0, 8);
      VarLicense = "PROJECT";
      console.noteln("🧪 License mode: TRIAL");
      console.noteln("📅 Trial time remaining: " + GetTrialDaysLeft() + " day(s).");
      return true;
   }

   RuntimeToken = "LICENSE_REQUIRED";
   if (expired && !grace) {
      VarLicense = "EXPIRED";
      ShowInNovaLicenseExpiryNotice("InNova Adaptive Stretch", license, false);
      return false;
   }
   if (signatureValid && !InNovaDeviceAuthorizationValid) {
      VarLicense = "DEVICE_REQUIRED";
      ShowInNovaProfileAuthorizationDialog("InNova Adaptive Stretch",
         "This paid license could not be verified on this device.");
      return false;
   }
   VarLicense = "EMPTY";
   if (paidHistory || complete) {
      ShowInNovaProfileAuthorizationDialog("InNova Adaptive Stretch",
         "Your paid license is missing or invalid. Please restore your license from your InNova profile.",
         { missingLicense: true });
      return false;
   }
   new MessageBox(
         "<p align=\"center\">The InNova Astro Photo Suite trial has expired.<br/><br/>" +
         "Please open InNova Integrator and click <b>Manage Subscription</b> in the " +
         "<b>License tab</b> to purchase or renew your subscription.</p>",
      "InNova Adaptive Stretch",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaAdaptiveStretchInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

class InNovaAdaptiveStretchLauncherDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "💫 InNova Adaptive Stretch";

      let logoPath = "";
      this.logoBitmap = null;
      try {
         logoPath = File.extractDrive(#__FILE__) +
            File.extractDirectory(#__FILE__) +
            "/InNova-Astro_Photo_Suite_logo.jpg";
         if (File.exists(logoPath))
            this.logoBitmap = new Bitmap(logoPath);
      }
      catch (logoError) {
         this.logoBitmap = null;
      }
      this.logoControl = null;
      if (this.logoBitmap && !this.logoBitmap.isNull) {
         this.logoControl = new Control(this);
         this.logoControl.bitmap = this.logoBitmap;
         this.logoControl.setScaledFixedSize(160, 120);
         this.logoControl.onPaint = function() {
            let graphics = new Graphics(this);
            graphics.drawScaledBitmap(
               new Rect(0, 0, this.width, this.height), this.bitmap);
            graphics.end();
         };
      }

      this.description = new Label(this);
      this.description.text = "Select an open color image.";
      this.description.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(90);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.refreshButton = new PushButton(this);
      this.refreshButton.text = "Refresh";
      this.refreshButton.icon = this.scaledResource(":/icons/reload.png");
      this.refreshButton.onClick = function() { dialog.populateImages(); };

      this.runButton = new PushButton(this);
      this.runButton.text = "Open Adaptive Stretch";
      this.runButton.icon = this.scaledResource(":/icons/power.png");
      this.runButton.defaultButton = true;
      this.runButton.onClick = function() { dialog.runAdaptiveStretch(); };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function() { dialog.cancel(); };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.refreshButton);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      let logoRow = null;
      if (this.logoControl) {
         logoRow = new HorizontalSizer;
         logoRow.addStretch();
         logoRow.add(this.logoControl);
         logoRow.addStretch();
      }

      let descriptionRow = new HorizontalSizer;
      descriptionRow.addStretch();
      descriptionRow.add(this.description);
      descriptionRow.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      if (logoRow) {
         this.sizer.add(logoRow);
         this.sizer.addSpacing(8);
      }
      this.sizer.add(descriptionRow);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;
      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image ||
             window.mainView.image.numberOfChannels < 3)
            continue;
         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }
      this.sourceCombo.currentItem = selectedIndex;
   }

   runAdaptiveStretch()
   {
      if (!RequireInNovaProcessingAuthorization()) return;
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Adaptive Stretch",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView || source.mainView.isNull) {
         this.populateImages();
         return;
      }

      ProjecTypevar = InNovaAdaptiveStretchInferProjectType(sourceId);
      ProjecTypevarRec = ProjecTypevar;
      MiraConsoleSection("💫 InNova Adaptive Stretch editing: " + sourceId);

      if (MiraRunAdaptiveStretch(source, true)) {
         this.ok();
         CoreApplication.processEvents();
         source.show();
         CoreApplication.processEvents();
         source.zoomToFit(true, false);
         source.bringToFront();
         CoreApplication.processEvents();
         MiraConsoleSection("✅ Process finished.");
      }
      else
         this.populateImages();
   }
}

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");

// Match Integrator: title/separator, license check, then script diagnostics.
// Keep all launcher initialization behind the license gate.
if (MiraRequireCompatiblePixInsight("InNova Adaptive Stretch") &&
    InNovaAdaptiveStretchInitializeLicense()) {
   let dialog = new InNovaAdaptiveStretchLauncherDialog;
   dialog.onShow = function() { MiraCenterDialog(this); };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}


#endif // PixInsight 1.9.4+
