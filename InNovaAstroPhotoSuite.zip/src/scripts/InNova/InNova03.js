#include "lib/InNovaNotice.js"
#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaSmartStretch : InNova Astro Photo Suite > InNova Smart Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open linear images. \
Uses the shared InNova Astro Photo Suite trial and license. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.";

console.criticalln( InNovaMinimumVersionMessage );
new InNovaNotice(
   InNovaTr(InNovaMinimumVersionMessage),
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#ifndef INNOVA_ADAPTIVE_EMBEDDED
#define TITLE "InNova Smart Stretch"
#endif

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

#ifndef INNOVA_ADAPTIVE_EMBEDDED
var ProjecTname = "💫 InNova Smart Stretch";
var ProjecTver = "v1.19.build 0104";
var _0x2d876a3211 = String.fromCharCode(50,53,97,100,49,49,120,106,114);
var _0xdb74725897 =
   String.fromCharCode(49,97,102,51,50,99,57,97,101,51,101,56,55,53,48,98,99,54,97,100,56,102,56,102,98,50,53,48,56,54,99,99,50,98,52,99,53,53,97,99,49,102,51,52,50,98,53,97,97,56,52,98,49,50,99,50,101,102,99,50,100,56,54,51);
var _0xbe2d41ec95 = "";
var _0xde359df820 = "EMPTY";
#endif
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionObjectType = "STARS";
var OptionSeestar = "OFF";
var OptionVaonisVespera = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Smart Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#ifndef INNOVA_ADAPTIVE_EMBEDDED
var MiraDependencyEntry = #__FILE__;
#include "lib/lite01.js"
#endif
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function _0x13298fd2a1()
{
   return _0x8fd8025167("InNova Smart Stretch");
}

function InNovaSmartStretchUniqueWindowId(baseId)
{
   let candidate = baseId;
   let suffix = 2;
   while (ImageWindow.windowById(candidate) &&
          !ImageWindow.windowById(candidate).isNull)
      candidate = baseId + "_" + suffix++;
   return candidate;
}

function InNovaAdaptiveRefreshIcon()
{
   let bitmap = new Bitmap(24, 24);
   bitmap.fill(0x00000000);
   let graphics = new Graphics(bitmap);
   graphics.antialiasing = true;
   graphics.pen = new Pen(0xff30343a, 2);


   let upperArc = [[4,10], [5,7], [7,5], [10,4], [14,4], [18,6]];
   let lowerArc = [[20,14], [19,17], [17,19], [14,20], [10,20], [6,18]];
   for (let i = 0; i + 1 < upperArc.length; ++i)
      graphics.drawLine(upperArc[i][0], upperArc[i][1],
                        upperArc[i + 1][0], upperArc[i + 1][1]);
   for (let j = 0; j + 1 < lowerArc.length; ++j)
      graphics.drawLine(lowerArc[j][0], lowerArc[j][1],
                        lowerArc[j + 1][0], lowerArc[j + 1][1]);
   graphics.drawLine(18, 6, 18, 2);
   graphics.drawLine(18, 6, 14, 7);
   graphics.drawLine(6, 18, 6, 22);
   graphics.drawLine(6, 18, 10, 17);
   graphics.end();
   return bitmap.scaled(2, 2, BitmapInterpolation_Bilinear);
}

function InNovaSmartStretchDebayerCopy(sourceWindow, outputId)
{
   let pattern = MiraMoonSunKeywordValue(sourceWindow, "BAYERPAT");
   if (pattern !== "RGGB" && pattern !== "BGGR" &&
       pattern !== "GBRG" && pattern !== "GRBG")
      return null;
   let temporaryInput = File.uniqueFileName(
      File.systemTempDirectory, 10, "InNova-Adaptive-CFA-", ".fits");
   let temporaryOutput = File.extractDrive(temporaryInput) +
      File.extractDirectory(temporaryInput) + "/" +
      File.extractName(temporaryInput) + "_InNova_d.xisf";
   let opened = null;
   let temporarySource = null;
   try {
      if (sourceWindow.filePath && File.exists(sourceWindow.filePath))
         File.copyFile(temporaryInput, sourceWindow.filePath);
      else {


         let sourceImage = sourceWindow.mainView.image;
         temporarySource = new ImageWindow(
            sourceImage.width, sourceImage.height,
            sourceImage.numberOfChannels, 32, true, false,
            InNovaSmartStretchUniqueWindowId("InNovaAdaptive_CFA_Input"));
         temporarySource.mainView.beginProcess(UndoFlag_NoSwapFile);
         temporarySource.mainView.image.assign(sourceImage);
         temporarySource.mainView.endProcess();
         try { temporarySource.keywords = sourceWindow.keywords; }
         catch (keywordError) {}
         if (!temporarySource.saveAs(
              temporaryInput, false, false, false, false))
            throw new Error(
               InNovaTr("The in-memory Bayer image could not be prepared for Debayer."));
         temporarySource.forceClose();
         temporarySource = null;
      }
      let process = new Debayer;
      process.targetItems = [[true, temporaryInput]];
      process.cfaPattern = MiraMoonSunDebayerPattern(pattern);
      process.debayerMethod = Debayer.VNG;
      process.evaluateNoise = false;
      process.evaluateSignal = false;
      process.outputRGBImages = true;
      process.outputSeparateChannels = false;
      process.outputDirectory = File.extractDrive(temporaryInput) +
                                File.extractDirectory(temporaryInput);
      process.outputExtension = ".xisf";
      process.outputPostfix = "_InNova_d";
      process.overwriteExistingFiles = true;
      if (!process.executeGlobal() || !File.exists(temporaryOutput))
         throw new Error(InNovaTr("PixInsight Debayer did not create its RGB output."));
      opened = ImageWindow.open(temporaryOutput);
      if (!opened || opened.length === 0 || opened[0].isNull ||
          !opened[0].mainView.image.isColor)
         throw new Error(InNovaTr("The Debayer output is not a valid RGB image."));
      opened[0].mainView.id = outputId;
      console.noteln("✅ Standalone preparation: VNG Debayer " + pattern + ".");
      return opened[0];
   }
   catch (error) {
      if (opened && opened.length > 0 && opened[0] && !opened[0].isNull)
         opened[0].forceClose();
      if (temporarySource && !temporarySource.isNull)
         temporarySource.forceClose();
      throw error;
   }
   finally {
      try {
         if (temporarySource && !temporarySource.isNull)
            temporarySource.forceClose();
      } catch (ignoreSourceError) {}
      try { if (File.exists(temporaryInput)) File.remove(temporaryInput); }
      catch (ignoreInputError) {}
      try { if (File.exists(temporaryOutput)) File.remove(temporaryOutput); }
      catch (ignoreOutputError) {}
   }
}

function InNovaSmartStretchPrepareCopy(sourceWindow, objectType,
                                           imageType)
{
   let baseId = InNovaSmartStretchUniqueWindowId(
      sourceWindow.mainView.id + "_InNova_Prepared");
   let prepared = null;
   let corrected = null;
   try {
      let image = sourceWindow.mainView.image;
      if (image.isColor && image.numberOfChannels >= 3)
         prepared = MiraAdaptiveStretchWindowFromImage(image, baseId);
      else if (objectType === "MOON_SUN" ||
               imageType.indexOf("SEESTAR") === 0 ||
               imageType.indexOf("VAONIS") === 0) {
         prepared = InNovaSmartStretchDebayerCopy(sourceWindow, baseId);
         if (!prepared)
            prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
      }
      else {
         prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
         console.noteln(
            "✅ Standalone preparation: monochrome source expanded to neutral RGB.");
      }


      if (objectType === "MOON_SUN") {
         console.noteln(
            "🌙 Moon or Sun preparation: preserving the source without ABE.");
         prepared.mainView.id = InNovaSmartStretchUniqueWindowId(
            sourceWindow.mainView.id + "_InNova_Adaptive");
         prepared.show();
         prepared.position = new Point(0, 0);
         prepared.bringToFront();
         let brightTarget = prepared;
         prepared = null;
         return brightTarget;
      }

      console.noteln("🧹 Standalone preparation: applying ABE to a temporary copy.");
      MiraABE(prepared);
      corrected = ImageWindow.windowById(prepared.mainView.id + "_ABE");
      if (!corrected || corrected.isNull || !corrected.mainView ||
          corrected.mainView.isNull)
         throw new Error(InNovaTr("ABE did not create the prepared image."));
      prepared.forceClose();
      prepared = null;
      corrected.mainView.id = InNovaSmartStretchUniqueWindowId(
         sourceWindow.mainView.id + "_InNova_Adaptive");
      corrected.show();
      corrected.position = new Point(0, 0);
      corrected.bringToFront();
      return corrected;
   }
   catch (error) {
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (corrected && !corrected.isNull) corrected.forceClose();
      throw error;
   }
}

function InNovaAdaptiveSelectSourceFile(masters)
{
   let files = new OpenFileDialog;
   files.caption = InNovaTr("Open an image for InNova Smart Stretch");
   files.multipleSelections = false;
   files.filters = [[InNovaTr("Images"), "*.xisf *.fits *.fit *.fts *.tif *.tiff *.png *.jpg *.jpeg"],
                    [InNovaTr("All files"), "*"]];
   if (masters) files.initialPath = InNovaImageMasterDirectory() + "/";
   if (!files.execute()) return null;
   let opened = ImageWindow.open(files.fileName);
   if (!opened || opened.length === 0) return null;
   for (let i = 0; i < opened.length; ++i) opened[i].show();
   return opened[0];
}

function InNovaAdaptiveSourceType(source)
{
   return !source.mainView.image.isColor ||
      source.mainView.image.numberOfChannels < 3 ? 0 : 1;
}

function InNovaAdaptiveKeywordValue(source, names)
{
   if (!source || source.isNull) return "";
   let keywords = source.keywords;
   for (let i = 0; i < keywords.length; ++i) {
      let name = String(keywords[i].name).toUpperCase();
      for (let j = 0; j < names.length; ++j)
         if (name === names[j])
            return String(keywords[i].strippedValue).trim();
   }
   return "";
}

function InNovaAdaptiveDetectedSourceType(source)
{
   let names = ["CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION",
      "INNVDEV"];
   let identity = InNovaAdaptiveKeywordValue(source, names) + " " +
      (source && source.filePath ? String(source.filePath) : "") + " " +
      (source && source.mainView && !source.mainView.isNull ?
         String(source.mainView.id) : "");
   if (/SEESTAR[^\n]*S50\s*PRO|S50\s*PRO(?![A-Z0-9])/i.test(identity)) return 4;
   if (/SEESTAR[^\n]*S50(?![^\n]*PRO)|S50(?!\s*PRO)(?![A-Z0-9])/i.test(identity)) return 3;
   if (/SEESTAR[^\n]*S30\s*PRO|S30\s*PRO(?![A-Z0-9])/i.test(identity)) return 2;
   if (/SEESTAR/i.test(identity)) return 5;
   if (/VAONIS_VESPERA_III|VESPERA[^A-Z0-9]*(III|3)([^A-Z0-9]|$)/i.test(identity)) return 6;
   if (/VAONIS|VESPERA/i.test(identity)) return 7;
   return InNovaAdaptiveSourceType(source);
}


function InNovaAdaptiveAcquisition(state)
{
   this.pending = null;
   let context = this;
   this.buildControls = function(dialog)
   {
      let group = new GroupBox(dialog);
      group.title = "";
      group.sizer = new VerticalSizer;
      group.sizer.margin = 8;
      group.sizer.spacing = 6;
      let line = new HorizontalSizer;
      line.spacing = 6;
      let typeLabel = new Label(group);
      typeLabel.text = InNovaAdaptiveText("Image type:");
      typeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let type = new ComboBox(group);
      for (let name of ["Monochrome (B/W)", "OSC", "Seestar S30 Pro",
                        "Seestar S50", "Seestar S50 Pro",
                        "Seestar (Automatic)", "VAONIS Vespera III",
                        "VAONIS Vespera (Automatic)"])
         type.addItem(InNovaTr(name));
      type.currentItem = state.imageType;
      let objectLabel = new Label(group);
      objectLabel.text = InNovaAdaptiveText("Object:");
      objectLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let object = new ComboBox(group);
      object.addItem(InNovaTr("Nebula or Galaxy"));
      object.addItem(InNovaTr("Moon or Sun"));
      object.currentItem = state.objectType;
      line.add(typeLabel);
      line.add(type, 100);
      line.addSpacing(8);
      line.add(objectLabel);
      line.add(object, 100);
      group.sizer.add(line);
      dialog.acquisitionOpenButton = new ToolButton(dialog);
      let open = dialog.acquisitionOpenButton;
      open.icon = dialog.scaledResource(":/icons/folder-open.png");
      open.setScaledFixedSize(28, 28);
      open.toolTip = InNovaAdaptiveText("Open an image file");
      dialog.acquisitionMastersButton = new ToolButton(dialog);
      let masters = dialog.acquisitionMastersButton;
      masters.icon = dialog.scaledResource(":/icons/documents-import.png");
      masters.setScaledFixedSize(28, 28);
      masters.toolTip = InNovaAdaptiveText("Open masters from Documents/InNova/Sub master files");
      group.toolTip = InNovaAdaptiveText("Changing acquisition restarts the stretch adjustments from the original image.");
      function request(sourceId, imageType, objectType) {
         if (sourceId === state.sourceId && imageType === state.imageType &&
             objectType === state.objectType) return;
         context.pending = { sourceId: sourceId, imageType: imageType,
            objectType: objectType };
         dialog.cancel();
      }
      type.onItemSelected = function(index) {
         request(state.sourceId, index, object.currentItem);
      };
      object.onItemSelected = function(index) {
         request(state.sourceId, type.currentItem, index);
      };
      function loadSource(fromMasters) {
         try {
            let win = fromMasters ? InNovaAdaptiveSelectSourceFile(true) :
               InNovaAdaptiveChooseOpenSource();
            if (win) request(win.mainView.id,
               InNovaAdaptiveDetectedSourceType(win), object.currentItem);
         } catch (error) {
            new InNovaNotice(String(error), "InNova Smart Stretch",
               StdIcon_Error, StdButton_Ok).execute();
         }
      };
      open.onClick = function() { loadSource(false); };
      masters.onClick = function() { loadSource(true); };
      return group;
   };
}

function InNovaAdaptiveChooseOpenSource()
{
   let id = InNovaChooseWorkspaceSource("InNova Smart Stretch", "adaptive", false,
      InNovaAdaptiveSelectSourceFile);
   return id ? ImageWindow.windowById(id) : null;
}

function InNovaAdaptiveRunMain(showSelector)
{
   let source = ImageWindow.activeWindow;
   if (showSelector || !source || source.isNull) {
      try { source = InNovaAdaptiveChooseOpenSource(); }
      catch (error) {
         new InNovaNotice(String(error), "InNova Smart Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         return;
      }
   }
   if (!source || source.isNull) return;
   let state = { sourceId: source.mainView.id,
      imageType: InNovaAdaptiveDetectedSourceType(source), objectType: 0 };
   let previous = null;
   for (;;) {
      if (!_0x0775d46f40()) return;
      let prepared = null;
      let context = null;
      try {
         source = ImageWindow.windowById(state.sourceId);
         if (!source || source.isNull) throw new Error(InNovaTr("The selected image is no longer available."));
         let selectedType = ["MONOCHROME", "OSC", "SEESTAR_S30_PRO",
            "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
            "VAONIS_VESPERA_III", "VAONIS_AUTO"][state.imageType];
         ProjecTypevar = "OSC";
         ProjecTypevarRec = ProjecTypevar;
         OptionObjectType = state.objectType === 1 ? "MOON_SUN" : "STARS";
         OptionSeestar = selectedType.indexOf("SEESTAR") === 0 ? "ON" : "OFF";
         OptionVaonisVespera = selectedType.indexOf("SEESTAR") === 0 ||
            selectedType.indexOf("VAONIS") === 0 ? "ON" : "OFF";
         OptionSmartTelescopeModel = OptionVaonisVespera === "ON" ?
            selectedType : "NONE";
         prepared = InNovaSmartStretchPrepareCopy(source, OptionObjectType, selectedType);
         context = new InNovaAdaptiveAcquisition({ sourceId: state.sourceId,
            imageType: state.imageType, objectType: state.objectType, prepared: prepared });
         if (MiraRunAdaptiveStretch(prepared, true, selectedType === "MONOCHROME", context)) {
            prepared.show();
            prepared.zoomToFit(true, false);
            prepared.bringToFront();
            return { window: prepared, sourceId: state.sourceId };
         }
      } catch (error) {
         new InNovaNotice(InNovaTr("The selected image could not be prepared.") + "\n\n" +
            (error.message || error), "InNova Smart Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         if (prepared && !prepared.isNull) prepared.forceClose();
         if (previous) { state = previous; previous = null; continue; }
         return;
      }
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (!context || !context.pending) return;
      previous = state;
      state = context.pending;
   }
}

#ifndef INNOVA_ADAPTIVE_EMBEDDED

InNovaDiagnosticRun("Smart Stretch", function() {
console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Smart Stretch") &&
    _0x13298fd2a1()) {
   InNovaAdaptiveRunMain(true);
}


});
#endif

#endif
