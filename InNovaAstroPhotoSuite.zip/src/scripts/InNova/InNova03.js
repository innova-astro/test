#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaAdaptiveStretch : InNova Astro Photo Suite > InNova Adaptive Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open linear images. \
Uses the shared InNova Astro Photo Suite access state. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#ifndef INNOVA_ADAPTIVE_EMBEDDED
#define TITLE "InNova Adaptive Stretch"
#endif

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

#ifndef INNOVA_ADAPTIVE_EMBEDDED
var ProjecTname = "💫 InNova Adaptive Stretch";
var ProjecTver = "v.1.0.build.0076";
var _0x470f5b15dc = String.fromCharCode(48,53,97,100,48,57,120,106,114);
var _0xcefea98f25 =
   String.fromCharCode(98,99,51,53,48,99,55,52,97,100,97,48,50,102,101,52,55,100,98,52,54,102,100,99,99,54,102,97,48,52,51,48,50,48,57,97,52,48,102,52,98,49,100,57,51,97,99,57,100,99,100,100,49,52,48,57,51,57,50,56,51,102,57,50);
var _0x8a60858f5f = "";
var _0xc7fa59117d = "EMPTY";
#endif
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionObjectType = "STARS";
var OptionSeestar = "OFF";
var OptionVaonisVespera = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Adaptive Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#ifndef INNOVA_ADAPTIVE_EMBEDDED
#include "lib/lite01.js"
#endif
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function _0x3e9632100e()
{
   if (!_0x9f874de4e9()) {
      _0x8a60858f5f = "";
      _0xc7fa59117d = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Adaptive Stretch",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let _0x005b54a9d2 = _0xb5810b7d9b();
   let complete = _0x1d80a60689(_0x005b54a9d2);
   let signatureValid = complete && _0x54354d7f32(_0x005b54a9d2);
   let _0x2a14b3be38 = signatureValid && _0x881275c82f(_0x005b54a9d2[String.fromCharCode(101,120,112,105,114,121)]);

   let refreshOutcome = {};
   if (signatureValid && _0x02a7e3f45c(_0x005b54a9d2, _0x2a14b3be38, refreshOutcome)) {
      _0x005b54a9d2 = _0x7799a174a1();
      complete = _0x1d80a60689(_0x005b54a9d2);
      signatureValid = complete && _0x54354d7f32(_0x005b54a9d2);
      _0x2a14b3be38 = signatureValid && _0x881275c82f(_0x005b54a9d2[String.fromCharCode(101,120,112,105,114,121)]);
   }

   if (signatureValid) _0x378405d922();
   let _0x0312825575 = _0x842d83d5c4();
   _0x2a14b3be38 = signatureValid && _0x881275c82f(_0x005b54a9d2[String.fromCharCode(101,120,112,105,114,121)]);
   let grace = signatureValid && _0x2a14b3be38 && _0x61ceb2dad9 &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)] && InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)].status === "GRACE" &&
      _0x4ffd097a2c(_0x005b54a9d2[String.fromCharCode(101,120,112,105,114,121)]);

   if (signatureValid && refreshOutcome.status === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
       refreshOutcome.paidRenewalPending && !_0x61ceb2dad9) {
      _0x8a60858f5f = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
      _0xc7fa59117d = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Adaptive Stretch");
      return false;
   }

   if (signatureValid && _0x61ceb2dad9 && (!_0x2a14b3be38 || grace)) {
      _0x8a60858f5f = _0x005b54a9d2[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
      _0xc7fa59117d = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         _0xe94ca2a3e7("InNova Adaptive Stretch", _0x005b54a9d2, true);
      else
         console.noteln(String.fromCharCode(9989,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,108,105,99,101,110,115,101,32,97,99,116,105,118,97,116,101,100,46));
      return true;
   }

   if (!complete && !_0x0312825575 && IsProjectDateValid()) {
      _0x8a60858f5f = _0x3aaefdb02b().substr(0, 8);
      _0xc7fa59117d = "PROJECT";
      console.noteln(String.fromCharCode(55358,56810,32,76,105,99,101,110,115,101,32,109,111,100,101,58,32,84,82,73,65,76));
      console.noteln(String.fromCharCode(55357,56517,32,84,114,105,97,108,32,116,105,109,101,32,114,101,109,97,105,110,105,110,103,58,32) + _0xed0ef1cb02() + " day(s).");
      return true;
   }

   _0x8a60858f5f = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
   if (_0x2a14b3be38 && !grace) {
      _0xc7fa59117d = String.fromCharCode(69,88,80,73,82,69,68);
      _0xe94ca2a3e7("InNova Adaptive Stretch", _0x005b54a9d2, false);
      return false;
   }
   if (signatureValid && !_0x61ceb2dad9) {
      _0xc7fa59117d = "DEVICE_REQUIRED";
      _0xe8c10b0eaf("InNova Adaptive Stretch",
         String.fromCharCode(84,104,105,115,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,111,110,32,116,104,105,115,32,100,101,118,105,99,101,46));
      return false;
   }
   _0xc7fa59117d = "EMPTY";
   if (_0x0312825575 || complete) {
      _0xe8c10b0eaf("InNova Adaptive Stretch",
         String.fromCharCode(89,111,117,114,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,109,105,115,115,105,110,103,32,111,114,32,105,110,118,97,108,105,100,46,32,80,108,101,97,115,101,32,114,101,115,116,111,114,101,32,121,111,117,114,32,108,105,99,101,110,115,101,32,102,114,111,109,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,46),
         { [String.fromCharCode(109,105,115,115,105,110,103,76,105,99,101,110,115,101)]: true });
      return false;
   }
   new MessageBox(
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,116,114,105,97,108,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
         String.fromCharCode(80,108,101,97,115,101,32,111,112,101,110,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,114,111,99,101,115,115,111,114,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32) +
         String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32,116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
      "InNova Adaptive Stretch",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaAdaptiveStretchUniqueWindowId(baseId)
{
   let candidate = baseId;
   let suffix = 2;
   while (ImageWindow.windowById(candidate) &&
          !ImageWindow.windowById(candidate).isNull)
      candidate = baseId + "_" + suffix++;
   return candidate;
}

function InNovaAdaptiveRefreshIcon()
{
   let bitmap = new Bitmap(24, 24);
   bitmap.fill(0x00000000);
   let graphics = new Graphics(bitmap);
   graphics.antialiasing = true;
   graphics.pen = new Pen(0xff30343a, 2);


   let upperArc = [[4,10], [5,7], [7,5], [10,4], [14,4], [18,6]];
   let lowerArc = [[20,14], [19,17], [17,19], [14,20], [10,20], [6,18]];
   for (let i = 0; i + 1 < upperArc.length; ++i)
      graphics.drawLine(upperArc[i][0], upperArc[i][1],
                        upperArc[i + 1][0], upperArc[i + 1][1]);
   for (let j = 0; j + 1 < lowerArc.length; ++j)
      graphics.drawLine(lowerArc[j][0], lowerArc[j][1],
                        lowerArc[j + 1][0], lowerArc[j + 1][1]);
   graphics.drawLine(18, 6, 18, 2);
   graphics.drawLine(18, 6, 14, 7);
   graphics.drawLine(6, 18, 6, 22);
   graphics.drawLine(6, 18, 10, 17);
   graphics.end();
   return bitmap.scaled(2, 2, BitmapInterpolation_Bilinear);
}

function InNovaAdaptiveStretchDebayerCopy(sourceWindow, outputId)
{
   let pattern = MiraMoonSunKeywordValue(sourceWindow, "BAYERPAT");
   if (pattern !== "RGGB" && pattern !== "BGGR" &&
       pattern !== "GBRG" && pattern !== "GRBG")
      return null;
   if (!sourceWindow.filePath || !File.exists(sourceWindow.filePath))
      throw new Error(
         "The Bayer image has no readable source file for Debayer.");

   let temporaryInput = File.uniqueFileName(
      File.systemTempDirectory, 10, "InNova-Adaptive-CFA-", ".fits");
   let temporaryOutput = File.extractDrive(temporaryInput) +
      File.extractDirectory(temporaryInput) + "/" +
      File.extractName(temporaryInput) + "_InNova_d.xisf";
   let opened = null;
   try {
      File.copyFile(temporaryInput, sourceWindow.filePath);
      let process = new Debayer;
      process.targetItems = [[true, temporaryInput]];
      process.cfaPattern = MiraMoonSunDebayerPattern(pattern);
      process.debayerMethod = Debayer.VNG;
      process.evaluateNoise = false;
      process.evaluateSignal = false;
      process.outputRGBImages = true;
      process.outputSeparateChannels = false;
      process.outputDirectory = File.extractDrive(temporaryInput) +
                                File.extractDirectory(temporaryInput);
      process.outputExtension = ".xisf";
      process.outputPostfix = "_InNova_d";
      process.overwriteExistingFiles = true;
      if (!process.executeGlobal() || !File.exists(temporaryOutput))
         throw new Error("PixInsight Debayer did not create its RGB output.");
      opened = ImageWindow.open(temporaryOutput);
      if (!opened || opened.length === 0 || opened[0].isNull ||
          !opened[0].mainView.image.isColor)
         throw new Error("The Debayer output is not a valid RGB image.");
      opened[0].mainView.id = outputId;
      console.noteln("✅ Standalone preparation: VNG Debayer " + pattern + ".");
      return opened[0];
   }
   catch (error) {
      if (opened && opened.length > 0 && opened[0] && !opened[0].isNull)
         opened[0].forceClose();
      throw error;
   }
   finally {
      try { if (File.exists(temporaryInput)) File.remove(temporaryInput); }
      catch (ignoreInputError) {}
      try { if (File.exists(temporaryOutput)) File.remove(temporaryOutput); }
      catch (ignoreOutputError) {}
   }
}

function InNovaAdaptiveStretchPrepareCopy(sourceWindow, objectType,
                                           imageType)
{
   let baseId = InNovaAdaptiveStretchUniqueWindowId(
      sourceWindow.mainView.id + "_InNova_Prepared");
   let prepared = null;
   let corrected = null;
   try {
      let image = sourceWindow.mainView.image;
      if (image.isColor && image.numberOfChannels >= 3)
         prepared = MiraAdaptiveStretchWindowFromImage(image, baseId);
      else if (objectType === "MOON_SUN" ||
               imageType.indexOf("SEESTAR") === 0 ||
               imageType.indexOf("VAONIS") === 0) {
         prepared = InNovaAdaptiveStretchDebayerCopy(sourceWindow, baseId);
         if (!prepared)
            prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
      }
      else {
         prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
         console.noteln(
            "✅ Standalone preparation: monochrome source expanded to neutral RGB.");
      }

      console.noteln("🧹 Standalone preparation: applying ABE to a temporary copy.");
      MiraABE(prepared);
      corrected = ImageWindow.windowById(prepared.mainView.id + "_ABE");
      if (!corrected || corrected.isNull || !corrected.mainView ||
          corrected.mainView.isNull)
         throw new Error("ABE did not create the prepared image.");
      prepared.forceClose();
      prepared = null;
      corrected.mainView.id = InNovaAdaptiveStretchUniqueWindowId(
         sourceWindow.mainView.id + "_InNova_Adaptive");
      corrected.show();
      corrected.position = new Point(0, 0);
      corrected.bringToFront();
      return corrected;
   }
   catch (error) {
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (corrected && !corrected.isNull) corrected.forceClose();
      throw error;
   }
}

function InNovaAdaptiveSelectSourceFile()
{
   let files = new OpenFileDialog;
   files.caption = "Open an image for InNova Adaptive Stretch";
   files.multipleSelections = false;
   files.filters = [["Images", "*.xisf *.fits *.fit *.fts *.tif *.tiff *.png *.jpg *.jpeg"],
                    ["All files", "*"]];
   if (!files.execute()) return null;
   let opened = ImageWindow.open(files.fileName);
   if (!opened || opened.length === 0) return null;
   for (let i = 0; i < opened.length; ++i) opened[i].show();
   return opened[0];
}

function InNovaAdaptiveSourceType(source)
{
   return !source.mainView.image.isColor ||
      source.mainView.image.numberOfChannels < 3 ? 0 : 1;
}

function InNovaAdaptiveKeywordValue(source, names)
{
   if (!source || source.isNull) return "";
   let keywords = source.keywords;
   for (let i = 0; i < keywords.length; ++i) {
      let name = String(keywords[i].name).toUpperCase();
      for (let j = 0; j < names.length; ++j)
         if (name === names[j])
            return String(keywords[i].strippedValue).trim();
   }
   return "";
}

function InNovaAdaptiveDetectedSourceType(source)
{
   let names = ["CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION"];
   let identity = InNovaAdaptiveKeywordValue(source, names) + " " +
      (source && source.filePath ? String(source.filePath) : "") + " " +
      (source && source.mainView && !source.mainView.isNull ?
         String(source.mainView.id) : "");
   if (/SEESTAR[^\n]*S50\s*PRO|S50\s*PRO(?![A-Z0-9])/i.test(identity)) return 4;
   if (/SEESTAR[^\n]*S50(?![^\n]*PRO)|S50(?!\s*PRO)(?![A-Z0-9])/i.test(identity)) return 3;
   if (/SEESTAR[^\n]*S30\s*PRO|S30\s*PRO(?![A-Z0-9])/i.test(identity)) return 2;
   if (/SEESTAR/i.test(identity)) return 5;
   if (/VAONIS_VESPERA_III|VESPERA[^A-Z0-9]*(III|3)([^A-Z0-9]|$)/i.test(identity)) return 6;
   if (/VAONIS|VESPERA/i.test(identity)) return 7;
   return InNovaAdaptiveSourceType(source);
}


function InNovaAdaptiveAcquisition(state)
{
   this.pending = null;
   let context = this;
   this.buildControls = function(dialog)
   {
      let group = new GroupBox(dialog);
      group.title = "1. Acquisition";
      group.sizer = new VerticalSizer;
      group.sizer.margin = 8;
      group.sizer.spacing = 6;
      let line = new HorizontalSizer;
      line.spacing = 6;
      let typeLabel = new Label(group);
      typeLabel.text = "Image type:";
      typeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let type = new ComboBox(group);
      for (let name of ["Monochrome (B/W)", "OSC", "Seestar S30 Pro",
                        "Seestar S50", "Seestar S50 Pro",
                        "Seestar (Automatic)", "VAONIS Vespera III",
                        "VAONIS Vespera (Automatic)"])
         type.addItem(name);
      type.currentItem = state.imageType;
      let objectLabel = new Label(group);
      objectLabel.text = "Object:";
      objectLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let object = new ComboBox(group);
      object.addItem("Nebula or Galaxy");
      object.addItem("Moon or Sun");
      object.currentItem = state.objectType;
      line.add(typeLabel);
      line.add(type, 100);
      line.addSpacing(16);
      line.add(objectLabel);
      line.add(object, 100);
      group.sizer.add(line);
      dialog.acquisitionOpenButton = new ToolButton(dialog);
      let open = dialog.acquisitionOpenButton;
      open.icon = dialog.scaledResource(":/icons/folder-open.png");
      open.setScaledFixedSize(28, 28);
      open.toolTip = "Open an image file";
      group.toolTip = "Changing acquisition restarts the stretch adjustments from the original image.";
      function request(sourceId, imageType, objectType) {
         if (sourceId === state.sourceId && imageType === state.imageType &&
             objectType === state.objectType) return;
         context.pending = { sourceId: sourceId, imageType: imageType,
            objectType: objectType };
         dialog.cancel();
      }
      type.onItemSelected = function(index) {
         request(state.sourceId, index, object.currentItem);
      };
      object.onItemSelected = function(index) {
         request(state.sourceId, type.currentItem, index);
      };
      open.onClick = function() {
         try {
            let win = InNovaAdaptiveSelectSourceFile();
            if (win) request(win.mainView.id,
               InNovaAdaptiveDetectedSourceType(win), object.currentItem);
         } catch (error) {
            new MessageBox(String(error), "InNova Adaptive Stretch",
               StdIcon_Error, StdButton_Ok).execute();
         }
      };
      return group;
   };
}

function InNovaAdaptiveChooseOpenSource()
{
   let dialog = new Dialog;
   dialog.windowTitle = "💫 InNova Adaptive Stretch";
   let sources = [];
   let images = new ComboBox(dialog);
   images.setMinWidth(430);
   let imageLabel = new Label(dialog);
   imageLabel.text = "Image:";
   imageLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   imageLabel.setFixedWidth(90);
   let header = new Control(dialog);
   let artworkRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/assets/headers/";
   let background = File.exists(artworkRoot + "guided.png") ? new Bitmap(artworkRoot + "guided.png") : null;
   header.onPaint = function() {
      let g = new Graphics(this);
      g.fillRect(0, 0, this.width, this.height, new Brush(0xffe5f2ff));
      if (background && !background.isNull)
         g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), background);
      g.pen = new Pen(0xff237aca, this.logicalPixelsToPhysical(1));
      g.drawRect(0, 0, this.width-1, this.height-1);
      g.end();
   };
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   let icon = new Control(header);
   icon.setScaledFixedSize(68, 68);
   let artwork = File.exists(artworkRoot + "adaptive.png") ? new Bitmap(artworkRoot + "adaptive.png") : null;
   icon.onPaint = function() {
      if (!artwork || artwork.isNull) return;
      let g = new Graphics(this);
      g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), artwork);
      g.end();
   };
   header.sizer.add(icon);
   let text = new VerticalSizer;
   text.spacing = 5;
   text.addStretch();
   function headerLabel(value, size) {
      let label = new Label(header);
      label.useRichText = true;
      label.wordWrapping = true;
      label.text = value;
      label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      label.styleSheet = "font-size:" + size + "pt;color:#102b50;background:transparent;";
      text.add(label);
   }
   headerLabel("<b>InNova Adaptive Stretch</b>", 20);
   headerLabel("Select an open image to stretch.", 12);
   headerLabel("Preserves the original and creates a new stretched result.", 12);
   text.addStretch();
   header.sizer.add(text, 100);
   let reload = new ToolButton(dialog);
   reload.icon = InNovaAdaptiveRefreshIcon();
   reload.setScaledFixedSize(28, 28);
   reload.toolTip = "Refresh the list of open PixInsight images";
   reload.onClick = function() { refresh(null); };
   let open = new ToolButton(dialog);
   open.icon = dialog.scaledResource(":/icons/folder-open.png");
   open.setScaledFixedSize(28, 28);
   open.toolTip = "Open an image file";
   let run = new PushButton(dialog);
   run.text = "Run InNova Adaptive Stretch";
   run.icon = dialog.scaledResource(":/icons/power.png");
   run.defaultButton = true;
   let cancel = new PushButton(dialog);
   cancel.text = "Close";
   cancel.icon = dialog.scaledResource(":/icons/close.png");
   function refresh(selected) {
      sources = ImageWindow.windows.filter(function(window) {
         return window != null && !window.isNull;
      });
      images.clear();
      images.addItem("<Select an image>");
      for (let i = 0; i < sources.length; ++i) {
         images.addItem(sources[i].mainView.id);
         if (selected && sources[i].mainView.id === selected.mainView.id)
            images.currentItem = i + 1;
      }
      run.enabled = images.currentItem > 0;
   }
   open.onClick = function() {
      try {
         let source = InNovaAdaptiveSelectSourceFile();
         if (source) refresh(source);
      } catch (error) {
         new MessageBox(String(error), "InNova Adaptive Stretch",
            StdIcon_Error, StdButton_Ok).execute();
      }
   };
   images.onItemSelected = function(index) { run.enabled = index > 0; };
   run.onClick = function() { if (images.currentItem > 0) dialog.ok(); };
   cancel.onClick = function() { dialog.cancel(); };
   let row = new HorizontalSizer;
   row.spacing = 8;
   row.add(imageLabel);
   row.add(images, 100);
   row.add(open);
   row.add(reload);
   let buttons = new HorizontalSizer;
   buttons.spacing = 8;
   buttons.addStretch();
   buttons.add(run);
   buttons.add(cancel);
   buttons.addStretch();
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 12;
   dialog.sizer.spacing = 10;
   dialog.sizer.add(header);
   dialog.sizer.add(row);
   dialog.sizer.addSpacing(4);
   dialog.sizer.add(buttons);
   refresh(null);
   dialog.adjustToContents();
   if (dialog.execute() != StdDialogCode_Ok) return null;
   return sources[images.currentItem - 1] || null;
}

function InNovaAdaptiveRunMain(showSelector)
{
   let source = ImageWindow.activeWindow;
   if (showSelector || !source || source.isNull) {
      try { source = InNovaAdaptiveChooseOpenSource(); }
      catch (error) {
         new MessageBox(String(error), "InNova Adaptive Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         return;
      }
   }
   if (!source || source.isNull) return;
   let state = { sourceId: source.mainView.id,
      imageType: InNovaAdaptiveDetectedSourceType(source), objectType: 0 };
   let previous = null;
   for (;;) {
      if (!_0x00683becdd()) return;
      let prepared = null;
      let context = null;
      try {
         source = ImageWindow.windowById(state.sourceId);
         if (!source || source.isNull) throw new Error("The selected image is no longer available.");
         let selectedType = ["MONOCHROME", "OSC", "SEESTAR_S30_PRO",
            "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
            "VAONIS_VESPERA_III", "VAONIS_AUTO"][state.imageType];
         ProjecTypevar = "OSC";
         ProjecTypevarRec = ProjecTypevar;
         OptionObjectType = state.objectType === 1 ? "MOON_SUN" : "STARS";
         OptionSeestar = selectedType.indexOf("SEESTAR") === 0 ? "ON" : "OFF";
         OptionVaonisVespera = selectedType.indexOf("SEESTAR") === 0 ||
            selectedType.indexOf("VAONIS") === 0 ? "ON" : "OFF";
         OptionSmartTelescopeModel = OptionVaonisVespera === "ON" ?
            selectedType : "NONE";
         prepared = InNovaAdaptiveStretchPrepareCopy(source, OptionObjectType, selectedType);
         context = new InNovaAdaptiveAcquisition({ sourceId: state.sourceId,
            imageType: state.imageType, objectType: state.objectType, prepared: prepared });
         if (MiraRunAdaptiveStretch(prepared, true, selectedType === "MONOCHROME", context)) {
            prepared.show();
            prepared.zoomToFit(true, false);
            prepared.bringToFront();
            return { window: prepared, sourceId: state.sourceId };
         }
      } catch (error) {
         new MessageBox("The selected image could not be prepared.\n\n" +
            (error.message || error), "InNova Adaptive Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         if (prepared && !prepared.isNull) prepared.forceClose();
         if (previous) { state = previous; previous = null; continue; }
         return;
      }
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (!context || !context.pending) return;
      previous = state;
      state = context.pending;
   }
}

#ifndef INNOVA_ADAPTIVE_EMBEDDED

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Adaptive Stretch") &&
    _0x3e9632100e()) {
   InNovaAdaptiveRunMain(true);
}


#endif

#endif
