#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaEditor : InNova Astro Photo Suite > InNova Photo Editor
#feature-icon  InNovaIcon.svg
#feature-info  Final image editor for InNova Astro Photo Suite. \
Uses the shared InNova Astro Photo Suite access state. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#ifndef INNOVA_EDITOR_EMBEDDED
#define TITLE "InNova Photo Editor"
#endif

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>


#ifndef INNOVA_EDITOR_EMBEDDED
var ProjecTname = "🪐 InNova Photo Editor";
var ProjecTver = "v.1.0.build.0210";
var _0x5d0b64ce15 = String.fromCharCode(48,56,97,100,48,57,120,106,114);
var _0xdbfebaadcc =
   String.fromCharCode(57,53,97,57,56,100,54,52,98,97,56,99,55,102,55,48,56,100,52,53,51,102,99,49,49,50,101,99,98,100,56,98,52,53,54,57,101,49,56,50,55,49,97,102,97,51,100,101,99,100,49,57,49,100,54,52,56,99,97,54,55,101,49,48);
var _0xc7acb59813 = "";
var _0xce8ee91fbb = "EMPTY";
#endif
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);
var InNovaEditorPendingSourceSetting = "InNovaEclipsesEditorSourceId";
var InNovaEditorEclipseCleanupSetting =
   "InNovaEclipsesCleanupAfterEditor";
var InNovaEditorEclipseGeometryXSetting =
   "InNovaEclipsesEditorGeometryX";
var InNovaEditorEclipseGeometryYSetting =
   "InNovaEclipsesEditorGeometryY";
var InNovaEditorEclipseGeometryRadiusSetting =
   "InNovaEclipsesEditorGeometryRadius";
var InNovaEditorEclipseCoronaStrengthSetting =
   "InNovaEclipsesEditorCoronaStrength";
var InNovaEditorEclipseLimbProtectionSetting =
   "InNovaEclipsesEditorLimbProtection";
var InNovaEditorEclipseFilamentCalibrationSetting =
   "InNovaEclipsesFilamentCalibrationMode";


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionNarrowbandToRGB = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var StarXPath = "EMPTY";
var StarXPath0 = "StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 = "StarXTerminator.lite.nonoise.11.pb";
var StarBPath = "EMPTY";
var StarBPath0 = "BlurXTerminator.4.mlpackage";
var StarBPath1 = "BlurXTerminator.4.pb";
var StarNPath = "EMPTY";
var StarNPath0 = "NoiseXTerminator.2.mlpackage";
var StarNPath03 = "NoiseXTerminator.3.mlpackage";
var StarNPath1 = "NoiseXTerminator.2.pb";
var StarNPath13 = "NoiseXTerminator.3.pb";
var StarMarsFirst = "MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond = "MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel = "MLDenoise_v5.xmlm";
var originalFilePathMLDenoisefin = "";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};
var InNovaEditorTitle = "🪐 InNova Photo Editor";

#ifndef INNOVA_EDITOR_EMBEDDED
#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#endif

function _0x628d89db09()
{
   if (!_0x4681b36cd8()) {
      _0xc7acb59813 = "";
      _0xce8ee91fbb = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Photo Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let _0x7b17512d63 = _0xe41e374b20();
   let complete = _0xbf217442e2(_0x7b17512d63);
   let signatureValid = complete && _0xa1483a8043(_0x7b17512d63);
   let _0x13e9f86dd7 = signatureValid && _0x5de34f4e10(_0x7b17512d63[String.fromCharCode(101,120,112,105,114,121)]);

   let refreshOutcome = {};
   if (signatureValid && _0xd10faedad3(_0x7b17512d63, _0x13e9f86dd7, refreshOutcome)) {
      _0x7b17512d63 = _0xecda1d7a41();
      complete = _0xbf217442e2(_0x7b17512d63);
      signatureValid = complete && _0xa1483a8043(_0x7b17512d63);
      _0x13e9f86dd7 = signatureValid && _0x5de34f4e10(_0x7b17512d63[String.fromCharCode(101,120,112,105,114,121)]);
   }

   if (signatureValid) _0x227e7c630a();
   let _0x6a02e17ad6 = _0xe0c31f124a();
   _0x13e9f86dd7 = signatureValid && _0x5de34f4e10(_0x7b17512d63[String.fromCharCode(101,120,112,105,114,121)]);
   let grace = signatureValid && _0x13e9f86dd7 && _0x9eb9db4d3a &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)] && InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)].status === "GRACE" &&
      _0xb7283dbf75(_0x7b17512d63[String.fromCharCode(101,120,112,105,114,121)]);

   if (signatureValid && refreshOutcome.status === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
       refreshOutcome.paidRenewalPending && !_0x9eb9db4d3a) {
      _0xc7acb59813 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
      _0xce8ee91fbb = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Photo Editor");
      return false;
   }

   if (signatureValid && _0x9eb9db4d3a && (!_0x13e9f86dd7 || grace)) {
      _0xc7acb59813 = _0x7b17512d63[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
      _0xce8ee91fbb = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         _0xed86563506("InNova Photo Editor", _0x7b17512d63, true);
      else
         console.noteln(String.fromCharCode(9989,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,108,105,99,101,110,115,101,32,97,99,116,105,118,97,116,101,100,46));
      return true;
   }

   if (!complete && !_0x6a02e17ad6 && IsProjectDateValid()) {
      _0xc7acb59813 = _0x5e809cc643().substr(0, 8);
      _0xce8ee91fbb = "PROJECT";
      console.noteln(String.fromCharCode(55358,56810,32,76,105,99,101,110,115,101,32,109,111,100,101,58,32,84,82,73,65,76));
      console.noteln(String.fromCharCode(55357,56517,32,84,114,105,97,108,32,116,105,109,101,32,114,101,109,97,105,110,105,110,103,58,32) + _0x03dc2cb43f() + " day(s).");
      return true;
   }

   _0xc7acb59813 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
   if (_0x13e9f86dd7 && !grace) {
      _0xce8ee91fbb = String.fromCharCode(69,88,80,73,82,69,68);
      _0xed86563506("InNova Photo Editor", _0x7b17512d63, false);
      return false;
   }
   if (signatureValid && !_0x9eb9db4d3a) {
      _0xce8ee91fbb = "DEVICE_REQUIRED";
      _0xf5790be582("InNova Photo Editor",
         String.fromCharCode(84,104,105,115,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,111,110,32,116,104,105,115,32,100,101,118,105,99,101,46));
      return false;
   }
   _0xce8ee91fbb = "EMPTY";
   if (_0x6a02e17ad6 || complete) {
      _0xf5790be582("InNova Photo Editor",
         String.fromCharCode(89,111,117,114,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,109,105,115,115,105,110,103,32,111,114,32,105,110,118,97,108,105,100,46,32,80,108,101,97,115,101,32,114,101,115,116,111,114,101,32,121,111,117,114,32,108,105,99,101,110,115,101,32,102,114,111,109,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,46),
         { [String.fromCharCode(109,105,115,115,105,110,103,76,105,99,101,110,115,101)]: true });
      return false;
   }
   new MessageBox(
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,116,114,105,97,108,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
         String.fromCharCode(80,108,101,97,115,101,32,111,112,101,110,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,114,111,99,101,115,115,111,114,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32) +
         String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32,116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
      "InNova Photo Editor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaEditorResetEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaEditorCloneWindow(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      sourceWindow.isColor !== undefined ? sourceWindow.isColor : true,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaEditorInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

function InNovaEditorRefreshIcon()
{
   let bitmap = new Bitmap(24, 24);
   bitmap.fill(0x00000000);

   let graphics = new Graphics(bitmap);
   graphics.antialiasing = true;
   graphics.pen = new Pen(0xff30343a, 2);

   let upperArc = [
      [4, 10], [5, 7], [7, 5], [10, 4], [14, 4], [18, 6]
   ];
   let lowerArc = [
      [20, 14], [19, 17], [17, 19], [14, 20], [10, 20], [6, 18]
   ];
   for (let i = 1; i < upperArc.length; ++i)
      graphics.drawLine(upperArc[i - 1][0], upperArc[i - 1][1],
         upperArc[i][0], upperArc[i][1]);
   for (let j = 1; j < lowerArc.length; ++j)
      graphics.drawLine(lowerArc[j - 1][0], lowerArc[j - 1][1],
         lowerArc[j][0], lowerArc[j][1]);

   graphics.drawLine(18, 6, 18, 2);
   graphics.drawLine(18, 6, 14, 7);
   graphics.drawLine(6, 18, 6, 22);
   graphics.drawLine(6, 18, 10, 17);
   graphics.end();

   return bitmap.scaled(2, 2, BitmapInterpolation_Bilinear);
}

function InNovaEditorCleanupEclipseIntermediates(finalWindow)
{
   if (!finalWindow || finalWindow.isNull || !finalWindow.mainView ||
       finalWindow.mainView.isNull)
      return 0;

   let finalId = finalWindow.mainView.id;
   let windows = ImageWindow.windows;
   let removed = 0;
   for (let i = windows.length - 1; i >= 0; --i) {
      let window = windows[i];
      if (!window || window.isNull || !window.mainView ||
          window.mainView.isNull)
         continue;
      let id = window.mainView.id;
      if (id === finalId)
         continue;


      let isAlignedCopy = /_EclipseAligned(?:_\d+)?$/.test(id);
      if (isAlignedCopy)
         continue;

      let isEclipseIntermediate =
         id.indexOf("InNovaEclipse_") === 0 ||
         id.indexOf("_EclipsePreFocusInNova") >= 0 ||
         id.indexOf("_EclipsePreFocusBlurX") >= 0 ||
         id.indexOf("_EclipseHDRSkyBalanced") >= 0;
      if (!isEclipseIntermediate)
         continue;

      try {
         window.forceClose();
         ++removed;
      }
      catch (closeError) {
         console.warningln("⚠️ Could not close eclipse intermediate " +
            id + ": " + closeError);
      }
   }

   finalWindow.show();
   finalWindow.bringToFront();
   console.noteln("🧹 Removed " + removed +
      " eclipse intermediate window(s). Originals and aligned copies were " +
      "preserved.");
   return removed;
}

function InNovaEditorCreateSmoothedLuminance(sourceWindow, sigma, baseId)
{
   let image = sourceWindow.mainView.image;
   let pixelMath = new PixelMath;
   pixelMath.expression = image.numberOfChannels >= 3 ?
      "0.2126*$T[0]+0.7152*$T[1]+0.0722*$T[2]" : "$T";
   pixelMath.expression1 = "";
   pixelMath.expression2 = "";
   pixelMath.expression3 = "";
   pixelMath.useSingleExpression = true;
   pixelMath.symbols = "";
   pixelMath.generateOutput = true;
   pixelMath.singleThreaded = false;
   pixelMath.use64BitWorkingImage = false;
   pixelMath.rescale = false;
   pixelMath.truncate = true;
   pixelMath.truncateLower = 0;
   pixelMath.truncateUpper = 1;
   pixelMath.createNewImage = true;
   pixelMath.showNewImage = false;
   pixelMath.newImageId = MiraUniqueWindowId(baseId);
   pixelMath.newImageWidth = 0;
   pixelMath.newImageHeight = 0;
   pixelMath.newImageAlpha = false;
   pixelMath.newImageColorSpace = PixelMath.Gray;
   pixelMath.newImageSampleFormat = PixelMath.f32;
   if (!pixelMath.executeOn(sourceWindow.mainView, false))
      throw new Error("Could not create the filament luminance map.");

   let luminance = ImageWindow.windowById(pixelMath.newImageId);
   if (!luminance || luminance.isNull)
      throw new Error("The filament luminance map was not created.");

   let convolution = new Convolution;
   convolution.mode = Convolution.Parametric;
   convolution.sigma = sigma;
   convolution.shape = 2.0;
   convolution.aspectRatio = 1.0;
   convolution.rotationAngle = 0.0;
   convolution.filterSource = "";
   convolution.rescaleHighPass = false;
   if (!convolution.executeOn(luminance.mainView, false)) {
      luminance.forceClose();
      throw new Error("Could not prepare the filament detail scale.");
   }
   luminance.hide();
   return luminance;
}

function InNovaEditorMeasureCoronaMaskRange(window, geometry, lowQuantile,
   highQuantile)
{
   let image = window.mainView.image;
   let step = Math.max(1, Math.floor(Math.max(image.width, image.height)/700));
   let samples = [];
   for (let y = Math.floor(step/2); y < image.height; y += step)
      for (let x = Math.floor(step/2); x < image.width; x += step) {
         let dx = x - geometry.centerX;
         let dy = y - geometry.centerY;
         let radial = Math.sqrt(dx*dx + dy*dy)/geometry.radius;
         if (radial <= 1.04)
            continue;
         let value = image.sample(x, y, 0);
         if (isFinite(value))
            samples.push(value);
      }
   if (samples.length < 100)
      throw new Error("Insufficient samples for the corona luminosity mask.");
   samples.sort(function(a, b) { return a - b; });
   let low = samples[Math.floor(lowQuantile*(samples.length - 1))];
   let high = samples[Math.floor(highQuantile*(samples.length - 1))];
   if (!(high > low + 0.00000001))
      high = low + 0.00000001;
   return { low: low, high: high };
}

function InNovaEditorCreateEclipseCoronaMask(sourceWindow, broadWindow,
   envelopeWindow, geometry)
{
   let maskWindow = null;
   try {
      let x = format("%.12g", geometry.centerX);
      let y = format("%.12g", geometry.centerY);
      let radius = format("%.12g", geometry.radius);
      let radial = "sqrt((x()-" + x + ")^2+(y()-" + y + ")^2)/" +
         radius;


      let broadRange = InNovaEditorMeasureCoronaMaskRange(broadWindow,
         geometry, 0.60, 0.95);


      let envelopeRange = InNovaEditorMeasureCoronaMaskRange(envelopeWindow,
         geometry, 0.48, 0.92);
      let signalT = "min(1,max(0,(" + broadWindow.mainView.id + "-" +
         format("%.15g", broadRange.low) + ")/" +
         format("%.15g", broadRange.high - broadRange.low) + "))";
      let signalGate = "((" + signalT + ")^2*(3-2*(" + signalT + ")))";


      let envelopeT = "min(1,max(0,(" + envelopeWindow.mainView.id + "-" +
         format("%.15g", envelopeRange.low) + ")/" +
         format("%.15g", envelopeRange.high - envelopeRange.low) + "))";
      let envelopeGate = "((" + envelopeT + ")^2*(3-2*(" +
         envelopeT + ")))";
      let combinedSignal = "((" + envelopeGate + ")*(0.45+0.55*(" +
         signalGate + ")))";


      let coronaT = "min(1,max(0,(" + combinedSignal + "-0.02)/0.62))";
      let coronaGate = "((" + coronaT + ")^2*(3-2*(" + coronaT + ")))";
      let discT = "min(1,max(0,(" + radial + "-1.005)/0.030))";
      let discGate = "((" + discT + ")^2*(3-2*(" + discT + ")))";

      let pixelMath = new PixelMath;
      pixelMath.expression = "(" + coronaGate + ")*(" + discGate + ")";
      pixelMath.expression1 = "";
      pixelMath.expression2 = "";
      pixelMath.expression3 = "";
      pixelMath.useSingleExpression = true;
      pixelMath.symbols = "";
      pixelMath.generateOutput = true;
      pixelMath.singleThreaded = false;
      pixelMath.use64BitWorkingImage = false;
      pixelMath.rescale = false;
      pixelMath.truncate = true;
      pixelMath.truncateLower = 0;
      pixelMath.truncateUpper = 1;
      pixelMath.createNewImage = true;
      pixelMath.showNewImage = false;
      pixelMath.newImageId = MiraUniqueWindowId(
         sourceWindow.mainView.id + "_CoronaMask");
      pixelMath.newImageWidth = 0;
      pixelMath.newImageHeight = 0;
      pixelMath.newImageAlpha = false;
      pixelMath.newImageColorSpace = PixelMath.Gray;
      pixelMath.newImageSampleFormat = PixelMath.f32;
      if (!pixelMath.executeOn(sourceWindow.mainView, false))
         throw new Error("Could not create the corona luminance mask.");

      maskWindow = ImageWindow.windowById(pixelMath.newImageId);
      if (!maskWindow || maskWindow.isNull)
         throw new Error("The corona luminance mask was not created.");

      let feather = new Convolution;
      feather.mode = Convolution.Parametric;
      feather.sigma = 5.0;
      feather.shape = 2.0;
      feather.aspectRatio = 1.0;
      feather.rotationAngle = 0.0;
      feather.filterSource = "";
      feather.rescaleHighPass = false;
      if (!feather.executeOn(maskWindow.mainView, false))
         throw new Error("Could not feather the corona luminance mask.");
      maskWindow.hide();
      console.noteln("🎭 Corona-only luminance mask prepared: " +
         maskWindow.mainView.id + " (broad " +
         format("%.6g", broadRange.low) + " to " +
         format("%.6g", broadRange.high) + ", envelope " +
         format("%.6g", envelopeRange.low) + " to " +
         format("%.6g", envelopeRange.high) + ").");
      return maskWindow;
   }
   catch (error) {
      if (maskWindow && !maskWindow.isNull)
         maskWindow.forceClose();
      throw error;
   }
}

function InNovaEditorClampedSample(image, x, y)
{
   let sx = Math.range(Math.round(x), 0, image.width - 1);
   let sy = Math.range(Math.round(y), 0, image.height - 1);
   return image.sample(sx, sy, 0);
}

function InNovaEditorRadialRidgeSample(image, x, y, geometry)
{
   let dx = x - geometry.centerX;
   let dy = y - geometry.centerY;
   let distance = Math.max(1, Math.sqrt(dx*dx + dy*dy));
   let ux = dx/distance;
   let uy = dy/distance;

   function ridgeAt(radialOffset)
   {
      let px = x + radialOffset*ux;
      let py = y + radialOffset*uy;
      let center = InNovaEditorClampedSample(image, px, py);
      let nearA = InNovaEditorClampedSample(image,
         px - 4*uy, py + 4*ux);
      let nearB = InNovaEditorClampedSample(image,
         px + 4*uy, py - 4*ux);
      let farA = InNovaEditorClampedSample(image,
         px - 9*uy, py + 9*ux);
      let farB = InNovaEditorClampedSample(image,
         px + 9*uy, py - 9*ux);
      return center - 0.35*(nearA + nearB) - 0.15*(farA + farB);
   }


   return 0.50*ridgeAt(0) + 0.25*ridgeAt(-6) + 0.25*ridgeAt(6);
}

function InNovaEditorMeasureFilamentRange(fineWindow, broadWindow,
   envelopeWindow, geometry)
{
   let fine = fineWindow.mainView.image;
   let broad = broadWindow.mainView.image;
   let envelope = envelopeWindow.mainView.image;
   let step = Math.max(1, Math.floor(
      Math.max(fine.width, fine.height)/750));
   let samples = [];
   for (let y = Math.floor(step/2); y < fine.height; y += step)
      for (let x = Math.floor(step/2); x < fine.width; x += step) {
         let dx = x - geometry.centerX;
         let dy = y - geometry.centerY;
         let radial = Math.sqrt(dx*dx + dy*dy)/geometry.radius;


         if (radial < 1.16 || radial > 4.6)
            continue;


         let detail = Math.abs(
            InNovaEditorRadialRidgeSample(fine, x, y, geometry)/
            Math.max(0.002, broad.sample(x, y, 0)));
         if (isFinite(detail))
            samples.push(detail);
      }

   if (samples.length < 100)
      throw new Error("Insufficient corona samples for filament detail.");
   samples.sort(function(a, b) { return a - b; });


   let low = samples[Math.floor(0.02*(samples.length - 1))];
   let high = samples[Math.floor(0.60*(samples.length - 1))];


   low = Math.max(0.00000001, low);
   if (!(high > low + 0.00000001))
      high = low + 0.00000001;
   return { low: low, high: high };
}

function InNovaEditorEnhanceEclipseFilaments(sourceWindow, geometry,
   strength, limbProtection, prepared)
{
   if (!sourceWindow || sourceWindow.isNull)
      throw new Error("The final InNova Photo Editor result is not available.");
   if (!geometry || !(geometry.radius > 0))
      throw new Error("The eclipse geometry is not available.");

   let fineWindow = null;
   let broadWindow = null;
   let envelopeWindow = null;
   let maskWindow = null;
   let output = null;
   let ownsPreparedMaps = prepared == null;
   try {
      let range;
      if ( prepared != null ) {
         fineWindow = prepared.fineWindow;
         broadWindow = prepared.broadWindow;
         envelopeWindow = prepared.envelopeWindow;
         maskWindow = prepared.maskWindow;
         range = prepared.range;
      } else {


         fineWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow, 2.8,
            "InNovaEclipse_FilamentFine");
         broadWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow, 18.0,
            "InNovaEclipse_FilamentBroad");
         envelopeWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow,
            80.0, "InNovaEclipse_FilamentEnvelope");
         maskWindow = InNovaEditorCreateEclipseCoronaMask(sourceWindow,
            broadWindow, envelopeWindow, geometry);
         range = InNovaEditorMeasureFilamentRange(fineWindow, broadWindow,
            envelopeWindow, geometry);
      }

      output = InNovaEditorCloneWindow(sourceWindow,
         MiraUniqueWindowId(sourceWindow.mainView.id + "_CoronaFilaments_" +
            Math.round(strength) + "pct_Limb" +
            Math.round(limbProtection) + "pct"));
      output.mainView.stf = sourceWindow.mainView.stf;

      let x = format("%.12g", geometry.centerX);
      let y = format("%.12g", geometry.centerY);
      let radius = format("%.12g", geometry.radius);


      let radial = "sqrt((x()-" + x + ")^2+(y()-" + y + ")^2)/" +
         radius;


      let hardT = "min(1,max(0,(" + radial + "-1.01)/0.025))";
      let hardGate = "((" + hardT + ")^2*(3-2*(" + hardT + ")))";
      let nearT = "min(1,max(0,(" + radial + "-1.03)/0.24))";
      let nearGate = "((" + nearT + ")^2*(3-2*(" + nearT + ")))";
      let protection = Math.range(limbProtection, 0, 100)/100;
      let innerGate = "(" + hardGate + "*(" +
         format("%.8g", 1-protection) + "+" +
         format("%.8g", protection) + "*(" + nearGate + ")))";
      let outerT = "min(1,max(0,(5.8-" + radial + ")/1.0))";
      let outerGate = "((" + outerT + ")^2*(3-2*(" + outerT + ")))";


      let pixelDistance = "sqrt((x()-" + x + ")^2+(y()-" + y + ")^2)";
      let unitX = "((x()-" + x + ")/max(1," + pixelDistance + "))";
      let unitY = "((y()-" + y + ")/max(1," + pixelDistance + "))";
      let fineId = fineWindow.mainView.id;
      function ridgePixel(radialOffset, tangentialOffset)
      {
         let px = "x()+round(" + radialOffset + "*(" + unitX + ")-" +
            tangentialOffset + "*(" + unitY + "))";
         let py = "y()+round(" + radialOffset + "*(" + unitY + ")+" +
            tangentialOffset + "*(" + unitX + "))";
         return "pixel(" + fineId + "," + px + "," + py + ")";
      }
      function ridgeAt(radialOffset)
      {
         return "((" + ridgePixel(radialOffset, 0) + ")-0.35*(" +
            ridgePixel(radialOffset, 4) + "+" +
            ridgePixel(radialOffset, -4) + ")-0.15*(" +
            ridgePixel(radialOffset, 9) + "+" +
            ridgePixel(radialOffset, -9) + "))";
      }
      let absoluteDetail = "(0.50*(" + ridgeAt(0) + ")+0.25*(" +
         ridgeAt(-6) + ")+0.25*(" + ridgeAt(6) + "))";
      let detail = "((" + absoluteDetail + ")/max(0.002," +
         broadWindow.mainView.id + "))";
      let magnitude = "abs(" + detail + ")";
      let selectT = "min(1,max(0,(" + magnitude + "-" +
         format("%.15g", range.low) + ")/" +
         format("%.15g", range.high - range.low) + "))";
      let selection = "((" + selectT + ")^2*(3-2*(" + selectT + ")))";


      let sourceId = sourceWindow.mainView.id;
      let sourceImage = sourceWindow.mainView.image;
      let rawLuminance = sourceImage.numberOfChannels >= 3 ?
         "(0.2126*" + sourceId + "[0]+0.7152*" + sourceId +
         "[1]+0.0722*" + sourceId + "[2])" : sourceId;


      let rawHighlight = sourceImage.numberOfChannels >= 3 ?
         "max(" + sourceId + "[0],max(" + sourceId + "[1]," +
         sourceId + "[2]))" : rawLuminance;
      let rawLowChannel = sourceImage.numberOfChannels >= 3 ?
         "min(" + sourceId + "[0],min(" + sourceId + "[1]," +
         sourceId + "[2]))" : rawLuminance;
      let rawChroma = "(" + rawHighlight + "-" + rawLowChannel + ")";


      let highlightT = "min(1,max(0,(0.72-" + rawHighlight + ")/0.16))";
      let highlightGate = "((" + highlightT + ")^2*(3-2*(" +
         highlightT + ")))";


      let chromaT = "min(1,max(0,(0.20-" + rawChroma + ")/0.14))";
      let chromaGate = "((" + chromaT + ")^2*(3-2*(" + chromaT + ")))";


      let gain = 12.0*Math.range(strength, 0, 100)/100;


      let shapedDetail = "iif(" + detail + "<0,0.65*(" + detail +
         "),3.50*(" + detail + "))";
      let limitedDetail = "max(-0.28,min(0.70," + shapedDetail + "))";
      let adjustment = "(" + rawLuminance + ")*" +
         format("%.8g", gain) + "*(" + limitedDetail + ")*(" +
         selection + ")*(" + innerGate + ")*(" + outerGate + ")*(" +
         highlightGate + ")*(" + chromaGate + ")";
      let targetLuminance = "min(0.98,max(0.000001,(" + rawLuminance +
         ")+(" + adjustment + ")))";
      let colourRatio = "((" + targetLuminance + ")/max(0.000001," +
         rawLuminance + "))";

      let pixelMath = new PixelMath;


      let maskId = maskWindow.mainView.id;


      let directionalSupport = "min(1,0.90*(" + selection + ")*(" +
         innerGate + ")*(" + outerGate + "))";
      let effectiveMask = "max(" + maskId + "," + directionalSupport + ")";
      pixelMath.expression = "$T*(1-(" + effectiveMask + "))+($T*(" +
         colourRatio + "))*(" + effectiveMask + ")";
      pixelMath.expression1 = "";
      pixelMath.expression2 = "";
      pixelMath.expression3 = "";
      pixelMath.useSingleExpression = true;
      pixelMath.symbols = "";
      pixelMath.generateOutput = true;
      pixelMath.singleThreaded = false;
      pixelMath.use64BitWorkingImage = true;
      pixelMath.rescale = false;
      pixelMath.truncate = true;
      pixelMath.truncateLower = 0;
      pixelMath.truncateUpper = 1;
      if (!pixelMath.executeOn(output.mainView, false))
         throw new Error("PixelMath could not enhance the corona filaments.");

      output.show();
      output.bringToFront();
      console.noteln("☀️ Neutral corona filament detail created: " +
         output.mainView.id + " (strength " + strength + "%, " +
         "limb protection " + limbProtection + "%, range " +
         format("%.6g", range.low) + " to " +
         format("%.6g", range.high) + ").");
      return output;
   }
   catch (error) {
      if (output && !output.isNull) {
         output.forceClose();
      }
      throw error;
   }
   finally {
      if (ownsPreparedMaps) {
         if (fineWindow && !fineWindow.isNull)
            fineWindow.forceClose();
         if (broadWindow && !broadWindow.isNull)
            broadWindow.forceClose();
         if (envelopeWindow && !envelopeWindow.isNull)
            envelopeWindow.forceClose();
         if (maskWindow && !maskWindow.isNull) {
            maskWindow.removeMaskReferences();
            maskWindow.forceClose();
         }
      }
   }
}

function InNovaEditorPrepareEclipseFilaments(sourceWindow, geometry)
{
   let fineWindow = null;
   let broadWindow = null;
   let envelopeWindow = null;
   let maskWindow = null;
   try {
      fineWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow, 2.8,
         "InNovaEclipse_FilamentFine");
      broadWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow, 18.0,
         "InNovaEclipse_FilamentBroad");
      envelopeWindow = InNovaEditorCreateSmoothedLuminance(sourceWindow,
         80.0, "InNovaEclipse_FilamentEnvelope");
      maskWindow = InNovaEditorCreateEclipseCoronaMask(sourceWindow,
         broadWindow, envelopeWindow, geometry);
      return {
         fineWindow: fineWindow,
         broadWindow: broadWindow,
         envelopeWindow: envelopeWindow,
         maskWindow: maskWindow,
         range: InNovaEditorMeasureFilamentRange(fineWindow, broadWindow,
            envelopeWindow, geometry)
      };
   }
   catch (error) {
      if (fineWindow && !fineWindow.isNull)
         fineWindow.forceClose();
      if (broadWindow && !broadWindow.isNull)
         broadWindow.forceClose();
      if (envelopeWindow && !envelopeWindow.isNull)
         envelopeWindow.forceClose();
      if (maskWindow && !maskWindow.isNull)
         maskWindow.forceClose();
      throw error;
   }
}

class InNovaEditorEclipseFilamentDialog extends Dialog
{
   constructor(sourceWindow, geometry, initialStrength,
      initialLimbProtection)
   {
      super();
      let dialog = this;
      this.sourceWindow = sourceWindow;
      this.geometry = geometry;
      this.candidateWindow = null;
      this.confirmed = false;
      this.prepared = InNovaEditorPrepareEclipseFilaments(sourceWindow,
         geometry);
      this.windowTitle = "InNova Eclipse · Corona filaments · " + ProjecTver;

      this.description = new Label(this);
      this.description.useRichText = true;
      this.description.text =
         "<b>Corona filament detail</b><br/>Every preview starts from the " +
         "untouched InNova Photo Editor result; adjustments never accumulate.";
      this.description.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;

      this.strengthLabel = new Label(this);
      this.strengthLabel.text = "Filament strength:";
      this.strengthLabel.textAlignment =
         TextAlign_Right | TextAlign_VertCenter;

      this.strength = new Slider(this);
      this.strength.setRange(0, 100);
      this.strength.tickInterval = 10;
      this.strength.pageStep = 5;
      this.strength.setScaledMinWidth(320);
      this.strength.value = Math.range(initialStrength, 0, 100);

      this.valueLabel = new Label(this);
      this.valueLabel.text = "Applied: " + this.strength.value + "%";
      this.valueLabel.textAlignment =
         TextAlign_Right | TextAlign_VertCenter;
      this.valueLabel.setScaledFixedWidth(95);

      this.limbLabel = new Label(this);
      this.limbLabel.text = "Limb protection:";
      this.limbLabel.textAlignment =
         TextAlign_Right | TextAlign_VertCenter;

      this.limbProtection = new Slider(this);
      this.limbProtection.setRange(0, 100);
      this.limbProtection.tickInterval = 10;
      this.limbProtection.pageStep = 5;
      this.limbProtection.setScaledMinWidth(320);
      this.limbProtection.value =
         Math.range(initialLimbProtection, 0, 100);

      this.limbValueLabel = new Label(this);
      this.limbValueLabel.text = "Applied: " +
         this.limbProtection.value + "%";
      this.limbValueLabel.textAlignment =
         TextAlign_Right | TextAlign_VertCenter;
      this.limbValueLabel.setScaledFixedWidth(95);


      this.previewTimer = new Timer(0.15, false, this);
      this.previewTimer.onTimeout = function() {
         dialog.applyCandidate();
      };
      this.strength.onValueUpdated = function(value) {
         dialog.valueLabel.text = "Selected: " + value + "%";
         dialog.previewTimer.stop();
         dialog.previewTimer.start();
      };
      this.strength.onMouseRelease = function() {
         dialog.previewTimer.stop();
         dialog.applyCandidate();
      };
      this.strength.onKeyRelease = function() {
         dialog.previewTimer.stop();
         dialog.applyCandidate();
      };
      this.limbProtection.onValueUpdated = function(value) {
         dialog.limbValueLabel.text = "Selected: " + value + "%";
         dialog.previewTimer.stop();
         dialog.previewTimer.start();
      };
      this.limbProtection.onMouseRelease = function() {
         dialog.previewTimer.stop();
         dialog.applyCandidate();
      };
      this.limbProtection.onKeyRelease = function() {
         dialog.previewTimer.stop();
         dialog.applyCandidate();
      };
      this.applyButton = new PushButton(this);
      this.applyButton.text = "Apply";
      this.applyButton.icon = this.scaledResource(":/icons/ok.png");
      this.applyButton.defaultButton = true;
      this.applyButton.onClick = function() {
         if (dialog.candidateWindow && !dialog.candidateWindow.isNull) {
            dialog.candidateWindow.show();
            dialog.candidateWindow.bringToFront();
         }
         dialog.confirmed = true;
         dialog.ok();
      };

      this.cancelButton = new PushButton(this);
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource(":/icons/cancel.png");
      this.cancelButton.onClick = function() {
         dialog.confirmed = false;
         dialog.cancel();
      };

      this.zoomOutButton = new PushButton(this);
      this.zoomOutButton.text = "Zoom −";
      this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
      this.zoomOutButton.setScaledMinWidth(90);
      this.zoomOutButton.onClick = function() {
         if (dialog.candidateWindow && !dialog.candidateWindow.isNull) {
            MiraZoomAdjustmentPreview(dialog.candidateWindow, false);
            dialog.bringToFront();
         }
      };

      this.fitButton = new PushButton(this);
      this.fitButton.text = "Fit";
      this.fitButton.icon =
         this.scaledResource(":/toolbar/view-zoom-fit.png");
      this.fitButton.setScaledMinWidth(80);
      this.fitButton.onClick = function() {
         if (dialog.candidateWindow && !dialog.candidateWindow.isNull) {
            dialog.candidateWindow.show();
            dialog.candidateWindow.bringToFront();
            dialog.candidateWindow.zoomToFit(true, false);
            dialog.bringToFront();
         }
      };

      this.zoomInButton = new PushButton(this);
      this.zoomInButton.text = "Zoom +";
      this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
      this.zoomInButton.setScaledMinWidth(90);
      this.zoomInButton.onClick = function() {
         if (dialog.candidateWindow && !dialog.candidateWindow.isNull) {
            if (MiraZoomAdjustmentPreview(dialog.candidateWindow, true))
               dialog.panButton.enabled = true;
            dialog.bringToFront();
         }
      };

      this.panButton = new PushButton(this);
      this.panButton.text = "Pan";
      this.panButton.icon = this.scaledResource(":/icons/move-center.png");
      this.panButton.setScaledMinWidth(80);
      this.panButton.enabled = false;
      this.panButton.onClick = function() {
         if (dialog.candidateWindow && !dialog.candidateWindow.isNull) {
            MiraOpenAdjustmentPan(dialog.candidateWindow);
            dialog.bringToFront();
         }
      };

      let controlSizer = new HorizontalSizer;
      controlSizer.addStretch();
      controlSizer.add(this.strengthLabel);
      controlSizer.addSpacing(5);
      controlSizer.add(this.strength, 100);
      controlSizer.addSpacing(8);
      controlSizer.add(this.valueLabel);
      controlSizer.addStretch();

      let limbSizer = new HorizontalSizer;
      limbSizer.addStretch();
      limbSizer.add(this.limbLabel);
      limbSizer.addSpacing(5);
      limbSizer.add(this.limbProtection, 100);
      limbSizer.addSpacing(8);
      limbSizer.add(this.limbValueLabel);
      limbSizer.addStretch();

      let buttonSizer = new HorizontalSizer;
      buttonSizer.addStretch();
      buttonSizer.add(this.applyButton);
      buttonSizer.addSpacing(8);
      buttonSizer.add(this.cancelButton);

      let navigationSizer = new HorizontalSizer;
      navigationSizer.spacing = 8;
      navigationSizer.addStretch();

      navigationSizer.add(this.zoomOutButton);
      navigationSizer.add(this.fitButton);
      navigationSizer.add(this.zoomInButton);
      navigationSizer.add(this.panButton);
      navigationSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add(this.description);
      this.sizer.add(controlSizer);
      this.sizer.add(limbSizer);
      this.sizer.add(navigationSizer);
      this.sizer.add(buttonSizer);
      this.adjustToContents();
   }

   applyCandidate()
   {
      this.enabled = false;
      processEvents();
      try {


         if (this.candidateWindow && !this.candidateWindow.isNull) {
            this.candidateWindow.forceClose();
            this.candidateWindow = null;
         }
         this.candidateWindow = InNovaEditorEnhanceEclipseFilaments(
            this.sourceWindow, this.geometry, this.strength.value,
            this.limbProtection.value, this.prepared);
         Settings.write(InNovaEditorEclipseCoronaStrengthSetting,
            DataType_Int32, this.strength.value);
         Settings.write(InNovaEditorEclipseLimbProtectionSetting,
            DataType_Int32, this.limbProtection.value);
         this.valueLabel.text = "Applied: " + this.strength.value + "%";
         this.limbValueLabel.text = "Applied: " +
            this.limbProtection.value + "%";
         this.panButton.enabled = true;
         return true;
      }
      catch (error) {
         this.sourceWindow.show();
         this.sourceWindow.bringToFront();
         new MessageBox(
            "Corona filament enhancement failed.\n\n" + error,
            "InNova Eclipse",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return false;
      }
      finally {
         this.enabled = true;
         this.bringToFront();
      }
   }

   closePreparedMaps()
   {
      this.previewTimer.stop();
      if (this.prepared != null) {
         if (this.prepared.fineWindow &&
             !this.prepared.fineWindow.isNull)
            this.prepared.fineWindow.forceClose();
         if (this.prepared.broadWindow &&
             !this.prepared.broadWindow.isNull)
            this.prepared.broadWindow.forceClose();
         if (this.prepared.envelopeWindow &&
             !this.prepared.envelopeWindow.isNull)
            this.prepared.envelopeWindow.forceClose();
         if (this.prepared.maskWindow &&
             !this.prepared.maskWindow.isNull) {
            this.prepared.maskWindow.removeMaskReferences();
            this.prepared.maskWindow.forceClose();
         }
         this.prepared = null;
      }
   }
}

function InNovaEditorRunEclipseFilamentTuner(sourceWindow, geometry,
   initialStrength, initialLimbProtection)
{
   let tuner = new InNovaEditorEclipseFilamentDialog(sourceWindow, geometry,
      initialStrength, initialLimbProtection);
   tuner.onShow = function() {
      MiraCenterDialog(this);
   };

   try {
      tuner.applyCandidate();
      tuner.execute();
      if (tuner.confirmed)
         return tuner.candidateWindow;
      if (tuner.candidateWindow && !tuner.candidateWindow.isNull) {
         tuner.candidateWindow.forceClose();
         tuner.candidateWindow = null;
      }
      sourceWindow.show();
      sourceWindow.bringToFront();
      return null;
   }
   finally {
      tuner.closePreparedMaps();
   }
}

function InNovaEditorFindExistingEclipseFinal()
{
   let active = ImageWindow.activeWindow;
   if (active && !active.isNull && active.mainView &&
       !active.mainView.isNull) {
      let activeId = active.mainView.id;
      let marker = activeId.indexOf("_CoronaFilaments");
      if (marker > 0) {
         let baseId = activeId.substring(0, marker);
         let baseWindow = ImageWindow.windowById(baseId);
         if (baseWindow && !baseWindow.isNull)
            return baseWindow;
      }
      if ((activeId.indexOf("_InNovaPhotoEditor") >= 0 ||
           activeId.indexOf("_InNovaEditor") >= 0) && marker < 0)
         return active;
   }

   let windows = ImageWindow.windows;
   for (let i = windows.length - 1; i >= 0; --i) {
      let window = windows[i];
      if (!window || window.isNull || !window.mainView ||
          window.mainView.isNull)
         continue;
      let id = window.mainView.id;
      if ((id.indexOf("_InNovaPhotoEditor") >= 0 ||
           id.indexOf("_InNovaEditor") >= 0) &&
          id.indexOf("_CoronaFilaments") < 0)
         return window;
   }
   return null;
}

function InNovaEditorCloseOldFilamentCandidates(sourceWindow)
{
   let prefix = sourceWindow.mainView.id + "_CoronaFilaments";
   let windows = ImageWindow.windows;
   for (let i = windows.length - 1; i >= 0; --i) {
      let window = windows[i];
      if (!window || window.isNull || !window.mainView ||
          window.mainView.isNull)
         continue;
      if (window.mainView.id.indexOf(prefix) === 0)
         try {
            window.forceClose();
         }
         catch (error) {
         }
   }
}

function InNovaEditorRunExistingFilamentCalibration()
{
   let sourceWindow = InNovaEditorFindExistingEclipseFinal();
   let geometryX = Settings.read(
      InNovaEditorEclipseGeometryXSetting, DataType_Double);
   let geometryXOK = Settings.lastReadOK;
   let geometryY = Settings.read(
      InNovaEditorEclipseGeometryYSetting, DataType_Double);
   let geometryYOK = Settings.lastReadOK;
   let geometryRadius = Settings.read(
      InNovaEditorEclipseGeometryRadiusSetting, DataType_Double);
   let geometryRadiusOK = Settings.lastReadOK;


   let strength = 50;
   let limbProtection = 100;

   if (!sourceWindow || sourceWindow.isNull || !geometryXOK ||
       !geometryYOK || !geometryRadiusOK || !(geometryRadius > 0)) {
      new MessageBox(
         "The existing clean InNova Photo Editor eclipse result or its measured " +
         "lunar geometry was not found. Keep the _InNovaPhotoEditor image open " +
         "and run the normal eclipse workflow once.",
         "InNova Eclipse · Corona filaments",
         StdIcon_Warning,
         StdButton_Ok
      ).execute();
      return false;
   }

   InNovaEditorCloseOldFilamentCandidates(sourceWindow);
   sourceWindow.show();
   sourceWindow.bringToFront();
   InNovaEditorRunEclipseFilamentTuner(sourceWindow, {
      centerX: geometryX,
      centerY: geometryY,
      radius: geometryRadius
   }, Math.range(strength, 0, 100),
      Math.range(limbProtection, 0, 100));
   return true;
}

class InNovaEditorDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "🪐 InNova Photo Editor";

   let header = new Control(dialog);
   let artworkRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/assets/headers/";
   let background = File.exists(artworkRoot + "guided.png") ? new Bitmap(artworkRoot + "guided.png") : null;
   header.onPaint = function() {
      let g = new Graphics(this);
      g.fillRect(0, 0, this.width, this.height, new Brush(0xffe5f2ff));
      if (background && !background.isNull)
         g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), background);
      g.pen = new Pen(0xff237aca, this.logicalPixelsToPhysical(1));
      g.drawRect(0, 0, this.width-1, this.height-1);
      g.end();
   };
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   let icon = new Control(header);
   icon.setScaledFixedSize(68, 68);
   let artwork = File.exists(artworkRoot + "photo-editor.png") ? new Bitmap(artworkRoot + "photo-editor.png") : null;
   icon.onPaint = function() {
      if (!artwork || artwork.isNull) return;
      let g = new Graphics(this);
      g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), artwork);
      g.end();
   };
   header.sizer.add(icon);
   let text = new VerticalSizer;
   text.spacing = 5;
   text.addStretch();
   function headerLabel(value, size) {
      let label = new Label(header);
      label.useRichText = true;
      label.wordWrapping = true;
      label.text = value;
      label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      label.styleSheet = "font-size:" + size + "pt;color:#102b50;background:transparent;";
      text.add(label);
   }
   headerLabel("<b>InNova Photo Editor</b>", 20);
   headerLabel("Select an open color image.", 12);
   headerLabel("Preserves the original and creates a new edited result.", 12);
   text.addStretch();
   header.sizer.add(text, 100);

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(90);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.openButton = new ToolButton(this);
      this.openButton.icon =
         this.scaledResource(":/icons/folder-open.png");
      this.openButton.toolTip = "Open an image file";
      this.openButton.setScaledFixedSize(28, 28);
      this.openButton.onClick = function () {
         dialog.openImageFile();
      };

      this.refreshButton = new ToolButton(this);
      this.refreshButton.icon = InNovaEditorRefreshIcon();
      this.refreshButton.toolTip =
         "Refresh the list of open PixInsight images";
      this.refreshButton.setScaledFixedSize(28, 28);
      this.refreshButton.onClick = function () {
         dialog.populateImages();
      };

      this.runButton = new PushButton(this);
      this.runButton.text = "Run InNova Photo Editor";
      this.runButton.icon =
         this.scaledResource(":/icons/power.png");
      this.runButton.onClick = function () {
         dialog.runEditor();
      };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon =
         this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function () {
         dialog.cancel();
      };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.openButton);
      imageRow.add(this.refreshButton);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add(header);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   openImageFile()
   {
      let chooser = new OpenFileDialog;
      chooser.caption = "Open an image for InNova Photo Editor";
      chooser.filters = [
         ["Supported image files",
          "*.xisf *.fits *.fit *.fts *.tif *.tiff *.png *.jpg *.jpeg"],
         ["All files", "*"]
      ];
      if (!chooser.execute())
         return;

      try {
         let opened = ImageWindow.open(chooser.fileName);
         let selectedId = "";
         for (let i = 0; i < opened.length; ++i) {
            opened[i].show();
            if (selectedId.length === 0 && opened[i].mainView.image &&
                opened[i].mainView.image.numberOfChannels >= 3)
               selectedId = opened[i].mainView.id;
         }
         this.populateImages();
         for (let item = 1; item < this.sourceCombo.numberOfItems; ++item)
            if (this.sourceCombo.itemText(item) === selectedId) {
               this.sourceCombo.currentItem = item;
               break;
            }
         if (selectedId.length === 0)
            new MessageBox(
               "The selected file does not contain an RGB color image.",
               "InNova Photo Editor",
               StdIcon_Warning,
               StdButton_Ok
            ).execute();
      }
      catch (error) {
         new MessageBox(
            "The selected image could not be opened.\n\n" +
            (error.message || error),
            "InNova Photo Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
      }
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;

      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image ||
             window.mainView.image.numberOfChannels < 3)
            continue;

         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }

      this.sourceCombo.currentItem = selectedIndex;
   }

   runEditor()
   {
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Photo Editor",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return null;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView ||
          source.mainView.isNull) {
         this.populateImages();
         return null;
      }

      let projectType = InNovaEditorInferProjectType(sourceId);
      let outputId = MiraUniqueWindowId(sourceId + "_InNovaPhotoEditor");
      let output = InNovaEditorCloneWindow(source, outputId);

      InNovaEditorResetEditorState();
      ProjecTypevar = projectType;
      ProjecTypevarRec = projectType;

      MiraConsoleSection("🪐 InNova Photo Editor editing: " + sourceId);

      let editorResult;
      let selectorPosition = MiraParkIntegratorForAdaptiveStretch(this);
      try {
         editorResult = InNovaEditorRunProEditor(
            output.mainView, projectType);
      }
      catch (error) {
         output.forceClose();
         new MessageBox(
            "InNova Photo Editor could not prepare the selected image.\n\n" +
            (error.message || error) + "\n\n" +
            "Review the Process Console for details.",
            "InNova Photo Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return null;
      }
      finally {
         MiraRestoreIntegratorAfterAdaptiveStretch(this, selectorPosition);
      }

      if (!editorResult.accepted) {
         output.forceClose();
         if (editorResult.openRequested) {
            console.noteln(
               "🪐 InNova Photo Editor returned to the image selector.");
            this.populateImages();
            this.sourceCombo.currentItem = 0;
            return null;
         }
         if (editorResult.cancelled) {
            console.noteln("🪐 InNova Photo Editor editing cancelled.");
            return null;
         }
         new MessageBox(
            "InNova Photo Editor could not prepare the selected image.\n\n" +
            "Review the Process Console for details.",
            "InNova Photo Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return null;
      }

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Photo Editor result created: " + outputId);
      console.noteln("✅ Process finished.");
      MiraConsoleSectionEnd();
      this.populateImages();
      console.hide();
      return output;
   }
}

#ifndef INNOVA_EDITOR_EMBEDDED
console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Photo Editor") &&
    _0x628d89db09()) {


   InitializeInNovaProviderPaths();
   originalFilePathMLDenoisefin =
      GetInNovaDataFilePath(StarMLDenoiseModel);
   Settings.write("originalFilePathMLDenoisefin", DataType_String,
                  originalFilePathMLDenoisefin);

   let dialog = new InNovaEditorDialog;
   dialog.onShow = function () {
      MiraCenterDialog(this);
   };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   let pendingSourceId = Settings.read(
      InNovaEditorPendingSourceSetting, DataType_String );
   if ( !Settings.lastReadOK || pendingSourceId == null )
      pendingSourceId = "";
   pendingSourceId = String( pendingSourceId );
   let cleanupEclipseIntermediates = Settings.read(
      InNovaEditorEclipseCleanupSetting, DataType_Boolean );
   if ( !Settings.lastReadOK )
      cleanupEclipseIntermediates = false;


   Settings.write( InNovaEditorPendingSourceSetting, DataType_String, "" );
   Settings.write( InNovaEditorEclipseCleanupSetting, DataType_Boolean,
      false );

   let filamentCalibrationMode = Settings.read(
      InNovaEditorEclipseFilamentCalibrationSetting, DataType_Boolean );
   if ( !Settings.lastReadOK )
      filamentCalibrationMode = false;
   Settings.write( InNovaEditorEclipseFilamentCalibrationSetting,
      DataType_Boolean, false );

   if ( filamentCalibrationMode ) {
      InNovaEditorRunExistingFilamentCalibration();
   } else {
      let pendingSourceIndex = -1;
      if ( pendingSourceId.length > 0 )
         for ( let i = 1; i < dialog.sourceCombo.numberOfItems; ++i )
            if ( dialog.sourceCombo.itemText( i ) == pendingSourceId ) {
               pendingSourceIndex = i;
               break;
            }

      if ( pendingSourceIndex > 0 ) {
         dialog.sourceCombo.currentItem = pendingSourceIndex;
         let finalEclipseWindow = dialog.runEditor();
         if ( cleanupEclipseIntermediates && finalEclipseWindow != null &&
              !finalEclipseWindow.isNull ) {
            InNovaEditorCleanupEclipseIntermediates( finalEclipseWindow );
            let geometryX = Settings.read(
               InNovaEditorEclipseGeometryXSetting, DataType_Double );
            let geometryXOK = Settings.lastReadOK;
            let geometryY = Settings.read(
               InNovaEditorEclipseGeometryYSetting, DataType_Double );
            let geometryYOK = Settings.lastReadOK;
            let geometryRadius = Settings.read(
               InNovaEditorEclipseGeometryRadiusSetting, DataType_Double );
            let geometryRadiusOK = Settings.lastReadOK;
            let coronaStrength = 50;
            let limbProtection = 100;
            if ( geometryXOK && geometryYOK && geometryRadiusOK &&
                 geometryRadius > 0 )
               try {


                  InNovaEditorRunEclipseFilamentTuner(finalEclipseWindow, {
                     centerX: geometryX,
                     centerY: geometryY,
                     radius: geometryRadius
                  }, Math.range(coronaStrength, 0, 100),
                     Math.range(limbProtection, 0, 100));
               }
               catch (filamentError) {
                  finalEclipseWindow.show();
                  finalEclipseWindow.bringToFront();
                  console.warningln(
                     "⚠️ Corona filament test was skipped: " +
                     filamentError);
               }
         }
      } else
         dialog.execute();
   }
}

#endif
#endif
