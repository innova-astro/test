InNova Black — shared astronomical header

Generated with the built-in image generation tool on 2026-09-29.
Master: innova-black-header.png
SHA-256: dd52f0027cad53e0edd8abde3cedf06a15217e3206d878f6fd5fc69bce905a55

Release packaging: include this PNG and its identical copies in Start assets/backgrounds and CropAssets/backgrounds, together with the updated JS helpers. Do not replace it with the old guided.png. File paths are relative to the bundled scripts; no user Desktop path is used at runtime.

Design prompt (revision 3, built-in image generation): Match selected option B / Cian equilibrado. Moderately desaturated dark blue-cyan with pale cyan stars and four-point diffraction spikes. Preserve a calm middle-left area for live text. No text, logo, icons or UI baked into the asset. Keep prominent stars in the central horizontal band for shallow header cropping.

Current treatment: Fondo atenuado (option A). Shared InNovaPaintBlackHeader paints a 60% dark navy #061726 overlay over the bitmap only. Include the matching InNovaEditorTheme.js in the RELEASE; text and icons remain undimmed.
