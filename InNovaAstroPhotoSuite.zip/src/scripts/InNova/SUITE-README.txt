INNOVA ASTRO PHOTO SUITE — PJSR-ONLY OBFUSCATED RELEASE CANDIDATE
==============================================

System requirement
------------------

PixInsight 1.9.4 or later with the V8 JavaScript engine is required. Earlier
versions display a bilingual update notice and do not start the Suite.

Current applications
--------------------

1. InNova01.js — InNova Astro Processor v.1.0.build.0416
   Integration and astrophotography processing workflow.
   InNova Adaptive Stretch pauses at the linear-to-nonlinear transition and
   previews independent Highlight protection and Shadow protection controls
   before
   the irreversible stretch is accepted. Zero Highlight protection reproduces
   the historical automatic curve, while higher values progressively protect
   bright galaxy and nebula cores before final editing.
   The Group 5 option "Open InNova Photo Editor when finished" closes the
   Integrator after a successful run and opens the Editor on a preserved
   copy of the final image.
   ImageSolver includes automatic recovery for metadata-free SEESTAR and
   Vespera files and extreme wide-field/fisheye images. Catalog identifiers
   found in FITS keywords, window names or source folders are resolved
   automatically; the
   assisted ImageSolver dialog is reserved for the final fallback.
   If any selected image has no astrometric solution, ImageSolver is enabled
   and executed automatically during the same run; no checkbox change or
   second launch is required.
   Group 4 starts in Stars mode. Moon / Sun provides a separate single-image
   OSC workflow that skips ImageSolver, MGC/SFC, star removal, final-star
   creation and star refinement while retaining normal gradient correction.
   A one-channel lunar or solar FITS with BAYERPAT metadata is reconstructed
   with PixInsight VNG Debayer before normal processing. A genuine monochrome
   source without Bayer metadata is expanded to neutral RGB only when required
   by the final colour container.
   Open project images are arranged from the upper-left edge so restored large
   windows remain inside the visible PixInsight workspace.
   A failed ImageSolver run in Stars mode recommends Moon / Sun for lunar or
   solar data. Integrator continues when astrometry is optional, or stops and
   removes solver-created windows when an enabled operation requires it.
   Targets read from astronomical metadata are trusted automatically. A target
   inferred only from a file or folder name is identified as low confidence
   and must be confirmed before automatic solving. Corrected ImageSolver
   coordinates are reused for other images in the same source folder during
   the current script session.
   Startup diagnostics check local Gaia astrometry and Gaia DR3/SP databases
   independently. ImageSolver can use its online catalog fallback when local
   astrometry is unavailable; MGC remains protected until Gaia DR3/SP is ready.

2. InNova02.js — InNova Photo Editor v.1.0.build.0207
   Independent final-image editor. It preserves the selected source image
   and creates a new result with the suffix "_InNovaPhotoEditor".
   When launched from InNova Astro Processor, the source image and exact project
   type are transferred automatically. In standalone mode, Auto detection
   remains available.

3. InNova03.js — 💫 InNova Adaptive Stretch v.1.0.build.0082
   Independent progressive stretch application for any open color image.
   It offers Advanced Adaptive protection and a Basic mode that reproduces
   the stable STF/HistogramTransformation stretch from the published release,
   plus an endpoint-preserving Stretch Boost for revealing faint detail,
   plus independent Red, Green and Blue midtones controls for removing color
   casts while the preview histogram updates,
   applies the accepted result in place, and leaves the image unchanged on
   Cancel.

4. InNovaStart.js — InNova Start v.0.1.build.0080
   Guided workflow, image preparation and direct access to the Suite modules.

PixInsight menu and installation folder
----------------------------------------

All four applications are registered under:

Script > InNova Astro Photo Suite

Install the InNova and InNova Start folders together as sibling script
folders. InNova Start uses the shared InNova engines and resources through
this relative installation layout.

No InNova native executables are included or invoked for license verification.
The same PJSR code is used on macOS, Windows and Linux. No Keychain prompt,
DPAPI component, secret-tool or Visual C++ Redistributable is needed for it.
Paid activation requires the matching innovaAccountLicense Wix endpoint.

Shared license and application data
-----------------------------------

InNova Astro Processor, InNova Photo Editor and InNova Adaptive Stretch use the same
trial, machine ID and license.dat. InNova Start is free and reads the same
Suite status without creating a separate trial or license identity. New application data is stored in:

Documents/InNova

The shared 60-day civil trial starts when any Suite application is launched
for the first time. All paid applications use the same start and exclusive end date. The embedded release date is only the earliest accepted first launch.

First license import remains in InNova Astro Processor. Check License Status is
informational only: it cannot renew, authorize, save a lease or change credentials.
Each paid period requires authorization by the purchasing Wix member account.
Open InNova, copy the linking code from the License tab, confirm it on the website,
then close and reopen InNova online. The website action does not charge the user.
A new random credential is pre-issued to that installation in PixInsight Settings;
only its hash is stored in Wix. It grants no access before member authorization.
All clients must use the matching v2 backend; previous clients are rejected.
Wix signs the credential hash, server time, expiry and maximum 48-hour lease.
Daily successful checks reuse the current credential within the paid period.
A new expiry requires a new authorization; old credentials cannot retrieve it.
Explicit refusals block paid access. Offline leases expire within 48 hours and
never extend beyond the authorized period's expiry + 48 hours.
Requests expire after 30 minutes; reopen InNova to request a new code.
One approval per license/expiry; repeat approval of the same code is idempotent.
A lost approved credential requires support, not re-registration from license.dat.
Copying a complete matching user profile (including the NEW credential), sharing
the purchasing account, patching PJSR or restoring clocks/state remain limitations.
Trial data and existing license files are not reset by updating this build.
The shared 60-day trial is only available without a previously verified paid
license on this installation. Paid licenses never fall back to the trial.
Paid history is retained in PixInsight Settings (InNovaPaidHistoryV1) and
Documents/InNova/paid_history.dat; deleting only license.dat does not reset it.
This local history cannot identify a previous buyer on a completely wiped or
different computer before the account/license is supplied.
Authorized paid expiry grants a fixed 48-hour grace period, with English
console and dialog renewal warnings; processing is blocked after grace.
Offline access still requires an unexpired signed lease and may end earlier.

Current editor capabilities
---------------------------

- internal cached preview with fit and zoom;
- RGB histogram, logarithmic display and clipping warnings;
- collapsible editing and mask modules;
- active module headers shown in bold blue;
- InNova Background Correction before denoising, luminance enhancement and
  sharpen;
- independent global, subject and background adjustments;
- cumulative Subject and Background strengths in H-alpha Blend and Dark
  Structure Enhance;
- luminosity masks and cumulative color-range profiles;
- hue, saturation and luminance editing for selected colors;
- cached Before/After, mask and regional previews;
- adjustable Subject/Background expansion and edge feather;
- debounced nonblocking slider workflow;
- bounded Detailed preview with selective per-stage caches;
- native full-resolution processing reserved for Apply;
- independent star-presence and star-brightness reduction controls;
- independent elapsed-time clock for every processing module;
- custom color-gradient and tonal slider controls;
- visual Color Picker eyedropper control;
- standalone initialization and validation of third-party AI model paths;
- full-resolution processing after Apply.

Brand assets
------------

- InNovaIcon.svg: PixInsight script icon.
- InNova_Icon.ico: reserved for a future installer; not distributed in this
  PixInsight script release.

Release-candidate date: 2026-09-06. Existing trial and license data is preserved.
This candidate is not signed or published. PixInsight CodeSign is required before
repository distribution. No ZIP or updates.xri is generated from this folder.

Website: https://www.teoriadelcolor.es/innovaastrophotosuite
