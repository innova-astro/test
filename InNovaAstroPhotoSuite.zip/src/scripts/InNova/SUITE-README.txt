2026-11-25 — FREE ACCESS UPDATE / ACCESO GRATUITO
Toda la suite gratis hasta el 30 de abril de 2027 inclusive (Europe/Madrid).
No requiere activación ni conexión para la licencia. Compras mensual/anual
bloqueadas con aviso. Licencias existentes preservadas. START build 0356.
La migración al Club del Fotógrafo sigue pendiente; la web antigua de licencias
no se consulta. Este candidato aún no está firmado ni publicado.

INNOVA ASTRO PHOTO SUITE 1.19 — DEVELOPMENT CANDIDATE
2026-11-25
Modules: Astro Processor, Photo Editor, Smart Stretch, START, Multi-Night,
Subframe Review and Integration, Review and Crop, Image Information.
Install the three sibling folders InNova, InNova Start and
InNova Image Information together. Start from ABRIR_INNOVA.js in development.
Read CONNECTIONS-AND-STORAGE.txt in this directory before use for network
connections, license data, external programs, file locations and migration.
PCL-LICENSE.txt covers the included upstream ImageSolver and AnnotateImage code.
Photo Editor retains its native InNova background correction.
This candidate must be signed and validated before public distribution.
