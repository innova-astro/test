#feature-id InNovaInformation : InNova Astro Photo Suite > InNova Image Information
#feature-icon ../InNova/InNovaIcon.svg
#feature-info Read-only image, acquisition and astrometric information.
#engine v8
var InNovaInformationStandaloneSession = true;
#define INNOVA_START_PUBLIC_WRAPPER
#define INNOVA_START_NATIVE_TEST
#include "../InNova Start/InNovaStart.js"
function InNovaInformationMain() {
   try {
      if(!MiraRequireCompatiblePixInsight("InNova Image Information"))return;
      _0x76b548f683();
      if(!_0x8fd8025167("InNova Image Information"))return;
      console.hide();
      let id=InNovaChooseWorkspaceSource("InNova Image Information",InNovaInformationIconPath,false,InNovaInformationLoadFile);
      if(id)InNovaShowInformation(ImageWindow.windowById(id),true);
   } finally {
      InNovaInformationConsoleMessage("👽 Exiting InNova Image Information.");
   }
}

#iflt __PI_VERSION__ 01.09.04
#else
InNovaDiagnosticRun("InNova Image Information",InNovaInformationMain);
#endif
