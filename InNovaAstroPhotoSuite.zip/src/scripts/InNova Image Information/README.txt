InNova Image Information — v1.19.build 0017

Abrir InNovaInformation.js en PixInsight o usar el icono tras Link Channels en Review & Crop.

Texto de 14 puntos, ventana más ancha, información de la imagen, FITS/HISTORY, XISF y pestaña Imagen anotada.
La pestaña Imagen anotada requiere PixInsight 1.9.5+, AnnotateImage instalado y una solución astrométrica. Genera el dibujo al abrir la pestaña y permite zoom, Fit y 1:1. No modifica la imagen fuente.

assets/: icono proporcionado por el usuario.
lib/: informe y adaptador al motor instalado de AnnotateImage.
Tests/ y Validation/: pruebas y resultados.
Dependencias compartidas: InNova y InNova Start, dentro de esta misma suite.

Calcular solución astrométrica abre ImageSolver y actualiza el informe y la anotación al volver. Añade la solución a la imagen abierta; no guarda el archivo automáticamente.
